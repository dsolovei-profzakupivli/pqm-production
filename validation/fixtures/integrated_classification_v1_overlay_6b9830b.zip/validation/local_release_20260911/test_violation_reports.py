import json
import io
import tempfile
import threading
import time
import unittest
from pathlib import Path
from datetime import datetime, timedelta, timezone
from types import SimpleNamespace
from unittest.mock import patch

import server
import violation_protocol_summary
from declension import DeclensionResult
from violation_text import normalize_justification_text


def organization(code):
    return {"identifier": {"id": code}, "name": code}


def report_payload(decisions=None):
    return {
        "id": "report-internal", "violationReportID": "UA-D-TEST", "status": "pending",
        "datePublished": "2026-08-18T10:00:00+03:00", "dateModified": "2026-08-18T10:00:00+03:00",
        "defendantPeriod": {"endDate": "2026-08-21T18:00:00+03:00"},
        "tender_id": "tender-id", "author": organization("11111111"),
        "defendants": [organization("22222222")], "authority": organization("40996564"),
        "details": {"reason": "contractBreach", "documents": [
            {"id": "customer-doc", "title": "Доказ.docx", "url": "https://example.test/customer"}
        ]},
        "defendantStatements": [{"id": "statement", "description": "Пояснення", "documents": [
            {"id": "supplier-doc", "title": "Пояснення.pdf", "url": "https://example.test/supplier"}
        ]}],
        "decisions": decisions or [],
    }


class ViolationReportTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(ignore_cleanup_errors=True)
        self.old_db = server.DB_PATH
        server.DB_PATH = Path(self.temp.name) / "test.sqlite3"
        server.init_db()
        with patch.object(server, "_resolve_violation_tender", return_value=("UA-TEST", "")):
            server.save_violation_report(report_payload())

    def tearDown(self):
        server.DB_PATH = self.old_db
        self.temp.cleanup()

    def _scenario_cache_fixture(self, internal_id="scenario-cache-report", status="pending",
                                reason="contractBreach"):
        payload = report_payload()
        payload.update({"id": internal_id, "violationReportID": "UA-D-2026-10-26-000001",
                        "status": status})
        payload["details"]["reason"] = reason
        with patch.object(server, "_resolve_violation_tender", return_value=("UA-TEST", "")):
            server.save_violation_report(payload)
        with server.db() as con:
            row = dict(con.execute("SELECT * FROM violation_reports WHERE id=?", (internal_id,)).fetchone())
        row["defendant_statements"] = json.loads(row["raw_json"]).get("defendantStatements") or []
        return row

    def _scenario_cache_context(self, *, modified=None, observed=None,
                                rejection_present=True, expired=True, security=True):
        observed = observed or time.time_ns()
        modified = modified or (datetime.now(timezone.utc) - timedelta(minutes=1)).isoformat()
        return {
            "rejection_ambiguous": False,
            "rejected_before_deadline": False,
            "rejection_present": rejection_present,
            "contract_deadline_expired": expired,
            "performance_security_required": security,
            "day_5_shifted": False,
            "_scenario_context_metadata": {
                "source_updated_at": modified,
                "observed_at_ns": observed,
            },
        }

    def test_scenario_context_snapshot_first_card_capture_then_local_list_reuses_same_summary(self):
        report = self._scenario_cache_fixture()
        context = self._scenario_cache_context()
        resolver_calls = []

        def resolved(_report, _review=None, *, prefer_snapshot=True):
            resolver_calls.append(prefer_snapshot)
            return context, "case_scoped_resolver"

        with patch.object(server, "resolve_violation_procurement_context", side_effect=resolved), \
             patch.object(server, "api_get", side_effect=AssertionError("test must not add a second request")), \
             patch.object(violation_protocol_summary, "present", return_value=None):
            card = server.violation_report_detail(report["id"], refresh=False)
        self.assertEqual(resolver_calls, [True], "card's already-resolved context is reused for the scenario cache")
        self.assertTrue(card["scenario_summary"])
        self.assertNotIn("_scenario_context_metadata", card["factual_procurement_context"])
        with server.db() as con:
            stored = dict(con.execute("SELECT * FROM violation_scenario_context_snapshots WHERE report_id=?",
                                      (report["id"],)).fetchone())
            decision_snapshot_count = con.execute(
                "SELECT COUNT(*) FROM violation_report_review_events WHERE report_id=? "
                "AND event_type='decision_context_snapshotted'", (report["id"],)).fetchone()[0]
        self.assertEqual(json.loads(stored["context_json"]), {
            "contract_deadline_expired": True, "day_5_shifted": False,
            "performance_security_required": True, "rejected_before_deadline": False,
            "rejection_ambiguous": False, "rejection_present": True})
        self.assertEqual(decision_snapshot_count, 0, "scenario cache is separate from decision snapshots")
        before = tuple(stored[key] for key in ("context_hash", "captured_at", "observed_at_ns"))
        with patch.object(server, "resolve_violation_procurement_context", side_effect=resolved), \
             patch.object(server, "api_get", side_effect=AssertionError("reopening reuses the same resolved context")), \
             patch.object(violation_protocol_summary, "present", return_value=None):
            reopened = server.violation_report_detail(report["id"], refresh=False)
        self.assertEqual(reopened["scenario_summary"], card["scenario_summary"])
        with server.db() as con:
            reopened_row = con.execute("SELECT context_hash,captured_at,observed_at_ns "
                                       "FROM violation_scenario_context_snapshots WHERE report_id=?",
                                       (report["id"],)).fetchone()
        self.assertEqual(tuple(reopened_row), before, "reopening unchanged context does not write")
        with patch.object(server, "api_get", side_effect=AssertionError("list may not contact Prozorro")), \
             patch.object(server, "save_violation_report_with_retry",
                          side_effect=AssertionError("list must not write reports")), \
             patch.object(violation_protocol_summary, "present", return_value=None):
            result = server.list_violation_reports({"page": ["1"], "size": ["100"]})
        listed = next(item for item in result["items"] if item["id"] == report["id"])
        self.assertEqual(listed["scenario_summary"], card["scenario_summary"])
        with server.db() as con:
            after = con.execute("SELECT context_hash,captured_at,observed_at_ns "
                                 "FROM violation_scenario_context_snapshots WHERE report_id=?",
                                 (report["id"],)).fetchone()
        self.assertEqual(tuple(after), before, "list projection is read-only")

    def test_scenario_context_snapshot_updates_changed_facts_and_rejects_older_source(self):
        report = self._scenario_cache_fixture()
        review = {}
        newer_time = time.time_ns()
        newer = self._scenario_cache_context(
            modified=(datetime.now(timezone.utc) - timedelta(minutes=1)).isoformat(), observed=newer_time,
                                             rejection_present=False, expired=False, security=False)
        saved_new = server._save_violation_scenario_context_snapshot(report, review, newer)
        self.assertFalse(saved_new["rejection_present"])
        old = self._scenario_cache_context(
                                           modified=(datetime.now(timezone.utc) - timedelta(minutes=2)).isoformat(),
                                           observed=newer_time - 5_000_000_000,
                                           rejection_present=True, expired=True, security=True)
        retained = server._save_violation_scenario_context_snapshot(report, review, old)
        self.assertEqual(retained, saved_new, "older source version cannot replace newer context")
        with server.db() as con:
            current = dict(con.execute("SELECT * FROM violation_scenario_context_snapshots WHERE report_id=?",
                                       (report["id"],)).fetchone())
        self.assertEqual(json.loads(current["context_json"])["rejection_present"], False)

    def test_scenario_context_snapshot_refuses_invalid_identity_partial_and_stale_context(self):
        report = self._scenario_cache_fixture()
        review = {}
        valid = self._scenario_cache_context()
        self.assertIsNotNone(server._scenario_context_from_card(report, review, valid))
        invalid_contexts = [
            {**valid, "_scenario_context_metadata": {**valid["_scenario_context_metadata"],
                                                       "source_updated_at": "not-a-date"}},
            {**valid, "_scenario_context_metadata": {**valid["_scenario_context_metadata"],
                                                       "observed_at_ns": time.time_ns() + 5_000_000_000}},
            {key: value for key, value in valid.items() if key != "day_5_shifted"},
        ]
        for candidate in invalid_contexts:
            with self.subTest(candidate=candidate):
                self.assertIsNone(server._scenario_context_from_card(report, review, candidate))
        wrong_id = dict(report, report_id="UA-D-not-valid")
        self.assertIsNone(server._scenario_context_from_card(wrong_id, review, valid))
        self.assertIsNone(server._scenario_context_from_card(dict(report, reason="unknown"), review, valid))
        candidate = server._scenario_context_from_card(report, review, valid)
        stale_row = {**candidate, "observed_at_ns": time.time_ns() - 25 * 60 * 60 * 1_000_000_000}
        stale_row["captured_at"] = "2026-10-25T00:00:00+00:00"
        self.assertIsNone(server._validated_scenario_context_snapshot(stale_row, report, review))

    def test_scenario_context_snapshot_isolated_across_statuses_and_preserves_decision_history(self):
        fixtures = [("pending", "contractBreach"), ("satisfied", "signingRefusal"),
                    ("declined", "goodsNonCompliance")]
        reports = []
        for index, (status, reason) in enumerate(fixtures, 1):
            report = self._scenario_cache_fixture(f"scenario-status-{index}", status, reason)
            reports.append(report)
            with server.db() as con:
                if index == 1:
                    con.execute("""INSERT INTO violation_report_reviews
                        (report_id,review_status,decision_justification,updated_at)
                        VALUES (?,?,?,?)""", (report["id"], "in_review", "Historical justification",
                                                "2026-10-25T10:00:00+03:00"))
                    con.execute("""INSERT INTO violation_report_review_events
                        (report_id,event_type,field_name,new_value,changed_at,changed_by)
                        VALUES (?,?,?,?,?,?)""", (report["id"], "decision_context_snapshotted",
                            "decision_context_snapshot", '{"version":1}', "2026-10-25T10:00:00+03:00", "УО"))
                else:
                    con.execute("INSERT INTO violation_report_reviews(report_id,review_status,updated_at) "
                                "VALUES (?,?,?)", (report["id"], "in_review", "2026-10-25T10:00:00+03:00"))
            context = self._scenario_cache_context()
            if reason == "signingRefusal":
                context = {"rejection_ambiguous": False, "written_refusal_within_deadline": True,
                           "day_3_shifted": False, **context}
            elif reason == "goodsNonCompliance":
                context = {"rejection_ambiguous": False, **context}
            with server.db() as con:
                current_review = con.execute("SELECT * FROM violation_report_reviews WHERE report_id=?",
                                              (report["id"],)).fetchone()
            server._save_violation_scenario_context_snapshot(
                report, server._review_dict(current_review), context)
        with server.db() as con:
            original_review = tuple(con.execute("SELECT * FROM violation_report_reviews WHERE report_id=?",
                                                (reports[0]["id"],)).fetchone())
            original_events = [tuple(row) for row in con.execute(
                "SELECT * FROM violation_report_review_events WHERE report_id=?", (reports[0]["id"],))]
        with patch.object(server, "api_get", side_effect=AssertionError("list must use local snapshots")), \
             patch.object(server, "save_violation_report_with_retry",
                          side_effect=AssertionError("list is read-only")), \
             patch.object(violation_protocol_summary, "present", return_value=None):
            result = server.list_violation_reports({"page": ["1"], "size": ["100"]})
        listed = {item["id"]: item for item in result["items"]}
        for report in reports:
            self.assertTrue(listed[report["id"]]["scenario_summary"], report["id"])
        with server.db() as con:
            self.assertEqual(tuple(con.execute("SELECT * FROM violation_report_reviews WHERE report_id=?",
                                               (reports[0]["id"],)).fetchone()), original_review)
            self.assertEqual([tuple(row) for row in con.execute(
                "SELECT * FROM violation_report_review_events WHERE report_id=?", (reports[0]["id"],))],
                original_events)

    def test_concurrent_scenario_context_saves_keep_newest_source_version(self):
        report = self._scenario_cache_fixture()
        barrier = threading.Barrier(2)
        base_ns = time.time_ns()
        candidates = [
            self._scenario_cache_context(modified=(datetime.now(timezone.utc) - timedelta(minutes=2)).isoformat(),
                                         observed=base_ns - 1_000_000_000,
                                         rejection_present=True),
            self._scenario_cache_context(modified=(datetime.now(timezone.utc) - timedelta(minutes=1)).isoformat(),
                                         observed=base_ns,
                                         rejection_present=False),
        ]
        errors = []

        def save(candidate):
            try:
                barrier.wait(timeout=5)
                return server._save_violation_scenario_context_snapshot(report, {}, candidate)
            except Exception as exc:
                errors.append(exc)
                return None

        threads = [threading.Thread(target=save, args=(candidate,)) for candidate in candidates]
        for thread in threads:
            thread.start()
        for thread in threads:
            thread.join(timeout=10)
        self.assertFalse(errors, errors)
        self.assertTrue(all(not thread.is_alive() for thread in threads))
        with server.db() as con:
            stored = json.loads(con.execute("SELECT context_json FROM violation_scenario_context_snapshots "
                                            "WHERE report_id=?", (report["id"],)).fetchone()[0])
        self.assertFalse(stored["rejection_present"])

    def test_list_api_projects_only_saved_justification_without_generation_or_writes(self):
        fixtures = [
            ("pending", "contractBreach", "За результатами розгляду звернення Замовника встановлено наступне.\n\nСтаном на 12.10.2026 строк укладення договору сплив, але договір не укладено."),
            ("satisfied", "signingRefusal", "У цій закупівлі письмову відмову надано 18.10.2026 після граничної дати 15.10.2026."),
            ("declined", "goodsNonCompliance", "До звернення не додано рішення суду, що набрало законної сили.")]
        for index, (status, reason, saved) in enumerate(fixtures, 1):
            payload = report_payload()
            payload.update({"id": f"saved-list-{index}", "violationReportID": f"UA-D-SAVED-{index}", "status": status})
            payload["details"]["reason"] = reason
            with patch.object(server, "_resolve_violation_tender", return_value=("UA-TEST", "")):
                server.save_violation_report(payload)
            with server.db() as con:
                con.execute("""INSERT INTO violation_report_reviews
                    (report_id,review_status,decision_justification,updated_at)
                    VALUES (?,?,?,?)""",
                    (f"saved-list-{index}", "in_review", saved, "2026-10-25T10:00:00+03:00"))
        with server.db() as con:
            before = [tuple(row) for row in con.execute(
                "SELECT report_id,review_status,decision_justification,updated_at "
                "FROM violation_report_reviews ORDER BY report_id")]
        with patch.object(server, "build_violation_decision_justification",
                          side_effect=AssertionError("list must not generate justification")), \
             patch.object(server, "resolve_violation_procurement_context", return_value=({}, "test_fixture")), \
             patch.object(violation_protocol_summary, "present", return_value=None):
            result = server.list_violation_reports({"page": ["1"], "size": ["100"]})
        projected = {row["id"]: row["decision_justification"] for row in result["items"]}
        for index, (_, _, saved) in enumerate(fixtures, 1):
            self.assertEqual(projected[f"saved-list-{index}"], normalize_justification_text(saved))
        self.assertEqual(projected.get("report-internal", ""), "")
        with server.db() as con:
            after = [tuple(row) for row in con.execute(
                "SELECT report_id,review_status,decision_justification,updated_at "
                "FROM violation_report_reviews ORDER BY report_id")]
        self.assertEqual(after, before)

    def test_list_api_projects_card_scenario_read_only_for_statuses_and_history(self):
        fixtures = [
            ("scenario-pending", "pending", "contractBreach", "in_review", "", {}, {
                "rejection_ambiguous": False, "rejected_before_deadline": False,
                "rejection_present": True, "contract_deadline_expired": True,
                "performance_security_required": True, "day_5_shifted": False}),
            ("scenario-pending-editable", "pending", "contractBreach", "in_review", "", {}, {
                "rejection_ambiguous": False, "rejected_before_deadline": False,
                "rejection_present": True, "contract_deadline_expired": True,
                "performance_security_required": True, "day_5_shifted": False}),
            ("scenario-satisfied", "satisfied", "signingRefusal", "reviewed", "warning", {
                "written_refusal_date": "2026-08-20", "written_refusal_number": "SYN-2"}, {
                "rejection_ambiguous": False, "written_refusal_within_deadline": False,
                "day_3_shifted": True}),
            ("scenario-declined", "declined", "goodsNonCompliance", "reviewed", "decline", {
                "court_decision_final_present": 1}, {"rejection_ambiguous": False}),
            ("scenario-historical-partial", "satisfied", "contractBreach", "reviewed", "decline", {}, {
                "rejection_ambiguous": False, "rejected_before_deadline": False,
                "rejection_present": False, "contract_deadline_expired": True,
                "day_5_shifted": False}),
            ("scenario-historical-empty", "satisfied", "unsupportedHistoricalReason", "reviewed", "decline", {}, None),
            ("scenario-historical-no-snapshot", "declined", "signingRefusal", "reviewed", "decline", {}, None),
        ]
        for fixture_index, (report_id, status, reason, review_status, decision, values, context) in enumerate(fixtures, 1):
            payload = report_payload(decisions=([{"id": "synthetic-official-decision"}]
                                               if report_id == "scenario-pending" else None))
            payload.update({"id": report_id,
                            "violationReportID": f"UA-D-2026-10-25-{fixture_index:06d}",
                            "status": status})
            payload["details"]["reason"] = reason
            with patch.object(server, "_resolve_violation_tender", return_value=("UA-TEST", "")):
                server.save_violation_report(payload)
            with server.db() as con:
                columns = {row[1] for row in con.execute("PRAGMA table_info(violation_report_reviews)")}
                review_values = {"report_id": report_id, "review_status": review_status,
                                 "internal_decision": decision, "updated_at": "2026-10-25T10:00:00+03:00"}
                if review_status == "reviewed":
                    review_values["completed_at"] = "2026-10-25T10:00:00+03:00"
                review_values.update({key: value for key, value in values.items() if key in columns})
                con.execute("INSERT INTO violation_report_reviews (" + ",".join(review_values) + ") VALUES (" +
                            ",".join("?" for _ in review_values) + ")", tuple(review_values.values()))
            if context is not None:
                snapshot = {"version": 1, "report_id": f"UA-D-{report_id}", "reason": reason,
                            "procurement_context": context}
                with server.db() as con:
                    con.execute("""INSERT INTO violation_report_review_events
                        (report_id,event_type,field_name,new_value,changed_at,changed_by)
                        VALUES (?,?,?,?,?,?)""",
                        (report_id, "decision_context_snapshotted", "decision_context_snapshot",
                         json.dumps(snapshot), "2026-10-25T10:00:00+03:00", "Синтетична УО"))
            if context is not None and server._minimal_scenario_context(reason, context) is not None:
                with server.db() as con:
                    report_row = dict(con.execute("SELECT * FROM violation_reports WHERE id=?",
                                                  (report_id,)).fetchone())
                    review_row = con.execute("SELECT * FROM violation_report_reviews WHERE report_id=?",
                                             (report_id,)).fetchone()
                cache_context = dict(context)
                cache_context["_scenario_context_metadata"] = {
                    "source_updated_at": (datetime.now(timezone.utc) - timedelta(minutes=1)).isoformat(),
                    "observed_at_ns": time.time_ns(),
                }
                server._save_violation_scenario_context_snapshot(
                    report_row, server._review_dict(review_row), cache_context)

        def database_state():
            with server.db() as con:
                return {
                    "reports": [tuple(row) for row in con.execute(
                        "SELECT id,status,raw_json,synced_at FROM violation_reports ORDER BY id")],
                    "reviews": [tuple(row) for row in con.execute(
                        "SELECT * FROM violation_report_reviews ORDER BY report_id")],
                    "events": [tuple(row) for row in con.execute(
                        "SELECT * FROM violation_report_review_events ORDER BY id")],
                    "scenario_contexts": [tuple(row) for row in con.execute(
                        "SELECT * FROM violation_scenario_context_snapshots ORDER BY report_id")],
                }

        before = database_state()
        with patch.object(server, "api_get",
                          side_effect=AssertionError("list API must not make external Prozorro requests")), \
             patch.object(server, "resolve_violation_procurement_context",
                          side_effect=AssertionError("list API must use saved context only")), \
             patch.object(server, "build_procurement_context",
                          side_effect=AssertionError("list API must not build context from external data")), \
             patch.object(server, "save_violation_report_with_retry",
                          side_effect=AssertionError("list must not refresh/save Prozorro reports")), \
             patch.object(server, "build_violation_decision_justification",
                          side_effect=AssertionError("list must not generate justification")), \
             patch.object(violation_protocol_summary, "present", return_value=None):
            result = server.list_violation_reports({"page": ["1"], "size": ["100"]})

        projected = {item["id"]: item for item in result["items"]}
        for report_id, status, reason, _, _, values, snapshot_context in fixtures:
            item = projected[report_id]
            review = dict(values)
            if review.get("court_decision_final_present") is not None:
                review["court_decision_final_present"] = bool(review["court_decision_final_present"])
            if snapshot_context is not None and ("performance_security_required" in snapshot_context or
                    "contract_guarantee_required" in snapshot_context or reason != "contractBreach"):
                self.assertEqual(item["scenario_summary"], server.violation_scenario_summary(
                    {"reason": reason, "review": review, "defendant_statements": [
                        {"description": "Пояснення постачальника"}]}, snapshot_context), report_id)
            else:
                self.assertEqual(item["scenario_summary"], "", report_id)
            self.assertEqual(item["status"], status)
        self.assertEqual(projected["scenario-declined"]["scenario_summary"],
                         "Сценарій: пп. 3 п. 49; рішення суду, що набрало законної сили — наявне; "
                         "пояснення постачальника — надані.")
        self.assertEqual(projected["scenario-historical-empty"]["scenario_summary"], "")
        self.assertEqual(projected["scenario-historical-no-snapshot"]["scenario_summary"], "")
        self.assertTrue(projected["scenario-pending-editable"]["scenario_summary"])
        with patch.object(server, "api_get",
                          side_effect=AssertionError("card comparison must use the saved snapshot")), \
             patch.object(server, "save_violation_report_with_retry",
                          side_effect=AssertionError("card comparison must not refresh/save reports")), \
             patch.object(violation_protocol_summary, "present", return_value=None):
            for report_id in ("scenario-pending", "scenario-pending-editable", "scenario-satisfied",
                              "scenario-declined"):
                card = server.violation_report_detail(report_id, refresh=False)
                self.assertEqual(projected[report_id]["scenario_summary"], card["scenario_summary"], report_id)
        self.assertEqual(database_state(), before, "GET list projection must not write reports, reviews, or events")

    def test_list_api_rejects_mismatched_snapshot_identity_version_reason_and_partial_facts(self):
        full = {"rejection_ambiguous": False, "rejected_before_deadline": False,
                "rejection_present": True, "contract_deadline_expired": True,
                "performance_security_required": True, "day_5_shifted": False}
        fixtures = [
            ("snapshot-wrong-id", "contractBreach", {"report_id": "UA-D-OTHER"}, full),
            ("snapshot-wrong-version", "contractBreach", {"version": 2}, full),
            ("snapshot-wrong-reason", "signingRefusal", {"reason": "contractBreach"}, {
                "rejection_ambiguous": False, "written_refusal_within_deadline": False,
                "day_3_shifted": False}),
            ("snapshot-incomplete", "contractBreach", {}, {
                "rejection_ambiguous": False, "rejection_present": True,
                "contract_deadline_expired": True, "day_5_shifted": False}),
        ]
        for report_id, reason, overrides, context in fixtures:
            payload = report_payload(decisions=[{"id": "synthetic-official-decision"}])
            payload.update({"id": report_id, "violationReportID": f"UA-D-{report_id}", "status": "satisfied"})
            payload["details"]["reason"] = reason
            with patch.object(server, "_resolve_violation_tender", return_value=("UA-TEST", "")):
                server.save_violation_report(payload)
            snapshot = {"version": 1, "report_id": f"UA-D-{report_id}", "reason": reason,
                        "procurement_context": context, **overrides}
            with server.db() as con:
                con.execute("""INSERT INTO violation_report_reviews
                    (report_id,review_status,completed_at,updated_at) VALUES (?,?,?,?)""",
                    (report_id, "reviewed", "2026-10-25T10:00:00+03:00", "2026-10-25T10:00:00+03:00"))
                con.execute("""INSERT INTO violation_report_review_events
                    (report_id,event_type,field_name,new_value,changed_at,changed_by)
                    VALUES (?,?,?,?,?,?)""",
                    (report_id, "decision_context_snapshotted", "decision_context_snapshot",
                     json.dumps(snapshot), "2026-10-25T10:00:00+03:00", "Синтетична УО"))
        with patch.object(server, "api_get", side_effect=AssertionError("list API must not request Prozorro")), \
             patch.object(server, "build_procurement_context", side_effect=AssertionError("list API must use snapshots")), \
             patch.object(server, "save_violation_report_with_retry", side_effect=AssertionError("list API must not write reports")), \
             patch.object(violation_protocol_summary, "present", return_value=None):
            result = server.list_violation_reports({"page": ["1"], "size": ["100"]})
        projected = {item["id"]: item for item in result["items"]}
        for report_id, _, _, _ in fixtures:
            self.assertEqual(projected[report_id]["scenario_summary"], "", report_id)

    def test_list_scenario_projection_has_zero_network_calls_and_bounded_latency_through_200_rows(self):
        full_context = {"rejection_ambiguous": False, "rejected_before_deadline": False,
                        "rejection_present": False, "contract_deadline_expired": True,
                        "performance_security_required": False, "day_5_shifted": False}
        groups = ((1, "81000001"), (50, "81000050"), (100, "81000100"), (200, "81000200"))
        sequence = 0
        source_updated_at = (datetime.now(timezone.utc) - timedelta(minutes=1)).isoformat()
        for count, supplier_code in groups:
            for index in range(count):
                sequence += 1
                report_id = f"perf-{count:03d}-{index:03d}"
                payload = report_payload()
                payload.update({"id": report_id,
                                "violationReportID": f"UA-D-2026-10-25-{sequence:06d}"})
                payload["defendants"] = [organization(supplier_code)]
                with patch.object(server, "_resolve_violation_tender", return_value=("UA-TEST", "")):
                    server.save_violation_report(payload)
                saved_snapshot = {"version": 1, "report_id": f"UA-D-{report_id}",
                                  "reason": "contractBreach", "procurement_context": full_context}
                with server.db() as con:
                    con.execute("""INSERT INTO violation_report_reviews
                        (report_id,review_status,completed_at,updated_at) VALUES (?,?,?,?)""",
                        (report_id, "reviewed", "2026-10-25T10:00:00+03:00",
                         "2026-10-25T10:00:00+03:00"))
                    con.execute("""INSERT INTO violation_report_review_events
                        (report_id,event_type,field_name,new_value,changed_at,changed_by)
                        VALUES (?,?,?,?,?,?)""",
                        (report_id, "decision_context_snapshotted", "decision_context_snapshot",
                         json.dumps(saved_snapshot), "2026-10-25T10:00:00+03:00", "Синтетична УО"))
                    report_row = dict(con.execute("SELECT * FROM violation_reports WHERE id=?",
                                                  (report_id,)).fetchone())
                    review_row = con.execute("SELECT * FROM violation_report_reviews WHERE report_id=?",
                                             (report_id,)).fetchone()
                cache_context = dict(full_context)
                cache_context["_scenario_context_metadata"] = {
                    "source_updated_at": source_updated_at,
                    "observed_at_ns": time.time_ns(),
                }
                server._save_violation_scenario_context_snapshot(
                    report_row, server._review_dict(review_row), cache_context)
        with patch.object(server, "api_get", side_effect=AssertionError("unexpected network request")), \
             patch.object(server, "resolve_violation_procurement_context",
                          side_effect=AssertionError("external resolver must not run")), \
             patch.object(server, "save_violation_report_with_retry",
                          side_effect=AssertionError("list must not save reports")), \
             patch.object(violation_protocol_summary, "present", return_value=None):
            timings = {}
            for count, supplier_code in groups:
                size = max(10, count)
                started = __import__("time").perf_counter()
                result = server.list_violation_reports({"page": ["1"], "size": [str(size)],
                                                        "supplier_code": [supplier_code]})
                timings[count] = __import__("time").perf_counter() - started
                self.assertEqual(len(result["items"]), count)
                self.assertTrue(all(item["scenario_summary"] for item in result["items"]))
        self.assertTrue(all(value < 5.0 for value in timings.values()), timings)
        print("READ_ONLY_LIST_TIMINGS_SECONDS " + json.dumps(timings, sort_keys=True))

    def _individual_protocol_fixture(self, reason):
        return {
            "id": "report-internal", "report_id": "UA-D-SYNTHETIC", "reason": reason,
            "authority_code": "40996564", "date_published": "2026-08-18T10:00:00+03:00",
            "date_created": "2026-08-18T10:00:00+03:00", "tender_pretty_id": "UA-TEST",
            "author_name": "Замовник", "author_code": "11111111",
            "defendant_name": "Постачальник", "defendant_code": "22222222",
            "description": "Синтетичний опис", "evidence_documents": [],
            "defendant_statements": [], "supplier_verified": None,
            "deadline_control": {"supplier_ready": True}, "has_official_decision": False,
            "procurement_context": {"available": True, "tender_date_published": "2026-07-30",
                                    "winner_state": "unknown", "rejection_ambiguous": False},
            "review": {"review_status": "in_review", "assigned_officer": "Тестова УО",
                       "internal_decision": "decline", "decision_justification": "Окреме обґрунтування",
                       "review_notes": "Актуальний коментар УО", "protocol_number": "SYN-1",
                       "protocol_date": "2026-08-31"},
        }

    @patch.object(server, "violation_protocol_declensions", lambda *_: [])
    def test_individual_decline_protocol_is_explicit_and_maps_reference_from_request_basis(self):
        expected = {"contractBreach": "пп. 1 п. 49", "signingRefusal": "пп. 2 п. 49",
                    "goodsNonCompliance": "пп. 3 п. 49"}
        for reason, reference in expected.items():
            with self.subTest(reason=reason):
                item = self._individual_protocol_fixture(reason)
                item["procurement_context"]["rejection_ambiguous"] = True
                gate = server.violation_protocol_readiness(
                    item, requested_protocol_type="decline_individual_review")
                self.assertTrue(gate["ready"], gate["reasons"])
                self.assertEqual(gate["protocol_type"], "decline_individual_review")
                with patch.object(server, "require_local_violation_report_owned"), \
                        patch.object(server, "require_owned_violation_report"), \
                        patch.object(server, "violation_report_detail", return_value=item), \
                        patch.object(server, "_resolve_violation_protocol_metadata", return_value={}):
                    prepared = server.generate_violation_protocol(item["id"], {
                        "protocol_type": "decline_individual_review", "protocol_number": "SYN-1",
                        "protocol_date": "2026-08-31", "confirm_review_notes": True,
                        "confirmed_review_notes": "Актуальний коментар УО",
                    }, prepare_only=True)
                self.assertEqual(prepared["values"]["p49_reference"], reference)
                self.assertEqual(prepared["values"]["review_notes"], item["review"]["review_notes"])
                self.assertEqual(prepared["values"]["decision_justification"],
                                 item["review"]["decision_justification"])
                self.assertEqual(prepared["values"]["winner_date"], "")

    @patch.object(server, "violation_protocol_declensions", lambda *_: [])
    def test_individual_decline_blocks_unknown_basis_wrong_decision_and_stale_comment(self):
        for reason, decision in (("supplierMisconduct", "decline"),
                                 ("contractBreach", "warning")):
            item = self._individual_protocol_fixture(reason)
            item["review"]["internal_decision"] = decision
            gate = server.violation_protocol_readiness(
                item, requested_protocol_type="decline_individual_review")
            self.assertFalse(gate["ready"])
            self.assertTrue(any("лише для рішення" in message for message in gate["reasons"]))
        item = self._individual_protocol_fixture("contractBreach")
        for supplied, confirmed in ((False, "Актуальний коментар УО"),
                                    (True, "Застарілий коментар")):
            payload = {"protocol_type": "decline_individual_review", "protocol_number": "SYN-1",
                       "protocol_date": "2026-08-31", "confirm_review_notes": supplied,
                       "confirmed_review_notes": confirmed}
            with patch.object(server, "require_local_violation_report_owned"), \
                    patch.object(server, "require_owned_violation_report"), \
                    patch.object(server, "violation_report_detail", return_value=item):
                with self.assertRaisesRegex(ValueError, "Коментар УО змінився"):
                    server.generate_violation_protocol(item["id"], payload, prepare_only=True)

    @patch.object(server, "violation_protocol_declensions", lambda *_: [])
    def test_individual_protocol_generation_does_not_complete_review(self):
        item = self._individual_protocol_fixture("goodsNonCompliance")
        with server.db() as con:
            con.execute("INSERT INTO violation_report_reviews (report_id,review_status,assigned_officer,internal_decision,decision_justification,review_notes,protocol_number,protocol_date,updated_at) VALUES (?,?,?,?,?,?,?,?,?)",
                        ("report-internal", "in_review", "Тестова УО", "decline", "Обґрунтування", "Актуальний коментар УО", "SYN-1", "2026-08-31", "2026-08-31T12:00:00+03:00"))
        output_dir = Path(self.temp.name) / "protocols"
        def write_docx(_kind, path, *_args):
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_bytes(b"synthetic-docx")
            return path
        payload = {"protocol_type": "decline_individual_review", "protocol_number": "SYN-1",
                   "protocol_date": "2026-08-31", "confirm_review_notes": True,
                   "confirmed_review_notes": "Актуальний коментар УО"}
        with patch.object(server, "require_local_violation_report_owned"), \
                patch.object(server, "require_owned_violation_report"), \
                patch.object(server, "violation_report_detail", return_value=item), \
                patch.object(server, "_resolve_violation_protocol_metadata", return_value={}), \
                patch.object(server, "PROTOCOLS_DIR", output_dir), \
                patch.object(server, "build_violation_protocol_docx", side_effect=write_docx):
            result = server.generate_violation_protocol("report-internal", payload)
        with server.db() as con:
            row = con.execute("SELECT review_status,completed_at,generated_protocol_metadata_json FROM violation_report_reviews WHERE report_id='report-internal'").fetchone()
        self.assertEqual(row["review_status"], "in_review")
        self.assertFalse(row["completed_at"])
        self.assertEqual(__import__("json").loads(row["generated_protocol_metadata_json"])["protocol_type"],
                         "decline_individual_review")
        self.assertTrue((output_dir / result["filename"]).is_file())

    def test_protocol_missing_required_context_returns_422(self):
        request = SimpleNamespace(
            path="/api/violation-reports/report-internal/protocol/generate",
            auth_user="УО", read_json=lambda: {},
            send_json=lambda body, status=200: (body, status))
        error = server.ProtocolContextValidationError(
            "Не заповнено обов’язкові поля: supplier_name", missing=("supplier_name",))
        with patch.object(server, "generate_violation_protocol", side_effect=error):
            body, status = server.Handler._do_POST(request)
        self.assertEqual(status, 422)
        self.assertEqual(body["missing"], ["supplier_name"])

    @patch.object(server, "violation_protocol_declensions", lambda _: [])
    def test_prod_empty_description_fixture_is_not_a_generation_blocker(self):
        item = {
            "id": "7733b223a90f4770b39d35082bbcb9cd",
            "report_id": "UA-D-2026-09-25-000001", "reason": "signingRefusal",
            "author_name": "Замовник", "defendant_name": "Постачальник", "defendant_code": "22222222",
            "description": "", "has_official_decision": False,
            "deadline_control": {"supplier_ready": True},
            "procurement_context": {"available": True, "tender_date_published": "2026-09-20", "winner_selected_at": "2026-09-21",
                "winner_state": "confirmed", "rejection_present": False,
                "rejection_ambiguous": False},
            "review": {"assigned_officer": "УО", "internal_decision": "decline",
                "decision_justification": "Погоджений текст", "protocol_number": "P-1",
                "protocol_date": "2026-10-05", "written_refusal_date": "2026-09-24",
                "written_refusal_number": "42", "written_refusal_url": "https://example.test/refusal"},
        }
        self.assertTrue(server.violation_protocol_readiness(item)["ready"])
        with patch.object(server, "require_local_violation_report_owned"), \
                patch.object(server, "require_owned_violation_report"), \
                patch.object(server, "violation_report_detail", return_value=item), \
                patch.object(server, "_resolve_violation_protocol_metadata", return_value={}):
            prepared = server.generate_violation_protocol(item["id"], {}, prepare_only=True)
        self.assertEqual(prepared["values"]["violation_description"], "")
        self.assertEqual(prepared["values"]["procurement_date"], "20.09.2026")

    def test_justification_plain_text_normalization(self):
        raw = "\tПерший абзац.\r\n\r\n  Другий абзац.\rТретій абзац.\n\n"
        self.assertEqual(
            normalize_justification_text(raw),
            "Перший абзац.\nДругий абзац.\nТретій абзац.",
        )

    def test_review_saved_only_without_official_decision(self):
        with patch.object(server, "api_get", return_value={"data": report_payload()}):
            result = server.save_violation_review("report-internal", {"review_status": "in_review"})
        self.assertFalse(result["is_read_only"])
        self.assertEqual(result["review"]["review_status"], "in_review")

    def test_contract_requisites_are_manual_and_survive_save_and_sync(self):
        external = {"available": True, "contract_pretty_id": "UA-AUTO-a1",
                    "contract_date": "2026-01-01", "contract_url": "https://auto.invalid"}
        with patch.object(server, "api_get", return_value={"data": report_payload()}), \
                patch.object(server, "build_procurement_context", return_value=external):
            saved = server.save_violation_review("report-internal", {
                "actual_contract_signed": True,
                "actual_contract_date": "2026-09-07",
                "actual_contract_number": "MANUAL-77",
                "actual_contract_url": "https://manual.example/77",
            })
            repeated = server.save_violation_review("report-internal", {"review_notes": "Повторний Save"})
        server.save_violation_report(report_payload())
        with patch.object(server, "build_procurement_context", return_value=external):
            after_sync = server.violation_report_detail("report-internal", refresh=False)
        for item in (saved, repeated, after_sync):
            self.assertTrue(item["review"]["actual_contract_signed"])
            self.assertEqual(item["review"]["actual_contract_date"], "2026-09-07")
            self.assertEqual(item["review"]["actual_contract_number"], "MANUAL-77")
            self.assertEqual(item["review"]["actual_contract_url"], "https://manual.example/77")

    def test_customer_names_reuse_latest_saved_same_code_and_current_values_win(self):
        historical=report_payload();historical.update(id='historical-report',violationReportID='UA-D-HISTORICAL')
        server.save_violation_report(historical)
        now=server.now_iso()
        with server.db() as connection:
            connection.execute("""INSERT INTO violation_report_reviews
              (report_id,customer_verified_full_name,customer_verified_short_name,updated_at,updated_by)
              VALUES (?,?,?,?,?)""",('historical-report','ПОВНА НАЗВА З ІСТОРІЇ','СКОРОЧЕНА З ІСТОРІЇ',now,'УО'))
        with patch.object(server,'build_procurement_context',return_value={'available':False}):
            reused=server.violation_report_detail('report-internal',refresh=False)
        self.assertEqual(reused['review']['customer_verified_full_name'],'ПОВНА НАЗВА З ІСТОРІЇ')
        self.assertEqual(reused['review']['customer_verified_short_name'],'СКОРОЧЕНА З ІСТОРІЇ')
        self.assertEqual(reused['review']['customer_name_reuse_sources']['customer_verified_full_name'],'UA-D-HISTORICAL')
        server.init_db()
        with patch.object(server,'build_procurement_context',return_value={'available':False}):
            after_restart=server.violation_report_detail('report-internal',refresh=False)
        self.assertEqual(after_restart['review']['customer_verified_full_name'],'ПОВНА НАЗВА З ІСТОРІЇ')
        self.assertEqual(after_restart['review']['customer_verified_short_name'],'СКОРОЧЕНА З ІСТОРІЇ')
        with server.db() as connection:
            connection.execute("""INSERT INTO violation_report_reviews
              (report_id,customer_verified_full_name,customer_verified_short_name,updated_at,updated_by)
              VALUES (?,?,?,?,?)""",('report-internal','ПОТОЧНА ПОВНА','ПОТОЧНА СКОРОЧЕНА',server.now_iso(),'УО'))
        with patch.object(server,'build_procurement_context',return_value={'available':False}):
            current=server.violation_report_detail('report-internal',refresh=False)
        self.assertEqual(current['review']['customer_verified_full_name'],'ПОТОЧНА ПОВНА')
        self.assertEqual(current['review']['customer_verified_short_name'],'ПОТОЧНА СКОРОЧЕНА')
        self.assertNotIn('customer_name_reuse_sources',current['review'])

    def test_contract_checkbox_can_be_cleared_without_technical_repopulation(self):
        external = {"available": True, "contract_pretty_id": "UA-AUTO-a1",
                    "contract_date": "2026-01-01", "contract_url": "https://auto.invalid"}
        with patch.object(server, "api_get", return_value={"data": report_payload()}), \
                patch.object(server, "build_procurement_context", return_value=external):
            server.save_violation_review("report-internal", {
                "actual_contract_signed": True, "actual_contract_date": "2026-09-07",
                "actual_contract_number": "MANUAL-77"})
            cleared = server.save_violation_review("report-internal", {"actual_contract_signed": False})
        self.assertFalse(cleared["review"]["actual_contract_signed"])
        source = (server.ROOT / "app.js").read_text(encoding="utf-8")
        active = source[source.rfind("function violationReasonFields(item)"):
                        source.rfind("requestContextBlock=function(item)")]
        self.assertNotIn("r.actual_contract_number||c.contract_pretty_id", active)
        self.assertNotIn("r.actual_contract_date||String(c.contract_date", active)

    def test_legacy_assigned_officer_fallback_and_patch_round_trip(self):
        with server.db() as connection:
            officer = connection.execute(
                "SELECT id,full_name FROM authorized_officers WHERE active=1 ORDER BY id LIMIT 1").fetchone()
            connection.execute("""INSERT INTO violation_report_reviews
                (report_id,assigned_officer,review_notes,updated_at,updated_by)
                VALUES (?,?,?,?,?)""", ("report-internal", officer["full_name"].lower(),
                "Не змінювати", server.now_iso(), "Тест"))
        with patch.object(server, "build_procurement_context", return_value={"available": False}):
            detail = server.violation_report_detail("report-internal", refresh=False)
        self.assertIsNone(detail["review"]["assigned_officer_id"])
        self.assertEqual(detail["review"]["assigned_officer_effective_id"], officer["id"])
        self.assertEqual(detail["review"]["assigned_officer_display"],
                         server.formatted_officer_name(officer["full_name"]))
        with patch.object(server, "api_get", return_value={"data": report_payload()}), \
                patch.object(server, "build_procurement_context", return_value={"available": False}):
            saved = server.save_violation_review("report-internal", {
                "assigned_officer_id": officer["id"]})
        self.assertEqual(saved["review"]["assigned_officer_id"], officer["id"])
        self.assertEqual(saved["review"]["assigned_officer_effective_id"], officer["id"])
        self.assertEqual(saved["review"]["review_notes"], "Не змінювати")
        server.save_violation_report(report_payload())
        with patch.object(server, "build_procurement_context", return_value={"available": False}):
            reopened = server.violation_report_detail("report-internal", refresh=False)
        self.assertEqual(reopened["review"]["assigned_officer_effective_id"], officer["id"])
        self.assertEqual(reopened["review"]["review_notes"], "Не змінювати")

    def test_managed_assigned_officer_survives_detail_reload(self):
        with server.db() as connection:
            officer = connection.execute(
                "SELECT id,full_name FROM authorized_officers WHERE active=1 ORDER BY id LIMIT 1").fetchone()
        with patch.object(server, "api_get", return_value={"data": report_payload()}), \
                patch.object(server, "build_procurement_context", return_value={"available": False}):
            saved = server.save_violation_review("report-internal", {
                "assigned_officer_id": officer["id"], "review_notes": "Контроль"})
            reopened = server.violation_report_detail("report-internal", refresh=False)
        self.assertEqual(saved["review"]["assigned_officer_effective_id"], officer["id"])
        self.assertEqual(reopened["review"]["assigned_officer_effective_id"], officer["id"])
        self.assertEqual(reopened["review"]["assigned_officer"], officer["full_name"])
        self.assertEqual(reopened["review"]["review_notes"], "Контроль")

    def test_official_decision_blocks_patch_without_overwriting_review(self):
        with patch.object(server, "api_get", return_value={"data": report_payload()}):
            server.save_violation_review("report-internal", {"review_notes": "Зберегти"})
        official = {"id": "decision", "resolution": "satisfied", "documents": []}
        with patch.object(server, "api_get", return_value={"data": report_payload([official])}):
            with self.assertRaises(PermissionError):
                server.save_violation_review("report-internal", {"review_notes": "Не записувати"})
        with server.db() as connection:
            note = connection.execute("SELECT review_notes FROM violation_report_reviews").fetchone()[0]
        self.assertEqual(note, "Зберегти")

    def test_document_review_is_sparse_audited_and_survives_prozorro_sync(self):
        with server.db() as connection:
            self.assertEqual(connection.execute(
                "SELECT COUNT(*) FROM violation_report_document_reviews").fetchone()[0], 0)
        with patch.object(server, "build_procurement_context", return_value={"available": False}):
            result = server.save_violation_document_review(
                "report-internal", "customer", "customer-doc", True, "Тестова УО")
        document = result["evidence_documents"][0]
        self.assertTrue(document["manual_reviewed"])
        self.assertTrue(document["file_unavailable"])
        server.save_violation_report(report_payload())
        with patch.object(server, "build_procurement_context", return_value={"available": False}):
            refreshed = server.violation_report_detail("report-internal", refresh=False)
        self.assertTrue(refreshed["evidence_documents"][0]["file_unavailable"])
        with server.db() as connection:
            row = connection.execute(
                "SELECT checked_by,file_unavailable FROM violation_report_document_reviews").fetchone()
            event = connection.execute("""SELECT field_name,new_value FROM violation_report_review_events
                WHERE field_name='document_unavailable:customer:customer-doc'""").fetchone()
        self.assertEqual(tuple(row), ("Тестова УО", 1))
        self.assertEqual(tuple(event), ("document_unavailable:customer:customer-doc", "1"))

    def test_unavailable_document_does_not_change_review_decision(self):
        with patch.object(server, "build_procurement_context", return_value={"available": False}):
            server.save_violation_document_review(
                "report-internal", "supplier", "supplier-doc", True, "Тестова УО")
        with server.db() as connection:
            review = connection.execute(
                "SELECT * FROM violation_report_reviews WHERE report_id='report-internal'").fetchone()
        self.assertIsNone(review)

    def test_fail_closed_when_prozorro_unavailable(self):
        with patch.object(server, "api_get", side_effect=OSError("offline")):
            with self.assertRaises(ConnectionError):
                server.save_violation_review("report-internal", {"review_status": "in_review"})

    def test_official_supplier_deadline_uses_exact_timestamp(self):
        report = {
            "date_published": "2026-08-26T10:45:58+03:00",
            "defendant_period_end": "2026-09-01T00:00:00+03:00",
        }
        before = server._parse_prozorro_date("2026-08-31T23:59:59+03:00")
        at_boundary = server._parse_prozorro_date("2026-09-01T00:00:00+03:00")
        self.assertFalse(server.violation_deadline_control(report, before)["supplier_ready"])
        self.assertTrue(server.violation_deadline_control(report, at_boundary)["supplier_ready"])
        self.assertEqual(server.violation_deadline_control(report, at_boundary)["supplier_official_deadline"],
                         "2026-09-01T00:00:00+03:00")

    def test_local_three_day_control_never_unlocks_missing_official_deadline(self):
        report = {"date_published": "2026-08-01T10:00:00+03:00", "defendant_period_end": ""}
        control = server.violation_deadline_control(
            report, server._parse_prozorro_date("2026-09-01T12:00:00+03:00"))
        self.assertFalse(control["supplier_ready"])
        self.assertTrue(control["supplier_deadline_missing"])

    def test_foreign_authority_is_read_only_and_all_mutations_fail_closed(self):
        payload = report_payload()
        payload["authority"] = organization("42574629")
        server.save_violation_report(payload)
        with patch.object(server, "build_procurement_context", return_value={"available": False}):
            detail = server.violation_report_detail("report-internal", refresh=False)
        self.assertTrue(detail["foreign_authority_read_only"])
        self.assertTrue(detail["is_read_only"])
        with patch.object(server, "api_get", return_value={"data": payload}):
            with self.assertRaises(server.ForeignAuthorityError):
                server.save_violation_review("report-internal", {"review_notes": "Заборонено"})
        with self.assertRaises(server.ForeignAuthorityError):
            server.save_violation_document_review(
                "report-internal", "customer", "customer-doc", True, "Адміністратор")

    def test_weekend_shift_and_extension(self):
        start = server._parse_prozorro_date("2026-08-17T10:00:00+03:00")
        five = server._calendar_deadline(start, 5)
        ten = server._calendar_deadline(start, 10)
        self.assertEqual(five["calendar_day"], "2026-08-22")
        self.assertEqual(five["deadline"], "2026-08-24")
        self.assertTrue(five["shifted"])
        self.assertEqual(ten["deadline"], "2026-08-27")

    def test_five_day_deadline_uses_full_calendar_day(self):
        start = server._parse_prozorro_date("2026-08-14T10:15:00+03:00")
        deadline = server._calendar_deadline(start, 5)
        self.assertEqual(deadline["deadline"], "2026-08-19")
        self.assertTrue(server._within_calendar_deadline(
            server._parse_prozorro_date("2026-08-19T23:59:59+03:00"), deadline["deadline"]))
        self.assertFalse(server._within_calendar_deadline(
            server._parse_prozorro_date("2026-08-20T00:00:00+03:00"), deadline["deadline"]))

    def test_shifted_monday_is_included_in_full(self):
        start = server._parse_prozorro_date("2026-08-17T10:00:00+03:00")
        deadline = server._calendar_deadline(start, 5)
        self.assertEqual(deadline["deadline"], "2026-08-24")
        self.assertTrue(server._within_calendar_deadline(
            server._parse_prozorro_date("2026-08-24T23:59:59+03:00"), deadline["deadline"]))
        self.assertFalse(server._within_calendar_deadline(
            server._parse_prozorro_date("2026-08-25T00:00:00+03:00"), deadline["deadline"]))

    def test_p1_business_logic_uses_effective_weekend_deadline(self):
        tender = {"data": {"tenderID": "UA-TEST", "awards": [
            {"id": "winner", "qualified": True, "status": "active",
             "period": {"startDate": "2026-08-17T10:00:00+03:00"},
             "documents": [{"id": "notice", "documentType": "notice", "datePublished": "2026-08-17T11:00:00+03:00"}],
             "suppliers": [organization("22222222")]},
            {"id": "rejected", "qualified": False, "status": "unsuccessful",
             "date": "2026-08-23T18:00:00+03:00", "title": "Не підписано договір",
             "suppliers": [organization("22222222")]},
        ], "contracts": [], "items": []}}
        with patch.object(server, "api_get", return_value=tender):
            context = server.build_procurement_context({
                "tender_id": "tender-id", "defendant_code": "22222222",
                "reason": "contractBreach",
            })
        self.assertEqual(context["day_5"], "2026-08-22")
        self.assertTrue(context["day_5_shifted"])
        self.assertEqual(context["contract_deadline"], "2026-08-24")
        self.assertTrue(context["rejected_before_deadline"])
        recommendation = server.violation_rules_engine("contractBreach", {
            **context, "supplier_deadline_ready": True, "defendant_statements_present": False,
        }, {})
        self.assertEqual(recommendation["recommended_decision"], "decline")

    def test_p1_decline_justification_ordinary_deadline_matches_recommendation(self):
        report = {"reason": "contractBreach", "defendant_statements": []}
        context = {
            "rejection_present": True, "rejected_before_deadline": True,
            "winner_selected_at": "2026-09-02T10:00:00+03:00",
            "day_5": "2026-09-07", "day_5_shifted": False,
            "contract_deadline": "2026-09-07", "rejection_date": "2026-09-06T12:00:00+03:00",
        }
        review = {"internal_decision": "decline"}
        self.assertEqual(server.violation_decision_template_key(report, context, review),
                         "p49_1_decline_before_deadline")
        recommendation = server.violation_rules_engine("contractBreach", context, review)
        self.assertEqual(recommendation["recommended_decision"], "decline")
        self.assertEqual(recommendation["recommendation_reason"],
                         "Пропозицію постачальника відхилено до закінчення строку, передбаченого п. 66 Порядку № 822 для укладення договору.")
        text = server.build_violation_decision_justification(report, context, review)
        self.assertIn("Граничним днем для укладення договору у цій закупівлі є 07.09.2026", text)
        self.assertIn("Замовник відхилив пропозицію Постачальника 06.09.2026", text)
        self.assertNotIn("ст. 254 Цивільного кодексу України", text)

    def test_p1_decline_before_deadline_adds_security_only_when_required(self):
        report = {"reason": "contractBreach", "defendant_statements": []}
        context = {
            "rejection_present": True, "rejected_before_deadline": True,
            "winner_selected_at": "2026-08-24T08:00:00+03:00",
            "day_5": "2026-08-29", "day_5_weekday_uk": "субота", "day_5_shifted": True,
            "contract_deadline": "2026-08-31", "contract_deadline_weekday_uk": "понеділок",
            "rejection_date": "2026-08-31T15:22:00+03:00",
            "performance_security_required": True,
        }
        review = {"internal_decision": "decline"}
        text = server.build_violation_decision_justification(report, context, review)
        self.assertIn("припадає на 29.08.2026 (субота)", text)
        self.assertIn("переноситься на понеділок 31.08.2026", text)
        self.assertIn("забезпечення виконання договору надається постачальником до або під час укладення", text)
        self.assertIn("відмову в задоволенні звернення Замовника", text)
        without_security = server.build_violation_decision_justification(
            report, {**context, "performance_security_required": False,
                     "contract_guarantee_required": False}, review)
        self.assertNotIn("забезпечення виконання договору надається постачальником", without_security)

    def test_p1_decline_security_without_shift_keeps_security_but_omits_civil_code(self):
        report = {"reason": "contractBreach", "defendant_statements": []}
        context = {
            "rejection_present": True, "rejected_before_deadline": True,
            "winner_selected_at": "2026-09-02T10:00:00+03:00",
            "day_5": "2026-09-07", "day_5_shifted": False,
            "contract_deadline": "2026-09-07", "rejection_date": "2026-09-06T12:00:00+03:00",
            "performance_security_required": True,
        }
        text = server.build_violation_decision_justification(
            report, context, {"internal_decision": "decline"})
        self.assertIn("строк для виконання цієї дії також вважається таким, що не закінчився", text)
        self.assertNotIn("ст. 254 ЦК України", text)
        self.assertNotIn("переноситься на", text)

    def test_p1_decline_justification_weekend_uses_structured_shift(self):
        report = {"reason": "contractBreach", "defendant_statements": []}
        context = {
            "rejection_present": True, "rejected_before_deadline": True,
            "winner_selected_at": "2026-08-24T08:00:00+03:00",
            "day_5": "2026-08-29", "day_5_weekday_uk": "субота", "day_5_shifted": True,
            "contract_deadline": "2026-08-31", "rejection_date": "2026-08-31T15:22:00+03:00",
        }
        review = {"internal_decision": "decline"}
        self.assertEqual(server.violation_decision_template_key(report, context, review),
                         "p49_1_decline_before_deadline_civil_shift")
        text = server.build_violation_decision_justification(report, context, review)
        self.assertIn("п’ятий календарний день припадає на 29.08.2026 (субота)", text)
        self.assertIn("ч. 5 ст. 254 ЦК України", text)
        self.assertIn("переноситься на перший робочий день 31.08.2026", text)
        self.assertIn("Замовник відхилив пропозицію Постачальника 31.08.2026", text)

    def test_contract_deadline_ui_uses_structured_shift_values_only(self):
        source = (server.ROOT / "app.js").read_text(encoding="utf-8")
        start = source.index("function violationReasonFields(item)")
        end = source.index("requestContextBlock=function(item)", start)
        renderer = source[start:end]
        self.assertIn("const shiftedWeekday=String(c.day_5_weekday_uk||'').trim()", renderer)
        self.assertIn("const shiftedDeadline=c.day_5_shifted?(shiftedWeekday?", renderer)
        self.assertIn("displayDateOnly(c.day_5)", renderer)
        self.assertIn("c.day_5_weekday_uk", renderer)
        self.assertIn("displayDateOnly(c.contract_deadline)", renderer)
        self.assertIn("5-й календарний день:", renderer)
        self.assertIn("Строк перенесено на перший робочий день відповідно до ч. 5 ст. 254 ЦК України.", renderer)
        self.assertIn("${shiftedDeadline}", renderer)
        self.assertIn("backend не повернув day_5_weekday_uk", renderer)
        self.assertNotIn("(${esc(c.day_5_weekday_uk)||'—'})", renderer)
        self.assertNotIn("getDay(", renderer)
        self.assertNotIn("new Date(c.day_5", renderer)

    def test_contract_checkbox_visibility_uses_backend_business_flag(self):
        self.assertFalse(server.violation_has_complete_rejection({}))
        self.assertFalse(server.violation_has_complete_rejection({
            "rejection_date": "2026-09-01", "rejection_title": ""}))
        self.assertFalse(server.violation_has_complete_rejection({
            "rejection_date": None, "rejection_title": "Відхилено"}))
        self.assertTrue(server.violation_has_complete_rejection({
            "rejection_date": "2026-09-01", "rejection_title": "Відхилено"}))
        source = (server.ROOT / "app.js").read_text(encoding="utf-8")
        self.assertIn("function violationHasCompleteRejection(context={})", source)
        self.assertIn("context.rejection_date&&String(context.rejection_reason||context.rejection_title||context.rejection_description||'').trim()", source)
        self.assertIn("const contract=violationContractEditorVisible(item)?", source)
        self.assertIn("context.rejection_present===true", source)
        self.assertIn("const extension=item.reason==='contractBreach'?", source)

    # These four tests isolate review/persistence, not the separately tested name gate.
    @patch.object(server, "violation_protocol_declensions", lambda _: [])
    def test_rejected_offer_ignores_but_does_not_clear_saved_contract_value(self):
        item = {
            "reason": "goodsNonCompliance",
            "deadline_control": {"supplier_ready": True},
            "has_official_decision": False,
            "procurement_context": {
                "available": True, "rejection_date": "2026-09-01",
                "rejection_description": "Документи не відповідають вимогам",
            },
            "review": {
                "assigned_officer": "УО", "internal_decision": "decline",
                "decision_justification": "Збережене обґрунтування",
                "protocol_number": "1", "protocol_date": "2026-09-08",
                "actual_contract_signed": True,
                "actual_contract_date": "", "actual_contract_number": "",
            },
        }
        gate = server.violation_protocol_readiness(item)
        self.assertTrue(gate["ready"], gate["reasons"])
        self.assertTrue(item["review"]["actual_contract_signed"])

    def test_ua_d_2026_08_31_000001_deadline_trace_has_approved_template(self):
        tender = {"data": {"tenderID": "UA-TEST", "awards": [
            {"id": "winner", "qualified": True, "status": "active",
             "period": {"startDate": "2026-08-24T08:00:00+03:00"},
             "documents": [{"id": "notice", "documentType": "notice", "datePublished": "2026-08-24T09:00:00+03:00"}],
             "suppliers": [organization("22222222")]},
            {"id": "rejected", "qualified": False, "status": "unsuccessful",
             "date": "2026-08-31T15:22:00+03:00", "title": "Не підписано договір",
             "suppliers": [organization("22222222")]},
        ], "contracts": [], "items": []}}
        report = {"report_id": "UA-D-2026-08-31-000001", "tender_id": "tender-id",
                  "defendant_code": "22222222", "reason": "contractBreach",
                  "defendant_statements": []}
        with patch.object(server, "api_get", return_value=tender):
            context = server.build_procurement_context(report)
        self.assertEqual(context["day_5"], "2026-08-29")
        self.assertEqual(context["day_5_weekday_uk"], "субота")
        self.assertTrue(context["day_5_shifted"])
        self.assertEqual(context["contract_deadline"], "2026-08-31")
        self.assertTrue(context["rejected_before_deadline"])
        review = {"internal_decision": "decline"}
        self.assertTrue(server.build_violation_decision_justification(report, context, review))

    def test_three_and_ten_day_boundaries(self):
        start = server._parse_prozorro_date("2026-08-14T10:15:00+03:00")
        three = server._calendar_deadline(start, 3)
        ten = server._calendar_deadline(start, 10)
        self.assertEqual(three["deadline"], "2026-08-17")
        self.assertEqual(ten["deadline"], "2026-08-24")
        self.assertTrue(server._within_calendar_deadline(
            server._parse_prozorro_date("2026-08-24T23:00:00+03:00"), ten["deadline"]))

    def test_rules_without_rejection_has_no_automatic_decision(self):
        result = server.violation_rules_engine("contractBreach", {"rejection_present": False}, None)
        self.assertIsNone(result["recommended_decision"])
        self.assertEqual(result["recommended_scenario"], "review_without_rejection")

    def test_contract_breach_recommendation_tracks_deadline_and_explanations(self):
        base = {"rejection_present": True, "rejected_before_deadline": False}
        running = server.violation_rules_engine(
            "contractBreach", {**base, "supplier_deadline_ready": False,
                                "defendant_statements_present": False}, None)
        ended = server.violation_rules_engine(
            "contractBreach", {**base, "supplier_deadline_ready": True,
                                "defendant_statements_present": False}, None)
        explained = server.violation_rules_engine(
            "contractBreach", {**base, "supplier_deadline_ready": True,
                                "defendant_statements_present": True}, None)
        self.assertEqual(running["recommendation_reason"],
                         "Строк для укладення договору закінчився до відхилення пропозиції; потрібно дочекатися пояснень для прийняття рішення.")
        self.assertEqual(ended["recommendation_reason"],
                         "Строк для укладення договору закінчився до відхилення пропозиції; пояснень від постачальника не надано.")
        self.assertEqual(explained["recommendation_reason"],
                         "Строк для укладення договору закінчився до відхилення пропозиції; пояснення від постачальника надано, для прийняття рішення потрібно проаналізувати надані пояснення/документи.")

    def test_written_refusal_and_court_rules(self):
        self.assertEqual(server.violation_rules_engine(
            "signingRefusal", {"written_refusal_within_deadline": True}, {})["recommended_decision"], "decline")
        self.assertEqual(server.violation_rules_engine(
            "signingRefusal", {"written_refusal_within_deadline": False}, {})["recommended_decision"], "warning")
        self.assertEqual(server.violation_rules_engine(
            "goodsNonCompliance", {}, {"court_decision_final_present": False})["recommended_decision"], "decline")
        self.assertEqual(server.violation_rules_engine(
            "goodsNonCompliance", {}, {"court_decision_final_present": True})["recommended_decision"], "individual_review")

    def test_supplier_awards_do_not_mix(self):
        tender = {
            "tenderID": "UA-TEST", "criteria": [], "contracts": [{"id": "c1", "awardID": "w1", "status": "cancelled", "date": "2026-07-20"}],
            "awards": [
                {"id": "w1", "status": "cancelled", "qualified": True, "date": "2026-07-20", "period": {"startDate": "2026-07-10T10:00:00+03:00"}, "documents": [{"id": "notice", "documentType": "notice", "datePublished": "2026-07-11"}], "suppliers": [organization("22222222")]},
                {"id": "r1", "status": "unsuccessful", "qualified": False, "date": "2026-07-16T10:00:00+03:00", "suppliers": [organization("22222222")]},
                {"id": "other", "status": "unsuccessful", "qualified": False, "date": "2026-07-17T10:00:00+03:00", "suppliers": [organization("33333333")]},
            ],
        }
        with patch.object(server, "api_get", return_value={"data": tender}):
            context = server.build_procurement_context({"tender_id": "tender-id", "defendant_code": "22222222"})
        self.assertEqual(context["winner_award_id"], "w1")
        self.assertEqual(context["rejection_award_id"], "r1")
        self.assertEqual(context["contract_status"], "cancelled")
        self.assertNotIn("actual_contract_date", context)

    def test_cancelled_contract_never_populates_manual_contract_fields(self):
        tender = {
            "tenderID": "UA-TEST", "criteria": [],
            "contracts": [{"id": "c1", "contractID": "UA-AUTO-a1", "awardID": "w1",
                           "status": "cancelled", "date": "2026-07-20"}],
            "awards": [{"id": "w1", "status": "cancelled", "qualified": True,
                        "suppliers": [organization("22222222")]}],
        }
        with patch.object(server, "api_get", return_value={"data": tender}):
            context = server.build_procurement_context({"tender_id": "tender-id", "defendant_code": "22222222"})
        self.assertEqual(context["contract_status"], "cancelled")
        for key in ("actual_contract_signed", "actual_contract_date", "actual_contract_number", "actual_contract_url"):
            self.assertNotIn(key, context)

    def test_manual_and_hourly_violation_sync_share_guard(self):
        server.VIOLATION_SYNC_STATE["running"] = True
        try:
            self.assertFalse(server.start_violation_reports_sync())
        finally:
            server.VIOLATION_SYNC_STATE["running"] = False

    def test_rejection_reason_classifier_is_conservative(self):
        self.assertEqual(server.classify_award_rejection_reason(
            {"title": "Відмова від підписання договору"}), "non_signing")
        self.assertEqual(server.classify_award_rejection_reason(
            {"description": "Не надано забезпечення виконання договору"}), "guarantee_missing")
        self.assertEqual(server.classify_award_rejection_reason(
            {"description": "Документи не відповідають вимогам"}), "other")
        self.assertEqual(server.classify_award_rejection_reason({}), "unknown")

    def test_contract_block_hidden_only_for_explicit_reason_without_related_contract(self):
        tender = {"tenderID": "UA-TEST", "criteria": [], "contracts": [], "awards": [
            {"id": "w1", "status": "cancelled", "qualified": True,
             "date": "2026-07-20",
             "period": {"startDate": "2026-07-10T10:00:00+03:00"},
             "documents": [{"id": "notice", "documentType": "notice", "datePublished": "2026-07-11"}],
             "suppliers": [organization("22222222")]},
            {"id": "r1", "status": "unsuccessful", "qualified": False,
             "date": "2026-07-16T10:00:00+03:00", "title": "Не підписано договір",
             "suppliers": [organization("22222222")]},
        ]}
        with patch.object(server, "api_get", return_value={"data": tender}):
            context = server.build_procurement_context(
                {"tender_id": "tender-id", "defendant_code": "22222222", "reason": "contractBreach"})
        self.assertFalse(context["contract_info_required"])
        self.assertEqual(context["rejection_reason_classification"], "non_signing")

    def test_non_signing_rejection_does_not_inherit_winner_award_contract(self):
        tender = {"tenderID": "UA-TEST", "criteria": [],
                  "contracts": [{"id": "c1", "awardID": "w1", "status": "active",
                                 "suppliers": [organization("22222222")]}],
                  "awards": [
                      {"id": "w1", "status": "active", "qualified": True,
                       "period": {"startDate": "2026-08-18T09:00:00+03:00"},
                       "documents": [{"id": "notice", "documentType": "notice", "datePublished": "2026-08-18T11:00:00+03:00"}],
                       "suppliers": [organization("22222222")]},
                      {"id": "r1", "status": "unsuccessful", "qualified": False,
                       "date": "2026-08-25T10:13:00+03:00", "title": "Не підписано договір",
                       "suppliers": [organization("22222222")]},
                  ]}
        with patch.object(server, "api_get", return_value={"data": tender}):
            context = server.build_procurement_context(
                {"tender_id": "tender-id", "defendant_code": "22222222", "reason": "contractBreach"})
        self.assertFalse(context["related_contract_found"])
        self.assertEqual(context["contract_warning"], "")
        self.assertFalse(context["contract_info_required"])

    def test_manual_justification_is_saved_as_canonical_plain_text(self):
        manual = "\tРучний офіційний текст УО\r\n\r\n  Другий абзац"
        expected = "Ручний офіційний текст УО\nДругий абзац"
        with patch.object(server, "api_get", return_value={"data": report_payload()}):
            result = server.save_violation_review(
                "report-internal", {"decision_justification": manual, "review_notes": ""})
        self.assertEqual(result["review"]["decision_justification"], expected)
        with server.db() as connection:
            stored = connection.execute(
                "SELECT decision_justification FROM violation_report_reviews WHERE report_id=?",
                ("report-internal",),
            ).fetchone()[0]
        self.assertEqual(stored, expected)
        self.assertEqual(result["justification_draft"], "")

    def test_supplier_refusal_and_customer_decision_are_stored_separately(self):
        payload = report_payload(); payload["details"]["reason"] = "signingRefusal"
        server.save_violation_report(payload)
        values = {
            "written_refusal_date": "2026-08-21", "written_refusal_number": "38",
            "written_refusal_url": "https://example.test/refusal",
            "customer_protocol_decision_date": "2026-08-25",
            "customer_protocol_decision_number": "106",
            "customer_protocol_decision_url": "https://example.test/customer-decision",
        }
        with patch.object(server, "api_get", return_value={"data": payload}), \
                patch.object(server, "build_procurement_context", return_value={"available": False}):
            result = server.save_violation_review("report-internal", values)
        review = result["review"]
        self.assertEqual(review["written_refusal_number"], "38")
        self.assertEqual(review["customer_protocol_decision_number"], "106")
        self.assertNotEqual(review["written_refusal_url"], review["customer_protocol_decision_url"])

    def test_supplier_and_administrator_working_day_deadlines_are_separate(self):
        control = server.violation_deadline_control({
            "date_published": "2026-08-21T10:00:00+03:00",
            "defendant_period_end": "2026-08-27T18:00:00+03:00",
        }, server._parse_prozorro_date("2026-08-28T10:00:00+03:00"))
        self.assertEqual(control["supplier_official_deadline"], "2026-08-27T18:00:00+03:00")
        self.assertEqual(control["supplier_local_control_deadline"], "2026-08-26")
        self.assertEqual(control["admin_deadline"], "2026-09-04")
        self.assertTrue(control["supplier_ready"])
        self.assertFalse(control["admin_overdue"])

    def test_dk_uses_contract_items_then_tender_fallback_and_deduplicates(self):
        tender = {"items": [
            {"classification": {"id": "11110000-0", "description": "Тендер"}},
            {"classification": {"id": "22220000-0", "description": "Інший"}},
        ]}
        contract = {"items": [
            {"classification": {"id": "33330000-0", "description": "Договір"}},
            {"classification": {"id": "33330000-0", "description": "Договір"}},
            {"classification": {"id": "44440000-0", "description": "Другий"}},
        ]}
        self.assertEqual(server.procurement_dk_classifications(tender, contract), [
            {"code": "33330000-0", "description": "Договір"},
            {"code": "44440000-0", "description": "Другий"},
        ])
        self.assertEqual(server.procurement_dk_classifications(tender, None)[0]["code"], "11110000-0")

    def test_reviewed_status_is_blocked_before_official_supplier_deadline(self):
        payload = report_payload()
        payload["defendantPeriod"] = {"endDate": "2099-01-01T18:00:00+02:00"}
        server.save_violation_report(payload)
        with patch.object(server, "api_get", return_value={"data": payload}):
            with self.assertRaisesRegex(ValueError, "окремою дією"):
                server.save_violation_review("report-internal", {
                    "review_status": "reviewed", "internal_decision": "warning"})
        with server.db() as connection:
            connection.execute("""INSERT INTO violation_report_reviews
                (report_id,review_status,internal_decision,updated_at,updated_by)
                VALUES (?,?,?,?,?)""", ("report-internal", "in_review", "warning", server.now_iso(), "УО"))
        detail = {"id": "report-internal", "decisions": [],
                  "authority_code": "40996564",
                  "deadline_control": {"supplier_ready": False},
                  "review": {"review_status": "in_review", "internal_decision": "warning"}}
        with patch.object(server, "violation_report_detail", return_value=detail):
            with self.assertRaisesRegex(ValueError, "офіційного строку"):
                server.complete_violation_review("report-internal", "УО")

    def test_official_decision_is_presented_as_completed_without_rewriting_review(self):
        payload = report_payload()
        payload["decisions"] = [{"id": "official-decision"}]
        server.save_violation_report(payload)
        with server.db() as connection:
            connection.execute("""INSERT INTO violation_report_reviews
                (report_id,review_status,updated_at,updated_by) VALUES (?,?,?,?)""",
                ("report-internal", "in_review", server.now_iso(), "УО"))
        with patch.object(server, "build_procurement_context", return_value={"available": False}):
            detail = server.violation_report_detail("report-internal", refresh=False)
        self.assertTrue(detail["is_read_only"])
        self.assertEqual(detail["review"]["review_status"], "completed")
        with server.db() as connection:
            stored = connection.execute(
                "SELECT review_status FROM violation_report_reviews WHERE report_id='report-internal'").fetchone()[0]
        self.assertEqual(stored, "in_review")

    def test_legacy_local_completed_is_presented_as_reviewed(self):
        with server.db() as connection:
            connection.execute("""INSERT INTO violation_report_reviews
                (report_id,review_status,updated_at,updated_by) VALUES (?,?,?,?)""",
                ("report-internal", "completed", server.now_iso(), "УО"))
        with patch.object(server, "build_procurement_context", return_value={"available": False}):
            detail = server.violation_report_detail("report-internal", refresh=False)
        self.assertTrue(detail["is_read_only"])
        self.assertEqual(detail["review"]["review_status"], "reviewed")

    @patch.object(server, "violation_protocol_declensions", lambda _: [])
    def test_protocol_generation_does_not_complete_review(self):
        now = server.now_iso()
        with server.db() as connection:
            connection.execute("""INSERT INTO violation_report_reviews
                (report_id,review_status,assigned_officer,internal_decision,
                 decision_justification,protocol_number,protocol_date,updated_at,updated_by)
                VALUES (?,?,?,?,?,?,?,?,?)""", (
                "report-internal", "in_review", "Тестова УО", "warning",
                "Остаточне ручне обґрунтування", "TEST-1", "2026-08-31", now, "Тест",
            ))
        detail = {
            "id": "report-internal", "report_id": "UA-D-TEST", "reason": "contractBreach",
            "authority_code": "40996564",
            "date_published": "2026-08-18T10:00:00+03:00", "date_created": "2026-08-18T10:00:00+03:00",
            "tender_pretty_id": "UA-TEST", "author_name": "Замовник", "author_code": "11111111",
            "defendant_name": "Постачальник", "defendant_code": "22222222", "description": "Порушення",
            "evidence_documents": [], "defendant_statements": [], "supplier_verified": None,
            "deadline_control": {"supplier_ready": True},
            "procurement_context": {"available": True, "tender_date_published": "2026-07-30", "winner_selected_at": "2026-08-01T10:00:00+03:00"},
            "review": {"review_status": "in_review", "assigned_officer": "Тестова УО",
                       "customer_verified_short_name": "Замовник",
                       "internal_decision": "warning", "decision_justification": "Остаточне ручне обґрунтування",
                       "protocol_number": "TEST-1", "protocol_date": "2026-08-31"},
        }
        output_dir = Path(self.temp.name) / "protocols"
        def write_test_protocol(_kind, path, *_args):
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_bytes(b"docx")
            return path
        with patch.object(server, "violation_report_detail", return_value=detail), \
                patch.object(server, "PROTOCOLS_DIR", output_dir), \
                patch.object(server, "build_violation_protocol_docx", side_effect=write_test_protocol):
            first = server.generate_violation_protocol(
                "report-internal", {"protocol_number": "TEST-1", "protocol_date": "2026-08-31"})
            result = server.generate_violation_protocol(
                "report-internal", {"protocol_number": "TEST-1", "protocol_date": "2026-08-31"})
        self.assertNotEqual(first["filename"], result["filename"])
        self.assertTrue((output_dir / result["filename"]).is_file())
        self.assertEqual(result["review_status"], "in_review")
        with server.db() as connection:
            review = connection.execute("""SELECT review_status,reviewed_at,updated_by,
                generated_protocol_filename,generated_protocol_metadata_json,protocol_generated_at
                FROM violation_report_reviews WHERE report_id='report-internal'""").fetchone()
            events = connection.execute("""SELECT COUNT(*) FROM violation_report_review_events
                WHERE report_id='report-internal' AND event_type='protocol_generated'""").fetchone()[0]
        self.assertEqual(review["review_status"], "in_review")
        self.assertFalse(review["reviewed_at"])
        self.assertEqual(review["generated_protocol_filename"], result["filename"])
        metadata = json.loads(review["generated_protocol_metadata_json"])
        self.assertEqual(metadata, result["metadata"])
        self.assertEqual(server._violation_protocol_download_filename(result["filename"]), result["download_filename"])
        self.assertEqual(metadata["protocol_download"]["filename"], result["download_filename"])
        self.assertEqual(server._violation_protocol_download_filename("other-generator.docx"), "other-generator.docx")
        self.assertEqual(metadata["protocol_subject"]["label"], "Тема протоколу / короткий зміст")
        self.assertIn("UA-D-TEST", metadata["protocol_subject"]["value"])
        self.assertEqual(result["resolved_metadata"], [{
            "metadata_key": "protocol_subject",
            "label": "Тема протоколу / короткий зміст",
            "resolved_text": metadata["protocol_subject"]["value"],
            "version": metadata["protocol_subject"]["config_version"],
            "display_order": 0,
        }])
        self.assertEqual(result["pdf_download_url"], "/api/violation-reports/report-internal/protocol/pdf")
        self.assertTrue(review["protocol_generated_at"])
        self.assertEqual(review["updated_by"], server.CURRENT_USER)
        self.assertGreaterEqual(events, 1)

    @patch.object(server, "violation_protocol_declensions", lambda _: [])
    def test_protocol_uses_manual_contract_requisites_not_prozorro_mapping(self):
        now = server.now_iso()
        with server.db() as connection:
            connection.execute("""INSERT INTO violation_report_reviews
                (report_id,review_status,assigned_officer,internal_decision,
                 decision_justification,protocol_number,protocol_date,actual_contract_signed,
                 actual_contract_date,actual_contract_number,updated_at,updated_by)
                VALUES (?,?,?,?,?,?,?,?,?,?,?,?)""", (
                "report-internal", "in_review", "Тестова УО", "warning", "Погоджений текст",
                "TEST-MANUAL", "2026-09-07", 1, "2026-09-06", "MANUAL-42", now, "Тест"))
        detail = {
            "id": "report-internal", "report_id": "UA-D-TEST", "reason": "contractBreach",
            "authority_code": "40996564", "date_published": "2026-08-18T10:00:00+03:00",
            "date_created": "2026-08-18T10:00:00+03:00", "tender_pretty_id": "UA-TEST",
            "author_name": "Замовник", "author_code": "11111111", "defendant_name": "Постачальник",
            "defendant_code": "22222222", "description": "Порушення", "evidence_documents": [],
            "defendant_statements": [], "supplier_verified": None,
            "deadline_control": {"supplier_ready": True},
            "procurement_context": {"available": True, "tender_date_published": "2026-08-01", "contract_date": "2020-01-01",
                                    "contract_pretty_id": "UA-AUTO-a1",
                                    "winner_selected_at": "2026-08-01T10:00:00+03:00"},
            "review": {"review_status": "in_review", "assigned_officer": "Тестова УО",
                       "customer_verified_short_name": "Замовник",
                       "internal_decision": "warning", "decision_justification": "Погоджений текст",
                       "protocol_number": "TEST-MANUAL", "protocol_date": "2026-09-07",
                       "actual_contract_signed": 1, "actual_contract_date": "2026-09-06",
                       "actual_contract_number": "MANUAL-42"},
        }
        captured = {}
        def write_test_protocol(_kind, path, values, _justification, _customer, _supplier, flags, *_args):
            captured.update(values=values, flags=flags);path.parent.mkdir(parents=True, exist_ok=True);path.write_bytes(b"docx")
        with patch.object(server, "violation_report_detail", return_value=detail), \
                patch.object(server, "PROTOCOLS_DIR", Path(self.temp.name) / "protocols"), \
                patch.object(server, "build_violation_protocol_docx", side_effect=write_test_protocol):
            server.generate_violation_protocol("report-internal", {
                "protocol_number": "TEST-MANUAL", "protocol_date": "2026-09-07"})
        self.assertEqual(captured["values"]["contract_number"], "MANUAL-42")
        self.assertEqual(captured["values"]["contract_date"], "06.09.2026")
        self.assertEqual(captured["values"]["contract_url"], "")
        self.assertNotIn("UA-AUTO-a1", captured["values"].values())
        self.assertTrue(captured["flags"]["has_contract"])

    @patch.object(server, "violation_protocol_declensions", lambda _: [])
    def test_saved_contract_url_reaches_protocol_without_changing_date_or_number(self):
        with patch.object(server, "api_get", return_value={"data": report_payload()}), \
                patch.object(server, "build_procurement_context", return_value={"available": True}):
            server.save_violation_review("report-internal", {
                "actual_contract_signed": True, "actual_contract_date": "2026-08-14",
                "actual_contract_number": "2026/08-25",
                "actual_contract_url": "https://example.test/contract",
            })
        with patch.object(server, "build_procurement_context", return_value={"available": True}):
            review = server.violation_report_detail("report-internal", refresh=False)["review"]
        item = {
            "id": "report-internal", "report_id": "UA-D-TEST", "reason": "goodsNonCompliance",
            "authority_code": "40996564", "date_published": "2026-08-18T10:00:00+03:00",
            "date_created": "2026-08-18T10:00:00+03:00", "tender_pretty_id": "UA-TEST",
            "author_name": "Замовник", "author_code": "11111111",
            "defendant_name": "Постачальник", "defendant_code": "22222222",
            "description": "Порушення", "evidence_documents": [], "defendant_statements": [],
            "supplier_verified": None, "deadline_control": {"supplier_ready": True},
            "procurement_context": {"available": True, "tender_date_published": "2026-07-30",
                                    "winner_selected_at": "2026-08-01T10:00:00+03:00"},
            "review": {**review, "review_status": "in_review", "assigned_officer": "УО",
                       "customer_verified_short_name": "Замовник", "internal_decision": "decline",
                       "decision_justification": "Обґрунтування", "protocol_number": "42",
                       "protocol_date": "2026-10-04"},
        }
        self.assertEqual(item["review"]["actual_contract_url"], "https://example.test/contract")
        with patch.object(server, "require_local_violation_report_owned"), \
                patch.object(server, "require_owned_violation_report"), \
                patch.object(server, "violation_report_detail", return_value=item), \
                patch.object(server, "_resolve_violation_protocol_metadata", return_value={}):
            prepared = server.generate_violation_protocol("report-internal", {}, prepare_only=True)
        self.assertEqual(prepared["values"]["contract_url"], "https://example.test/contract")
        self.assertEqual(prepared["values"]["contract_date"], "14.08.2026")
        self.assertEqual(prepared["values"]["contract_number"], "2026/08-25")

    def test_protocol_normalizes_customer_supplier_quotes_before_all_declensions(self):
        now = server.now_iso()
        with server.db() as connection:
            connection.execute("""INSERT INTO violation_report_reviews
                (report_id,review_status,assigned_officer,internal_decision,
                 decision_justification,protocol_number,protocol_date,updated_at,updated_by)
                VALUES (?,?,?,?,?,?,?,?,?)""", (
                "report-internal", "in_review", "Тестова УО", "warning", "Погоджений текст",
                "TEST-QUOTES", "2026-09-08", now, "Тест"))
        customer = 'ДЕРЖАВНЕ ПІДПРИЄМСТВО "ЗАМОВНИК"'
        supplier = 'ТОВАРИСТВО З ОБМЕЖЕНОЮ ВІДПОВІДАЛЬНІСТЮ "ОХТИРКА М\'ЯСОПРОДУКТ"'
        detail = {
            "id": "report-internal", "report_id": "UA-D-TEST", "reason": "contractBreach",
            "authority_code": "40996564", "date_created": "2026-09-01", "tender_pretty_id": "UA-TEST",
            "author_name": customer, "author_code": "11111111", "defendant_name": supplier,
            "defendant_code": "22222222", "description": "Порушення", "evidence_documents": [],
            "defendant_statements": [], "supplier_verified": {"full_name": supplier, "short_name": 'ТОВ "ОХТИРКА М\'ЯСОПРОДУКТ"'},
            "deadline_control": {"supplier_ready": True},
            "procurement_context": {"available": True, "tender_date_published": "2026-08-30", "winner_selected_at": "2026-09-01"},
            "review": {"assigned_officer": "Тестова УО", "internal_decision": "warning",
                       "customer_verified_short_name": "ДП «ЗАМОВНИК»",
                       "decision_justification": "Погоджений текст", "protocol_number": "TEST-QUOTES",
                       "protocol_date": "2026-09-08"},
        }
        captured = {}
        declined_inputs = []
        def decline_presentation_name(original, entity_type, grammatical_case):
            declined_inputs.append(original)
            # Simulate an override/automatic rule that still contains source
            # ASCII quotes: document presentation must normalize its result too.
            ascii_result = original.replace("«", '"').replace("»", '"')
            return DeclensionResult(ascii_result, "resolved", "automatic", original, entity_type)
        def capture(_kind, path, values, *_args):
            captured.update(values)
            path.parent.mkdir(parents=True, exist_ok=True); path.write_bytes(b"docx")
        with patch.object(server, "violation_report_detail", return_value=detail), \
                patch.object(server, "PROTOCOLS_DIR", Path(self.temp.name) / "protocols"), \
                patch.object(server, "decline_name", side_effect=decline_presentation_name), \
                patch.object(server, "build_violation_protocol_docx", side_effect=capture):
            server.generate_violation_protocol("report-internal", {
                "protocol_number": "TEST-QUOTES", "protocol_date": "2026-09-08"})
        name_tokens = ("customer_name", "customer_name_genitive", "customer_name_accusative",
                       "supplier_name", "supplier_short_name", "supplier_name_genitive",
                       "supplier_name_dative", "supplier_name_accusative")
        for token in name_tokens:
            self.assertNotIn('"', captured[token], token)
        self.assertIn("«ЗАМОВНИК»", captured["customer_name"])
        for token in name_tokens[3:]:
            self.assertIn("«ОХТИРКА М'ЯСОПРОДУКТ»", captured[token], token)
        self.assertTrue(declined_inputs)
        self.assertTrue(all('"' not in value for value in declined_inputs))

    def test_protocol_civil_code_flag_uses_only_the_current_reason_deadline(self):
        now = server.now_iso()
        with server.db() as connection:
            connection.execute("""INSERT INTO violation_report_reviews
                (report_id,review_status,assigned_officer,internal_decision,
                 decision_justification,protocol_number,protocol_date,updated_at,updated_by)
                VALUES (?,?,?,?,?,?,?,?,?)""", (
                "report-internal", "in_review", "Тестова УО", "warning", "Погоджений текст",
                "TEST-CIVIL", "2026-09-08", now, "Тест"))
        detail = {
            "id": "report-internal", "report_id": "UA-D-TEST", "reason": "contractBreach",
            "authority_code": "40996564", "date_created": "2026-09-01", "tender_pretty_id": "UA-TEST",
            "author_name": "Замовник", "author_code": "11111111", "defendant_name": "Постачальник",
            "defendant_code": "22222222", "description": "Порушення", "evidence_documents": [],
            "defendant_statements": [], "supplier_verified": None,
            "deadline_control": {"supplier_ready": True},
            "procurement_context": {"available": True, "tender_date_published": "2026-08-30", "winner_selected_at": "2026-09-01",
                                    "day_5_shifted": False, "day_3_shifted": True},
            "review": {"assigned_officer": "Тестова УО", "internal_decision": "warning",
                       "customer_verified_short_name": "Замовник",
                       "decision_justification": "Погоджений текст", "protocol_number": "TEST-CIVIL",
                       "protocol_date": "2026-09-08"},
        }
        captured = {}
        def capture(_kind, path, _values, _justification, _customer, _supplier, flags, *_args):
            captured.update(flags)
            path.parent.mkdir(parents=True, exist_ok=True); path.write_bytes(b"docx")
        with patch.object(server, "violation_report_detail", return_value=detail), \
                patch.object(server, "PROTOCOLS_DIR", Path(self.temp.name) / "protocols"), \
                patch.object(server, "decline_name", side_effect=lambda value, entity, case:
                             DeclensionResult(value, "resolved", "automatic", value, entity)), \
                patch.object(server, "build_violation_protocol_docx", side_effect=capture):
            server.generate_violation_protocol("report-internal", {
                "protocol_number": "TEST-CIVIL", "protocol_date": "2026-09-08"})
        self.assertFalse(captured["has_civil_code_basis"])

    def test_contract_breach_scenario_summary_is_derived_and_keeps_manual_comment_separate(self):
        report = {
            "reason": "contractBreach",
            "defendant_statements": [],
            "review": {"review_notes": "Ручний коментар УО"},
        }
        context = {
            "available": True, "rejection_present": True,
            "rejected_before_deadline": True,
            "performance_security_required": True,
            "day_5_shifted": True,
        }
        summary = server.violation_scenario_summary(report, context)
        self.assertEqual(summary, (
            "Сценарій: дострокове відхилення; забезпечення виконання договору — вимагається; "
            "пояснення постачальника — відсутні; ЦКУ — застосовується "
            "(перенесення граничного строку)."))
        self.assertNotIn(report["review"]["review_notes"], summary)
        self.assertEqual(report["review"]["review_notes"], "Ручний коментар УО")

    def test_contract_breach_scenario_summary_updates_from_structured_context(self):
        report = {"reason": "contractBreach", "defendant_statements": [
            {"description": "Фактичне пояснення постачальника"}]}
        context = {
            "available": True, "rejection_present": True,
            "rejected_before_deadline": False,
            "contract_guarantee_required": False,
            "day_5_shifted": False,
        }
        self.assertEqual(server.violation_scenario_summary(report, context), (
            "Сценарій: відхилення після закінчення строку, визначеного п. 66 Порядку № 822; "
            "забезпечення виконання договору — не вимагається; пояснення постачальника — надані; "
            "ЦКУ — не застосовується."))
        self.assertEqual(server.violation_scenario_summary(
            {"reason": "goodsNonCompliance"}, context), (
                "Сценарій: пп. 3 п. 49; рішення суду, що набрало законної сили — не визначено; "
                "пояснення постачальника — відсутні."))

    def test_scenario_summary_covers_p2_before_and_after_deadline(self):
        report = {"reason": "signingRefusal", "defendant_statements": [], "review": {
            "written_refusal_date": "2026-09-08"}}
        before = {"available": True, "written_refusal_deadline_expired": False,
                  "written_refusal_within_deadline": True, "day_3_shifted": True}
        self.assertEqual(server.violation_scenario_summary(report, before), (
            "Сценарій: пп. 2 п. 49; триденний строк — не сплив; письмова відмова "
            "постачальника — надана; пояснення постачальника — відсутні; ЦКУ — "
            "застосовується (перенесення граничного строку)."))
        report["review"] = {}
        after = {"available": True, "written_refusal_deadline_expired": True,
                 "day_3_shifted": False}
        self.assertIn("триденний строк — не визначено; письмова відмова постачальника — відсутня",
                      server.violation_scenario_summary(report, after))

        report["review"] = {"written_refusal_url": "https://example.test/refusal"}
        self.assertIn("триденний строк — не визначено; письмова відмова постачальника — надана",
                      server.violation_scenario_summary(report, after))

    def test_ua_d_2026_09_08_000001_uses_canonical_refusal_deadline_flag(self):
        report = {
            "report_id": "UA-D-2026-09-08-000001",
            "reason": "signingRefusal",
            "defendant_statements": [],
            "review": {"written_refusal_date": "2026-09-07"},
        }
        context = {
            "available": True,
            "written_refusal_within_deadline": True,
            # The wall clock is now past the deadline, but the refusal itself
            # was submitted while that deadline had not expired.
            "written_refusal_deadline_expired": True,
            "day_3_shifted": True,
        }
        recommendation = server.violation_rules_engine(
            report["reason"], context, report["review"])
        self.assertEqual(recommendation["recommended_decision"], "decline")
        self.assertEqual(recommendation["recommendation_reason"],
                         "Письмову відмову надано в межах строку.")
        self.assertEqual(server.violation_scenario_summary(report, context), (
            "Сценарій: пп. 2 п. 49; триденний строк — не сплив; письмова відмова "
            "постачальника — надана; пояснення постачальника — відсутні; ЦКУ — "
            "застосовується (перенесення граничного строку)."))

    def test_scenario_summary_covers_p3_without_unrelated_contract_facts(self):
        report = {"reason": "goodsNonCompliance", "defendant_statements": [
            {"description": "Пояснення"}], "review": {"court_decision_final_present": False}}
        summary = server.violation_scenario_summary(report, {})
        self.assertEqual(summary, (
            "Сценарій: пп. 3 п. 49; рішення суду, що набрало законної сили — відсутнє; "
            "пояснення постачальника — надані."))
        self.assertNotIn("догов", summary.lower())
        self.assertNotIn("штраф", summary.lower())

    def test_scenario_summary_p1_exists_before_deadline_without_rejection(self):
        report = {"reason": "contractBreach", "defendant_statements": []}
        summary = server.violation_scenario_summary(report, {
            "available": True, "rejection_present": False, "contract_deadline_expired": False,
            "performance_security_required": False, "day_5_shifted": False})
        self.assertIn("строк, визначений п. 66 Порядку № 822, ще не сплив", summary)
        self.assertTrue(summary.startswith("Сценарій:"))

    @patch.object(server, "violation_protocol_declensions", lambda _: [])
    def test_protocol_passes_last_saved_justification_verbatim(self):
        detail = {
            "id": "report-internal", "report_id": "UA-D-TEST", "reason": "contractBreach",
            "authority_code": "40996564", "date_created": "2026-09-01", "tender_pretty_id": "UA-TEST",
            "author_name": "Замовник", "author_code": "11111111", "defendant_name": "Постачальник",
            "defendant_code": "22222222", "description": "Порушення", "evidence_documents": [],
            "defendant_statements": [], "supplier_verified": None,
            "deadline_control": {"supplier_ready": True, "supplier_deadline": "2026-09-05"},
            "procurement_context": {"available": True, "tender_date_published": "2026-08-30", "winner_selected_at": "2026-09-01", "dk_code": "44110000-4"},
            "review": {"assigned_officer": "Тестова УО", "internal_decision": "warning",
                       "customer_verified_short_name": "Замовник",
                       "decision_justification": "Останній збережений текст УО — без змін.",
                       "protocol_number": "P-1", "protocol_date": "2026-09-08"},
        }
        captured = {}
        def capture(_kind, path, _values, justification, *_args):
            captured["justification"] = justification
            captured["violation_description"] = _values["violation_description"]
            path.parent.mkdir(parents=True, exist_ok=True); path.write_bytes(b"docx")
        with patch.object(server, "violation_report_detail", return_value=detail), \
                patch.object(server, "PROTOCOLS_DIR", Path(self.temp.name) / "protocols"), \
                patch.object(server, "build_violation_protocol_docx", side_effect=capture):
            server.generate_violation_protocol("report-internal", {"protocol_number": "P-1", "protocol_date": "2026-09-08"})
        self.assertEqual(captured["justification"], "Останній збережений текст УО — без змін.")
        self.assertEqual(captured["violation_description"], detail["description"])

    def test_protocol_reason_bindings_use_full_reason_metadata_not_customer_description(self):
        descriptions = {
            "contractBreach": "Опис Замовника для пп. 1",
            "signingRefusal": "Опис Замовника для пп. 2",
            "goodsNonCompliance": "Опис Замовника для пп. 3",
        }
        for reason, description in descriptions.items():
            metadata = server.VIOLATION_REASON_PROTOCOL_METADATA[reason]
            self.assertIn(f"Підпункт {metadata['number']} пункту 49", metadata["label"])
            self.assertIn("Постанови Кабінету Міністрів України від 14.09.2020 № 822", metadata["label"])
            self.assertTrue(metadata["text"])
            self.assertNotEqual(metadata["text"], description)
        self.assertNotIn("Непідписання договору / ненадання забезпечення в строк",
                         {item["label"] for item in server.VIOLATION_REASON_PROTOCOL_METADATA.values()})

    def test_protocol_officer_name_uses_first_name_then_uppercase_surname(self):
        self.assertEqual(server._protocol_officer_name("СВІТЛАНА НАМЯСЕНКО"),
                         "Світлана НАМЯСЕНКО")
        self.assertEqual(server._protocol_officer_name("Яна КАСЬЯН"), "Яна КАСЬЯН")

    def test_manual_completion_is_separate_and_preserves_review_history(self):
        now = server.now_iso()
        with server.db() as connection:
            connection.execute("""INSERT INTO violation_report_reviews
                (report_id,review_status,assigned_officer,internal_decision,
                 decision_justification,generated_protocol_filename,updated_at,updated_by)
                VALUES (?,?,?,?,?,?,?,?)""", (
                "report-internal", "in_review", "Тестова УО", "warning",
                "Ручне обґрунтування", "already-generated.docx", now, "Тест",
            ))
        detail = {
            "id": "report-internal", "report_id": "UA-D-TEST", "decisions": [],
            "authority_code": "40996564",
            "deadline_control": {"supplier_ready": True},
            "review": {"review_status": "in_review", "internal_decision": "warning",
                       "decision_justification": "Ручне обґрунтування",
                       "generated_protocol_filename": "already-generated.docx"},
        }
        with patch.object(server, "violation_report_detail", return_value=detail), \
                patch.object(server, "build_procurement_context", return_value={
                    "available": True, "dk_code": "15510000-6", "winner_selected_at": "2026-08-20",
                    "rejection_date": "2026-08-26", "contract_guarantee_required": True}):
            result = server.complete_violation_review("report-internal", "Тестова УО")
        self.assertEqual(result["review_status"], "reviewed")
        with server.db() as connection:
            review = connection.execute("""SELECT review_status,completed_at,completed_by,
                decision_justification,generated_protocol_filename
                FROM violation_report_reviews WHERE report_id='report-internal'""").fetchone()
            events = connection.execute("""SELECT COUNT(*) FROM violation_report_review_events
                WHERE report_id='report-internal' AND event_type='review_completed'""").fetchone()[0]
        self.assertEqual(review["review_status"], "reviewed")
        self.assertTrue(review["completed_at"])
        self.assertEqual(review["completed_by"], "Тестова УО")
        self.assertEqual(review["decision_justification"], "Ручне обґрунтування")
        self.assertEqual(review["generated_protocol_filename"], "already-generated.docx")
        self.assertEqual(events, 1)

    def test_completion_atomically_saves_form_and_context_snapshot(self):
        now = server.now_iso()
        with server.db() as connection:
            connection.execute("""INSERT INTO violation_report_reviews
                (report_id,review_status,assigned_officer,internal_decision,
                 decision_justification,review_notes,updated_at,updated_by)
                VALUES (?,?,?,?,?,?,?,?)""", (
                "report-internal", "in_review", "Тестова УО", "warning",
                "Попередній текст", "Попередня примітка", now, "Тест",
            ))
        detail = {
            "id": "report-internal", "report_id": "UA-D-TEST", "reason": "contractBreach",
            "status": "pending", "decisions": [], "has_official_decision": False,
            "authority_code": "40996564", "defendant_statements": [],
            "evidence_documents": [], "description": "Порушення",
            "deadline_control": {"supplier_ready": True},
            "review": {"review_status": "in_review", "internal_decision": "warning"},
        }
        context = {"available": True, "dk_code": "15510000-6", "winner_selected_at": "2026-08-20",
                   "rejection_present": True, "rejection_date": "2026-08-26",
                   "contract_deadline": "2026-08-25", "rejected_before_deadline": False,
                   "contract_guarantee_required": True}
        payload = {"review_status": "in_review", "internal_decision": "warning",
                   "decision_justification": "Остаточний текст", "review_notes": "Остання примітка"}
        with patch.object(server, "violation_report_detail", return_value=detail), \
                patch.object(server, "build_procurement_context", return_value=context):
            result = server.complete_violation_review("report-internal", "Тестова УО", payload)
        self.assertEqual(result["review_status"], "reviewed")
        with server.db() as connection:
            review = connection.execute("""SELECT review_status,completed_at,decision_justification,
                review_notes FROM violation_report_reviews WHERE report_id='report-internal'""").fetchone()
            snapshot = connection.execute("""SELECT new_value FROM violation_report_review_events
                WHERE report_id='report-internal' AND event_type='decision_context_snapshotted'""").fetchone()
        self.assertEqual(review["review_status"], "reviewed")
        self.assertTrue(review["completed_at"])
        self.assertEqual(review["decision_justification"], "Остаточний текст")
        self.assertEqual(review["review_notes"], "Остання примітка")
        saved = json.loads(snapshot["new_value"])
        self.assertEqual(saved["procurement_context"]["dk_code"], "15510000-6")
        self.assertEqual(saved["recommendation"]["recommended_decision"], "warning")

    def test_failed_atomic_save_does_not_complete_or_snapshot(self):
        now = server.now_iso()
        with server.db() as connection:
            connection.execute("""INSERT INTO violation_report_reviews
                (report_id,review_status,internal_decision,decision_justification,updated_at,updated_by)
                VALUES (?,?,?,?,?,?)""", (
                "report-internal", "in_review", "warning", "Збережено", now, "Тест"))
        detail = {"id": "report-internal", "reason": "contractBreach", "decisions": [],
                  "has_official_decision": False, "authority_code": "40996564",
                  "deadline_control": {"supplier_ready": True}, "review": {}}
        with patch.object(server, "violation_report_detail", return_value=detail):
            with self.assertRaisesRegex(ValueError, "Невідоме внутрішнє рішення"):
                server.complete_violation_review("report-internal", "УО", {
                    "internal_decision": "invalid", "decision_justification": "Не зберігати"})
        with server.db() as connection:
            review = connection.execute("""SELECT completed_at,decision_justification FROM
                violation_report_reviews WHERE report_id='report-internal'""").fetchone()
            snapshots = connection.execute("""SELECT COUNT(*) FROM violation_report_review_events
                WHERE event_type='decision_context_snapshotted'""").fetchone()[0]
        self.assertFalse(review["completed_at"])
        self.assertEqual(review["decision_justification"], "Збережено")
        self.assertEqual(snapshots, 0)

    def test_stale_patch_cannot_change_completed_review(self):
        now = server.now_iso()
        with server.db() as connection:
            connection.execute("""INSERT INTO violation_report_reviews
                (report_id,review_status,internal_decision,completed_at,completed_by,updated_at,updated_by)
                VALUES (?,?,?,?,?,?,?)""", (
                "report-internal", "reviewed", "warning", now, "УО", now, "УО"))
        payload = report_payload()
        with patch.object(server, "api_get", return_value={"data": payload}):
            with self.assertRaisesRegex(PermissionError, "завершено"):
                server.save_violation_review("report-internal", {"review_status": "in_review"})
        with server.db() as connection:
            status = connection.execute("SELECT review_status FROM violation_report_reviews WHERE report_id='report-internal'").fetchone()[0]
        self.assertEqual(status, "reviewed")

    def test_local_completion_uses_snapshot_and_sync_does_not_overwrite_it(self):
        now = server.now_iso()
        snapshot = {"version": 1, "procurement_context": {"dk_code": "OLD-CPV"},
                    "recommendation": {"recommended_decision": "warning", "recommendation_reason": "Збережено"}}
        with server.db() as connection:
            connection.execute("""INSERT INTO violation_report_reviews
                (report_id,review_status,internal_decision,completed_at,completed_by,updated_at,updated_by)
                VALUES (?,?,?,?,?,?,?)""", (
                "report-internal", "reviewed", "warning", now, "УО", now, "УО"))
            connection.execute("""INSERT INTO violation_report_review_events
                (report_id,event_type,field_name,new_value,changed_at,changed_by)
                VALUES (?,?,?,?,?,?)""", (
                "report-internal", "decision_context_snapshotted", "decision_context_snapshot",
                json.dumps(snapshot, ensure_ascii=False), now, "УО"))
        with patch.object(server, "build_procurement_context", return_value={"available": False}):
            detail = server.violation_report_detail("report-internal", refresh=False)
        self.assertEqual(detail["read_only_reason"], "local_completion")
        self.assertEqual(detail["procurement_context"]["dk_code"], "OLD-CPV")
        self.assertEqual(detail["recommendation"]["recommendation_reason"], "Збережено")
        refreshed = report_payload()
        refreshed["dateModified"] = "2026-09-01T18:00:00+03:00"
        server.save_violation_report(refreshed)
        with patch.object(server, "build_procurement_context", return_value={"available": False}):
            after = server.violation_report_detail("report-internal", refresh=False)
        self.assertEqual(after["procurement_context"]["dk_code"], "OLD-CPV")
        refreshed["decisions"] = [{"id":"official","status":"satisfied","date":"2026-09-02"}]
        server.save_violation_report(refreshed)
        with patch.object(server, "build_procurement_context", return_value={"available": False}):
            official = server.violation_report_detail("report-internal", refresh=False)
        self.assertEqual(official["read_only_reason"], "official_decision")
        self.assertEqual(official["procurement_context"]["dk_code"], "OLD-CPV")
        self.assertEqual(official["recommendation"]["recommendation_reason"], "Збережено")
        late_rejection = {"available": True, "rejection_present": True,
                          "rejection_award_id": "later-award",
                          "rejection_datetime": "2026-09-29T09:20:17+03:00"}
        with patch.object(server, "build_procurement_context", return_value=late_rejection), \
                patch.object(server, "_fresh_violation_report", return_value=None):
            current = server.violation_report_detail("report-internal", refresh=True)
        self.assertEqual(current["procurement_context"]["dk_code"], "OLD-CPV")
        self.assertEqual(current["recommendation"]["recommendation_reason"], "Збережено")
        self.assertEqual(current["factual_procurement_context"]["rejection_award_id"], "later-award")

    def test_single_report_sheets_json_is_sparse_kyiv_dated_and_snapshot_only(self):
        snapshot = {"version": 1, "procurement_context": {
            "available": True,
            "dk_code": "15610000-7 — Продукція борошномельно-круп’яної промисловості",
            "winner_selected_at": "2026-08-23T22:30:00Z",
            "rejection_date": "2026-08-31T15:16:00+03:00",
            "rejection_title": "Підстава з finalized context",
        }, "recommendation": {}}
        now = server.now_iso()
        with server.db() as connection:
            connection.execute("""UPDATE violation_reports SET report_id=?,tender_pretty_id=?,
              author_name=?,author_code=?,defendant_name=?,defendant_code=?,description=?,reason=?
              WHERE id='report-internal'""", (
                "UA-D-2026-08-31-000001", "UA-2026-08-19-008079-a",
                "Замовник із Prozorro", "00112233", "Постачальник із Prozorro", "22222222",
                "Фактичний опис без перефразування", "contractBreach"))
            connection.execute("""INSERT INTO supplier_edr_profiles
              (supplier_code,full_name,short_name,synced_at) VALUES (?,?,?,?)""", (
                "22222222", "КАНОНІЧНА ПОВНА НАЗВА", "ТОВ «КОРОТКО»", now))
            connection.execute("""INSERT INTO violation_report_reviews
              (report_id,review_status,assigned_officer,internal_decision,protocol_number,
               protocol_date,customer_verified_full_name,customer_verified_short_name,
               updated_at,updated_by) VALUES (?,?,?,?,?,?,?,?,?,?)""", (
                "report-internal", "reviewed", "СВІТЛАНА НАМЯСЕНКО", "decline", "679-1",
                "2026-09-08", "КАНОНІЧНИЙ ЗАМОВНИК", "ЗАМОВНИК КОРОТКО", now, "УО"))
            connection.execute("""INSERT INTO violation_report_review_events
              (report_id,event_type,field_name,new_value,changed_at,changed_by)
              VALUES (?,?,?,?,?,?)""", (
                "report-internal", "decision_context_snapshotted", "decision_context_snapshot",
                json.dumps(snapshot, ensure_ascii=False), now, "УО"))
        with patch.object(server, "build_procurement_context") as live_lookup:
            payload = server.violation_report_sheets_json("UA-D-2026-08-31-000001")
        live_lookup.assert_not_called()
        self.assertEqual(payload["received_at"], "18.08.2026")
        self.assertEqual(payload["winner_selected_at"], "24.08.2026")
        self.assertEqual(payload["rejection_at"], "31.08.2026")
        self.assertEqual(payload["supplier_name"], "КАНОНІЧНА ПОВНА НАЗВА")
        self.assertEqual(payload["uo_decision"], "Відмова в задоволенні звернення")
        self.assertEqual(payload["output_name"], "UA-D-2026-08-31-000001_679-1_В")
        self.assertEqual(payload["legal_basis_short"], "пп. 1 п. 49")
        self.assertNotIn("contract_date", payload)
        self.assertNotIn("contract_number", payload)
        self.assertEqual(len(payload), 21)

    def test_sheets_json_eligibility_starts_at_reviewed_not_completed_at(self):
        now = server.now_iso()
        with server.db() as connection:
            connection.execute("""INSERT INTO violation_report_reviews
              (report_id,review_status,internal_decision,completed_at,updated_at,updated_by)
              VALUES (?,?,?,?,?,?)""", (
                "report-internal", "reviewed", "warning", "", now, "УО"))
        with patch.object(server, "build_procurement_context", return_value={"available": False}):
            detail = server.violation_report_detail("report-internal", refresh=False)
            payload = server.violation_report_sheets_json("report-internal")
        self.assertTrue(detail["sheets_json_available"])
        self.assertNotIn("protocol_number", payload)
        self.assertNotIn("protocol_date", payload)
        self.assertNotIn("output_name", payload)
        with server.db() as connection:
            connection.execute("UPDATE violation_report_reviews SET review_status='completed' "
                               "WHERE report_id='report-internal'")
        with patch.object(server, "build_procurement_context", return_value={"available": False}):
            completed = server.violation_report_detail("report-internal", refresh=False)
        self.assertTrue(completed["sheets_json_available"])

    def test_sheets_json_accepts_official_completed_projection_with_saved_decision(self):
        official = report_payload([{"id": "decision", "status": "declined", "date": "2026-09-08"}])
        server.save_violation_report(official)
        now = server.now_iso()
        with server.db() as connection:
            connection.execute("""INSERT INTO violation_report_reviews
              (report_id,review_status,internal_decision,protocol_number,protocol_date,
               updated_at,updated_by) VALUES (?,?,?,?,?,?,?)""", (
                "report-internal", "in_review", "decline", "P-1", "2026-09-08", now, "УО"))
        detail = server.violation_report_detail("report-internal", refresh=False)
        self.assertEqual(detail["review"]["review_status"], "completed")
        self.assertFalse(detail["local_review_completed"])
        self.assertTrue(detail["sheets_json_available"])
        with patch.object(server, "build_procurement_context", return_value={"available": False}):
            payload = server.violation_report_sheets_json("report-internal")
        self.assertEqual(payload["report_id"], "UA-D-TEST")
        self.assertEqual(payload["uo_decision"], "Відмова в задоволенні звернення")

    def test_sheets_json_rejects_in_review_without_completed_projection(self):
        now = server.now_iso()
        with server.db() as connection:
            connection.execute("""INSERT INTO violation_report_reviews
              (report_id,review_status,internal_decision,protocol_number,protocol_date,
               updated_at,updated_by) VALUES (?,?,?,?,?,?,?)""", (
                "report-internal", "in_review", "decline", "P-1", "2026-09-08", now, "УО"))
        detail = server.violation_report_detail("report-internal", refresh=False)
        self.assertEqual(detail["review"]["review_status"], "in_review")
        self.assertFalse(detail["sheets_json_available"])
        with self.assertRaisesRegex(PermissionError, "Розглянуто"):
            server.violation_report_sheets_json("report-internal")

    def test_sheets_json_legacy_procurement_fallback_is_one_case_only(self):
        now = server.now_iso()
        with server.db() as connection:
            connection.execute("""INSERT INTO violation_report_reviews
              (report_id,review_status,internal_decision,protocol_number,protocol_date,
               updated_at,updated_by) VALUES (?,?,?,?,?,?,?)""", (
                "report-internal", "reviewed", "decline", "P-2", "2026-09-08", now, "УО"))
        legacy = {"available": True, "dk_code": "99999999-9", "winner_selected_at": "2026-08-20"}
        with patch.object(server, "build_procurement_context", return_value=legacy) as lookup:
            payload = server.violation_report_sheets_json("report-internal")
        self.assertEqual(lookup.call_count, 1)
        self.assertEqual(lookup.call_args.args[0]["id"], "report-internal")
        self.assertEqual(payload["cpv"], "99999999-9")

    def test_read_only_card_and_sheets_json_share_case_scoped_resolved_context(self):
        official = report_payload([{"id": "decision", "status": "declined", "date": "2026-09-01"}])
        server.save_violation_report(official)
        now = server.now_iso()
        with server.db() as connection:
            connection.execute("""INSERT INTO violation_report_reviews
              (report_id,review_status,internal_decision,protocol_number,protocol_date,
               updated_at,updated_by) VALUES (?,?,?,?,?,?,?)""", (
                "report-internal", "in_review", "warning", "679-4", "2026-09-08", now, "УО"))
        resolved = {
            "available": True,
            "dk_code": "44110000-4 — Конструкційні матеріали",
            "winner_selected_at": "2026-08-21T10:00:00+03:00",
            "rejection_date": "2026-09-01T12:00:00+03:00",
            "rejection_title": "Канонічна підстава відхилення",
        }
        with patch.object(server, "build_procurement_context", return_value=resolved) as card_lookup:
            detail = server.violation_report_detail("report-internal", refresh=False)
        card_lookup.assert_called_once()
        self.assertTrue(detail["is_read_only"])
        self.assertEqual(detail["decision_context_source"], "case_scoped_resolver")
        self.assertEqual(detail["procurement_context"]["cpv"], resolved["dk_code"])
        self.assertEqual(detail["procurement_context"]["rejection_at"], resolved["rejection_date"])
        self.assertEqual(detail["procurement_context"]["rejection_reason"], resolved["rejection_title"])
        with patch.object(server, "build_procurement_context", return_value=resolved) as export_lookup:
            payload = server.violation_report_sheets_json("report-internal")
        export_lookup.assert_called_once()
        self.assertEqual(payload["cpv"], detail["procurement_context"]["cpv"])
        self.assertEqual(payload["winner_selected_at"], "21.08.2026")
        self.assertEqual(payload["rejection_at"], "01.09.2026")
        self.assertEqual(payload["rejection_reason"], detail["procurement_context"]["rejection_reason"])

    def test_unreviewed_read_only_card_resolves_factual_cpv_without_json_eligibility(self):
        official = report_payload([{"id": "decision", "status": "declined", "date": "2026-07-06"}])
        server.save_violation_report(official)
        resolved = {
            "available": True,
            "dk_code": "44110000-4 — Конструкційні матеріали",
            "contract_pretty_id": "UA-2026-06-22-011297-a-a2",
        }
        with patch.object(server, "build_procurement_context", return_value=resolved) as lookup:
            detail = server.violation_report_detail("report-internal", refresh=False)
        lookup.assert_called_once()
        self.assertTrue(detail["is_read_only"])
        self.assertFalse(detail["sheets_json_available"])
        self.assertIsNone(detail["procurement_context"])
        self.assertEqual(detail["factual_procurement_context_source"], "case_scoped_resolver")
        self.assertEqual(detail["factual_procurement_context"]["cpv"], resolved["dk_code"])
        self.assertEqual(detail["review"].get("internal_decision") or "", "")

    def test_justification_generation_is_blocked_before_supplier_deadline(self):
        payload = report_payload()
        payload["defendantPeriod"] = {"endDate": "2099-01-01T18:00:00+02:00"}
        payload["defendantStatements"] = []
        server.save_violation_report(payload)
        context = {
            "available": True, "rejection_present": True,
            "contract_guarantee_required": True, "rejected_before_deadline": False,
            "winner_selected_at": "2026-08-01T10:00:00+03:00",
            "contract_deadline": "2026-08-06", "rejection_date": "2026-08-07T12:00:00+03:00",
        }
        with server.db() as connection:
            connection.execute("""INSERT INTO violation_report_reviews
                (report_id,internal_decision,decision_justification,decision_template_key,
                 justification_source_hash,justification_generated_at,justification_manually_edited,
                 updated_at,updated_by) VALUES (?,?,?,?,?,?,?,?,?)""",
                ("report-internal", "warning", "Стара автоматична чернетка", "individual_review",
                 "old-hash", "2026-08-26T12:00:00+00:00", 0, server.now_iso(), "УО"))
        with patch.object(server, "build_procurement_context", return_value=context):
            detail = server.violation_report_detail("report-internal", refresh=False)
        self.assertFalse(detail["deadline_control"]["supplier_ready"])
        self.assertEqual(detail["justification_draft"], "")
        self.assertEqual(detail["justification_template_key"], "")
        self.assertFalse(detail["justification_stale"])
        self.assertTrue(detail["hide_saved_automatic_justification"])
        self.assertTrue(any("строк постачальника" in reason
                            for reason in detail["protocol_readiness"]["reasons"]))
        with patch.object(server, "api_get", return_value={"data": payload}), \
                patch.object(server, "build_procurement_context", return_value=context):
            with self.assertRaisesRegex(ValueError, "буде доступне після завершення строку"):
                server.save_violation_review("report-internal", {
                    "action": "regenerate_justification", "internal_decision": "warning",
                    "guarantee_documents_visible": False})

    def test_manual_justification_remains_visible_before_supplier_deadline(self):
        payload = report_payload()
        payload["defendantPeriod"] = {"endDate": "2099-01-01T18:00:00+02:00"}
        server.save_violation_report(payload)
        with server.db() as connection:
            connection.execute("""INSERT INTO violation_report_reviews
                (report_id,decision_justification,justification_manually_edited,updated_at,updated_by)
                VALUES (?,?,?,?,?)""", ("report-internal", "Ручний текст УО", 1, server.now_iso(), "УО"))
        with patch.object(server, "build_procurement_context", return_value={"available": True}):
            detail = server.violation_report_detail("report-internal", refresh=False)
        self.assertFalse(detail["hide_saved_automatic_justification"])
        self.assertEqual(detail["review"]["decision_justification"], "Ручний текст УО")

    def test_review_changes_are_audited_and_guarantee_is_tri_state(self):
        with patch.object(server, "api_get", return_value={"data": report_payload()}):
            server.save_violation_review("report-internal", {
                "additional_check_required": True, "guarantee_documents_visible": None,
                "supplier_explanation_assessment": "Документи переглянуто"})
        with server.db() as connection:
            review = connection.execute("SELECT * FROM violation_report_reviews").fetchone()
            events = connection.execute("SELECT COUNT(*) FROM violation_report_review_events").fetchone()[0]
        self.assertEqual(review["additional_check_required"], 1)
        self.assertIsNone(review["guarantee_documents_visible"])
        self.assertGreaterEqual(events, 2)

    def test_explicit_regeneration_records_hash_without_silent_overwrite(self):
        payload = report_payload()
        payload["defendantStatements"] = []
        server.save_violation_report(payload)
        context = {
            "rejection_present": True, "contract_guarantee_required": True,
            "rejected_before_deadline": False,
            "winner_selected_at": "2026-08-01T10:00:00+03:00",
            "contract_deadline": "2026-08-06", "rejection_date": "2026-08-07T12:00:00+03:00",
        }
        with patch.object(server, "api_get", return_value={"data": payload}), \
                patch.object(server, "build_procurement_context", return_value=context):
            result = server.save_violation_review("report-internal", {
                "action": "regenerate_justification", "internal_decision": "warning",
                "guarantee_documents_visible": False})
        self.assertTrue(result["review"]["decision_justification"])
        self.assertTrue(result["review"]["justification_source_hash"])
        self.assertFalse(result["review"]["justification_manually_edited"])
        self.assertEqual(result["review"]["decision_template_key"],
                         "p49_1_warning_guarantee_no_documents_no_explanation")
        self.assertFalse(result["justification_stale"],
                         "A freshly generated draft cannot be stale without an input change")
        changed_context = {**context, "rejection_date": "2026-08-08T12:00:00+03:00"}
        with patch.object(server, "build_procurement_context", return_value=changed_context):
            changed = server.violation_report_detail("report-internal", refresh=False)
        self.assertTrue(changed["justification_stale"])

    def test_p1_approved_template_requires_exact_supported_combination(self):
        report = {"reason": "contractBreach", "defendant_statements": []}
        context = {
            "rejection_present": True, "contract_guarantee_required": True,
            "rejected_before_deadline": False,
            "winner_selected_at": "2026-08-01T10:00:00+03:00",
            "contract_deadline": "2026-08-06", "rejection_date": "2026-08-07T12:00:00+03:00",
        }
        review = {"internal_decision": "warning", "guarantee_documents_visible": False}
        text = server.build_violation_decision_justification(report, context, review)
        self.assertNotIn("\r", text)
        self.assertNotIn("\n\n", text)
        self.assertIn("пп. 1 п. 49 Порядку № 822", text)
        self.assertIn("відсутні документи/відомості", text)
        self.assertNotIn("recommended_scenario", text)
        self.assertEqual(server.build_violation_decision_justification(
            report, context, {**review, "guarantee_documents_visible": None}), "")
        self.assertEqual(server.build_violation_decision_justification(
            {**report, "defendant_statements": [{"description": "Надано пояснення"}]},
            context, review), "")

    def test_p3_existing_no_court_no_explanation_justification_restored_exactly(self):
        report = {"reason": "goodsNonCompliance", "defendant_statements": []}
        review = {"internal_decision": "decline", "court_decision_final_present": False}
        expected = "\n".join((
            "Замовником подано звернення про порушення з посиланням на пп. 3 п. 49 Порядку № 822. Зазначена норма передбачає вжиття заходів реагування у разі, якщо постачальник не виконав зобов’язання за раніше укладеним договором із цим самим замовником, що призвело до його дострокового розірвання та застосування санкцій.",
            "Відповідно до положень Порядку № 822, факт невиконання зобов'язань та застосування санкцій (штрафів/збитків) має обов'язково підтверджуватися рішенням суду, що набрало законної сили.",
            "Однак Замовником до звернення не додано відповідного судового рішення, яке б підтверджувало факт порушення та застосування санкцій до Постачальника. Оскільки наявність такого рішення є імперативною (обов'язковою) умовою для кваліфікації порушення за пп. 3 п. 49 Порядку № 822, відсутність документального підтвердження унеможливлює задоволення звернення.",
            "Отже, Адміністратор приймає рішення про відмову в задоволенні звернення Замовника.",
        ))
        self.assertEqual(server.violation_decision_template_key(report, {}, review),
                         "p49_3_decline_no_final_court_decision_no_explanation")
        self.assertEqual(server.build_violation_decision_justification(report, {}, review), expected)
        for stored_value in (False, 0, "0", "false"):
            with self.subTest(stored_value=stored_value):
                self.assertEqual(server.violation_decision_template_key(
                    report, {}, {**review, "court_decision_final_present": stored_value}),
                    "p49_3_decline_no_final_court_decision_no_explanation")
        # The approved rule is only applied after the officer selects decline.
        unselected = {**review, "internal_decision": ""}
        self.assertEqual(server.violation_decision_template_key(report, {}, unselected), "")
        self.assertEqual(server.build_violation_decision_justification(report, {}, unselected), "")
        # Live SANDBOX UA-D-2026-09-25-000002: a saved manual text remains
        # authoritative in the card; the resolver must not rewrite it.
        saved = {**review, "decision_justification": expected}
        self.assertEqual(saved["decision_justification"], expected)
        for changed_report, changed_review in (
            (report, {**review, "court_decision_final_present": True}),
            (report, {**review, "court_decision_final_present": None}),
            (report, {**review, "internal_decision": "warning"}),
            ({**report, "defendant_statements": [{"description": "Пояснення"}]}, review),
        ):
            self.assertEqual(server.violation_decision_template_key(changed_report, {}, changed_review), "")

    def test_p3_decision_round_trip_recomputes_rule_from_current_tri_state_fact(self):
        payload = report_payload()
        payload["details"]["reason"] = "goodsNonCompliance"
        payload["defendantStatements"] = []
        server.save_violation_report(payload)
        context = {"available": True, "rejection_present": False}
        with patch.object(server, "api_get", return_value={"data": payload}), \
                patch.object(server, "build_procurement_context", return_value=context):
            first = server.save_violation_review("report-internal", {
                "action": "regenerate_justification", "internal_decision": "decline",
                "court_decision_final_present": "0"})
            draft = first["review"]["decision_justification"]
            self.assertTrue(draft)
            self.assertFalse(first["justification_stale"])
            warning = server.save_violation_review("report-internal", {"internal_decision": "warning"})
            self.assertEqual(warning["justification_template_key"], "")
            restored = server.save_violation_review("report-internal", {
                "action": "regenerate_justification", "internal_decision": "decline",
                "court_decision_final_present": "0"})
            self.assertEqual(restored["review"]["decision_justification"], draft)
            self.assertFalse(restored["justification_stale"])
            repeated = server.save_violation_review("report-internal", {
                "action": "regenerate_justification", "internal_decision": "decline",
                "court_decision_final_present": "0"})
            self.assertEqual(repeated["review"]["decision_justification"], draft)
            self.assertFalse(repeated["justification_stale"])
            manual = server.save_violation_review("report-internal", {
                "internal_decision": "warning", "decision_justification": "Ручний текст УО"})
            self.assertEqual(manual["review"]["decision_justification"], "Ручний текст УО")
            back_without_regeneration = server.save_violation_review("report-internal", {
                "internal_decision": "decline"})
            self.assertEqual(back_without_regeneration["review"]["decision_justification"], "Ручний текст УО")

    def test_contrary_officer_decision_requires_review_of_recommendation_draft(self):
        report = {"reason": "goodsNonCompliance", "defendant_statements": []}
        recommendation = {"recommended_decision": "decline"}
        draft = server.build_violation_decision_justification(
            report, {}, {"internal_decision": "decline", "court_decision_final_present": False})
        item = {**report, "recommendation": recommendation,
                "procurement_context": {"available": True},
                "deadline_control": {"supplier_ready": True},
                "review": {"internal_decision": "warning", "court_decision_final_present": False,
                           "decision_justification": draft}}
        gate = server.violation_protocol_readiness(item)
        self.assertTrue(any("не відповідає рішенню УО" in reason for reason in gate["reasons"]))
        item["review"].update(decision_template_key="p49_3_decline_no_final_court_decision_no_explanation",
                              justification_manually_edited=False,
                              decision_justification="Раніше автоматично збережений текст")
        gate = server.violation_protocol_readiness(item)
        self.assertTrue(any("не відповідає рішенню УО" in reason for reason in gate["reasons"]))
        item["review"]["justification_manually_edited"] = True
        item["review"]["decision_justification"] = "Перевірене та відредаговане УО обґрунтування."
        gate = server.violation_protocol_readiness(item)
        self.assertFalse(any("не відповідає рішенню УО" in reason for reason in gate["reasons"]))

    def test_generated_justification_fingerprint_ignores_sqlite_boolean_representation(self):
        report = {"reason": "contractBreach", "defendant_statements": [],
                  "description": "Підстава звернення"}
        context = {"winner_selected_at": "2026-09-24", "rejection_date": "2026-09-28"}
        saved = {"internal_decision": "decline", "additional_check_required": 0,
                 "guarantee_documents_visible": 0, "court_decision_final_present": 0}
        saved_fingerprint = server._justification_hash(report, context, saved)
        reopened = {**saved, "additional_check_required": False,
                    "guarantee_documents_visible": False, "court_decision_final_present": False}
        self.assertEqual(server._justification_hash(report, context, reopened), saved_fingerprint)
        self.assertNotEqual(server._justification_hash(report, context,
                            {**reopened, "additional_check_required": True}), saved_fingerprint)
        self.assertNotEqual(server._justification_hash(report,
                            {**context, "rejection_date": "2026-09-29"}, reopened), saved_fingerprint)

    def test_review_ready_separates_missing_facts_from_no_auto_rule(self):
        item = {"reason": "contractBreach", "deadline_control": {"supplier_ready": False},
                "procurement_context": {"winner_state": "present", "winner_selected_at": "2026-09-25",
                                        "rejection_present": False}, "review": {}}
        self.assertFalse(server.violation_review_ready(item))
        item["deadline_control"]["supplier_ready"] = True
        self.assertTrue(server.violation_review_ready(item))
        self.assertIsNone(server.violation_rules_engine("contractBreach", item["procurement_context"],
                                                        item["review"])["recommended_decision"])
        item["procurement_context"].update(winner_state="ambiguous", winner_selected_at=None)
        self.assertFalse(server.violation_review_ready(item))
        item["procurement_context"].update(winner_date_source="officer_manual",
                                            winner_selected_at="2026-09-26",
                                            winner_manual_provenance={"basis": "Перевірено ЕСЗ"})
        self.assertTrue(server.violation_review_ready(item))
        item["reason"] = "signingRefusal"
        self.assertFalse(server.violation_review_ready(item))
        item["review"]["written_refusal_date"] = "2026-09-28"
        self.assertTrue(server.violation_review_ready(item))
        item["reason"] = "goodsNonCompliance"
        self.assertFalse(server.violation_review_ready(item))
        item["review"]["court_decision_final_present"] = False
        self.assertTrue(server.violation_review_ready(item))

    def test_existing_p1_p2_justification_keys_remain_reachable(self):
        cases = (
            ({"reason": "contractBreach", "defendant_statements": []},
             {"available": True, "winner_state": "absent_confirmed"},
             {"internal_decision": "decline"}, "winner_absent_decline"),
            ({"reason": "contractBreach", "defendant_statements": []},
             {"rejection_present": True, "rejected_before_deadline": True},
             {"internal_decision": "decline"}, "p49_1_decline_before_deadline"),
            ({"reason": "contractBreach", "defendant_statements": []},
             {"rejection_present": True, "rejected_before_deadline": True,
              "day_5_shifted": True},
             {"internal_decision": "decline"}, "p49_1_decline_before_deadline_civil_shift"),
            ({"reason": "contractBreach", "defendant_statements": []},
             {"rejection_present": True, "rejected_before_deadline": False,
              "contract_guarantee_required": False},
             {"internal_decision": "warning"}, "p49_1_warning"),
            ({"reason": "contractBreach", "defendant_statements": []},
             {"rejection_present": True, "rejected_before_deadline": False,
              "contract_guarantee_required": True},
             {"internal_decision": "warning", "guarantee_documents_visible": False},
             "p49_1_warning_guarantee_no_documents_no_explanation"),
            ({"reason": "signingRefusal", "defendant_statements": []},
             {"written_refusal_within_deadline": True},
             {"internal_decision": "decline"}, "p49_2_decline_timely_refusal"),
            ({"reason": "signingRefusal", "defendant_statements": []},
             {"written_refusal_within_deadline": True, "day_3_shifted": True},
             {"internal_decision": "decline"}, "p49_2_decline_timely_refusal_civil_shift"),
        )
        for report, context, review, expected in cases:
            with self.subTest(expected=expected):
                self.assertEqual(server.violation_decision_template_key(report, context, review), expected)
                unselected = {**review, "internal_decision": ""}
                self.assertEqual(server.violation_decision_template_key(report, context, unselected), "")
                self.assertFalse(server.build_violation_decision_justification(report, context, unselected))
                opposite = "warning" if review["internal_decision"] == "decline" else "decline"
                self.assertEqual(server.violation_decision_template_key(
                    report, context, {**review, "internal_decision": opposite}), "")

    def test_both_live_p3_review_states_resolve_approved_draft_without_overwriting_manual_text(self):
        key = "p49_3_decline_no_final_court_decision_no_explanation"
        cases = (
            ("UA-D-2026-09-25-000002", "decline", "Збережений ручний текст УО"),
            ("UA-D-2026-09-29-000002", "", ""),
        )
        for report_id, officer_decision, saved_text in cases:
            with self.subTest(report_id=report_id):
                review = {"court_decision_final_present": False,
                          "internal_decision": officer_decision,
                          "decision_justification": saved_text}
                report = {"report_id": report_id, "reason": "goodsNonCompliance",
                          "defendant_statements": [], "review": review}
                recommendation = server.violation_rules_engine(
                    report["reason"], {"defendant_statements_present": False}, review)
                self.assertEqual(recommendation["recommended_decision"], "decline")
                self.assertEqual(recommendation["recommended_scenario"], "court_decision_absent")
                self.assertIn("пояснення постачальника — відсутні",
                              server.violation_scenario_summary(report, {}))
                self.assertEqual(server.violation_decision_template_key(report, {}, review),
                                 key if officer_decision else "")
                selected = {**review, "internal_decision": "decline"}
                draft = server.build_violation_decision_justification(report, {}, selected)
                self.assertTrue(draft.startswith("Замовником подано звернення про порушення"))
                self.assertEqual(review["decision_justification"], saved_text)
                if saved_text:
                    self.assertNotEqual(saved_text, draft)
                else:
                    self.assertEqual(saved_text or draft, draft)
                self.assertEqual(review["internal_decision"], officer_decision)

    def test_p1_warning_without_guarantee_uses_approved_base_scenario(self):
        report = {"reason": "contractBreach", "defendant_statements": []}
        context = {
            "rejection_present": True, "contract_guarantee_required": False,
            "rejected_before_deadline": False,
            "winner_selected_at": "2026-08-18T10:00:00+03:00",
            "contract_deadline": "2026-08-24", "rejection_date": "2026-08-25T12:00:00+03:00",
        }
        review = {"internal_decision": "warning", "guarantee_documents_visible": None}
        self.assertEqual(server.violation_decision_template_key(report, context, review),
                         "p49_1_warning")
        text = server.build_violation_decision_justification(report, context, review)
        self.assertIn("пп. 1 п. 49 Порядку № 822", text)
        self.assertIn("не надано жодних доказів або пояснень", text)
        self.assertNotIn("забезпечення виконання договору", text)

    def test_p2_approved_template_adds_civil_code_only_for_weekend_shift(self):
        report = {"reason": "signingRefusal", "defendant_statements": []}
        context = {
            "written_refusal_within_deadline": True, "day_3_shifted": True,
            "winner_selected_at": "2026-08-20T10:00:00+03:00", "day_3": "2026-08-23",
            "day_3_weekday_uk_accusative": "неділю", "written_refusal_deadline": "2026-08-24",
        }
        review = {"internal_decision": "decline", "written_refusal_date": "2026-08-24"}
        shifted = server.build_violation_decision_justification(report, context, review)
        self.assertNotIn("\r", shifted)
        self.assertNotIn("\n\n", shifted)
        self.assertIn("ч. 5 ст. 254 ЦК України", shifted)
        self.assertIn("пп. 2 п. 49 Порядку № 822", shifted)
        ordinary = server.build_violation_decision_justification(
            report, {**context, "day_3_shifted": False}, review)
        self.assertNotIn("ст. 254 ЦК України", ordinary)

    def test_p2_timely_refusal_recommendation_does_not_depend_on_later_rejection(self):
        facts = {"written_refusal_within_deadline": True,
                 "winner_selected_at": "2026-09-24T12:18:44+03:00",
                 "written_refusal_deadline": "2026-09-28",
                 "rejection_present": True,
                 "rejection_datetime": "2026-09-29T09:20:17+03:00",
                 "rejection_ambiguous": True}
        result = server.violation_rules_engine("signingRefusal", facts,
                                               {"written_refusal_date": "2026-09-24"})
        self.assertEqual(result["recommended_decision"], "decline")
        self.assertEqual(result["recommended_scenario"], "written_refusal_within_deadline")
        for rejection_present in (False, True):
            result = server.violation_rules_engine(
                "signingRefusal", {**facts, "rejection_present": rejection_present,
                                   "rejection_ambiguous": False},
                {"written_refusal_date": "2026-09-24"})
            self.assertEqual(result["recommended_decision"], "decline")

    def test_review_time_rejection_context_keeps_historical_winner_and_raw_evidence(self):
        cases = (
            ("UA-D-2026-09-28-000003", "contractBreach", "2026-09-28T11:30:28+03:00",
             "67428cb69cd04582972a2208f72efa9e", "2026-09-21T13:44:00+03:00",
             "a7577944b8824a0b9b84de6cd66bee20", "2026-09-28T11:33:37+03:00",
             "Непідписання договору"),
            ("UA-D-2026-09-25-000001", "signingRefusal", "2026-09-25T15:15:31+03:00",
             "5a57485c2052426091dd13c03ecb2c3f", "2026-09-24T12:18:44+03:00",
             "b89a345d8c7f433ba4f896b126fc4e15", "2026-09-29T09:20:17+03:00",
             "Письмова відмова"),
        )
        for report_id, reason, created, winner_id, notice_at, rejected_id, rejected_at, title in cases:
            with self.subTest(report_id=report_id):
                report = {"id": report_id, "report_id": report_id, "reason": reason,
                          "date_created": created, "tender_id": "test-tender",
                          "defendant_code": "22222222"}
                supplier = [{"identifier": {"id": "22222222"}}]
                winner = {"id": winner_id, "status": "cancelled", "qualified": True,
                          "date": rejected_at, "suppliers": supplier,
                          "documents": [{"id": "notice-1", "documentType": "notice",
                                         "datePublished": notice_at}]}
                rejected = {"id": rejected_id, "status": "unsuccessful", "qualified": False,
                            "date": rejected_at, "suppliers": supplier, "title": title,
                            "description": title,
                            "documents": [{"id": "rejection-doc", "title": "Протокол відмови.pdf"}]}
                tender = {"id": "test-tender", "awards": [winner, rejected]}
                with patch.object(server, "api_get", return_value={"data": tender}):
                    context = server.build_procurement_context(
                        report, {"written_refusal_date": "2026-09-24"})
                self.assertEqual(context["winner_award_id"], winner_id)
                self.assertEqual(context["historical_winner_decision"]["decision_date"], notice_at[:10])
                self.assertEqual(context["rejection_award_id"], rejected_id)
                self.assertEqual(context["rejection_datetime"], rejected_at)
                self.assertEqual(context["rejection_title"], title)
                self.assertEqual(context["rejection_provenance"]["award_id"], rejected_id)
                self.assertEqual(context["rejection_provenance"]["documents"][0]["id"], "rejection-doc")
                if reason == "signingRefusal":
                    self.assertTrue(context["written_refusal_within_deadline"])
                    self.assertEqual(server.violation_rules_engine(reason, context, {})[
                        "recommended_decision"], "decline")

    def test_review_time_rejection_states_distinguish_absent_from_ambiguous(self):
        supplier = [{"identifier": {"id": "22222222"}}]
        report = {"id": "case", "reason": "contractBreach", "tender_id": "test-tender",
                  "defendant_code": "22222222"}
        winner = {"id": "winner", "status": "active", "qualified": True,
                  "suppliers": supplier, "documents": []}
        with patch.object(server, "api_get", return_value={"data": {
                "id": "test-tender", "awards": [winner]}}):
            absent = server.build_procurement_context(report)
        self.assertFalse(absent["rejection_present"])
        self.assertFalse(absent["rejection_ambiguous"])
        self.assertEqual(absent["rejection_date_display"], "—")
        rejects = [{"id": key, "status": "unsuccessful", "qualified": False,
                    "suppliers": supplier, "date": "2026-09-29T09:20:17+03:00"}
                   for key in ("reject-1", "reject-2")]
        with patch.object(server, "api_get", return_value={"data": {
                "id": "test-tender", "awards": [winner, *rejects]}}):
            ambiguous = server.build_procurement_context(report)
        self.assertTrue(ambiguous["rejection_ambiguous"])
        self.assertIsNone(ambiguous["rejection_date_display"])
        self.assertIsNone(server.violation_rules_engine("contractBreach", ambiguous, {})[
            "recommended_decision"])

    def test_late_winner_is_review_time_deadline_base_without_report_date_comparison(self):
        report = {"id": "report-internal", "report_id": "UA-D-TEST",
                  "reason": "signingRefusal", "tender_id": "tender-id",
                  "defendant_code": "22222222",
                  "date_created": "2026-09-25T12:00:00+03:00"}
        winner = {"id": "late-winner", "status": "active", "qualified": True,
                  "suppliers": [{"identifier": {"id": "22222222"}}],
                  "documents": [{"id": "winner-notice", "documentType": "notice",
                                 "datePublished": "2026-09-26T10:00:00+03:00"}]}
        with patch.object(server, "api_get", return_value={"data": {
                "id": "tender-id", "awards": [winner]}}):
            context = server.build_procurement_context(
                report, {"contract_deadline_extended": True,
                         "written_refusal_date": "2026-09-29"})
        self.assertTrue(context["winner_present"])
        self.assertEqual(context["winner_state"], "present")
        self.assertFalse(context["winner_ambiguous"])
        self.assertEqual(context["winner_award_id"], "late-winner")
        self.assertEqual(context["winner_provenance"]["evidence_document"]["id"], "winner-notice")
        self.assertEqual(context["winner_selected_at"], "2026-09-26")
        self.assertEqual(context["written_refusal_deadline"], "2026-09-29")
        self.assertEqual(context["day_5"], "2026-10-01")
        self.assertEqual(context["day_10"], "2026-10-06")
        self.assertNotIn("winner_chronology_mismatch", context)
        self.assertTrue(context["written_refusal_within_deadline"])
        self.assertEqual(server.violation_rules_engine("signingRefusal", context, {})[
            "recommended_decision"], "decline")

    def test_winner_absent_declines_but_ambiguity_and_unavailable_do_not(self):
        report = {"id": "unsnapshotted-case", "reason": "signingRefusal",
                  "tender_id": "tender-id", "defendant_code": "22222222",
                  "date_created": "2026-09-25T12:00:00+03:00"}
        with patch.object(server, "api_get", return_value={"data": {
                "id": "tender-id", "awards": []}}):
            absent = server.build_procurement_context(report, {"written_refusal_date": "2026-09-29"})
        self.assertFalse(absent["winner_present"])
        self.assertEqual(absent["winner_state"], "absent_confirmed")
        self.assertFalse(absent["winner_ambiguous"])
        for reason in ("signingRefusal", "contractBreach"):
            decision = server.violation_rules_engine(reason, absent, {})
            self.assertEqual(decision["recommended_decision"], "decline")
            self.assertEqual(decision["recommended_scenario"], "winner_absent")
            approved = server.build_violation_decision_justification(
                {"reason": reason}, absent, {"internal_decision": "decline"})
            self.assertIn("Відсутня дата визначення переможцем", approved)
            self.assertIn("факт порушення", approved)
        ambiguous = {**absent, "winner_state": "ambiguous", "winner_ambiguous": True}
        self.assertIsNone(server.violation_rules_engine("signingRefusal", ambiguous, {})[
            "recommended_decision"])
        self.assertEqual(server.violation_rules_engine("signingRefusal", ambiguous, {})[
            "recommended_scenario"], "winner_unresolved")
        unavailable = {**absent, "available": False, "winner_state": "unavailable"}
        self.assertEqual(server.violation_rules_engine("signingRefusal", unavailable, {})[
            "recommended_scenario"], "winner_unavailable")

    def test_winner_same_day_uses_winner_date_without_report_date_comparison(self):
        report = {"id": "unsnapshotted-same-day", "reason": "signingRefusal",
                  "tender_id": "tender-id", "defendant_code": "22222222",
                  "date_created": "2026-09-26T09:00:00+03:00"}
        award = {"id": "same-day", "status": "active", "qualified": True,
                 "suppliers": [{"identifier": {"id": "22222222"}}],
                 "documents": [{"id": "notice", "documentType": "notice",
                                "datePublished": "2026-09-26T10:00:00+03:00"}]}
        with patch.object(server, "api_get", return_value={"data": {
                "id": "tender-id", "awards": [award]}}):
            context = server.build_procurement_context(report)
        self.assertTrue(context["winner_present"])
        self.assertEqual(context["winner_state"], "present")
        self.assertNotIn("winner_chronology_mismatch", context)

    def test_manual_winner_date_resolves_unknown_ambiguous_and_unavailable(self):
        report = {"id": "manual-winner-fixture", "reason": "signingRefusal",
                  "tender_id": "tender-id", "defendant_code": "22222222",
                  "date_created": "2026-09-25T12:00:00+03:00"}
        manual = {"manual_winner_date": "2026-09-26", "manual_winner_basis": "Перевірено ЕСЗ",
                  "manual_winner_entered_by": "Тестова УО",
                  "manual_winner_entered_at": "2026-10-04T12:00:00+03:00"}
        award = {"id": "no-notice", "status": "active", "qualified": True,
                 "suppliers": [{"identifier": {"id": "22222222"}}]}
        tenders = ({"id": "tender-id", "awards": [award]},
                   {"id": "tender-id", "awards": [
                       {**award, "id": "first", "documents": [{"id": "n1", "documentType": "notice",
                         "datePublished": "2026-09-26T10:00:00+03:00"}]},
                       {**award, "id": "second", "documents": [{"id": "n2", "documentType": "notice",
                         "datePublished": "2026-09-27T10:00:00+03:00"}]}]},
                   None)
        for expected_state, tender in zip(("unknown", "ambiguous", "unavailable"), tenders):
            with self.subTest(state=expected_state), patch.object(
                    server, "api_get", return_value={"data": tender}):
                context = server.build_procurement_context(report, manual)
                self.assertEqual(context["winner_state"], expected_state)
                self.assertEqual(context["winner_date_source"], "officer_manual")
                self.assertEqual(context["winner_selected_at"], "2026-09-26")
                self.assertEqual(context["winner_manual_provenance"]["basis"], "Перевірено ЕСЗ")
                self.assertEqual(context["written_refusal_deadline"], "2026-09-29")
                self.assertEqual(context["contract_deadline"], "2026-10-01")
                if expected_state != "unavailable":
                    self.assertEqual(server.build_procurement_context(
                        report, {**manual, "contract_deadline_extended": True})["contract_deadline"],
                        "2026-10-06")

    def test_confirmed_and_absent_winner_ignore_manual_date(self):
        report = {"id": "manual-priority-fixture", "reason": "contractBreach",
                  "tender_id": "tender-id", "defendant_code": "22222222"}
        manual = {"manual_winner_date": "2026-09-26", "manual_winner_basis": "Перевірено ЕСЗ",
                  "manual_winner_entered_by": "Тестова УО",
                  "manual_winner_entered_at": "2026-10-04T12:00:00+03:00"}
        award = {"id": "confirmed", "status": "active", "qualified": True,
                 "suppliers": [{"identifier": {"id": "22222222"}}],
                 "documents": [{"id": "notice", "documentType": "notice",
                                "datePublished": "2026-09-24T10:00:00+03:00"}]}
        with patch.object(server, "api_get", return_value={"data": {
                "id": "tender-id", "awards": [award]}}):
            confirmed = server.build_procurement_context(report, manual)
        self.assertEqual(confirmed["winner_date_source"], "prozorro")
        self.assertEqual(confirmed["winner_selected_at"], "2026-09-24")
        self.assertIsNone(confirmed["winner_manual_provenance"])
        with patch.object(server, "api_get", return_value={"data": {
                "id": "tender-id", "awards": []}}):
            absent = server.build_procurement_context(report, manual)
        self.assertEqual(absent["winner_state"], "absent_confirmed")
        self.assertEqual(absent["winner_date_source"], "absent_confirmed")
        self.assertIsNone(absent["winner_selected_at"])

    def test_unavailable_tender_does_not_override_frozen_prozorro_winner(self):
        with server.db() as connection:
            connection.execute("UPDATE violation_winner_decision_snapshots SET decision_json=? "
                               "WHERE report_id='report-internal'", (json.dumps({
                "award_id": "confirmed", "decision_date": "2026-09-24",
                "decision_datetime": "2026-09-24T10:00:00+03:00"}),))
        context = server._unavailable_winner_context({"id": "report-internal"}, {
            "manual_winner_date": "2026-09-26", "manual_winner_basis": "ЕСЗ",
            "manual_winner_entered_by": "УО", "manual_winner_entered_at": "2026-10-04T12:00:00+03:00"},
            "Tender API unavailable")
        self.assertEqual(context["winner_date_source"], "prozorro")
        self.assertEqual(context["winner_selected_at"], "2026-09-24T10:00:00+03:00")
        self.assertIsNone(context["winner_manual_provenance"])

    def test_manual_winner_persists_with_server_audit_fields(self):
        with server.db() as connection:
            raw_before = connection.execute("SELECT raw_json FROM violation_reports WHERE id='report-internal'").fetchone()[0]
            winner_before = connection.execute("SELECT decision_json FROM violation_winner_decision_snapshots WHERE report_id='report-internal'").fetchone()[0]
        with patch.object(server, "_fresh_violation_report", return_value=report_payload()), \
                patch.object(server, "violation_report_detail", return_value={"id": "report-internal"}):
            server.save_violation_review("report-internal", {
                "manual_winner_date": "2026-09-26", "manual_winner_basis": "Перевірено ЕСЗ"},
                updated_by="Тестова УО")
        with server.db() as connection:
            row = dict(connection.execute("SELECT manual_winner_date,manual_winner_basis,"
                "manual_winner_entered_by,manual_winner_entered_at FROM violation_report_reviews "
                "WHERE report_id='report-internal'").fetchone())
            self.assertEqual(connection.execute("SELECT raw_json FROM violation_reports WHERE id='report-internal'").fetchone()[0], raw_before)
            self.assertEqual(connection.execute("SELECT decision_json FROM violation_winner_decision_snapshots WHERE report_id='report-internal'").fetchone()[0], winner_before)
        self.assertEqual(row["manual_winner_date"], "2026-09-26")
        self.assertEqual(row["manual_winner_basis"], "Перевірено ЕСЗ")
        self.assertEqual(row["manual_winner_entered_by"], "Тестова УО")
        self.assertTrue(row["manual_winner_entered_at"])
        self.assertEqual(server._manual_winner_fact(row)["date"], "2026-09-26")
        with patch.object(server, "api_get", return_value={"data": {"id": "tender-id", "awards": [
                {"id": "no-notice", "status": "active", "qualified": True,
                 "suppliers": [{"identifier": {"id": "22222222"}}]}]}}):
            reopened = server.violation_report_detail("report-internal", refresh=False)
        self.assertEqual(reopened["review"]["manual_winner_date"], "2026-09-26")
        self.assertEqual(reopened["review"]["manual_winner_basis"], "Перевірено ЕСЗ")
        self.assertEqual(reopened["procurement_context"]["winner_date_source"], "officer_manual")
        frozen = server.violation_decision_context_snapshot({
            "id": "report-internal", "reason": "contractBreach",
            "procurement_context": {"winner_selected_at": "2026-09-26",
                                    "winner_date_source": "officer_manual",
                                    "winner_manual_provenance": server._manual_winner_fact(row)}},
            row, "2026-10-04T12:00:00+03:00")
        self.assertEqual(frozen["procurement_context"]["winner_date_source"], "officer_manual")
        self.assertEqual(frozen["procurement_context"]["winner_manual_provenance"]["entered_by"],
                         "Тестова УО")
        with self.assertRaisesRegex(ValueError, "джерело"):
            server._validate_manual_winner_edit({"manual_winner_date": "2026-09-27"}, {},
                                                "УО", server.now_iso())

    def test_manual_winner_control_is_sandbox_review_only(self):
        source = (server.ROOT / "app.js").read_text(encoding="utf-8")
        self.assertIn("['unknown','ambiguous','unavailable'].includes(c.winner_state)", source)
        self.assertIn('data-review="manual_winner_date"', source)
        self.assertIn('data-review="manual_winner_basis"', source)
        self.assertIn("Підтверджено УО вручну", source)

    def test_manual_winner_is_frozen_in_completed_decision_context(self):
        now = server.now_iso()
        with server.db() as connection:
            connection.execute("""INSERT INTO violation_report_reviews
                (report_id,review_status,assigned_officer,internal_decision,
                 decision_justification,manual_winner_date,manual_winner_basis,
                 manual_winner_entered_by,manual_winner_entered_at,updated_at,updated_by)
                 VALUES (?,?,?,?,?,?,?,?,?,?,?)""", (
                "report-internal", "in_review", "Тестова УО", "decline",
                "Ручне обґрунтування", "2026-09-26", "Перевірено ЕСЗ",
                "Тестова УО", now, now, "Тестова УО"))
        detail = {"id": "report-internal", "report_id": "UA-D-TEST",
                  "reason": "contractBreach", "tender_id": "tender-id",
                  "defendant_code": "22222222", "authority_code": "40996564",
                  "date_created": "2026-09-25T12:00:00+03:00",
                  "deadline_control": {"supplier_ready": True},
                  "defendant_statements": [], "has_official_decision": False}
        tender = {"id": "tender-id", "awards": [{"id": "no-notice", "status": "active",
                  "qualified": True, "suppliers": [{"identifier": {"id": "22222222"}}]}]}
        with patch.object(server, "violation_report_detail", return_value=detail), \
                patch.object(server, "api_get", return_value={"data": tender}):
            server.complete_violation_review("report-internal", "Тестова УО")
        with server.db() as connection:
            raw = connection.execute("SELECT new_value FROM violation_report_review_events "
                "WHERE report_id='report-internal' AND event_type='decision_context_snapshotted'").fetchone()[0]
        frozen = json.loads(raw)["procurement_context"]
        self.assertEqual(frozen["winner_date_source"], "officer_manual")
        self.assertEqual(frozen["winner_selected_at"], "2026-09-26")
        self.assertEqual(frozen["winner_manual_provenance"]["basis"], "Перевірено ЕСЗ")

    @patch.object(server, "violation_protocol_declensions", lambda _: [])
    def test_unmodelled_facts_allow_manual_officer_decision_and_protocol(self):
        context = {"available": True, "winner_present": True,
                   "winner_selected_at": "2026-09-26", "rejection_present": False,
                   "rejection_ambiguous": False}
        report = {"reason": "contractBreach"}
        auto = server.violation_rules_engine("contractBreach", context, {})
        self.assertIsNone(auto["recommended_decision"])
        review = {"assigned_officer": "УО", "internal_decision": "warning",
                  "decision_justification": "Ручне обґрунтування УО на підставі перевірених фактів.",
                  "protocol_number": "17", "protocol_date": "2026-10-04"}
        self.assertEqual(server.violation_decision_template_key(report, context, review), "")
        item = {**report, "review": review, "procurement_context": context,
                "deadline_control": {"supplier_ready": True}, "has_official_decision": False}
        gate = server.violation_protocol_readiness(item)
        self.assertTrue(gate["ready"], gate["reasons"])
        self.assertEqual(gate["protocol_type"], "warning")

    @patch.object(server, "violation_protocol_declensions", lambda _: [])
    def test_confirmed_winner_absence_uses_dash_only_in_manual_decline_protocol(self):
        item = {"id": "report-internal", "report_id": "UA-D-TEST",
                "reason": "contractBreach", "author_name": "ТОВ ЗАМОВНИК",
                "author_code": "11111111", "defendant_name": "ТОВ ПОСТАЧАЛЬНИК",
                "defendant_code": "22222222", "tender_pretty_id": "UA-TEST",
                "date_created": "2026-09-25T12:00:00+03:00",
                "deadline_control": {"supplier_ready": True, "supplier_deadline": "2026-09-28"},
                "has_official_decision": False,
                "procurement_context": {"available": True, "tender_date_published": "2026-09-20", "winner_present": False,
                                        "winner_state": "absent_confirmed",
                                        "winner_ambiguous": False, "rejection_present": False,
                                        "rejection_ambiguous": False},
                "review": {"assigned_officer": "УО", "internal_decision": "decline",
                           "decision_justification": "Переможця не визначено.",
                           "protocol_number": "17", "protocol_date": "2026-10-04"}}
        with patch.object(server, "require_local_violation_report_owned"), \
                patch.object(server, "require_owned_violation_report"), \
                patch.object(server, "violation_report_detail", return_value=item), \
                patch.object(server, "_resolve_violation_protocol_metadata", return_value={}):
            prepared = server.generate_violation_protocol("report-internal", {}, prepare_only=True)
        self.assertTrue(prepared["gate"]["ready"])
        self.assertEqual(prepared["values"]["winner_date"], "—")
        self.assertEqual(prepared["values"]["rejection_date"], "—")
        self.assertEqual(prepared["values"]["rejection_reason"], "—")
        for state in ("unknown", "ambiguous", "unavailable"):
            uncertain = {**item, "procurement_context": {
                **item["procurement_context"], "winner_state": state}}
            self.assertFalse(server.violation_protocol_readiness(uncertain)["ready"])
            claimed_date = {**uncertain, "procurement_context": {
                **uncertain["procurement_context"], "winner_selected_at": "2026-09-26"}}
            self.assertFalse(server.violation_protocol_readiness(claimed_date)["ready"])
            self.assertNotEqual(server.violation_decision_template_key(
                item, uncertain["procurement_context"], item["review"]),
                "winner_absent_decline")
            manual = {**uncertain, "procurement_context": {
                **uncertain["procurement_context"], "available": state != "unavailable",
                "winner_selected_at": "2026-09-26",
                "winner_date_source": "officer_manual",
                "winner_manual_provenance": {"date": "2026-09-26", "basis": "ЕСЗ",
                    "entered_by": "УО", "entered_at": "2026-10-04T12:00:00+03:00"}}}
            self.assertTrue(server.violation_protocol_readiness(manual)["ready"])
            with patch.object(server, "require_local_violation_report_owned"), \
                    patch.object(server, "require_owned_violation_report"), \
                    patch.object(server, "violation_report_detail", return_value=manual), \
                    patch.object(server, "_resolve_violation_protocol_metadata", return_value={}):
                prepared = server.generate_violation_protocol("report-internal", {}, prepare_only=True)
            self.assertEqual(prepared["values"]["winner_date"], "26.09.2026")

    def test_unsupported_reason_has_no_generated_legal_text(self):
        self.assertEqual(server.build_violation_decision_justification(
            {"reason": "goodsNonCompliance"}, {}, {"internal_decision": "warning"}), "")

    def test_violation_modal_uses_approved_wide_reason_specific_layout(self):
        source = (server.ROOT / "app.js").read_text(encoding="utf-8")
        self.assertIn('class="violation-top-row"', source)
        self.assertIn("Замовник", source)
        self.assertIn("Постачальник", source)
        self.assertIn("Закупівля · Договір · Звернення", source)
        self.assertIn("Підстава та докази замовника", source)
        self.assertIn("Строк для документів постачальника — 3 р.д.", source)
        self.assertIn("Пояснення та документи постачальника", source)
        self.assertIn("Обґрунтування рішення буде доступне після завершення строку", source)
        self.assertIn("hide_saved_automatic_justification", source)
        self.assertIn("До завершення строку постачальника", source)
        self.assertIn("data-copy-violation-json", source)
        self.assertIn("/sheets-json", source)
        self.assertIn("JSON скопійовано", source)
        self.assertIn("['Код ДК / CPV',c.cpv]", source)
        self.assertIn("['Дата визначення переможцем',displayDateOnly(c.winner_selected_at)]", source)
        self.assertIn("['Дата відхилення',displayDateOnly(c.rejection_at)]", source)
        self.assertIn("['Підстава відхилення',c.rejection_reason]", source)

        reason_fields = source[source.rfind("function violationReasonFields(item)"):
                               source.rfind("requestContextBlock=function(item)")]
        p1 = reason_fields[reason_fields.find("if(item.reason==='contractBreach')"):
                           reason_fields.find("if(item.reason==='signingRefusal')")]
        self.assertIn("Дата визначення переможцем", p1)
        self.assertIn("Забезпечення виконання договору", p1)
        self.assertIn("Дата укладення договору", source)
        self.assertIn("violationContractSigned", source)
        self.assertNotIn("Дата визначення переможцем не збігається з датою подання звернення", source)
        self.assertNotIn("winner_chronology_mismatch", source)
        self.assertIn("Автоматичну рекомендацію не визначено", source)
        self.assertIn("УО може внести обґрунтування вручну", source)
        p2 = reason_fields[reason_fields.find("if(item.reason==='signingRefusal')"):]
        self.assertIn("Дата письмової відмови</small>", p2)
        self.assertNotIn("Дата звернення замовника</small>", p2)
        self.assertIn("rejectionDate", p2)
        self.assertIn("rejectionGround", p2)
        self.assertIn("context.contract_info_required!==true", source)
        self.assertIn("context.rejection_present===true", source)
        self.assertNotIn("Письмова відмова", p1)
        self.assertNotIn("Рішення суду", p1)

        self.assertIn("syncContractDetails", source)
        self.assertIn("input.disabled=!enabled", source)

        module_css = (server.ROOT / "modules.css").read_text(encoding="utf-8")
        legacy_grid = module_css.find(".request-details-body{padding:18px 24px;display:grid")
        wide_override = module_css.rfind(".request-details-dialog-wide .request-details-body{display:block")
        self.assertGreater(wide_override, legacy_grid)
        self.assertIn(".request-details-dialog.request-details-dialog-wide{width:min(1500px,96vw)", module_css)


class WarningCivilCodeScenarioTests(unittest.TestCase):
    def test_late_rejection_warning_does_not_require_extra_civil_code(self):
        report = {"reason": "contractBreach", "defendant_statements": []}
        for shifted in (False, True):
            for guarantee in (False, True):
                context = {"rejection_present": True, "rejected_before_deadline": False,
                           "day_5_shifted": shifted, "contract_guarantee_required": guarantee}
                review = {"internal_decision": "warning", "guarantee_documents_visible": 0,
                          "decision_template_key": "p49_1_decline_before_deadline_civil_shift"}
                with self.subTest(shifted=shifted, guarantee=guarantee):
                    self.assertFalse(server.violation_civil_code_required(report, context, review))

    def test_refusals_and_other_warning_scenarios_preserve_existing_rules(self):
        for reason in ("contractBreach", "signingRefusal", "goodsNonCompliance"):
            for shifted in (False, True):
                context = {"day_5_shifted": shifted, "day_3_shifted": shifted,
                           "rejection_present": True, "rejected_before_deadline": True}
                report = {"reason": reason, "defendant_statements": []}
                expected = shifted if reason != "goodsNonCompliance" else False
                self.assertEqual(server.violation_civil_code_required(
                    report, context, {"internal_decision": "decline"}), expected)
                self.assertEqual(server.violation_civil_code_required(
                    report, context, {"internal_decision": "warning"}), expected)
        report = {"reason": "contractBreach", "defendant_statements": [{"description": "Пояснення"}]}
        context = {"rejection_present": True, "rejected_before_deadline": False, "day_5_shifted": True}
        self.assertTrue(server.violation_civil_code_required(report, context, {"internal_decision": "warning"}))
        self.assertTrue(server.violation_civil_code_required(
            {**report, "defendant_statements": []}, {**context, "rejection_ambiguous": True},
            {"internal_decision": "warning"}))

    def test_769_2_preparation_preserves_saved_text_and_other_requisites(self):
        item = {"id": "fixture-report", "report_id": "UA-D-2026-10-06-000002",
            "reason": "contractBreach", "author_name": "Замовник", "author_code": "11111111",
            "defendant_name": "Постачальник", "defendant_code": "22222222",
            "description": "Опис порушення без автоматичних доповнень", "defendant_statements": [],
            "deadline_control": {"supplier_ready": True},
            "procurement_context": {"available": True, "winner_selected_at": "2026-09-28",
                "tender_date_published": "2026-09-28", "day_5_shifted": True,
                "rejection_present": True, "rejection_date": "2026-10-06",
                "rejection_title": "Непідписання договору", "rejected_before_deadline": False},
            "review": {"internal_decision": "warning", "assigned_officer": "УО",
                "protocol_number": "769-2", "protocol_date": "2026-10-12",
                "decision_justification": "Обґрунтування УО збережене дослівно"}}
        before = json.loads(json.dumps(item))
        with patch.object(server, "require_local_violation_report_owned"), \
                patch.object(server, "require_owned_violation_report"), \
                patch.object(server, "violation_report_detail", return_value=item), \
                patch.object(server, "violation_protocol_declensions", return_value=[]), \
                patch.object(server, "_resolve_violation_protocol_metadata", return_value={}), \
                patch.object(server, "decline_name", side_effect=lambda value, entity, case:
                    DeclensionResult(value, "resolved", "automatic", value, entity)):
            prepared = server.generate_violation_protocol(item["id"], {}, prepare_only=True)
        self.assertFalse(prepared["flags"]["has_civil_code_basis"])
        for key, expected in (("protocol_number", "769-2"), ("protocol_date", "12.10.2026"),
                ("report_id", "UA-D-2026-10-06-000002"),
                ("violation_description", item["description"]),
                ("decision_justification", item["review"]["decision_justification"]),
                ("rejection_date", "06.10.2026")):
            self.assertEqual(prepared["values"][key], expected)
        self.assertEqual(item, before)


class ViolationProtocolFilenameTests(unittest.TestCase):
    def item(self):
        return {"report_id": "UA-D-2026-10-06-000001", "defendant_code": "45727617",
                "author_name": "ТЕРИТОРІАЛЬНЕ УПРАВЛІННЯ ДЕРЖАВНОЇ СУДОВОЇ АДМІНІСТРАЦІЇ УКРАЇНИ В КІРОВОГРАДСЬКІЙ ОБЛАСТІ",
                "defendant_name": "ТОВАРИСТВО З ОБМЕЖЕНОЮ ВІДПОВІДАЛЬНІСТЮ «СІСТО»",
                "review": {"customer_verified_short_name": "ТУДСА УКРАЇНИ В КІРОВОГРАДСЬКІЙ ОБЛАСТІ"},
                "supplier_verified": {"short_name": "ТОВ «СІСТО»"}}

    def gate(self, kind="decline_p49_1_2"):
        return {"protocol_number": "769-1", "protocol_type": kind}

    def test_exact_format_both_decisions_and_hyphen(self):
        for kind, marker in (("warning", "П"), ("decline_p49_1_2", "В"), ("decline_p49_3", "В")):
            self.assertEqual(server._violation_protocol_filename(self.item(), self.gate(kind)),
                f"UA-D-2026-10-06-000001_769-1_{marker}_ТУДСА УКРАЇНИ В КІРОВОГРАДСЬКІЙ ОБЛАСТІ (на ТОВ «СІСТО»; 45727617).docx")

    def test_missing_customer_short_uses_exact_report_name(self):
        item = self.item()
        item["review"] = {"customer_verified_short_name": "  ", "customer_verified_full_name": "ІНША НАЗВА"}
        name = server._violation_protocol_filename(item, self.gate())
        self.assertIn(item["author_name"], name)
        self.assertNotIn("ІНША НАЗВА", name)
        self.assertEqual(name, f"UA-D-2026-10-06-000001_769-1_В_{item['author_name']} (на ТОВ «СІСТО»; 45727617).docx")

    def test_long_unicode_full_names_are_preserved_not_linux_components(self):
        item = self.item(); item["review"] = {}; item["supplier_verified"] = {}
        name = server._violation_protocol_filename(item, self.gate())
        self.assertGreater(len(name.encode('utf-8')), 255)
        self.assertLessEqual(len(name.encode('utf-16-le')) // 2, 240)
        self.assertIn(item["author_name"], name)
        self.assertIn(item["defendant_name"], name)

    def test_missing_supplier_short_uses_exact_report_full_name(self):
        item = self.item()
        item["supplier_verified"] = {"full_name": "АКТУАЛЬНА ПОВНА НАЗВА З ЄДР", "short_name": "—"}
        name = server._violation_protocol_filename(item, self.gate())
        self.assertIn(item["supplier_verified"]["full_name"], name)
        self.assertNotIn(item["defendant_name"], name)

    def test_sanitization_preserves_unicode_punctuation_and_blocks_traversal(self):
        item = self.item()
        item["review"]["customer_verified_short_name"] = '  ../Назва<>:"/\\|?*\n  «тест»  '
        filename = server._violation_protocol_filename(item, self.gate())
        self.assertNotRegex(filename, r'[<>:"/\\|?*\x00-\x1f]')
        self.assertIn('«тест» (на ТОВ «СІСТО»; 45727617)', filename)
        self.assertIn('_769-1_В_', filename)
        self.assertEqual(Path(filename).name, filename)

    def test_supplier_filename_uses_same_quote_presentation_as_document_names(self):
        item = self.item()
        item["defendant_name"] = 'ТОВ "КОНТИНЕНТ-СТАЛЬ"'
        item["supplier_verified"] = {
            "full_name": 'ТОВ "КОНТИНЕНТ-СТАЛЬ"',
            "short_name": 'ТОВ "КОНТИНЕНТ-СТАЛЬ"',
        }
        names = server.protocol_supplier_names.resolve(item, server.normalize_document_name)
        for key in ("full_name", "short_name", "filename_name"):
            self.assertEqual(names[key]["value"], "ТОВ «КОНТИНЕНТ-СТАЛЬ»")
        filename = server._violation_protocol_filename(item, self.gate())
        self.assertIn("(на ТОВ «КОНТИНЕНТ-СТАЛЬ»; 45727617)", filename)
        self.assertNotIn('"КОНТИНЕНТ-СТАЛЬ"', filename)

    def test_missing_requisites_and_long_names_fail_without_truncation(self):
        for field in ("report_id", "defendant_code"):
            item = self.item(); item[field] = ""
            with self.assertRaisesRegex(ValueError, "реквізит"):
                server._violation_protocol_filename(item, self.gate())
        for party in ("customer", "supplier"):
            item = self.item()
            if party == "customer": item["review"] = {}; item["author_name"] = ""
            else: item["supplier_verified"] = {}; item["defendant_name"] = ""
            with self.assertRaisesRegex(ValueError, "назва"):
                server._violation_protocol_filename(item, self.gate())
        item = self.item(); item["review"]["customer_verified_short_name"] = "Назва" * 100
        with self.assertRaisesRegex(ValueError, "240"):
            server._violation_protocol_filename(item, self.gate())
        with self.assertRaisesRegex(ValueError, "номер протоколу"):
            server._violation_protocol_filename(self.item(), {**self.gate(), "protocol_number": ""})

    def test_download_header_and_docx_bytes_are_unchanged(self):
        with tempfile.TemporaryDirectory(ignore_cleanup_errors=True) as tmp:
            path = Path(tmp).resolve() / "violation-physical.docx"
            original = b"synthetic-docx-bytes"
            path.write_bytes(original)
            headers = {}
            request = SimpleNamespace(path="/api/protocol/files/violation-physical.docx",
                send_response=lambda status: self.assertEqual(status, 200),
                send_header=lambda key, value: headers.update({key: value}),
                end_headers=lambda: None, wfile=io.BytesIO())
            name = server._violation_protocol_filename(self.item(), self.gate())
            with patch.object(server, "PROTOCOLS_DIR", path.parent), \
                    patch.object(server, "_violation_protocol_download_filename", return_value=name):
                server.Handler._do_GET(request)
            encoded = headers["Content-Disposition"].split("filename*=UTF-8''", 1)[1]
            self.assertEqual(server.urllib.parse.unquote(encoded), name)
            self.assertEqual(request.wfile.getvalue(), original)
            self.assertEqual(path.read_bytes(), original)


class ProcurementPublicationDateTests(unittest.TestCase):
    def test_source_is_exact_tender_notice_not_report_or_other_events(self):
        tender = {"id": "exact-tender", "tenderID": "UA-2026-09-28-004953-a",
                  "noticePublicationDate": "2026-09-27T22:30:00Z",
                  "dateCreated": "2026-09-20T10:00:00+03:00",
                  "dateModified": "2026-10-07T10:00:00+03:00", "awards": []}
        original = json.loads(json.dumps(tender))
        report = {"tender_id": "exact-tender", "report_id": "UA-D-2026-10-06-000001",
                  "date_created": "2026-10-06T10:00:00+03:00", "defendant_code": "22222222"}
        with patch.object(server, "api_get", return_value={"data": tender}) as api, \
                patch.object(server, "_report_winner_decision", return_value=None):
            context = server.build_procurement_context(report)
        api.assert_called_once_with(f"{server.API_ROOT}/tenders/exact-tender")
        self.assertEqual(context["tender_date_published"], "2026-09-28")
        self.assertEqual(context["tender_date_published_source"], "tender.noticePublicationDate")
        self.assertEqual(tender, original)
        for raw in (None, "not-a-date"):
            with self.subTest(raw=raw), \
                    patch.object(server, "api_get", return_value={"data": {**tender, "noticePublicationDate": raw}}), \
                    patch.object(server, "_report_winner_decision", return_value=None):
                missing = server.build_procurement_context(report)
                self.assertEqual(missing["tender_date_published"], "2026-09-28")
                self.assertEqual(missing["tender_date_published_source"], "tender_id_date")

    def test_missing_invalid_publication_fails_before_document_write(self):
        for value in (None, "", "invalid", "2026-02-30", "2026-09-28T10:00:00"):
            with self.subTest(value=value):
                item = {"date_created": "2026-10-06", "tender_pretty_id": "UA-2026-09-28-004953-a",
                        "procurement_context": {"tender_date_published": value}}
                with patch.object(server, "require_local_violation_report_owned"), \
                        patch.object(server, "require_owned_violation_report"), \
                        patch.object(server, "violation_report_detail", return_value=item), \
                        patch.object(server, "violation_protocol_readiness", return_value={"ready": True}), \
                        patch.object(server, "build_violation_protocol_docx") as renderer:
                    with self.assertRaisesRegex(ValueError, "Не вказано дату оголошення закупівлі"):
                        server.generate_violation_protocol("test", {}, prepare_only=True)
                    renderer.assert_not_called()

    def test_publication_timezone_calendar_bounds(self):
        self.assertEqual(server._procurement_publication_date("2026-09-27T22:30:00Z"), "2026-09-28")
        self.assertEqual(server._procurement_publication_date("2026-09-28T00:30:00+03:00"), "2026-09-28")
        self.assertEqual(server._procurement_publication_date("2026-09-28"), "2026-09-28")

    def test_fallback_requires_valid_calendar_and_exact_identity(self):
        report = {"tender_id": "exact", "tender_pretty_id": "UA-2026-09-28-004953-a"}
        tender = {"id": "exact", "tenderID": report["tender_pretty_id"],
                  "noticePublicationDate": None}
        fields = server._procurement_publication_fields(tender, report)
        self.assertEqual(fields["tender_date_published"], "2026-09-28")
        self.assertEqual(server._violation_publication_document_metadata(fields),
                         {"date": "2026-09-28", "source": "tender_id_date"})
        for invalid in (None, 123, "UA-2026-02-30-004953-a", "UA-2026-09-28-4953-a",
                        "UA-D-2026-09-28-000001", "UA-2026-09-28-004953-a-extra"):
            with self.subTest(invalid=invalid):
                fields = server._procurement_publication_fields({**tender, "tenderID": invalid},
                                                               {"tender_id": "exact"})
                self.assertEqual(fields["tender_date_published"], "")
        for changed in ({**tender, "id": "other"}, {**tender, "id": None},
                        {**tender, "tenderID": "UA-2026-09-29-004953-a"}):
            self.assertEqual(server._procurement_publication_fields(changed, report)["tender_date_published"], "")

    def test_api_date_wins_over_different_id_date(self):
        fields = server._procurement_publication_fields(
            {"id": "exact", "tenderID": "UA-2026-09-28-004953-a",
             "noticePublicationDate": "2026-09-29T00:30:00+03:00"}, {"tender_id": "exact"})
        self.assertEqual(fields["tender_date_published"], "2026-09-29")
        self.assertEqual(fields["tender_date_published_source"], "tender.noticePublicationDate")
        self.assertTrue(fields["tender_date_published_id_mismatch"])


if __name__ == "__main__":
    unittest.main()
