import copy
import hashlib
import json
from pathlib import Path
import subprocess
import unittest
import test_production_ui_release_integrity as guard

ROOT=Path(__file__).resolve().parent
MANIFEST_SHA='9902b0cf1e281cba3c1852a5be83df2d8d925f303a26c234c53744bcfeb93c5a'

class ProductionDstHotfixIntegrityTests(unittest.TestCase):
    def test_complete_manifest_and_immutable_history(self):
        raw=(ROOT/'validation/production_dst_hotfix_integrity_v1.json').read_bytes().replace(b'\r\n',b'\n')
        self.assertEqual(hashlib.sha256(raw).hexdigest(),MANIFEST_SHA)
        c=guard.DST_VARIANT
        self.assertEqual(c['baseline'],'292b0726b4adc13644c7f98721e569c8809ea785')
        self.assertTrue(guard.variant_matches(ROOT,c['files'],variant=c))
        for name,key in [('validation/production_ui_baseline_contract.json','historical_contract_sha256'),
                         ('validation/fixtures/production_dst_parent_292b072.zip','parent_fixture_sha256')]:
            data=(ROOT/name).read_bytes()
            if name.endswith('.json'):data=data.replace(b'\r\n',b'\n')
            self.assertEqual(hashlib.sha256(data).hexdigest(),c[key])

    def test_single_byte_mutations_partial_and_forged_manifests_fail(self):
        c=guard.DST_VARIANT
        for name in c['files']:
            data=(ROOT/name).read_bytes()
            with self.subTest(name=name):
                self.assertFalse(guard.variant_matches(ROOT,c['files'],variant=c,
                    overrides={name:bytes([data[0]^1])+data[1:]}))
        self.assertFalse(guard.variant_matches(ROOT,set(c['files'])-{'server.py'},variant=c))
        self.assertFalse(guard.variant_matches(ROOT,set(c['files'])|{'unexpected.py'},variant=c))
        forged=copy.deepcopy(c);forged['files']['server.py']='0'*64
        self.assertFalse(guard.variant_matches(ROOT,c['files'],variant=forged))

    def test_verified_declension_loader_regression(self):
        result=subprocess.run(['node','validation/declension_loader_result.cjs'],cwd=ROOT,
                              capture_output=True,text=True,timeout=30)
        self.assertEqual(result.returncode,0,result.stderr)
        self.assertIn('DECLENSION_LOADER_RESULT=PASS',result.stdout)

if __name__=='__main__':unittest.main()
