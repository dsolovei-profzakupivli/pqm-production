"""Isolated, destination-attested SANDBOX runtime. Never use a PROD DB.

Render Docker command: python sandbox_runtime.py
Local writes require the owned SANDBOX DB or storage. External mutations
require an independently attested SANDBOX-owned destination.
"""
from __future__ import annotations

import datetime
import base64
from contextlib import closing
from execution_digest import is_canonical_sha256_b64url
from execution_apply_contract import checkpoint_apply_enabled
import hashlib
import ipaddress
import json
import os
import re
from pathlib import Path
import secrets
import shutil
import socket
import sqlite3
import sys
import tempfile
import threading
import unicodedata
import urllib.parse
import urllib.request
from contextlib import contextmanager
import sandbox_documents
import sandbox_amcu

ROOT = Path(__file__).resolve().parent


class SandboxExecutionPreflightRejected(RuntimeError):
    """The local Sandbox egress policy rejected a request before network I/O."""


POLICY = {
    'PQM_SANDBOX': '1', 'PQM_ENV': 'test_web', 'PQM_SAFE_MODE': '1',
    'PQM_AUTH_ENABLED': '1', 'PQM_LOCAL_ROLE_IMPERSONATION': '0',
    'PQM_RELEASE_SCHEMA_ONLY': '1', 'PQM_ENABLE_BROWSER': '0',
    'PQM_ENABLE_SCHEDULER': '0', 'PQM_ENABLE_PROZORRO_SCHEDULER': '0',
    'PQM_ENABLE_VIOLATION_SCHEDULER': '0', 'PQM_ENABLE_NAZK_SCHEDULER': '0',
    'PQM_ENABLE_NAZK_WORKFLOW': '0', 'PQM_ENABLE_GOOGLE': '0',
    'PQM_ENABLE_BIDS_UPDATE': '0', 'PQM_ENABLE_POWERBI': '0',
    'PQM_BIDS_MODE': 'disabled',
}
ACCESS_FILE = '.sandbox-initial-access.json'
_guard_installed = False
_egress = threading.local()
PROZORRO_HOST = 'public-api.prozorro.gov.ua'
GOOGLE_TOKEN_HOST = 'oauth2.googleapis.com'
GOOGLE_SHEETS_HOST = 'sheets.googleapis.com'
NAZK_HOST = 'corruptinfo.nazk.gov.ua'
NAZK_PATH = '/ep/1.0/corrupt/getAllData'
SANDBOX_EDR_SPREADSHEET_ID = '1lZtneKmCTvFcEL0erlJbegVzTTLNA-IKnjempn1G8Ww'
SANDBOX_PARTIAL_RECONCILIATION_REQUEST_FINGERPRINT = '9be34ff2df1e661346176eeb'
SANDBOX_PARTIAL_RECONCILIATION_REQUEST_FINGERPRINTS = frozenset({
    SANDBOX_PARTIAL_RECONCILIATION_REQUEST_FINGERPRINT,
    '18a4aba10c1c13ab3bf59f56',
    '30331b560493209210f1e507',
    '816c6424279bff220878b0c4',
})
SANDBOX_LEGACY_WRITER_REQUEST_IDS = frozenset({'592128d9837d4b71bbeb330ef8aabf4b'})
_original_getaddrinfo = socket.getaddrinfo


def _sandbox_append_identity_digest(identities):
    """Digest sorted [tab,row,code] identities using the Writer canonical JSON contract."""
    normalized=sorted(identities,key=lambda item:(item[0],item[1],item[2]))
    raw=json.dumps(normalized,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode('utf-8')
    return base64.urlsafe_b64encode(hashlib.sha256(raw).digest()).decode().rstrip('=')


def validate_environment(env=None):
    env = os.environ if env is None else env
    for key, expected in POLICY.items():
        if env.get(key) != expected:
            raise RuntimeError(f'STOP: sandbox policy requires {key}={expected}')
    if env.get('PQM_SANDBOX_EDITS', '0') not in {'0', '1'}:
        raise RuntimeError('STOP: PQM_SANDBOX_EDITS must be 0 or 1')
    if env.get('PQM_SANDBOX_DOCUMENTS', '0') not in {'0', '1'}:
        raise RuntimeError('STOP: PQM_SANDBOX_DOCUMENTS must be 0 or 1')
    if env.get('PQM_SANDBOX_AMCU_READ', '0') not in {'0', '1'}:
        raise RuntimeError('STOP: PQM_SANDBOX_AMCU_READ must be 0 or 1')
    if env.get('PQM_SANDBOX_PROZORRO_READ', '0') not in {'0', '1'}:
        raise RuntimeError('STOP: PQM_SANDBOX_PROZORRO_READ must be 0 or 1')
    if env.get('PQM_SANDBOX_PROZORRO_SCHEDULER', '0') not in {'0', '1'}:
        raise RuntimeError('STOP: PQM_SANDBOX_PROZORRO_SCHEDULER must be 0 or 1')
    if env.get('PQM_SANDBOX_EDR_GOOGLE', '0') not in {'0', '1'}:
        raise RuntimeError('STOP: PQM_SANDBOX_EDR_GOOGLE must be 0 or 1')
    if env.get('PQM_SANDBOX_OPERATIONAL', '0') not in {'0', '1'}:
        raise RuntimeError('STOP: PQM_SANDBOX_OPERATIONAL must be 0 or 1')
    if env.get('PQM_SANDBOX_NAZK_READ', '0') not in {'0', '1'}:
        raise RuntimeError('STOP: PQM_SANDBOX_NAZK_READ must be 0 or 1')
    if env.get('PQM_SANDBOX_REQUESTS_SCHEDULER', '0') not in {'0', '1'}:
        raise RuntimeError('STOP: invalid sandbox requests scheduler opt-in')
    if env.get('PQM_SANDBOX_EDR_SPREADSHEET_ID') not in (None, '', SANDBOX_EDR_SPREADSHEET_ID):
        raise RuntimeError('STOP: sandbox EDR spreadsheet identity mismatch')
    if env.get('PQM_SANDBOX_EDR_GOOGLE') == '1' or env.get('PQM_SANDBOX_EDR_REDIRECT_URI'):
        redirect = env.get('PQM_SANDBOX_EDR_REDIRECT_URI', '')
        parsed_redirect = urllib.parse.urlsplit(redirect)
        if (parsed_redirect.scheme != 'https' or not re.fullmatch(r'pqm-sandbox(?:-[a-z0-9]+)?\.onrender\.com', parsed_redirect.hostname or '')
                or parsed_redirect.path != '/api/google-oauth/callback' or parsed_redirect.query or parsed_redirect.fragment
                or parsed_redirect.username or parsed_redirect.password):
            raise RuntimeError('STOP: sandbox EDR OAuth redirect URI mismatch')
    data = Path(env.get('PQM_DATA_DIR', '')).resolve()
    db = Path(env.get('PQM_DB_PATH', '')).resolve()
    if db != data / 'pqm_sandbox.sqlite3' or Path(env['PQM_DB_PATH']).is_symlink():
        raise RuntimeError('STOP: sandbox database path mismatch')
    service = env.get('RENDER_SERVICE_ID', '')
    if service:
        if (env.get('RENDER_SERVICE_NAME') != 'pqm-sandbox'
                or service != 'srv-dalfd77f3r2c7392uub0'
                or data != Path('/var/data').resolve()):
            raise RuntimeError('STOP: wrong Render service or disk path')
    elif not (env.get('PQM_SANDBOX_LOCAL_FIXTURE') == '1'
              and data.is_relative_to(Path(tempfile.gettempdir()).resolve())
              and data != Path(tempfile.gettempdir()).resolve()):
        raise RuntimeError('STOP: Render sandbox identity or isolated local fixture required')
    for key, child in [('PQM_PROTOCOLS_DIR', 'protocols'), ('PQM_CACHE_DIR', 'cache'),
                       ('PQM_LOG_DIR', 'logs')]:
        if env.get(key) and Path(env[key]).resolve() != data / child:
            raise RuntimeError(f'STOP: sandbox path mismatch: {key}')
    forbidden = {'PQM_USERS_JSON', 'PQM_SUPPLIER_REGISTRY_TOKEN'}
    if any(value for key, value in env.items()
           if key in forbidden or key.startswith('PQM_GOOGLE_OAUTH_')):
        raise RuntimeError('STOP: no inherited accounts, OAuth or integration credentials allowed')
    if (data / 'google_oauth').exists() and any((data / 'google_oauth').iterdir()):
        raise RuntimeError('STOP: sandbox must not contain OAuth files')
    # SANDBOX OAuth files belong to the SANDBOX destination; the production
    # OAuth directory above remains forbidden regardless of feature settings.
    return data, db, service or 'local-synthetic-fixture'


def edr_google_enabled():
    # Transport authorization is by destination identity, not by an action
    # switch. The OAuth paths and spreadsheet id remain SANDBOX-specific.
    return os.environ.get('PQM_SANDBOX') == '1'


def edr_google_route_allowed(method, path):
    # This is only a safe-mode exception; normal session auth/RBAC still applies.
    return edr_google_enabled() and method == 'POST' and path in {
        '/api/google-oauth/start', '/api/supplier-edr-sync/preview', '/api/supplier-edr-sync'}


def operational_enabled():
    return os.environ.get('PQM_SANDBOX') == '1'


def nazk_read_enabled():
    return operational_enabled()


def scheduler_job_allowed(job_key):
    return operational_enabled() and job_key in {'prozorro', 'violation_reports', 'nazk_registry'}


def attest_internal_target(db_path, *, require_operational=True):
    """Check the real owned DB immediately before a sandbox workflow may write."""
    if require_operational and not operational_enabled():
        raise RuntimeError('STOP: SANDBOX operational workflow is disabled')
    data, expected, service = validate_environment()
    target = Path(db_path)
    if (target.is_symlink() or target.resolve() != expected or
            expected != data / 'pqm_sandbox.sqlite3' or not expected.is_file()):
        raise RuntimeError('STOP: operation targets a non-SANDBOX database')
    _verify_existing(expected, service)
    return expected


def operational_route_allowed(method, path):
    """Safe-mode exception only; session auth and RBAC still decide access."""
    if not operational_enabled():
        return False
    if method == 'PATCH':
        return bool(re.fullmatch(r'/api/operational-tasks/[a-f0-9]{32}(?:/responses/\d+|/amcu-decisions/[^/]+)?', path))
    if method != 'POST':
        return False
    if path in {'/api/operational-tasks/rebuild', '/api/frameworks/refresh',
                '/api/violation-reports/sync',
                '/api/edr-monitoring/termination-exclusions/preview',
                '/api/edr-monitoring/termination-exclusions/create'}:
        return True
    if path == '/api/nazk-registry/refresh':
        return nazk_read_enabled()
    if path in {'/api/admin/scheduler-jobs/violation_reports',
                '/api/admin/scheduler-jobs/nazk_registry'}:
        return scheduler_job_allowed(path.rsplit('/', 1)[-1])
    # Task cards and responses are local SANDBOX records, never documents or sends.
    return bool(re.fullmatch(
        r'/api/operational-tasks/[a-f0-9]{32}(?:/channels/(?:supplier|nazk)/sent|'
        r'/responses|/nazk-result|/manager-tax-id|/blocking-decision|/blocking-complete)?', path))


def local_edits_enabled():
    return os.environ.get('PQM_SANDBOX') == '1'


def prozorro_read_enabled():
    return os.environ.get('PQM_SANDBOX') == '1'


def prozorro_scheduler_enabled():
    return prozorro_read_enabled() and os.environ.get('PQM_SANDBOX_PROZORRO_SCHEDULER', '0') == '1'


def prozorro_catchup_delay(db_path, moment):
    """Read-only restart decision: None=skip, 0=due, positive=retry delay.

    Never steal a live lease. An orphan expires after the existing 180s TTL;
    retrying here avoids waiting an extra hour after an interrupted deploy.
    A single manual framework import is not a successful automatic full run.
    """
    def parse(value):
        if not value:
            return None
        parsed = datetime.datetime.fromisoformat(value.replace('Z', '+00:00'))
        return parsed.replace(tzinfo=datetime.timezone.utc) if parsed.tzinfo is None else parsed
    with closing(sqlite3.connect(Path(db_path).resolve().as_uri() + '?mode=ro', uri=True)) as con:
        con.execute('PRAGMA query_only=ON')
        con.execute('BEGIN')
        lease = con.execute("SELECT lease_until FROM scheduler_job_leases WHERE job_key='prozorro'").fetchone()
        state = con.execute("SELECT last_status,last_trigger,last_finished_at FROM scheduler_job_state WHERE job_key='prozorro'").fetchone()
    if lease:
        remaining = (parse(lease[0]) - moment).total_seconds()
        if remaining > 0:
            return min(30, remaining)
    if state and state[0] != 'running' and state[1] in {'scheduled', 'startup_catchup'}:
        finished = parse(state[2])
        if finished and (moment - finished).total_seconds() < 3600:
            return None
    return 0


def manual_sync_allowed(method, path):
    # This does not grant a role permission; normal auth/RBAC still applies.
    return prozorro_read_enabled() and method == 'POST' and path == '/api/sync'


def validate_prozorro_url(url):
    parsed = urllib.parse.urlsplit(url)
    if (parsed.scheme != 'https' or parsed.netloc != PROZORRO_HOST
            or parsed.username or parsed.password or parsed.fragment
            or not re.fullmatch(r'/api/2\.5/(?:frameworks(?:/[a-zA-Z0-9_-]+(?:/(?:submissions|qualifications))?)?|agreements/[a-zA-Z0-9_-]+/contracts|violation_reports(?:/[a-zA-Z0-9_-]+)?|tenders/[a-zA-Z0-9_-]+)', parsed.path)
            or any(key != 'offset' for key in urllib.parse.parse_qs(parsed.query, keep_blank_values=True))):
        raise RuntimeError('Sandbox permits only public read-only Prozorro framework endpoints')


def _restricted_getaddrinfo(host, port, *args, **kwargs):
    if getattr(_egress, 'active', False):
        permitted_host = (getattr(_egress, 'google_host', None) or
                          getattr(_egress, 'execution_host', None) or
                          getattr(_egress, 'reference_host', None) or PROZORRO_HOST)
        if host != permitted_host or port not in (443, '443'):
            raise RuntimeError('Sandbox DNS destination is not approved')
        rows = _original_getaddrinfo(host, port, *args, **kwargs)
        if not rows or any(not ipaddress.ip_address(row[4][0]).is_global for row in rows):
            raise RuntimeError('Sandbox rejects non-public Prozorro addresses')
        _egress.addresses = {row[4][0] for row in rows}
        return rows
    return _original_getaddrinfo(host, port, *args, **kwargs)


class _ProzorroRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        validate_prozorro_url(newurl)
        return super().redirect_request(req, fp, code, msg, headers, newurl)


class _NoGoogleRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        raise RuntimeError('Sandbox Google redirect is not approved')


def validate_public_read_request(url, method):
    parsed = urllib.parse.urlsplit(url)
    search_read = method == 'POST' and url == 'https://prozorro.gov.ua/api/search/contracts'
    if (method != 'GET' and not search_read or parsed.scheme != 'https' or not parsed.hostname
            or parsed.port not in (None, 443) or parsed.username or parsed.password
            or parsed.fragment):
        raise RuntimeError('Sandbox external request is not a public read')
    return parsed.hostname


class _PublicReadRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        host = validate_public_read_request(newurl, 'GET')
        _egress.reference_host = host
        _egress.addresses = set()
        return super().redirect_request(req, fp, code, msg, headers, newurl)


@contextmanager
def external_read_open(request, timeout=60):
    """Destination-checked public GET; all external mutations remain blocked."""
    host = validate_public_read_request(request.full_url, request.get_method())
    if getattr(_egress, 'active', False):
        raise RuntimeError('Nested sandbox network scope is not supported')
    _egress.active = True
    _egress.public_read = True
    _egress.reference_host = host
    _egress.addresses = set()
    try:
        opener = urllib.request.build_opener(urllib.request.ProxyHandler({}), _PublicReadRedirect())
        with opener.open(request, timeout=timeout) as response:
            yield response
    finally:
        _egress.active = False
        _egress.public_read = False
        _egress.reference_host = None
        _egress.addresses = set()


def validate_nazk_request(url, method):
    parsed = urllib.parse.urlsplit(url)
    if (not nazk_read_enabled() or method != 'GET' or parsed.scheme != 'https'
            or parsed.hostname != NAZK_HOST or parsed.port not in (None, 443)
            or parsed.path != NAZK_PATH or parsed.query or parsed.fragment
            or parsed.username or parsed.password):
        raise RuntimeError('Sandbox NAZK source is not approved')
    return NAZK_HOST


def fetch_nazk_bytes(url):
    """One bounded public GET; no generic network exception or destination write."""
    host = validate_nazk_request(url, 'GET')
    if getattr(_egress, 'active', False):
        raise RuntimeError('Nested sandbox network scope is not supported')
    _egress.active = True
    _egress.reference_host = host
    _egress.addresses = set()
    try:
        request = urllib.request.Request(url, headers={'Accept': 'application/json'}, method='GET')
        opener = urllib.request.build_opener(urllib.request.ProxyHandler({}), _NoGoogleRedirect())
        with opener.open(request, timeout=900) as response:
            raw = response.read(128 * 1024 * 1024 + 1)
            if len(raw) > 128 * 1024 * 1024:
                raise RuntimeError('Sandbox NAZK source exceeds read limit')
            return raw
    finally:
        _egress.active = False
        _egress.reference_host = None
        _egress.addresses = set()


def validate_google_request(url, method):
    if not edr_google_enabled():
        raise RuntimeError('Sandbox Google EDR path is disabled')
    if not isinstance(url, str) or any(ord(char) < 32 or ord(char) == 127 for char in url):
        raise RuntimeError('Sandbox Google destination is malformed')
    try:
        parsed = urllib.parse.urlsplit(url)
        valid_authority = (parsed.scheme == 'https' and parsed.port in (None, 443)
                           and not parsed.username and not parsed.password and not parsed.fragment)
    except (TypeError, ValueError):
        valid_authority = False
    if not valid_authority:
        raise RuntimeError('Sandbox Google destination is not approved')
    if method == 'POST' and parsed.hostname == GOOGLE_TOKEN_HOST and parsed.path == '/token' and not parsed.query:
        return GOOGLE_TOKEN_HOST
    if parsed.hostname != GOOGLE_SHEETS_HOST or method not in {'GET', 'POST', 'PUT', 'PATCH', 'DELETE'}:
        raise RuntimeError('Sandbox Google destination or method is not approved')
    # Decode every segment to a fixed point before comparing identities. An
    # encoded separator, dot segment or residual percent escape is ambiguous
    # to an upstream proxy and must never reach Google as a write target.
    raw_segments = parsed.path.split('/')
    if len(raw_segments) < 4 or raw_segments[0] != '' or any(not item for item in raw_segments[1:]):
        raise RuntimeError('Sandbox Google destination path is malformed')
    segments = []
    for raw in raw_segments[1:]:
        segment = raw
        for _ in range(8):
            try:
                decoded = urllib.parse.unquote(segment, errors='strict')
            except UnicodeDecodeError as exc:
                raise RuntimeError('Sandbox Google destination path is malformed') from exc
            if decoded == segment:
                break
            segment = decoded
        if ('%' in segment or '/' in segment or '\\' in segment or '?' in segment
                or '#' in segment or any(ord(char) < 32 or ord(char) == 127 for char in segment)
                or segment in {'.', '..'}
                or unicodedata.normalize('NFKC', segment) != segment):
            raise RuntimeError('Sandbox Google destination path is not canonical')
        segments.append(segment)
    identity = ['v4', 'spreadsheets', SANDBOX_EDR_SPREADSHEET_ID]
    valid_path = (segments == identity or
                  segments == ['v4', 'spreadsheets', SANDBOX_EDR_SPREADSHEET_ID + ':batchUpdate'] or
                  segments == identity + ['values:batchUpdate'] or
                  (len(segments) == 5 and segments[:4] == identity + ['values']))
    query = urllib.parse.parse_qs(parsed.query, keep_blank_values=True)
    if (valid_path and not ({'key', 'access_token', 'spreadsheetId', 'sheetId'} & query.keys())
            and not any(ord(char) < 32 for char in parsed.query)):
        return GOOGLE_SHEETS_HOST
    raise RuntimeError('Sandbox Google destination or method is not approved')


@contextmanager
def google_open(request, timeout=60):
    """One exact HTTPS request; never expose generic Google or network egress."""
    host = validate_google_request(request.full_url, request.get_method())
    if getattr(_egress, 'active', False):
        raise RuntimeError('Nested sandbox network scope is not supported')
    _egress.active = True
    _egress.google_host = host
    _egress.addresses = set()
    try:
        opener = urllib.request.build_opener(urllib.request.ProxyHandler({}), _NoGoogleRedirect())
        with opener.open(request, timeout=timeout) as response:
            yield response
    finally:
        _egress.active = False
        _egress.google_host = None
        _egress.addresses = set()


def validate_execution_request(request, environment, script_id, spreadsheet_id, deployment_id):
    """Only attested OAuth refresh or one pinned API-executable invocation."""
    expected_script = '1Ht0jL2xQc3hsd6uWKui4uA6o1z2Oe_BAUbZq8HTXcw6C1Kpyi7JxNtmQ'
    if (os.getenv('PQM_SANDBOX', '').lower() not in ('1', 'true') or
            os.getenv('RENDER_SERVICE_ID') != 'srv-dalfd77f3r2c7392uub0' or
            os.getenv('PQM_SANDBOX_EXECUTION_READY', '').lower() not in ('1', 'true') or
            not edr_google_enabled() or environment != 'SANDBOX' or
            script_id != expected_script or spreadsheet_id != SANDBOX_EDR_SPREADSHEET_ID or
            not re.fullmatch(r'[A-Za-z0-9_-]{20,256}', str(deployment_id or '')) or
            deployment_id != os.getenv('PQM_SANDBOX_EXECUTION_DEPLOYMENT_ID')):
        raise SandboxExecutionPreflightRejected('Sandbox execution identity or configuration is not approved')
    url = request.full_url
    if request.get_method() != 'POST' or not isinstance(request.data, bytes):
        raise SandboxExecutionPreflightRejected('Sandbox execution method is not approved')
    if url == 'https://oauth2.googleapis.com/token':
        try:
            fields = urllib.parse.parse_qs(request.data.decode('ascii'), strict_parsing=True)
            if (set(fields) != {'client_id', 'client_secret', 'refresh_token', 'grant_type'} or
                    any(len(v) != 1 or not v[0] for v in fields.values()) or
                    fields['grant_type'] != ['refresh_token']):
                raise ValueError()
        except (ValueError, UnicodeError):
            raise SandboxExecutionPreflightRejected('Sandbox execution OAuth request is not approved') from None
        return GOOGLE_TOKEN_HOST
    if url != 'https://script.googleapis.com/v1/scripts/' + deployment_id + ':run':
        raise SandboxExecutionPreflightRejected('Sandbox execution endpoint is not approved')
    try:
        body = json.loads(request.data)
        envelope = body['parameters'][0]
        payload = json.loads(envelope['payload'])
        if not isinstance(body, dict) or not isinstance(payload, dict):
            raise ValueError()
        action = payload.get('action')
        function = body.get('function')
        all_scope_endpoint = function == 'pqmSandboxAllScopeExecution20261109'
        append_diagnostic_endpoint = function == 'pqmSandboxAppendDiagnostic20261112'
        all_scope_shape = (all_scope_endpoint and action in {'apply', 'recover_apply_chunk'} and
            payload.get('environment') == 'SANDBOX' and payload.get('planScope') == 'ALL' and
            payload.get('requestId') not in SANDBOX_LEGACY_WRITER_REQUEST_IDS and
            payload.get('trigger') == 'manual' and
            is_canonical_sha256_b64url(payload.get('expectedDigest')) and
            type(payload.get('chunkIndex')) is int and 0 <= payload.get('chunkIndex') <= 499 and
            re.fullmatch(r'[0-9a-f]{32}', str(payload.get('chunkId') or '')) and
            is_canonical_sha256_b64url(payload.get('chunkDigest')) and
            payload.get('planId') == payload.get('requestId') and
            is_canonical_sha256_b64url(payload.get('chunkDetailsDigest')) and
            payload.get('chunkPhase') in {'append', 'update'} and
            (payload.get('chunkPhase') == 'update' and payload.get('chunkAddedAt') is None or
             payload.get('chunkPhase') == 'append' and isinstance(payload.get('chunkAddedAt'), str) and
             re.fullmatch(r'\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}[+-]\d{2}:\d{2}', payload.get('chunkAddedAt'))))
        diagnostic_targets = payload.get('targetIdentities')
        diagnostic_codes = set()
        diagnostic_targets_valid = isinstance(diagnostic_targets, list) and 1 <= len(diagnostic_targets) <= 10000
        if diagnostic_targets_valid:
            for item in diagnostic_targets:
                if (not isinstance(item, dict) or set(item) != {'tab', 'code', 'row'} or
                        item.get('tab') not in {'ФОП', 'ЮО'} or
                        not isinstance(item.get('code'), str) or
                        not re.fullmatch(r'\d{8,10}', item['code']) or
                        type(item.get('row')) is not int or item['row'] < 2 or
                        item['code'] in diagnostic_codes):
                    diagnostic_targets_valid = False
                    break
                diagnostic_codes.add(item['code'])
        append_diagnostic_shape = (append_diagnostic_endpoint and action == 'diagnose_append_plan' and
            set(payload) == {'environment', 'scriptId', 'spreadsheetId', 'contract', 'action',
                'requestId', 'actor', 'trigger', 'issuedAt', 'expiresAt', 'expectedDigest',
                'planScope', 'chunkIndex', 'chunkId', 'chunkDigest', 'planId',
                'detailsDigest', 'fullPlanDigest', 'sourceDigest', 'totalAppendCount', 'targetIdentities',
                'diagnosticMode'} and
            payload.get('diagnosticMode') == 'recovery' and
            payload.get('environment') == 'SANDBOX' and payload.get('planScope') == 'APPEND_ONLY' and
            isinstance(payload.get('requestId'), str) and
            re.fullmatch(r'[0-9a-f]{32}', payload['requestId']) and
            payload['requestId'] not in SANDBOX_LEGACY_WRITER_REQUEST_IDS and
            isinstance(payload.get('actor'), str) and bool(payload['actor'].strip()) and
            len(payload['actor']) <= 128 and payload.get('trigger') == 'manual' and
            type(payload.get('issuedAt')) is int and type(payload.get('expiresAt')) is int and
            payload['issuedAt'] < payload['expiresAt'] <= payload['issuedAt'] + 300 and
            is_canonical_sha256_b64url(payload.get('expectedDigest')) and
            is_canonical_sha256_b64url(payload.get('detailsDigest')) and
            is_canonical_sha256_b64url(payload.get('fullPlanDigest')) and
            is_canonical_sha256_b64url(payload.get('sourceDigest')) and
            type(payload.get('chunkIndex')) is int and payload['chunkIndex'] == 0 and
            re.fullmatch(r'[0-9a-f]{32}', str(payload.get('chunkId') or '')) and
            is_canonical_sha256_b64url(payload.get('chunkDigest')) and
            payload.get('planId') == payload.get('requestId') and
            type(payload.get('totalAppendCount')) is int and
            payload.get('totalAppendCount') == len(diagnostic_targets or []) and diagnostic_targets_valid)
        audit_targets=payload.get('auditTargets')
        audit_codes=set()
        audit_targets_valid=isinstance(audit_targets,list) and 1<=len(audit_targets)<=10000
        if audit_targets_valid:
            for item in audit_targets:
                if (not isinstance(item,list) or len(item)!=4 or item[0] not in {'ФОП','ЮО'} or
                        not isinstance(item[1],str) or not re.fullmatch(r'\d{8,10}',item[1]) or
                        type(item[2]) is not int or item[2]<2 or item[1] in audit_codes or
                        not is_canonical_sha256_b64url(item[3])):
                    audit_targets_valid=False;break
                audit_codes.add(item[1])
        try:
            audit_targets_digest=base64.urlsafe_b64encode(hashlib.sha256(json.dumps(
                audit_targets,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode('utf-8')).digest()).decode().rstrip('=')
        except (TypeError,ValueError): audit_targets_digest=None
        append_audit_page_shape = (append_diagnostic_endpoint and action == 'diagnose_append_plan' and
            set(payload) == {'environment','scriptId','spreadsheetId','contract','action','requestId','actor',
                'trigger','issuedAt','expiresAt','expectedDigest','planScope','chunkIndex','planId',
                'detailsDigest','fullPlanDigest','sourceDigest','totalAppendCount','diagnosticMode',
                'auditTargets','auditTargetsDigest'} and
            payload.get('diagnosticMode')=='audit' and payload.get('environment')=='SANDBOX' and
            payload.get('planScope')=='APPEND_ONLY' and isinstance(payload.get('requestId'),str) and
            re.fullmatch(r'[0-9a-f]{32}',payload['requestId']) and
            payload['requestId'] not in SANDBOX_LEGACY_WRITER_REQUEST_IDS and
            isinstance(payload.get('actor'),str) and bool(payload['actor'].strip()) and len(payload['actor'])<=128 and
            payload.get('trigger')=='manual' and type(payload.get('issuedAt')) is int and
            type(payload.get('expiresAt')) is int and payload['issuedAt']<payload['expiresAt']<=payload['issuedAt']+300 and
            is_canonical_sha256_b64url(payload.get('expectedDigest')) and
            is_canonical_sha256_b64url(payload.get('detailsDigest')) and
            is_canonical_sha256_b64url(payload.get('fullPlanDigest')) and
            is_canonical_sha256_b64url(payload.get('sourceDigest')) and
            type(payload.get('chunkIndex')) is int and payload['chunkIndex']==0 and
            payload.get('planId')==payload.get('requestId') and
            type(payload.get('totalAppendCount')) is int and 1<=payload['totalAppendCount']<=10000 and
            len(audit_targets or [])==payload['totalAppendCount'] and audit_targets_valid and
            is_canonical_sha256_b64url(payload.get('auditTargetsDigest')) and
            payload.get('auditTargetsDigest')==audit_targets_digest)
        append_audit_recovery_shape = (append_diagnostic_endpoint and action == 'diagnose_append_plan' and
            set(payload) == {'environment','scriptId','spreadsheetId','contract','action','requestId','actor',
                'trigger','issuedAt','expiresAt','expectedDigest','planScope','chunkIndex','chunkId','chunkDigest',
                'planId','detailsDigest','fullPlanDigest','sourceDigest','totalAppendCount','diagnosticMode',
                'auditTargets','auditTargetsDigest','expectedPlanCounts','expectedUpdateIdentityDigest',
                'expectedUpdateIdentities','expectedCellDigests'} and
            payload.get('diagnosticMode')=='audit_recovery' and payload.get('environment')=='SANDBOX' and
            payload.get('planScope')=='APPEND_ONLY' and isinstance(payload.get('requestId'),str) and
            re.fullmatch(r'[0-9a-f]{32}',payload['requestId']) and
            payload['requestId'] not in SANDBOX_LEGACY_WRITER_REQUEST_IDS and
            isinstance(payload.get('actor'),str) and bool(payload['actor'].strip()) and len(payload['actor'])<=128 and
            payload.get('trigger')=='manual' and type(payload.get('issuedAt')) is int and
            type(payload.get('expiresAt')) is int and payload['issuedAt']<payload['expiresAt']<=payload['issuedAt']+300 and
            is_canonical_sha256_b64url(payload.get('expectedDigest')) and
            is_canonical_sha256_b64url(payload.get('detailsDigest')) and
            is_canonical_sha256_b64url(payload.get('fullPlanDigest')) and
            is_canonical_sha256_b64url(payload.get('sourceDigest')) and
            type(payload.get('chunkIndex')) is int and payload['chunkIndex']==0 and
            re.fullmatch(r'[0-9a-f]{32}',str(payload.get('chunkId') or '')) and
            is_canonical_sha256_b64url(payload.get('chunkDigest')) and
            payload.get('planId')==payload.get('requestId') and
            type(payload.get('totalAppendCount')) is int and 1<=payload['totalAppendCount']<=10000 and
            len(audit_targets or [])==payload['totalAppendCount'] and audit_targets_valid and
            is_canonical_sha256_b64url(payload.get('auditTargetsDigest')) and
            payload.get('auditTargetsDigest')==audit_targets_digest and
            isinstance(payload.get('expectedPlanCounts'),dict) and
            set(payload['expectedPlanCounts'])=={'append','update','conflict','error'} and
            all(type(payload['expectedPlanCounts'].get(key)) is int and payload['expectedPlanCounts'][key]>=0
                for key in ('append','update','conflict','error')) and
            payload['expectedPlanCounts']['append']==payload['totalAppendCount'] and
            is_canonical_sha256_b64url(payload.get('expectedUpdateIdentityDigest')) and
            isinstance(payload.get('expectedUpdateIdentities'),list) and len(payload['expectedUpdateIdentities'])<=1000 and
            payload['expectedPlanCounts']['update']==len(payload['expectedUpdateIdentities']) and
            all(isinstance(item,list) and len(item)==3 and item[0] in ('ФОП','ЮО') and
                type(item[1]) is int and item[1]>=2 and isinstance(item[2],str) and
                re.fullmatch(r'\d{8,10}',item[2]) for item in payload['expectedUpdateIdentities']) and
            _sandbox_append_identity_digest(payload['expectedUpdateIdentities'])==payload['expectedUpdateIdentityDigest'] and
            isinstance(payload.get('expectedCellDigests'),dict) and 1<=len(payload['expectedCellDigests'])<=30 and
            all(re.fullmatch(r'(?:value|formula):[A-O]',str(key)) and is_canonical_sha256_b64url(value)
                for key,value in payload['expectedCellDigests'].items()))
        audit_field_targets=payload.get('auditFieldTargets')
        audit_field_codes=set()
        audit_field_targets_valid=isinstance(audit_field_targets,list) and 1<=len(audit_field_targets)<=25
        if audit_field_targets_valid:
            for item in audit_field_targets:
                if (not isinstance(item,list) or len(item)!=5 or item[0] not in {'ФОП','ЮО'} or
                        not isinstance(item[1],str) or not re.fullmatch(r'\d{8,10}',item[1]) or
                        type(item[2]) is not int or item[2]<2 or item[1] in audit_field_codes or
                        not is_canonical_sha256_b64url(item[3]) or not isinstance(item[4],list) or
                        len(item[4])!=15 or any(not isinstance(value,list) or len(value)!=2 or
                            value[0] not in {'blank','value','formula'} or
                            not is_canonical_sha256_b64url(value[1]) for value in item[4])):
                    audit_field_targets_valid=False;break
                audit_field_codes.add(item[1])
        try:
            audit_field_targets_digest=base64.urlsafe_b64encode(hashlib.sha256(json.dumps(
                audit_field_targets,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode('utf-8')).digest()).decode().rstrip('=')
        except (TypeError,ValueError): audit_field_targets_digest=None
        append_audit_fields_shape = (append_diagnostic_endpoint and action == 'diagnose_append_plan' and
            set(payload) == {'environment','scriptId','spreadsheetId','contract','action','requestId','actor',
                'trigger','issuedAt','expiresAt','expectedDigest','planScope','chunkIndex','planId',
                'detailsDigest','fullPlanDigest','sourceDigest','totalAppendCount','diagnosticMode',
                'auditFieldTargets','auditFieldTargetsDigest'} and
            payload.get('diagnosticMode')=='audit_fields' and payload.get('environment')=='SANDBOX' and
            payload.get('planScope')=='APPEND_ONLY' and isinstance(payload.get('requestId'),str) and
            re.fullmatch(r'[0-9a-f]{32}',payload['requestId']) and
            payload['requestId'] not in SANDBOX_LEGACY_WRITER_REQUEST_IDS and
            isinstance(payload.get('actor'),str) and bool(payload['actor'].strip()) and len(payload['actor'])<=128 and
            payload.get('trigger')=='manual' and type(payload.get('issuedAt')) is int and
            type(payload.get('expiresAt')) is int and payload['issuedAt']<payload['expiresAt']<=payload['issuedAt']+300 and
            is_canonical_sha256_b64url(payload.get('expectedDigest')) and
            is_canonical_sha256_b64url(payload.get('detailsDigest')) and
            is_canonical_sha256_b64url(payload.get('fullPlanDigest')) and
            is_canonical_sha256_b64url(payload.get('sourceDigest')) and
            type(payload.get('chunkIndex')) is int and payload['chunkIndex']==0 and
            payload.get('planId')==payload.get('requestId') and
            type(payload.get('totalAppendCount')) is int and 1<=payload['totalAppendCount']<=10000 and
            audit_field_targets_valid and
            is_canonical_sha256_b64url(payload.get('auditFieldTargetsDigest')) and
            payload.get('auditFieldTargetsDigest')==audit_field_targets_digest)
        close_unknown_shape = (all_scope_endpoint and action == 'close_unknown_run' and
            set(payload) == {'environment', 'scriptId', 'spreadsheetId', 'contract', 'action',
                'requestId', 'actor', 'trigger', 'issuedAt', 'expiresAt', 'expectedDigest',
                'planScope', 'closeId', 'closeEvidenceDigest', 'reasonDigest'} and
            payload.get('environment') == 'SANDBOX' and
            payload.get('planScope') in {'ALL', 'APPEND_ONLY'} and
            isinstance(payload.get('requestId'), str) and
            re.fullmatch(r'[0-9a-f]{32}', payload.get('requestId')) and
            isinstance(payload.get('actor'), str) and bool(payload.get('actor').strip()) and
            len(payload.get('actor')) <= 128 and payload.get('trigger') == 'manual' and
            type(payload.get('issuedAt')) is int and
            type(payload.get('expiresAt')) is int and
            payload.get('issuedAt') < payload.get('expiresAt') <= payload.get('issuedAt') + 300 and
            is_canonical_sha256_b64url(payload.get('expectedDigest')) and
            isinstance(payload.get('closeId'), str) and
            re.fullmatch(r'[0-9a-f]{32}', payload.get('closeId')) and
            is_canonical_sha256_b64url(payload.get('closeEvidenceDigest')) and
            is_canonical_sha256_b64url(payload.get('reasonDigest')))
        prewrite_preflight_fields = {'environment', 'scriptId', 'spreadsheetId', 'contract', 'action',
            'requestId', 'actor', 'trigger', 'issuedAt', 'expiresAt', 'expectedDigest', 'planScope',
            'chunkIndex', 'chunkId', 'chunkDigest', 'planId', 'prewriteStage',
            'targetIdentityDigest', 'targetIdentities'}
        legacy_prewrite_fields = {'legacyManifestRows', 'legacyManifestProjectionDigest'}
        prewrite_stage = payload.get('prewriteStage')
        prewrite_keys = set(payload)
        prewrite_identity_digest = None
        identity_pairs = []
        try:
            target_identities = payload.get('targetIdentities')
            if not isinstance(target_identities, list) or not 1 <= len(target_identities) <= 25:
                raise ValueError()
            codes = set()
            identity_pairs = []
            for identity in target_identities:
                if (not isinstance(identity, dict) or set(identity) != {'tab', 'code'} or
                        identity.get('tab') not in {'ФОП', 'ЮО'} or
                        not isinstance(identity.get('code'), str) or
                        not re.fullmatch(r'\d{8,10}', identity['code']) or
                        identity['code'] in codes):
                    raise ValueError()
                codes.add(identity['code'])
                identity_pairs.append([identity['tab'], identity['code']])
            identity_raw = json.dumps(identity_pairs, ensure_ascii=False, separators=(',', ':')).encode('utf-8')
            prewrite_identity_digest = base64.urlsafe_b64encode(
                hashlib.sha256(identity_raw).digest()).decode('ascii').rstrip('=')
        except (ValueError, TypeError, KeyError):
            target_identities = None
        legacy_prewrite_valid = True
        if prewrite_stage == 'LEGACY_V1_WRITEAHEAD_LIMIT_PROOF_V1':
            try:
                rows = payload.get('legacyManifestRows')
                projection = []
                if (payload.get('requestId') != 'b11433e8efb84b4492bf2df7c7c25908' or
                        not isinstance(rows, list) or len(rows) != 25):
                    raise ValueError()
                for item in rows:
                    if (not isinstance(item, dict) or set(item) != {'tab', 'row', 'code', 'formulaA'} or
                            item.get('tab') not in {'ФОП', 'ЮО'} or
                            type(item.get('row')) is not int or item['row'] < 2 or
                            not isinstance(item.get('code'), str) or
                            not re.fullmatch(r'\d{8,10}', item['code']) or
                            not isinstance(item.get('formulaA'), str) or not item['formulaA'].startswith('=')):
                        raise ValueError()
                    projection.append(item)
                projection_raw = json.dumps(projection, ensure_ascii=False, sort_keys=True,
                    separators=(',', ':')).encode('utf-8')
                projection_digest = base64.urlsafe_b64encode(
                    hashlib.sha256(projection_raw).digest()).decode('ascii').rstrip('=')
                if (projection_digest != payload.get('legacyManifestProjectionDigest') or
                        [[item['tab'], item['code']] for item in projection] != identity_pairs):
                    raise ValueError()
            except (ValueError, TypeError, KeyError):
                legacy_prewrite_valid = False
        elif prewrite_keys & legacy_prewrite_fields:
            legacy_prewrite_valid = False
        expected_prewrite_keys = (prewrite_preflight_fields | legacy_prewrite_fields
            if prewrite_stage == 'LEGACY_V1_WRITEAHEAD_LIMIT_PROOF_V1' else prewrite_preflight_fields)
        prewrite_preflight_shape = (all_scope_endpoint and action == 'prewrite_close_preflight' and
            prewrite_keys == expected_prewrite_keys and
            payload.get('environment') == 'SANDBOX' and payload.get('planScope') == 'APPEND_ONLY' and
            payload.get('trigger') == 'manual' and
            isinstance(payload.get('requestId'), str) and
            re.fullmatch(r'[0-9a-f]{32}', payload['requestId']) and
            isinstance(payload.get('actor'), str) and bool(payload['actor'].strip()) and
            len(payload['actor']) <= 128 and
            type(payload.get('issuedAt')) is int and type(payload.get('expiresAt')) is int and
            payload['issuedAt'] < payload['expiresAt'] <= payload['issuedAt'] + 300 and
            is_canonical_sha256_b64url(payload.get('expectedDigest')) and
            type(payload.get('chunkIndex')) is int and payload['chunkIndex'] == 0 and
            re.fullmatch(r'[0-9a-f]{32}', str(payload.get('chunkId') or '')) and
            is_canonical_sha256_b64url(payload.get('chunkDigest')) and
            payload.get('planId') == payload.get('requestId') and
            isinstance(prewrite_stage, str) and re.fullmatch(r'[A-Za-z0-9_]{1,40}', prewrite_stage) and
            is_canonical_sha256_b64url(payload.get('targetIdentityDigest')) and
            payload.get('targetIdentityDigest') == prewrite_identity_digest and
            target_identities is not None and legacy_prewrite_valid and
            (prewrite_stage != 'LEGACY_V1_WRITEAHEAD_LIMIT_PROOF_V1' or
             is_canonical_sha256_b64url(payload.get('legacyManifestProjectionDigest'))))
        prewrite_close_fields = {'closeId', 'closeEvidenceDigest', 'reasonDigest'}
        expected_prewrite_close_keys = (prewrite_preflight_fields | prewrite_close_fields |
            (legacy_prewrite_fields if prewrite_stage == 'LEGACY_V1_WRITEAHEAD_LIMIT_PROOF_V1' else set()))
        prewrite_close_shape = (all_scope_endpoint and action == 'close_prewrite_failure' and
            prewrite_keys == expected_prewrite_close_keys and
            payload.get('environment') == 'SANDBOX' and payload.get('planScope') == 'APPEND_ONLY' and
            payload.get('trigger') == 'manual' and
            isinstance(payload.get('requestId'), str) and re.fullmatch(r'[0-9a-f]{32}', payload['requestId']) and
            isinstance(payload.get('actor'), str) and bool(payload['actor'].strip()) and
            len(payload['actor']) <= 128 and
            type(payload.get('issuedAt')) is int and type(payload.get('expiresAt')) is int and
            payload['issuedAt'] < payload['expiresAt'] <= payload['issuedAt'] + 300 and
            is_canonical_sha256_b64url(payload.get('expectedDigest')) and
            isinstance(prewrite_stage, str) and prewrite_stage in {
                'source_and_sheet_guard', 'chunk_selection', 'append_prewrite_guard',
                'append_request_build', 'append_inflight_save',
                'APPS_SCRIPT_PREWRITE_GUARD_V1', 'LEGACY_V1_WRITEAHEAD_LIMIT_PROOF_V1'} and
            type(payload.get('chunkIndex')) is int and payload['chunkIndex'] == 0 and
            re.fullmatch(r'[0-9a-f]{32}', str(payload.get('chunkId') or '')) and
            is_canonical_sha256_b64url(payload.get('chunkDigest')) and
            payload.get('planId') == payload.get('requestId') and
            is_canonical_sha256_b64url(payload.get('targetIdentityDigest')) and
            payload.get('targetIdentityDigest') == prewrite_identity_digest and
            target_identities is not None and legacy_prewrite_valid and
            re.fullmatch(r'[0-9a-f]{32}', str(payload.get('closeId') or '')) and
            is_canonical_sha256_b64url(payload.get('closeEvidenceDigest')) and
            is_canonical_sha256_b64url(payload.get('reasonDigest')) and
            (prewrite_stage != 'LEGACY_V1_WRITEAHEAD_LIMIT_PROOF_V1' or
             is_canonical_sha256_b64url(payload.get('legacyManifestProjectionDigest'))))
        continuation_v2_fields = {'continuationVersion','continuationSourcePlanDigest','continuationExclusionsDigest'}
        continuation_v2_present = bool(set(payload) & continuation_v2_fields)
        continuation_guard_rows=payload.get('continuationGuardRows')
        continuation_guard_valid=(isinstance(continuation_guard_rows,list) and len(continuation_guard_rows)==25)
        if continuation_guard_valid:
            continuation_guard_seen=set()
            for item in continuation_guard_rows:
                identity=(item.get('tab'),item.get('row'),item.get('codeDigest')) if isinstance(item,dict) else None
                if (not isinstance(item,dict) or set(item)!={'tab','row','codeDigest','rowDigest','serviceDigest'} or
                        item.get('tab') not in {'ФОП','ЮО'} or type(item.get('row')) is not int or
                        item['row']<2 or identity in continuation_guard_seen or
                        not all(is_canonical_sha256_b64url(item.get(key)) for key in
                            ('codeDigest','rowDigest','serviceDigest'))):
                    continuation_guard_valid=False;break
                continuation_guard_seen.add(identity)
        continuation_v2_shape = (continuation_v2_present and
            continuation_v2_fields.issubset(payload) and payload.get('continuationVersion') == 2 and
            action in {'apply','resume_check'} and payload.get('environment') == 'SANDBOX' and
            payload.get('planScope') == 'APPEND_ONLY' and payload.get('trigger') == 'manual' and
            isinstance(payload.get('requestId'),str) and re.fullmatch(r'[0-9a-f]{32}',payload['requestId']) and
            payload.get('requestId')!=payload.get('continuationSourceRequestId') and
            type(payload.get('chunkIndex')) is int and 0<=payload['chunkIndex']<11 and
            is_canonical_sha256_b64url(payload.get('expectedDigest')) and
            is_canonical_sha256_b64url(payload.get('continuationPlanDigest')) and
            is_canonical_sha256_b64url(payload.get('continuationRemainingDigest')) and
            continuation_guard_valid and
            payload.get('continuationSourceRequestId') == '71487a74779f4445a186a8dbe6252fbc' and
            is_canonical_sha256_b64url(payload.get('continuationSourcePlanDigest')) and
            is_canonical_sha256_b64url(payload.get('continuationExclusionsDigest')) and
            (action!='resume_check' or is_canonical_sha256_b64url(payload.get('expectedCheckpointDigest'))))
        legacy_shape = (function == 'pqmSandboxExecution' and
            (action in ('preview', 'apply', 'reconcile_partial') or
                (action=='resume_check' and continuation_v2_shape)) and
            not (action == 'apply' and payload.get('planScope', 'ALL') == 'ALL') and
            (not continuation_v2_present or continuation_v2_shape))
        allowed_reconciliation_fingerprints = (
            SANDBOX_PARTIAL_RECONCILIATION_REQUEST_FINGERPRINTS |
            {SANDBOX_PARTIAL_RECONCILIATION_REQUEST_FINGERPRINT}
        )
        reconciliation_allowed = action == 'reconcile_partial' and (
            payload.get('trigger') == 'manual' and
            payload.get('expectedDigest') is None and
            isinstance(payload.get('actor'), str) and
            bool(payload.get('actor').strip()) and len(payload.get('actor')) <= 128 and
            isinstance(payload.get('requestId'), str) and
            re.fullmatch(r'[0-9a-f]{32}', payload.get('requestId')) and
            isinstance(payload.get('reconciliationId'), str) and
            re.fullmatch(r'[0-9a-f]{32}', payload.get('reconciliationId')) and
            payload.get('requestFingerprint') in allowed_reconciliation_fingerprints and
            hashlib.sha256(payload['requestId'].encode('utf-8')).hexdigest()[:24] ==
                payload.get('requestFingerprint') and
            is_canonical_sha256_b64url(payload.get('evidenceDigest'))
        )
        if (set(body) != {'function', 'devMode', 'parameters'} or
                not (legacy_shape or all_scope_shape or append_diagnostic_shape or append_audit_page_shape or append_audit_recovery_shape or append_audit_fields_shape or close_unknown_shape or prewrite_preflight_shape or prewrite_close_shape) or body['devMode'] is not False or
                len(body['parameters']) != 1 or
                set(envelope) != {'payload', 'signature'} or
                not re.fullmatch(r'[A-Za-z0-9_-]{43}', str(envelope['signature'])) or
                payload['environment'] != environment or payload['scriptId'] != script_id or
                payload['spreadsheetId'] != spreadsheet_id or
                payload['contract'] != 'pqm-mirror-datetime-v1' or
                action not in ('preview', 'apply', 'resume_check', 'reconcile_partial', 'recover_apply_chunk', 'close_unknown_run',
                    'prewrite_close_preflight', 'close_prewrite_failure', 'diagnose_append_plan') or
                (action == 'reconcile_partial' and not reconciliation_allowed) or
                (payload['action'] == 'apply' and not is_canonical_sha256_b64url(payload.get('expectedDigest'))) or
                (checkpoint_apply_enabled(environment) and payload['action'] == 'apply' and
                 (type(payload.get('chunkIndex')) is not int or not 0 <= payload['chunkIndex'] <= 499)) or
                (checkpoint_apply_enabled(environment) and payload['action'] == 'preview' and 'chunkIndex' in payload) or
                not re.fullmatch(r'Bearer [A-Za-z0-9._~+/-]+=*', request.get_header('Authorization', ''))):
            raise ValueError()
    except (ValueError, KeyError, TypeError, IndexError):
        raise SandboxExecutionPreflightRejected('Sandbox execution envelope is not approved') from None
    return 'script.googleapis.com'


@contextmanager
def execution_open(request, timeout, *, environment, script_id, spreadsheet_id, deployment_id):
    identity = (environment, script_id, spreadsheet_id, deployment_id)
    try:
        host = validate_execution_request(request, *identity)
    except SandboxExecutionPreflightRejected:
        # google_writer_execution is already loaded before this transport is
        # entered; its typed preflight exception keeps this local rejection out
        # of the remote-outcome-unknown path.
        from google_writer_execution import ExecutionPreflightError
        raise ExecutionPreflightError(
            'Execution transport preflight rejected; Apps Script was not called') from None
    if getattr(_egress, 'active', False):
        raise RuntimeError('Nested sandbox network scope is not supported')
    _egress.active = True
    _egress.execution_host = host
    _egress.execution_identity = identity
    _egress.addresses = set()
    try:
        opener = urllib.request.build_opener(urllib.request.ProxyHandler({}), _NoGoogleRedirect())
        with opener.open(request, timeout=timeout) as response:
            yield response
    finally:
        _egress.active = False
        _egress.execution_host = None
        _egress.execution_identity = None
        _egress.addresses = set()


def fetch_prozorro_json(url):
    """One bounded credential-free HTTPS GET, never a generic egress exception."""
    if not prozorro_read_enabled():
        raise RuntimeError('Sandbox Prozorro read is disabled')
    validate_prozorro_url(url)
    if getattr(_egress, 'active', False):
        raise RuntimeError('Nested sandbox network scope is not supported')
    _egress.active = True
    _egress.addresses = set()
    try:
        opener = urllib.request.build_opener(urllib.request.ProxyHandler({}), _ProzorroRedirect())
        request = urllib.request.Request(url, headers={'User-Agent': 'PQM-Sandbox/0.1', 'Accept': 'application/json'}, method='GET')
        with opener.open(request, timeout=60) as response:
            raw = response.read(32 * 1024 * 1024 + 1)
            if len(raw) > 32 * 1024 * 1024:
                raise RuntimeError('Sandbox Prozorro response exceeds limit')
            result = json.loads(raw)
            if not isinstance(result, dict) or 'data' not in result:
                raise RuntimeError('Sandbox Prozorro response is not an API payload')
            return result
    finally:
        _egress.active = False
        _egress.addresses = set()


def local_edit_allowed(method, path):
    """Allowlist, not a role grant. Normal RBAC/final/history guards still run.

    No imports, document generation, verification, NAZK results, builders,
    refresh or integration controls. Unknown/future routes stay blocked.
    """
    if not local_edits_enabled():
        return False
    routes = {
        'PATCH': (
            r'/api/applications/[A-Za-z0-9_-]+(?:/remark-selections)?',
            r'/api/account', r'/api/admin/users/[A-Za-z0-9._-]+',
            r'/api/admin/officers/\d+', r'/api/application-profiles/[A-Za-z0-9_-]+',
            r'/api/admin/declension-overrides/[a-f0-9]{20}',
        ),
        'POST': (
            r'/api/account/avatar', r'/api/admin/users',
            r'/api/admin/users/[A-Za-z0-9._-]+/avatar', r'/api/admin/officers',
            r'/api/chats', r'/api/chats/\d+/(?:messages|read|messages/\d+/marks)',
            r'/api/application-profiles', r'/api/history-columns',
            r'/api/admin/declension-overrides',
        ),
        'DELETE': (
            r'/api/account/avatar', r'/api/admin/users/[A-Za-z0-9._-]+(?:/avatar)?',
            r'/api/admin/officers/\d+', r'/api/application-profiles/[A-Za-z0-9_-]+',
            r'/api/admin/declension-overrides/[a-f0-9]{20}',
        ),
    }
    return any(re.fullmatch(pattern, path) for pattern in routes.get(method, ()))


def outbound_audit(event, args):
    # Defense in depth for this Python process. This is not an OS firewall.
    loopback = {'localhost', '127.0.0.1', '::1'}
    if event in {'socket.connect', 'socket.sendto'}:
        address = args[1] if event == 'socket.connect' else args[-1]
        scoped = (event == 'socket.connect' and (prozorro_read_enabled() or edr_google_enabled() or nazk_read_enabled())
                  and getattr(_egress, 'active', False) and isinstance(address, tuple)
                  and address[0] in getattr(_egress, 'addresses', set()) and address[1] == 443)
        if not scoped and (not isinstance(address, tuple) or address[0] not in loopback):
            raise RuntimeError('Sandbox outbound network is disabled')
    if event in {'socket.getaddrinfo', 'socket.gethostbyname', 'socket.gethostbyaddr'} and args[0] not in loopback:
        if not (event == 'socket.getaddrinfo' and getattr(_egress, 'active', False)
                and ((prozorro_read_enabled() and args[0] == PROZORRO_HOST)
                     or (edr_google_enabled() and args[0] == getattr(_egress, 'google_host', None))
                     or (edr_google_enabled() and args[0] == getattr(_egress, 'execution_host', None))
                     or (nazk_read_enabled() and args[0] == getattr(_egress, 'reference_host', None)))):
            raise RuntimeError('Sandbox external DNS is disabled')
    if event == 'urllib.Request' and getattr(_egress, 'active', False):
        if getattr(_egress, 'eds_verify', False):
            import sandbox_eds
            sandbox_eds.validate_verification_request(args[0], args[3], args[1])
        elif getattr(_egress, 'execution_host', None):
            request = urllib.request.Request(args[0], data=args[1], headers=args[2], method=args[3])
            validate_execution_request(request, *_egress.execution_identity)
        elif getattr(_egress, 'google_host', None):
            validate_google_request(args[0], args[3])
        elif getattr(_egress, 'public_read', False):
            validate_public_read_request(args[0], args[3])
        elif getattr(_egress, 'reference_host', None):
            validate_nazk_request(args[0], args[3])
        else:
            validate_prozorro_url(args[0])
            if args[1] is not None or args[3] != 'GET':
                raise RuntimeError('Sandbox external mutations are disabled')
    if event in {'subprocess.Popen', 'os.system', 'os.exec', 'os.posix_spawn'}:
        import sandbox_eds
        if sandbox_eds.permitted_process(event, args):
            return
        if sandbox_amcu.enabled() and sandbox_amcu.permitted_process(event, args):
            return
        if sandbox_documents.enabled() and sandbox_documents.permitted_process(event, args):
            return
        raise RuntimeError('Sandbox safe smoke does not launch child processes')


def install_outbound_guard():
    global _guard_installed
    if not _guard_installed:
        socket.getfqdn = lambda name='': name or 'localhost'
        socket.getaddrinfo = _restricted_getaddrinfo
        sys.addaudithook(outbound_audit)
        _guard_installed = True


def _verify_existing(db, service):
    with sqlite3.connect(db.as_uri() + '?mode=ro', uri=True) as con:
        con.execute('PRAGMA query_only=ON')
        try:
            identity = con.execute('SELECT environment,service_id FROM sandbox_deployment_identity').fetchall()
        except sqlite3.OperationalError as exc:
            raise RuntimeError('STOP: existing database has no sandbox ownership marker') from exc
        if identity != [('sandbox', service)]:
            raise RuntimeError('STOP: sandbox database belongs to another environment/service')
        enabled_jobs = {str(row[0]) for row in con.execute(
            'SELECT job_key FROM scheduler_job_settings WHERE enabled<>0')}
        if any(not scheduler_job_allowed(job_key) for job_key in enabled_jobs):
            raise RuntimeError('STOP: sandbox contains scheduler state without its own opt-in')
        if con.execute('SELECT COUNT(*) FROM runtime_feature_settings WHERE enabled<>0').fetchone()[0]:
            raise RuntimeError('STOP: sandbox contains enabled runtime integrations')
        if not con.execute("SELECT 1 FROM auth_users WHERE role='admin' AND active=1").fetchone():
            raise RuntimeError('STOP: sandbox has no active administrator; do not reset accounts')


def _bootstrap_snapshot(source, target):
    """Publish a standalone bootstrap DB without switching a shared WAL file.

    Legacy init helpers can retain committed connections until GC. SQLite
    refuses WAL -> DELETE on that file while those connections remain open.
    Backup includes committed WAL data and the unique destination has no other
    connections. This is used only for a new, disposable bootstrap DB.
    """
    if target.exists():
        raise RuntimeError('STOP: bootstrap snapshot destination already exists')
    with closing(sqlite3.connect(source.as_uri() + '?mode=ro', uri=True)) as src:
        with closing(sqlite3.connect(target)) as dst:
            src.backup(dst)
            if dst.execute('PRAGMA journal_mode=DELETE').fetchone()[0] != 'delete':
                raise RuntimeError('STOP: bootstrap snapshot is not standalone')
            if dst.execute('PRAGMA integrity_check').fetchone()[0] != 'ok':
                raise RuntimeError('STOP: invalid bootstrap snapshot')


def bootstrap(server):
    """Create only an absent sandbox DB; repeat startup is a read-only ownership check."""
    data, db, service = validate_environment()
    if os.environ.get('RENDER_SERVICE_ID') and not os.path.ismount(data):
        raise RuntimeError('STOP: persistent sandbox disk is not mounted')
    data.mkdir(mode=0o700, parents=True, exist_ok=True)
    if db.exists():
        _verify_existing(db, service)
        return {'created': False, 'fixture_applications': 0, 'credentials_written': False}
    # Never reuse an imported DB, a partial init or an old credential delivery.
    if any(p.name != 'lost+found' for p in data.iterdir()):
        raise RuntimeError('STOP: bootstrap requires a new empty sandbox disk')
    previous_db = server.DB_PATH
    stamp = datetime.datetime.now(datetime.timezone.utc).isoformat()
    accounts = [('sandbox.admin', 'admin', None), ('sandbox.officer', 'officer', 1),
                ('sandbox.viewer', 'viewer', None)]
    access = {name: secrets.token_urlsafe(24) for name, _, _ in accounts}
    with tempfile.TemporaryDirectory(prefix='.pqm-sandbox-bootstrap-', dir=data) as temp:
        stage = Path(temp)
        stage_db = stage / 'new.sqlite3'
        try:
            server.DB_PATH = stage_db
            server.init_db()
            server.init_reference_tables(stage_db)
            from migrations.additive import plan, verify
            target = json.loads((ROOT / 'migrations/target_schema.json').read_text())
            with server.db() as con:
                steps, blockers = plan(con, target)
                if blockers:
                    raise RuntimeError('STOP: incompatible sandbox schema')
                for sql in steps:
                    con.execute(sql)
                con.execute('CREATE TABLE sandbox_deployment_identity (environment TEXT NOT NULL, service_id TEXT NOT NULL, created_at TEXT NOT NULL)')
                con.execute('INSERT INTO sandbox_deployment_identity VALUES (?,?,?)', ('sandbox', service, stamp))
                con.execute('INSERT INTO authorized_officers(id,full_name,role,active,created_at,updated_at) VALUES (1,?,?,1,?,?)',
                            ('Тестова УО SANDBOX', 'УО', stamp, stamp))
                for name, role, officer in accounts:
                    con.execute('INSERT INTO auth_users(username,password_hash,role,officer_id,active,created_at,updated_at,created_by) VALUES (?,?,?,?,1,?,?,?)',
                                (name, server.hash_password(access[name]), role, officer, stamp, stamp, 'sandbox bootstrap'))
                for key in server.SCHEDULER_TARGETS:
                    server.scheduler_runtime.save_enabled(con, key, False, 'sandbox bootstrap')
                con.execute("INSERT INTO frameworks(id,pretty_id,dk_code,raw_json,synced_at) VALUES ('sandbox-framework','SANDBOX-TEST-ONLY','00000000-0','{}',?)", (stamp,))
                con.execute("INSERT INTO framework_officers(framework_id,officer,synced_at) VALUES ('sandbox-framework','Тестова УО SANDBOX',?)", (stamp,))
                for name, status in [('pending', 'pending'), ('admitted', 'active'), ('rejected', 'unsuccessful')]:
                    sid, qid = 'sandbox-' + name, 'sandbox-q-' + name
                    con.execute('INSERT INTO submissions(id,framework_id,supplier_name,supplier_code,date_published,qualification_id,raw_json,synced_at) VALUES (?,?,?,?,?,?,?,?)',
                                (sid, 'sandbox-framework', 'СИНТЕТИЧНИЙ ПОСТАЧАЛЬНИК — НЕ РОБОЧІ ДАНІ', '00000000', stamp, qid, '{}', stamp))
                    con.execute('INSERT INTO qualifications(id,framework_id,submission_id,status,raw_json,synced_at) VALUES (?,?,?,?,?,?)',
                                (qid, 'sandbox-framework', sid, status, '{}', stamp))
                    con.execute('INSERT INTO application_fields(submission_id,protocol_officer) VALUES (?,?)', (sid, 'Тестова УО SANDBOX'))
                verify(con)
            con.close()
            # Snapshot only our disposable new DB; never change journal mode
            # on the shared source or rely on init-helper connection GC.
            published_db = stage / 'published.sqlite3'
            _bootstrap_snapshot(stage_db, published_db)
            _verify_existing(published_db, service)
            secret = stage / ACCESS_FILE
            fd = os.open(secret, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
            with os.fdopen(fd, 'w') as stream:
                json.dump({'scope': 'pqm-sandbox only', 'created_at': stamp, 'accounts': access}, stream)
                stream.flush()
                os.fsync(stream.fileno())
            # Link is exclusive (unlike rename/replace), so an existing target cannot be overwritten.
            shutil.copytree(ROOT / 'templates', data / 'templates')
            os.link(secret, data / ACCESS_FILE)
            os.chmod(published_db, 0o600)
            os.link(published_db, db)
        finally:
            server.DB_PATH = previous_db
    return {'created': True, 'fixture_applications': 3, 'credentials_written': True}


def decorate_html(raw):
    text = raw.decode('utf-8')
    if os.environ.get('PQM_SANDBOX') == '1':
        text = text.replace('<html', '<html data-pqm-environment="sandbox" data-halloween="off" data-pqm-cat="on"', 1)
        current_brand = ('<div class="brand prod-brand"><img class="prod-brand-initials" '
                         'src="/assets/pqm-brand-mark-prod.svg" alt="" aria-hidden="true">'
                         '<span class="prod-brand-divider" aria-hidden="true"></span>'
                         '<span class="prod-brand-copy"><strong>Професійні закупівлі</strong>'
                         '<small>Procurement Qualification Manager</small></span>'
                         '<em id="environmentBanner" class="prod-brand-accessible">PQM</em></div>')
        sandbox_brand = ('<div class="brand sandbox-brand">'
                         '<img class="sandbox-brand-initials" src="/assets/pqm-brand-mark-prod.svg" width="82" height="40" alt="" aria-hidden="true">'
                         '<span class="sandbox-brand-divider" aria-hidden="true"></span>'
                         '<span class="sandbox-brand-copy"><strong class="halloween-title" style="position:relative">Професійні закупівлі'
                         '<img class="halloween-cat" src="assets/pqm-cat-no-hat.png" width="180" height="97" '
                         'style="position:absolute;pointer-events:none;max-width:none" alt="" aria-hidden="true" draggable="false"></strong>'
                         '<small>Procurement Qualification Manager</small></span>'
                         '<em id="environmentBanner" class="sandbox-brand-accessible">PQM</em></div>')
        if text.count(current_brand) != 1:
            raise RuntimeError('STOP: SANDBOX navbar brand markup mismatch')
        text = text.replace(current_brand, sandbox_brand, 1)
        prod_favicon = ('<link rel="icon" href="/assets/pqm-q-favicon-prod-192.png?v=6" type="image/png" sizes="192x192">'
                        '\n  <link rel="icon" href="/assets/pqm-q-favicon-prod.svg?v=6" type="image/svg+xml" sizes="any">'
                        '\n  <link rel="icon" href="/assets/pqm-q-favicon-prod-16.png?v=6" type="image/png" sizes="16x16">'
                        '\n  <link rel="icon" href="/assets/pqm-q-favicon-prod-32.png?v=6" type="image/png" sizes="32x32">'
                        '\n  <link rel="apple-touch-icon" href="/assets/pqm-q-favicon-prod-180.png?v=6">')
        prod_favicon = prod_favicon.replace('\n', '\r\n' if '\r\n' in text else '\n')
        sandbox_favicon = ('<link rel="icon" href="/assets/pqm-q-favicon-192.png?v=4" type="image/png" sizes="192x192">'
                           '<link rel="icon" href="/assets/pqm-q-favicon.svg?v=4" type="image/svg+xml" sizes="any">'
                           '<link rel="icon" href="/assets/pqm-q-favicon-16.png?v=4" type="image/png" sizes="16x16">'
                           '<link rel="icon" href="/assets/pqm-q-favicon-32.png?v=4" type="image/png" sizes="32x32">'
                           '<link rel="apple-touch-icon" href="/assets/pqm-q-favicon-180.png?v=4">')
        if text.count(prod_favicon) != 1:
            raise RuntimeError('STOP: SANDBOX favicon markup mismatch')
        text = text.replace(prod_favicon, sandbox_favicon, 1)
        theme = (ROOT / 'sandbox_theme.css').read_text(encoding='utf-8')
        text = text.replace('</head>', '<style id="pqmSandboxTheme">' + theme + '</style></head>', 1)
        text = text.replace('</head>', '<script src="/sandbox_contrast.js?v=1" defer></script></head>', 1)
        # Permanent geometry is independent of the seasonal resource pack.
        text = text.replace('</head>', '<link rel="stylesheet" href="pqm_cat.css"></head>', 1)
        # The permanent controller alone decides whether to request seasonal resources.
        text = text.replace('<link rel="stylesheet" href="halloween.css">', '', 1)
        halloween_anchor = '<script src="halloween.js"></script>'
        if text.count(halloween_anchor) != 1:
            raise RuntimeError('STOP: SANDBOX seasonal loader markup mismatch')
        text = text.replace(halloween_anchor,
                            '<script src="pqm_cat.js"></script>'
                            '\n  <script src="registry_popovers.js"></script>'
                            '\n  <script src="operational_task_officers.js?v=1"></script>', 1)
        for include in ('<script src="pqm_cat.js"></script>',
                        '<link rel="stylesheet" href="pqm_cat.css">',
                        '<script src="operational_task_officers.js?v=1"></script>'):
            if text.count(include) != 1:
                raise RuntimeError('STOP: SANDBOX permanent UI include mismatch')
    text = text.replace('<head>', '<head><meta name="robots" content="noindex,nofollow,noarchive">', 1)
    mode = ('ЗОВНІШНІ ДЖЕРЕЛА — читання · локальні записи лише в SANDBOX · '
            'Google-записи лише в підтверджену SANDBOX Sheet · PROD призначення заблоковані')
    text = text.replace('<body>', '<body><aside id="sandboxWarning" role="note" style="position:fixed;bottom:0;left:0;right:0;z-index:100000;background:#fff3cd;color:#583d00;padding:8px 16px;text-align:center;font:600 14px system-ui;border-top:2px solid #d29b00">SANDBOX · ТЕСТОВІ ДАНІ · ' + mode + '</aside>', 1)
    text = text.replace('PQM · WEB TEST</em>', 'PQM · SANDBOX</em>', 1)
    return text.encode('utf-8')


def main():
    validate_environment()
    install_outbound_guard()
    import server
    result = bootstrap(server)
    print('PQM SANDBOX bootstrap:', json.dumps(result), flush=True)
    server.main()


if __name__ == '__main__':
    # server imports this policy too. Keep one audit hook/thread-local scope
    # when the entrypoint itself was loaded as __main__.
    sys.modules['sandbox_runtime'] = sys.modules[__name__]
    main()
