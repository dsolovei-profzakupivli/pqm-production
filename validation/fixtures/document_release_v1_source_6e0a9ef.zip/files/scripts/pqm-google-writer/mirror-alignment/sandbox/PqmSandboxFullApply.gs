/* PROD-only full writer. Install with the existing Preview and Controlled Apply files. */
// One targeted grid read requests three times per chunk; keep range count bounded.
var PQM_SANDBOX_FULL_CHUNK_MAX_CELLS = 400;
var PQM_SANDBOX_FULL_CHUNK_MAX_ROWS = 200;
var PQM_SANDBOX_FULL_RUN_BUDGET_MS = 270000;
var PQM_SANDBOX_EXECUTION_APPEND_PAGE_ROWS = 25;
var PQM_SANDBOX_EXECUTION_UPDATE_PAGE_ROWS = 50;
var PQM_SANDBOX_EXECUTION_UPDATE_PAGE_CELLS = 100;
var PQM_SANDBOX_EXECUTION_CHECKPOINT_MAX_BYTES = 8000;

function pqmSandboxFullTimed_(timing, key, action) {
  var started = Date.now();
  try { return action(); }
  finally { timing[key] += Date.now() - started; }
}

function pqmSandboxFullBlocked_(plan) {
  return plan.changes.some(function(change) {
    return !change.append && Object.keys(change.cells).some(function(column) {
      return !Object.prototype.hasOwnProperty.call(PQM_SANDBOX_CONTROLLED_COLUMNS, column);
    });
  });
}

function pqmSandboxFullEntries_(plan, tabs) {
  var seen = {};
  return plan.changes.filter(function(change) { return !change.append; }).map(function(change) {
    var tab = tabs[change.tab], row = tab && tab.rows[change.row - 2];
    var code = row && String(row.codeDisplay || '').trim();
    var columns = pqmSandboxControlledColumns_(change);
    if (!tab || !row || !code || change.row < 2 || change.row > tab.maxRows ||
        seen[change.tab + ':' + change.row] || columns.some(function(column) { return [2, 3, 4, 5, 7, 8, 11].indexOf(column) < 0; })) {
      throw new Error('PQM SANDBOX FULL: invalid matched-only plan; no writes.');
    }
    seen[change.tab + ':' + change.row] = true;
    return {code: code, tab: change.tab, row: change.row, change: change, columns: columns};
  }).sort(function(a, b) {
    return a.tab < b.tab ? -1 : a.tab > b.tab ? 1 : a.row - b.row;
  });
}

function pqmSandboxFullSheetState_(tabs) {
  return PQM_GOOGLE_TABS.map(function(name) {
    var tab = tabs[name];
    return {name: name, id: tab.id, maxRows: tab.maxRows, headers: tab.headers,
      rows: tab.rows.map(function(row) {
        return {values: row.values, formulas: row.formulas,
          codeDisplay: row.codeDisplay, dateFormat: row.dateFormat,
          verificationDateFormat: row.verificationDateFormat};
      }), merges: tab.merges, protectedRanges: tab.protectedRanges,
      conditionalFormats: tab.conditionalFormats, templateRowHeight:tab.templateRowHeight};
  });
}

function pqmSandboxFullState_(body, tabs, plan, profile) {
  var payload = body.items.map(pqmSandboxControlledPqmState_).sort(function(a, b) {
    return a.supplier_code < b.supplier_code ? -1 : a.supplier_code > b.supplier_code ? 1 : 0;
  });
  var changes = plan.changes.map(function(change) {
    return {tab: change.tab, row: change.row, append: change.append, cells: change.cells};
  }).sort(function(a, b) {
    return a.tab < b.tab ? -1 : a.tab > b.tab ? 1 : a.row - b.row;
  });
  var localStarted = Date.now(), payloadDigest = pqmSandboxControlledDigest_(payload);
  var googleStarted = Date.now(), googleDigest = pqmSandboxControlledDigest_(pqmSandboxFullSheetState_(tabs));
  if (profile) profile.google_state_digest = {total_ms: Date.now() - googleStarted};
  var changesDigest = pqmSandboxControlledDigest_(changes), countsDigest = pqmSandboxControlledDigest_(plan.counts);
  if (profile) profile.payload_plan_digests = {total_ms: Date.now() - localStarted - profile.google_state_digest.total_ms};
  return {payload_digest: payloadDigest,
    google_digest: googleDigest,
    changes_digest: changesDigest,
    counts_digest: countsDigest};
}

function pqmSandboxFullDigest_(state) {
  return pqmSandboxControlledDigest_({version: 1, state: state});
}

function pqmSandboxFullLoad_(spreadsheetId) {
  var fetchStarted = Date.now(), body = pqmSandboxFetchRegistry_();
  var fetchMs = Date.now() - fetchStarted;
  var googlePhases = {};
  var snapshotStarted = Date.now(), tabs = pqmGoogleSnapshot_(spreadsheetId, googlePhases);
  var snapshotMs = Date.now() - snapshotStarted;
  var apiMs = Object.keys(googlePhases).reduce(function(sum, key) {
    return sum + googlePhases[key].total_ms;
  }, 0);
  googlePhases.snapshot_reconstruction = {total_ms: Math.max(0, snapshotMs - apiMs)};
  var plannerStarted = Date.now(), plan = pqmGooglePlan_(body, tabs);
  var plannerMs = Date.now() - plannerStarted;
  if (pqmSandboxFullBlocked_(plan)) {
    throw new Error('PQM SANDBOX FULL: UNSAFE_PLANNED_COLUMN; no writes.');
  }
  var entries = pqmSandboxFullEntries_(plan, tabs);
  if (plan.conflicts.length !== plan.counts.conflicts || plan.errors.length !== plan.counts.errors)
    throw new Error('PQM SANDBOX FULL: plan detail counters do not match; no writes.');
  pqmSandboxControlledProtectionCheck_(entries, tabs);
  var guardStarted = Date.now(), state = pqmSandboxFullState_(body, tabs, plan, googlePhases);
  var guardMs = Date.now() - guardStarted;
  var planDigest = pqmSandboxFullDigest_(state);
  var appendChanges = plan.changes.filter(function(change) { return change.append; }).map(function(change) {
    return {tab: change.tab, row: change.row, append: true, cells: change.cells};
  });
  var appendOnlyDigest = pqmSandboxFullDigest_({version: 1, state: {
    scope: 'APPEND_ONLY', parent_plan_digest: planDigest,
    payload_digest: state.payload_digest, google_digest: state.google_digest,
    changes_digest: pqmSandboxControlledDigest_(appendChanges),
    counts: {append: plan.counts.appended, update: 0,
      conflict: plan.counts.conflicts, error: plan.counts.errors}
  }});
  return {body: body, tabs: tabs, plan: plan, entries: entries, state: state,
    plan_digest: planDigest, append_only_digest: appendOnlyDigest,
    timing_ms: {pqm_fetch: fetchMs, google_snapshot: snapshotMs,
      planner: plannerMs, google_state_guard: guardMs, initial_google_phases: googlePhases}};
}

var PQM_SANDBOX_PREVIEW_CONFLICT_LABELS_ = {
  duplicate_key: 'Дублікат коду постачальника', routing_mismatch: 'Тип постачальника не відповідає вкладці',
  invalid_pqm_verification_date: 'Некоректна дата перевірки в PQM',
  missing_google_verification_date: 'У Google Sheets відсутня дата перевірки',
  invalid_google_verification_date: 'Некоректна дата перевірки в Google Sheets',
  merged_owned_cell: 'Об’єднана клітинка у керованому діапазоні',
  formula_in_owned_cell: 'Формула в клітинці, якою керує синхронізація',
  missing_append_template: 'Немає шаблонного рядка для додавання',
  append_formula_A_unavailable: 'Не вдалося побудувати формулу стовпця A',
  missing_template_row_height: 'Не задана висота шаблонного рядка',
  merged_append_template_or_destination: 'Об’єднаний діапазон у зоні нового рядка',
  formula_in_append_template_owned_cell: 'Формула шаблону конфліктує з керованою клітинкою',
  missing_verification_officer: 'Для дати перевірки не вказано відповідальну особу',
  unknown_edr_status: 'Статус ЄДР не входить до дозволеного переліку',
  unknown_prozorro_status: 'Статус Prozorro не вдалося класифікувати',
  missing_append_name_or_status: 'Для нового рядка бракує обов’язкового поля',
  protected_owned_cell: 'Запланована клітинка захищена',
  invalid_initial_verification_pair: 'Початкова дата та відповідальна особа некоректні'
};
var PQM_SANDBOX_PREVIEW_ERROR_LABELS_ = {
  invalid_date: 'Некоректна дата в даних PQM'
};

function pqmSandboxPreviewDisplayValue_(value, column) {
  if (value === null || value === undefined || value === '') return '';
  if (column === 7) {
    var calendar = pqmGoogleCalendarDate_(value);
    return calendar.kind === 'date' ? calendar.value : String(value);
  }
  if (column === 8) {
    var verification = pqmVerificationDatetime_(value);
    if (verification.kind === 'blank') return '';
    if (verification.kind === 'datetime') return Utilities.formatDate(
      new Date(verification.value), 'Europe/Kyiv', 'dd.MM.yyyy HH:mm:ss');
    return String(value);
  }
  return typeof value === 'string' ? value : String(value);
}

function pqmSandboxFullPreviewDetails_(loaded) {
  var items = new Map();
  loaded.body.items.forEach(function(item) { items.set(item.supplier_code.trim(), item); });
  var letters = 'ABCDEFGHIJKLMNO'.split('');
  function supplier(code, tab, row) {
    var item = items.get(code) || {}, sheetRow = loaded.tabs[tab].rows[row - 2];
    return {code: code, name: item.supplier_name || item.latest_submission_name ||
      (sheetRow && sheetRow.values[2]) || '', tab: tab, row: row};
  }
  function cells(change) {
    var tab = loaded.tabs[change.tab], oldRow = change.append ? null : tab.rows[change.row - 2];
    return Object.keys(change.cells).sort(function(a, b) { return Number(a) - Number(b); }).map(function(index) {
      var column = Number(index), rawOld = oldRow ? oldRow.values[column] : '', rawNew = change.cells[index];
      return {column: letters[column], old_value: pqmSandboxPreviewDisplayValue_(rawOld, column),
        new_value: pqmSandboxPreviewDisplayValue_(rawNew, column),
        formula: column === 0 && typeof rawNew === 'string' && rawNew.charAt(0) === '='};
    });
  }
  var appends = [], updates = [];
  loaded.plan.changes.forEach(function(change) {
    var code = change.append ? String(change.cells[1] || '') :
      String(loaded.tabs[change.tab].rows[change.row - 2].codeDisplay || '');
    var entry = Object.assign(supplier(code, change.tab, change.row), {
      operation: change.append ? 'APPEND' : 'UPDATE', cells: cells(change)
    });
    (change.append ? appends : updates).push(entry);
  });
  var conflicts = loaded.plan.conflicts.map(function(issue) {
    var found = items.get(issue.supplier_code) || {};
    return {code: issue.supplier_code, name: found.supplier_name || found.latest_submission_name || '',
      tab: issue.tab || null, reason: issue.reason,
      explanation: PQM_SANDBOX_PREVIEW_CONFLICT_LABELS_[issue.reason] || issue.reason};
  });
  var errors = loaded.plan.errors.map(function(issue) {
    var found = items.get(issue.supplier_code) || {};
    return {code: issue.supplier_code, name: found.supplier_name || found.latest_submission_name || '',
      tab: issue.tab || null, reason: issue.reason,
      explanation: PQM_SANDBOX_PREVIEW_ERROR_LABELS_[issue.reason] || issue.reason};
  });
  return {version: 1, environment: 'SANDBOX', plan_digest: loaded.plan_digest,
    source_digest: loaded.state.payload_digest,
    append_only_digest: loaded.append_only_digest, counts: {
      append: loaded.plan.counts.appended, update: loaded.plan.counts.updated,
      conflict: loaded.plan.counts.conflicts, error: loaded.plan.counts.errors
    }, appends: appends, updates: updates, conflicts: conflicts, errors: errors};
}

function pqmSandboxFullApplyPreview() {
  var id = pqmSandboxControlledSpreadsheetId_();
  var started = Date.now(), loaded = pqmSandboxFullLoad_(id);
  var byColumn = {C: 0, D:0, E:0, F:0, H:0, I:0, L:0}, total = 0;
  loaded.entries.forEach(function(entry) {
    entry.columns.forEach(function(column) {
      byColumn[PQM_SANDBOX_CONTROLLED_COLUMNS[column]]++;
      total++;
    });
  });
  var output = {dry_run: true, google_writes: 0,
    total_pqm_suppliers: loaded.body.count,
    matched: loaded.plan.counts.matched, skipped: loaded.plan.counts.skipped,
    updated: loaded.plan.counts.updated, unchanged: loaded.plan.counts.unchanged,
    appended: loaded.plan.counts.appended, conflicts: loaded.plan.counts.conflicts,
    duplicate_keys: loaded.plan.counts.duplicate_keys, errors: loaded.plan.counts.errors,
    changes_by_column: byColumn, total_planned_cells: total,
    plan_digest: loaded.plan_digest,
    timing_ms: {pqm_fetch: loaded.timing_ms.pqm_fetch,
      google_snapshot: loaded.timing_ms.google_snapshot,
      planner: loaded.timing_ms.planner,
      google_state_guard: loaded.timing_ms.google_state_guard,
      initial_google_phases: loaded.timing_ms.initial_google_phases,
      total: Date.now() - started}};
  console.log(JSON.stringify(output));
  return output;
}

/* Read-only Phase 1 impact report, including blockers that Full Preview rejects. */
function pqmSandboxExpandedImpactPreview() {
  var started = Date.now();
  var id = pqmSandboxControlledSpreadsheetId_();
  var body = pqmSandboxFetchRegistry_();
  var tabs = pqmGoogleSnapshot_(id);
  var plan = pqmGooglePlan_(body, tabs);
  var byColumn = {C: 0, D:0, E:0, F:0, H:0, I:0, L:0};
  var matchedCells = 0;
  plan.changes.forEach(function(change) {
    if (change.append) return;
    Object.keys(change.cells).forEach(function(rawColumn) {
      var column = Number(rawColumn);
      var letter = PQM_SANDBOX_CONTROLLED_COLUMNS[column];
      if (!letter) throw new Error('PQM SANDBOX: unowned planned cell; no writes.');
      byColumn[letter]++;
      matchedCells++;
    });
  });
  var output = {dry_run: true, google_writes: 0,
    total_pqm_suppliers: body.count, matched: plan.counts.matched,
    updated: plan.counts.updated, unchanged: plan.counts.unchanged,
    skipped: plan.counts.skipped, appended: plan.counts.appended,
    conflicts: plan.counts.conflicts, duplicate_keys: plan.counts.duplicate_keys,
    errors: plan.counts.errors,
    changes_by_column: byColumn,
    total_planned_matched_cells: matchedCells, a_writes: 0, formulas_touched: 0,
    full_apply_blocked: pqmSandboxFullBlocked_(plan), timing_ms: {total: Date.now() - started}};
  console.log(JSON.stringify(output));
  return output;
}

/* Read-only profile of the exact Google snapshot path and sheet-state digest. */
function pqmSandboxProfileInitialGoogleGuard() {
  var spreadsheetId = pqmSandboxControlledSpreadsheetId_();
  var started = Date.now(), phases = {};
  var snapshotStarted = Date.now();
  var tabs = pqmGoogleSnapshot_(spreadsheetId, phases);
  var snapshotMs = Date.now() - snapshotStarted;
  var apiMs = Object.keys(phases).reduce(function(sum, key) {
    return sum + phases[key].total_ms;
  }, 0);
  phases.snapshot_reconstruction = {total_ms: Math.max(0, snapshotMs - apiMs)};
  var digestStarted = Date.now();
  pqmSandboxControlledDigest_(pqmSandboxFullSheetState_(tabs));
  phases.google_state_digest = {total_ms: Date.now() - digestStarted};
  var output = {dry_run: true, google_writes: 0,
    total_ms: Date.now() - started, phases: phases};
  console.log(JSON.stringify(output));
  return output;
}

function pqmSandboxFullChunks_(entries) {
  var chunks = [], chunk = [], cells = 0;
  entries.forEach(function(entry) {
    if (chunk.length && (chunk.length >= PQM_SANDBOX_FULL_CHUNK_MAX_ROWS ||
        cells + entry.columns.length > PQM_SANDBOX_FULL_CHUNK_MAX_CELLS)) {
      chunks.push(chunk); chunk = []; cells = 0;
    }
    chunk.push(entry); cells += entry.columns.length;
  });
  if (chunk.length) chunks.push(chunk);
  return chunks;
}

function pqmSandboxFullCellValue_(cell) {
  var value = cell.effectiveValue || {};
  return value.stringValue !== undefined ? value.stringValue :
    value.numberValue !== undefined ? value.numberValue :
    value.boolValue !== undefined ? value.boolValue : '';
}

function pqmSandboxExecutionOperationProjection_(loaded,phase,selected) {
  var details=pqmSandboxFullPreviewDetails_(loaded),items=phase==='append'?details.appends:details.updates;
  var keys=new Set((selected||[]).map(function(entry) {
    var change=entry.change||entry;
    return change.tab+':'+change.row;
  }));
  return items.filter(function(item) { return keys.has(item.tab+':'+item.row); }).map(function(item) {
    return {operation:item.operation,tab:item.tab,row:item.row,code:String(item.code||'').trim(),
      cells:(item.cells||[]).map(function(cell) { return {column:cell.column,new_value:cell.new_value,
        formula:cell.formula===true}; })};
  });
}

function pqmSandboxExecutionComparableValue_(value,column) {
  if (value===null || value===undefined || value==='') return '';
  if (column===7) {
    var date=pqmGoogleCalendarDate_(value);
    return date && date.kind==='date' ? date.value : String(value);
  }
  if (column===8) {
    var datetime=pqmVerificationDatetime_(value);
    return datetime && datetime.kind==='datetime' ? datetime.value : String(value);
  }
  return typeof value==='string'?value:String(value);
}

function pqmSandboxExecutionRowProjection_(tab,row,columns,values,formulas,service) {
  return {tab:tab,row:row,cells:columns.map(function(column) {
    return {column:column,value:column===0?'':pqmSandboxExecutionComparableValue_(values[column],column),
      formula:column===0?String(formulas[0]||''):''};
  }),service:service||null};
}

function pqmSandboxExecutionChunkEvidence_(phase,selected,loaded,request,beforeRows) {
  return (selected||[]).map(function(entry,index) {
    var change=entry.change||entry,tab=change.tab,row=change.row;
    var plannedColumns=Object.keys(change.cells||{}).map(Number).sort(function(a,b){return a-b;});
    if (!plannedColumns.length) throw new Error('PQM EXECUTION CHECKPOINT: empty chunk row evidence.');
    var cols=Array.from({length:15},function(_,column){return column;});
    var old=loaded.tabs[tab].rows[row-2],oldValues=old?old.values:Array(15).fill(''),
      oldFormulas=old?old.formulas:Array(15).fill('');
    var afterValues=oldValues.slice(),afterFormulas=oldFormulas.slice();
    plannedColumns.forEach(function(column) {
      afterValues[column]=change.cells[column];
      if (column===0 && typeof change.cells[column]==='string' && change.cells[column].charAt(0)==='=')
        afterFormulas[column]=change.cells[column];
    });
    var beforeService=null,afterService=null;
    if (phase==='append') {
      oldValues=Array(15).fill('');oldFormulas=Array(15).fill('');
      afterValues=oldValues.slice();afterFormulas=oldFormulas.slice();
      plannedColumns.forEach(function(column) {
        afterValues[column]=change.cells[column];
        if (column===0 && typeof change.cells[column]==='string' && change.cells[column].charAt(0)==='=')
          afterFormulas[column]=change.cells[column];
      });
      afterService={addedAt:request.chunkAddedAt,planId:request.planId,runId:request.requestId};
      beforeService={addedAt:'',planId:'',runId:''};
    }
    var before=pqmSandboxExecutionRowProjection_(tab,row,cols,oldValues,oldFormulas,beforeService);
    var after=pqmSandboxExecutionRowProjection_(tab,row,cols,afterValues,afterFormulas,afterService);
    var evidence={tab:tab,row:row,columns:cols,beforeDigest:pqmSandboxControlledDigest_(before),
      afterDigest:pqmSandboxControlledDigest_(after)};
    evidence.codeDigest=pqmSandboxControlledDigest_(String(change.code||change.cells[1]||'').trim());
    return evidence;
  });
}

function pqmSandboxExecutionReadChunkEvidence_(id,manifest) {
  var rows=manifest.rows||[],ranges=rows.map(function(item) {
    return "'"+item.tab.replace(/'/g,"''")+"'!A"+item.row+':S'+item.row;
  });
  var values=Sheets.Spreadsheets.Values.batchGet(id,{ranges:ranges,valueRenderOption:'UNFORMATTED_VALUE'});
  var formulas=Sheets.Spreadsheets.Values.batchGet(id,{ranges:ranges.map(function(range) {
    return range.substring(0,range.indexOf('!')+1)+'A'+range.substring(range.indexOf('!A')+2,range.indexOf(':'));
  }),valueRenderOption:'FORMULA'});
  if (!values || !Array.isArray(values.valueRanges) || values.valueRanges.length!==ranges.length ||
      !formulas || !Array.isArray(formulas.valueRanges) || formulas.valueRanges.length!==ranges.length)
    throw new Error('PQM EXECUTION CHECKPOINT: bounded recovery read-back incomplete.');
  var services=manifest.phase==='append'?Sheets.Spreadsheets.Values.batchGet(id,{ranges:ranges.map(function(range) {
    var row=range.substring(range.indexOf('!A')+2,range.indexOf(':'));
    return range.substring(0,range.indexOf('!')+1)+'Q'+row+':S'+row;
  }),valueRenderOption:'UNFORMATTED_VALUE'}):null;
  if (manifest.phase==='append' && (!services || !Array.isArray(services.valueRanges) || services.valueRanges.length!==ranges.length))
    throw new Error('PQM EXECUTION CHECKPOINT: service marker recovery read-back incomplete.');
  return rows.map(function(expected,index) {
    var row=((values.valueRanges[index]||{}).values||[])[0]||[],formula=((formulas.valueRanges[index]||{}).values||[])[0]||[];
    var serviceRow=manifest.phase==='append'?(((services.valueRanges[index]||{}).values||[])[0]||[]):null;
    var service=manifest.phase==='append'?{addedAt:serviceRow[0]||'',planId:serviceRow[1]||'',runId:serviceRow[2]||''}:null;
    var digest=pqmSandboxControlledDigest_(pqmSandboxExecutionRowProjection_(expected.tab,expected.row,
      expected.columns,row,formula,service));
    return {tab:expected.tab,row:expected.row,digest:digest,
      codeDigest:pqmSandboxControlledDigest_(String(row[1]||'').trim())};
  });
}

function pqmSandboxFullBeforeCheck_(chunk, rawRows, tabs) {
  chunk.forEach(function(entry, index) {
    var expected = tabs[entry.tab].rows[entry.row - 2], cells = rawRows[index];
    if (!expected || !cells || cells.length !== 15) {
      throw new Error('PQM SANDBOX FULL: ROW_STATE_CHANGED; no further writes.');
    }
    for (var column = 0; column < 15; column++) {
      var cell = cells[column] || {}, actual = pqmSandboxFullCellValue_(cell);
      var planned = expected.values[column] === undefined ? '' : expected.values[column];
      if (actual !== planned) throw new Error('PQM SANDBOX FULL: ROW_STATE_CHANGED; no further writes.');
      if ([0, 1, 2, 3, 4, 5, 7, 8, 11].indexOf(column) >= 0 &&
          ((cell.userEnteredValue || {}).formulaValue || '') !== (expected.formulas[column] || '')) {
        throw new Error('PQM SANDBOX FULL: FORMULA_STATE_CHANGED; no further writes.');
      }
    }
    if (String((cells[1] || {}).formattedValue || '').trim() !== entry.code ||
        String(expected.codeDisplay || '').trim() !== entry.code ||
        ((((cells[7] || {}).userEnteredFormat || {}).numberFormat || {}).pattern || '') !==
          (expected.dateFormat || '') ||
        ((((cells[8] || {}).userEnteredFormat || {}).numberFormat || {}).pattern || '') !==
          (expected.verificationDateFormat || '')) {
      throw new Error('PQM SANDBOX FULL: IDENTITY_OR_DATE_FORMAT_CHANGED; no further writes.');
    }
  });
}

function pqmSandboxFullRequests_(chunk, tabs) {
  var requests = [];
  chunk.forEach(function(entry) {
    if (Object.keys(entry.change.cells).concat(entry.columns).some(function(column) {
      return !Object.prototype.hasOwnProperty.call(PQM_SANDBOX_CONTROLLED_COLUMNS, column);
    })) throw new Error('PQM SANDBOX FULL: unowned cell; no writes.');
    entry.columns.forEach(function(column) {
      var value = entry.change.cells[column];
      if (pqmGoogleBlank_(value)) throw new Error('PQM SANDBOX FULL: blank planned value; no further writes.');
      var dateColumn = column === 7 || column === 8;
      var cell = {userEnteredValue: dateColumn ? {numberValue: value} : {stringValue: value}};
      if (dateColumn) cell.userEnteredFormat = {numberFormat: {type: column === 8 ? 'DATE_TIME' : 'DATE', pattern: column === 8 ? 'dd.MM.yyyy HH:mm:ss' : 'dd.MM.yyyy'}};
      requests.push({updateCells: {range: {sheetId: tabs[entry.tab].id,
        startRowIndex: entry.row - 1, endRowIndex: entry.row,
        startColumnIndex: column, endColumnIndex: column + 1},
        rows: [{values: [cell]}],
        fields: dateColumn ? 'userEnteredValue,userEnteredFormat.numberFormat' : 'userEnteredValue'}});
    });
  });
  if (!requests.length || requests.length > PQM_SANDBOX_FULL_CHUNK_MAX_CELLS ||
      chunk.length > PQM_SANDBOX_FULL_CHUNK_MAX_ROWS) {
    throw new Error('PQM SANDBOX FULL: chunk bound exceeded; no further writes.');
  }
  return requests;
}

function pqmSandboxFullProgress_(progress, status) {
  progress.status = status;
  progress.remaining_chunks = progress.chunks_total - progress.chunks_completed;
  progress.remaining_cells = progress.cells_total - progress.cells_written;
  console.log(JSON.stringify(progress));
  return progress;
}

function pqmSandboxFullApply() {
  pqmMirrorContext_();
  var ui = SpreadsheetApp.getUi();
  var digestAnswer = ui.prompt('PQM SANDBOX FULL Apply',
    'Paste plan_digest from the immediately preceding FULL Preview.', ui.ButtonSet.OK_CANCEL);
  if (digestAnswer.getSelectedButton() !== ui.Button.OK) return {cancelled: true, google_writes: 0};
  var expectedDigest = digestAnswer.getResponseText().trim();
  if (!/^[A-Za-z0-9_-]{40,}$/.test(expectedDigest)) {
    throw new Error('PQM SANDBOX FULL: invalid Preview digest; zero writes.');
  }
  var answer = ui.alert('PQM SANDBOX FULL Apply',
    'Confirm bounded writes to ONLY current planned C/D/E/F/H/I/L cells in the SANDBOX copy. ' +
      'A time-limited run may stop partially; a NEW Preview is required before another run.', ui.ButtonSet.YES_NO);
  if (answer !== ui.Button.YES) return {cancelled: true, google_writes: 0};
  var lock = LockService.getScriptLock();
  if (!lock.tryLock(0)) throw new Error('PQM SANDBOX FULL: another operation is running; zero writes.');
  var started = Date.now();
  try {
    var id = pqmSandboxControlledSpreadsheetId_();
    var loaded = pqmSandboxFullLoad_(id);
    if (loaded.plan_digest !== expectedDigest) {
      throw new Error('PQM SANDBOX FULL: PLAN_OR_GOOGLE_STATE_CHANGED; zero writes.');
    }
    var chunks = pqmSandboxFullChunks_(loaded.entries);
    var progress = {chunks_total: chunks.length, chunks_completed: 0,
      rows_total: loaded.entries.length, rows_processed: 0,
      cells_total: loaded.entries.reduce(function(n, entry) { return n + entry.columns.length; }, 0),
      cells_written: 0, cells_attempted: 0, cells_verified: 0, failures: 0, remaining_chunks: chunks.length,
      remaining_cells: 0, google_writes: 0,
      timing_ms: {initial_pqm_fetch: loaded.timing_ms.pqm_fetch,
        initial_google_guard: loaded.timing_ms.google_snapshot + loaded.timing_ms.google_state_guard,
        initial_plan_rebuild: loaded.timing_ms.planner,
        initial_google_phases: loaded.timing_ms.initial_google_phases,
        chunk_pre_read: 0, chunk_write: 0,
        chunk_after_read_verification: 0}};
    // The freshly fetched and digest-validated PQM plan is frozen for this one
    // time-bounded execution. Every later execution requires a new Preview.
    for (var i = 0; i < chunks.length; i++) {
      if (Date.now() - started >= PQM_SANDBOX_FULL_RUN_BUDGET_MS) {
        return pqmSandboxFullProgress_(progress, 'TIME_BUDGET_STOP_NEW_PREVIEW_REQUIRED');
      }
      var chunk = chunks[i];
      var writeStarted = false;
      try {
        var before, prewriteStable = pqmSandboxFullTimed_(progress.timing_ms, 'chunk_pre_read', function() {
          pqmSandboxControlledProtectionCheck_(chunk, loaded.tabs);
          before = pqmSandboxControlledReadRows_(id, chunk, loaded.tabs);
          pqmSandboxFullBeforeCheck_(chunk, before, loaded.tabs);
          var rechecked = pqmSandboxControlledReadRows_(id, chunk, loaded.tabs);
          return pqmSandboxControlledDigest_(before.map(pqmSandboxControlledRowState_)) ===
            pqmSandboxControlledDigest_(rechecked.map(pqmSandboxControlledRowState_));
        });
        if (!prewriteStable) {
          progress.failures++;
          return pqmSandboxFullProgress_(progress, 'ROW_CHANGED_BEFORE_WRITE_NEW_PREVIEW_REQUIRED');
        }
        var requests = pqmSandboxFullRequests_(chunk, loaded.tabs);
        if (Date.now() - started >= PQM_SANDBOX_FULL_RUN_BUDGET_MS) {
          return pqmSandboxFullProgress_(progress, 'TIME_BUDGET_STOP_NEW_PREVIEW_REQUIRED');
        }
        progress.cells_attempted += requests.length;
        writeStarted = true;
        pqmSandboxFullTimed_(progress.timing_ms, 'chunk_write', function() {
          pqmMirrorSheetsBatchUpdate_({requests: requests}, id);
        });
        progress.google_writes++;
        progress.cells_written += requests.length;
        var verification = pqmSandboxFullTimed_(progress.timing_ms, 'chunk_after_read_verification', function() {
          var after = pqmSandboxControlledReadRows_(id, chunk, loaded.tabs);
          return pqmSandboxControlledVerify_(chunk, before, after);
        });
        if (!verification.verification_passed) {
          progress.failures += verification.failures.length;
          return pqmSandboxFullProgress_(progress, 'VERIFICATION_FAILED_NEW_PREVIEW_REQUIRED');
        }
        progress.cells_verified += verification.verified_owned_cells;
        progress.chunks_completed++;
        progress.rows_processed += chunk.length;
        pqmSandboxFullProgress_(progress, 'IN_PROGRESS');
      } catch (error) {
        progress.failures++;
        return pqmSandboxFullProgress_(progress,
          writeStarted ? 'WRITE_OR_READBACK_UNCERTAIN_NEW_PREVIEW_REQUIRED' :
            'CHUNK_FAILED_NEW_PREVIEW_REQUIRED');
      }
    }
    return pqmSandboxFullProgress_(progress, loaded.plan.counts.appended ?
      'UPDATES_COMPLETE_APPEND_PENDING' : loaded.plan.counts.conflicts || loaded.plan.counts.errors ?
      'COMPLETE_WITH_CONFLICTS' : 'COMPLETE');
  } finally {
    lock.releaseLock();
  }
}

/* Trigger-safe coordinator: one planner, the same append/update requests and read-back guards. */
function pqmSandboxDailySync(execution) {
  pqmMirrorContext_();
  var borrowed = execution && execution.lock && typeof execution.lock.releaseLock === 'function';
  var lock = borrowed ? execution.lock : LockService.getScriptLock();
  if (!borrowed && !lock.tryLock(0)) throw new Error('PQM SANDBOX DAILY: another sync is running; zero writes.');
  var started = Date.now(), appends = 0, updates = 0, batches = 0;
  try {
    var id = pqmSandboxControlledSpreadsheetId_();
    if (execution && execution.expectedDigest && pqmSandboxFullLoad_(id).plan_digest !== execution.expectedDigest)
      throw new Error('PQM: stale execution Preview; zero writes.');
    while (Date.now() - started < PQM_SANDBOX_FULL_RUN_BUDGET_MS) {
      var append = pqmSandboxAppendLoad_(id);
      if (execution && execution.payloadDigest && append.payload_digest !== execution.payloadDigest)
        throw new Error('PQM: source changed after execution Preview; no further writes.');
      if (!append.selected.length) break;
      if (Date.now() - started >= PQM_SANDBOX_FULL_RUN_BUDGET_MS) break;
      var checked = pqmSandboxAppendLoad_(id);
      if (checked.digest !== append.digest) {
        throw new Error('PQM SANDBOX DAILY: append source or Sheet changed; zero further writes.');
      }
      var templates = {};
      append.selected.forEach(function(change) {
        if (!templates[change.tab]) templates[change.tab] = pqmSandboxAppendRowMetadata_(id,
          change.tab, append.tabs[change.tab].rows.length + 1);
      });
      var appendRequests = pqmSandboxAppendRequests_(append.selected, append.tabs);
      if (!appendRequests.length || Date.now() - started >= PQM_SANDBOX_FULL_RUN_BUDGET_MS) break;
      pqmSandboxAppendPrewriteGuard_(id, append);
      try { pqmMirrorSheetsBatchUpdate_({requests: appendRequests}, id); }
      catch (_) { throw new Error('PQM SANDBOX DAILY: append write outcome unknown; no retry.'); }
      pqmSandboxAppendVerify_(id, append.selected, append.tabs);
      pqmSandboxAppendVerifyMetadata_(id, append.selected, templates);
      appends += append.selected.length;
      batches++;
    }
    if (Date.now() - started < PQM_SANDBOX_FULL_RUN_BUDGET_MS) {
      var loaded = pqmSandboxFullLoad_(id);
      if (execution && execution.payloadDigest && pqmSandboxAppendPayloadDigest_(loaded.body) !== execution.payloadDigest)
        throw new Error('PQM: source changed after execution Preview; no further writes.');
      var chunks = pqmSandboxFullChunks_(loaded.entries);
      for (var i = 0; i < chunks.length; i++) {
        if (Date.now() - started >= PQM_SANDBOX_FULL_RUN_BUDGET_MS) break;
        var chunk = chunks[i];
        var currentBody = pqmSandboxFetchRegistry_();
        if (pqmSandboxAppendPayloadDigest_(currentBody) !== pqmSandboxAppendPayloadDigest_(loaded.body))
          throw new Error('PQM: source changed during run; no further writes, new Preview required.');
        pqmSandboxControlledProtectionCheck_(chunk, loaded.tabs);
        var before = pqmSandboxControlledReadRows_(id, chunk, loaded.tabs);
        pqmSandboxFullBeforeCheck_(chunk, before, loaded.tabs);
        var rechecked = pqmSandboxControlledReadRows_(id, chunk, loaded.tabs);
        if (pqmSandboxControlledDigest_(before.map(pqmSandboxControlledRowState_)) !==
            pqmSandboxControlledDigest_(rechecked.map(pqmSandboxControlledRowState_))) {
          throw new Error('PQM SANDBOX DAILY: row changed before write; no further writes.');
        }
        var requests = pqmSandboxFullRequests_(chunk, loaded.tabs);
        if (Date.now() - started >= PQM_SANDBOX_FULL_RUN_BUDGET_MS) break;
        try { pqmMirrorSheetsBatchUpdate_({requests: requests}, id); }
        catch (_) { throw new Error('PQM SANDBOX DAILY: update write outcome unknown; no retry.'); }
        var after = pqmSandboxControlledReadRows_(id, chunk, loaded.tabs);
        if (!pqmSandboxControlledVerify_(chunk, before, after).verification_passed) {
          throw new Error('PQM SANDBOX DAILY: update read-back failed; no retry.');
        }
        updates += chunk.length;
        batches++;
      }
    }
    var finalPlan = pqmGooglePlan_(pqmSandboxFetchRegistry_(), pqmGoogleSnapshot_(id));
    var remaining = finalPlan.counts.appended + finalPlan.counts.updated;
    var report = {mode: 'scheduled_apply', append: appends, update: updates,
      conflict: finalPlan.counts.conflicts, error: finalPlan.counts.errors,
      remaining_safe: remaining,
      batches: batches, status: remaining ? 'PARTIAL_SAFE_OPERATIONS_REMAIN' :
        finalPlan.counts.conflicts || finalPlan.counts.errors ? 'COMPLETE_WITH_CONFLICTS' : 'COMPLETE'};
    console.log(JSON.stringify(report));
    return report;
  } finally {
    if (!borrowed) lock.releaseLock();
  }
}

/* Sandbox binds its existing guarded writer operations to the shared engine. */
function pqmSandboxCheckpointAdapter_() {
  return {
    appendLoad:pqmSandboxAppendLoad_, appendPrewriteGuard:pqmSandboxAppendPrewriteGuard_,
    continuationPrewriteGuard:pqmSandboxContinuationPrewriteGuard_,
    appendRowMetadata:pqmSandboxAppendRowMetadata_,
    appendRequests:function(selected,tabs,context) {
      return pqmSandboxAppendRequests_(selected,tabs,Object.assign({},context,{journaled:true}));
    },
    batchUpdate:pqmMirrorSheetsBatchUpdate_, appendVerify:pqmSandboxAppendVerify_,
    appendVerifyMetadata:pqmSandboxAppendVerifyMetadata_, fullChunks:pqmSandboxFullChunks_,
    projectVerifiedAppend:pqmSandboxAppendProjectVerified_,
    appendServiceRanges:pqmSandboxAppendServiceRanges_,
    verifyServiceRanges:pqmSandboxAppendVerifyServiceRanges_,
    fetchRegistry:pqmSandboxFetchRegistry_, appendPayloadDigest:pqmSandboxAppendPayloadDigest_,
    protectionCheck:pqmSandboxControlledProtectionCheck_, readRows:pqmSandboxControlledReadRows_,
    fullBeforeCheck:pqmSandboxFullBeforeCheck_, fullRequests:pqmSandboxFullRequests_,
    controlledVerify:pqmSandboxControlledVerify_, snapshot:pqmGoogleSnapshot_,
    fullSheetState:pqmSandboxFullSheetState_, plan:pqmGooglePlan_,
    controlledDigest:pqmSandboxControlledDigest_, rowState:pqmSandboxControlledRowState_,
    chunkEvidence:pqmSandboxExecutionChunkEvidence_
  };
}

function pqmSandboxApplyCheckpointStep_(id, loaded, request, properties, key, record, receipt) {
  return pqmExecutionApplyCheckpointStep_(pqmSandboxCheckpointAdapter_(),id,loaded,request,
    properties,key,record,receipt,{appendPageRows:PQM_SANDBOX_EXECUTION_APPEND_PAGE_ROWS,
      updatePageRows:PQM_SANDBOX_EXECUTION_UPDATE_PAGE_ROWS,
      updatePageCells:PQM_SANDBOX_EXECUTION_UPDATE_PAGE_CELLS,
      maxBytes:PQM_SANDBOX_EXECUTION_CHECKPOINT_MAX_BYTES});
}
