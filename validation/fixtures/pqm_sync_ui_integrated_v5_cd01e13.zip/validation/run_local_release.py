"""Run the delivered LOCAL suite on a disposable WEB-code/synthetic-DB fixture.

The delivered tests expect source and tests side-by-side, unlike ZIP layout.
No production/local database or credential is read. Outbound network is denied.
"""
import os
import gc
import hashlib
import logging
from contextlib import closing
from pathlib import Path
import shutil
import socket
import sqlite3
import subprocess
import sys
import tempfile
import unittest
import zipfile

ROOT=Path(os.environ.get('PQM_RELEASE_SOURCE_ROOT') or Path(__file__).resolve().parents[1]).resolve()
INFRA_ROOT=Path(os.environ.get('PQM_RELEASE_INFRA_ROOT') or Path(__file__).resolve().parents[1]).resolve()
C246_RUNNER_SHA256='98817c305569e973b84edb3529f13a3426853fdf42de99cb99d389376206a39f'
C246_STAGING_FILE_SHA256={
    'validation/c246_historical_integrity_snapshots_v1.json':'9cc63f46d931ac18e83f1bcce8693c23604e740640031fc312b6e93d4b38eff8',
    'validation/fixtures/c246_historical/af8202b4e968f09e55ac5c6855ad29a6f2c05bc1.zip':'e0931cc43d5c99a001771fdd12ef5bea6a87003400a458c9a3f197372671c865',
}
HISTORICAL_INTEGRITY_MODULES={
    'test_google_sandbox_baseline_compatibility',
    'test_halloween_motion_integration',
    'test_sandbox_admin_officer_link_integrity',
    'test_sandbox_appeals_scenario_api_integrity',
    'test_sandbox_appeals_scenario_readonly_integrity',
    'test_sandbox_dst_hotfix_integrity',
    'test_sandbox_nazk_appeals_stabilization_integrity',
    'test_sandbox_nazk_appeals_stabilization_v3_integrity',
    'test_sandbox_nazk_appeals_stabilization_v4_integrity',
    'test_sandbox_nazk_appeals_stabilization_v5_integrity',
    'test_sandbox_nazk_columns_integrity',
    'test_sandbox_nazk_preview_integrity',
    'test_sandbox_nazk_recovery_integrity',
    'test_sandbox_nazk_recovery_qualification_integrity',
    'test_sandbox_nazk_scroll_integrity',
    'test_sandbox_messages_integrity',
    'test_sandbox_messages_header_polish_integrity_v3',
    'test_sandbox_messages_search_header_integrity_v2',
    'test_sandbox_nazk_messages_integrated_integrity',
    'test_nazk_authority_request_integrity',
    'test_sandbox_edr_google_nazk_reconcile_integrity',
    'test_google_edr_timezone_alias_integrity_v1',
    'test_edr_preview_skipped_integrity',
    'test_edr_preview_skipped_rows',
    'test_google_writer_supplier_types_integrity',
    # Checkpoint v1 pins its exact 95bc pre-reconciliation source tree; run it
    # only against the immutable c8a97d6 fixture via the additive overlay.
    'test_checkpointed_apply_integrity_v1',
    # v3's exact-tree contract is executed only against its original pinned
    # commit by the overlay runner below; the current candidate has additive
    # manual-classification changes to files pinned by that historical tree.
    'test_supplier_classification_v3_integrity',
    'test_supplier_manual_classification_v4_integrity',
    # v1 remains byte-pinned to the original digest candidate and runs only
    # through its exact-tree overlay; v2 protects later additive changes.
    'test_preview_digest_contract_integrity_v1',
    'test_google_edr_date_only_midnight_integrity_v1',
    'test_date_only_edr_status_integrated_integrity_v1',
    'test_date_only_edr_status_integrated_integrity_v2',
    'validation.local_release_20260911.test_date_only_edr_status_integrated_integrity_v2',
    'test_edr_status_evidence_integrity_v1',
    'test_messages_historical_line_endings',
    'test_sandbox_personal_theme',
    'test_sandbox_ui_integrated_d457_integrity',
    'test_supplier_classification_integrity',
    'test_google_writer_update_append_integrity',
    'test_google_writer_supplier_types_integrity',
    # These candidate-specific overlays run against their declared source
    # pins outside the disposable product-test copy.
    'test_partial_reconciliation_second_integrity_v1',
    # These v1 overlays keep their original exact-source pins and run against
    # the immutable 067e2e8 fixture; the additive candidate overlay pins the
    # current source and the historical-routing runners.
    'test_sandbox_preview_append_only_integrity_v1',
    'test_sandbox_preview_workflow_integrity_v1',
    # These writer overlays describe immutable releases. They are executed
    # against byte-verified source snapshots by the historical snapshot runner,
    # never against the current candidate tree.
    'test_google_writer_admin_close_integrity_v1',
    'test_google_writer_manifest_compatibility_integrity_v2',
    'test_google_writer_preview_formula_integrity_v1',
    'test_google_writer_prewrite_stage_integrity_v1',
    'test_legacy_reconciliation_evidence_v2_integrity',
    'test_google_writer_prewrite_diagnostics_integrity_v2',
    'test_google_writer_prewrite_readonly_integrity_v1',
    'test_sandbox_execution_envelope_limit_v1',
    'test_sandbox_execution_prewrite_egress_integrity_v1',
    'test_google_writer_append_continuation_integrity_v1',
    # v2 pins its historical source runner; the new runner is checked by the
    # current infrastructure overlay and this old assertion runs on its exact snapshot.
    'test_google_writer_legacy_source_snapshots_history_v2',
}
EXACT_TREE_OVERLAY_MODULES={
    # Continuation v2-v5, Apply Result v5-v10, and integrated candidate v1-v4
    # run from exact Git snapshots. Integrated candidate v5 pins current files.
    'test_google_writer_append_continuation_integrity_v2',
    'test_google_writer_append_continuation_integrity_v3',
    'test_google_writer_append_continuation_integrity_v4',
    'test_google_writer_append_continuation_integrity_v5',
    'test_google_writer_apply_result_integrity_v5',
    'test_google_writer_apply_result_integrity_v6',
    'test_google_writer_apply_result_integrity_v7',
    'test_google_writer_apply_result_integrity_v8',
    'test_google_writer_apply_result_integrity_v9',
    'test_google_writer_apply_result_integrity_v10',
    # Integrated UI v1/v2 stay bound to immutable snapshots; v3 pins the current
    # checkout. The aggregate runner invokes each route explicitly.
    'test_google_writer_integrated_candidate_integrity_v1',
    'test_google_writer_integrated_candidate_integrity_v2',
    'test_google_writer_integrated_candidate_integrity_v3',
    'test_google_writer_integrated_candidate_integrity_v4',
    'test_google_writer_integrated_candidate_integrity_v5',
    # Run this original exact-source pin on the immutable 1fd48f4 fixture;
    # the candidate carries its own additive prepared-intent retry overlay.
    'test_partial_reconciliation_first_append_only_integrity_v1',
    # Keep the prepared-retry v1 pin on its immutable d386586 snapshot;
    # newer receipt-recovery changes are pinned by the additive v2 overlay.
    'test_partial_reconciliation_prepared_append_only_retry_integrity_v1',
    # Receipt-recovery v1 remains pinned to its original 24554fef tree; its
    # additive successor is tested against the current candidate separately.
    'test_google_writer_receipt_recovery_integrity_v1',
    # ALL-scope recovery v1 is immutable at 9037e57; v2 pins the manifest
    # compatibility correction against the evolving candidate.
    'test_google_writer_all_scope_receipt_recovery_integrity_v1',
    # The source-snapshot v1 assertions run against their materialized pinned
    # tree through the additive history runner, never against candidate files.
    'test_google_writer_legacy_source_snapshots_integrity_v1',
    # Legacy append reconciliation v1 remains pinned to the original 1111eb9
    # profile source; its source-digest-absence successor is an additive v2.
    'test_legacy_append_reconciliation_integrity_v1',
    # Legacy append reconciliation v2 remains pinned to the exact 98eb5d5
    # source snapshot; the corrected 25+0 profile is pinned by additive v3.
    'test_legacy_append_reconciliation_integrity_v2',
    # The v3 and bounded-read exact-source contracts run only against their
    # immutable source snapshots, never against the evolving candidate tree.
    'test_legacy_append_reconciliation_integrity_v3',
    # The flattened discovery copy is also present beside the namespace import.
    'test_legacy_sheet_read_bounds_integrity_v1',
    'validation.local_release_20260911.test_legacy_sheet_read_bounds_integrity_v1',
}

def selected_suite(suite,mode):
    selected=[]
    def visit(node):
        for test in node:
            if isinstance(test,unittest.TestSuite):visit(test)
            else:
                modules=set(test.id().split('.')[:-1])
                if modules & EXACT_TREE_OVERLAY_MODULES:
                    continue
                historic=bool(modules & HISTORICAL_INTEGRITY_MODULES)
                if (mode=='historical_integrity' and historic) or (mode!='historical_integrity' and not historic):
                    selected.append(test)
    visit(suite)
    return unittest.TestSuite(selected)

def copy_candidate_manifests(source_root, validation_target, mode):
    if mode == 'historical_integrity':
        return
    source_validation=Path(source_root)/'validation'
    target_validation=Path(validation_target)
    target_validation.mkdir(parents=True, exist_ok=True)
    manifests=list(source_validation.glob('sandbox_preview_*.json'))
    for release_dir in source_validation.glob('local_release_*'):
        if release_dir.is_dir():
            manifests.extend(release_dir.rglob('*.json'))
    for source in sorted(manifests):
        relative=source.relative_to(source_validation)
        target=target_validation/relative
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(source,target)


def copy_pinned_release_file(source_root, target_root, relative_path, expected_sha256):
    """Copy an allowlisted release-test dependency only when its bytes are pinned."""
    relative_path=Path(relative_path)
    source=Path(source_root)/relative_path
    if not source.is_file():
        raise FileNotFoundError(f'Required pinned Release Gate file missing: {relative_path.as_posix()}')
    source_sha256=hashlib.sha256(source.read_bytes()).hexdigest()
    if source_sha256!=expected_sha256:
        raise RuntimeError(f'Required pinned Release Gate file SHA-256 mismatch: {relative_path.as_posix()}')
    target=Path(target_root)/relative_path
    target.parent.mkdir(parents=True,exist_ok=True)
    shutil.copyfile(source,target)
    if hashlib.sha256(target.read_bytes()).hexdigest()!=expected_sha256:
        raise RuntimeError(f'Staged Release Gate file SHA-256 mismatch: {relative_path.as_posix()}')
    return target


def stage_gitattributes(source_root, target_root):
    """Stage checkout EOL rules in the disposable tree when the candidate has them."""
    source=Path(source_root)/'.gitattributes'
    if not source.is_file():
        return None
    target=Path(target_root)/'.gitattributes'
    target.parent.mkdir(parents=True,exist_ok=True)
    shutil.copy2(source,target)
    if target.read_bytes()!=source.read_bytes():
        raise RuntimeError('Staged .gitattributes differs from candidate source')
    return target


def release_fixture_source(source_root, infrastructure_root, fixture_name, mode):
    """Resolve a named fixture without ever falling back to product source.

    Historical source archives may predate later immutable fixture archives.
    In that mode only the allowlisted fixture basename may be sourced from the
    current infrastructure checkout; tests verify each fixture's pinned SHA.
    Candidate runs retain their strict source-root-only behavior.
    """
    if not isinstance(fixture_name, str) or Path(fixture_name).name != fixture_name:
        raise ValueError("Release fixture must be an allowlisted basename")
    historical = Path(source_root) / "validation/fixtures" / fixture_name
    if historical.is_file():
        return historical
    if mode == "historical_integrity":
        infrastructure = Path(infrastructure_root) / "validation/fixtures" / fixture_name
        if infrastructure.is_file():
            return infrastructure
    return historical


def normalize_windows_sqlite_uri(database):
    if not isinstance(database,str) or not database.startswith('file:'):
        return database
    raw,separator,query=database[5:].partition('?')
    if len(raw)>=3 and raw[1]==':' and raw[2] in {'\\','/'}:
        return Path(raw).resolve().as_uri()+(('?'+query) if separator else '')
    return database


def install_windows_sqlite_uri_compatibility():
    """Normalize only absolute Windows file: URIs in the disposable test process.

    SQLite URI syntax requires a file URL (file:///C:/...) on Windows. Some
    application read-only paths intentionally build POSIX-style file URIs for
    Linux; this test-process adapter keeps those local tests portable without
    changing application code or database permissions.
    """
    original_connect=sqlite3.connect
    def connect(database,*args,**kwargs):
        if kwargs.get('uri'):
            database=normalize_windows_sqlite_uri(database)
        return original_connect(database,*args,**kwargs)
    sqlite3.connect=connect

def main():
    old_cwd=Path.cwd()
    mode=os.environ.get('PQM_RELEASE_MODE','')
    full_candidate_run=(not mode and len(sys.argv)==1) or mode=='baseline_full'
    with tempfile.TemporaryDirectory(prefix='pqm-local-suite-') as tmp:
        root=Path(tmp)
        stage_gitattributes(ROOT,root)
        for source in ROOT.iterdir():
            if source.name.startswith('.') or source.name in {'data','validation','__pycache__','backups','output','logs','evidence'}:continue
            if source.is_dir():shutil.copytree(source,root/source.name)
            else:shutil.copy2(source,root/source.name)
        for source in (ROOT/'validation/local_release_20260911').glob('test_*.py'):
            shutil.copy2(source,root/source.name)
        # Preserve namespace imports used by root-level regressions. The flat
        # copies above remain the discovery layout expected by delivered tests.
        shutil.copytree(ROOT/'validation/local_release_20260911',
                        root/'validation/local_release_20260911',
                        ignore=shutil.ignore_patterns('__pycache__'))
        # The integrated UI-v2 integrity contract pins this local-only
        # destination/safety smoke helper; include it in the disposable tree
        # so exact-tree and adversarial mutation checks see the same fixture.
        for helper_name in ('sandbox_editable_smoke.py', 'nazk_scheduler_failure_smoke.py',
                            'nazk_recovery_unit_smoke.py', 'sandbox_smoke.py', 'web_smoke.py',
                            'run_integrated_messages_v1_integrity.py',
                            'run_messages_search_header_v2_integrity.py',
                            'run_messages_header_polish_v3_integrity.py',
                            'run_sandbox_edr_google_nazk_reconcile_v1_integrity.py',
                            'run_google_edr_timezone_alias_v1_integrity.py', 'supplier_classification_planner.cjs', 'run_local_release.py', 'run_classification_parent_integrity.py',
                            'run_integrated_source_integrity_overlays.py',
                            'run_messages_integrated_v1_history.py',
                            'run_date_only_previous_contract_overlays.py',
                            'run_date_only_status_integrated_v2_history.py',
                            'run_supplier_classification_v3_integrity.py',
                            'run_supplier_manual_classification_v4_integrity.py',
                            'run_preview_digest_contract_v1_integrity.py',
                            'run_checkpointed_apply_v1_integrity.py',
                            'run_partial_reconciliation_second_v1_history.py',
                            'run_partial_reconciliation_first_append_only_v1_history.py',
                            'run_prepared_append_only_retry_v1_history.py',
                            'run_google_writer_receipt_recovery_v1_history.py',
                            'run_google_writer_all_scope_receipt_recovery_v1_history.py',
                            'run_google_writer_legacy_source_snapshots_v1_history.py',
                            'run_integrated_writer_ui_v1_history.py',
                            'run_integrated_writer_ui_v2_history.py',
                            'run_integrated_writer_ui_v3_history.py',
                            'run_integrated_writer_ui_v4_history.py',
                            'run_google_writer_historical_integrity_snapshots_v1.py',
                            'run_google_writer_prewrite_diagnostics_v2.py',
                            'run_google_writer_prewrite_readonly_v1.py',
                            'run_google_writer_execution_envelope_v1.py',
                            'run_google_writer_prewrite_egress_v1.py',
                            'run_legacy_append_reconciliation_v1_history.py',
                            'run_legacy_append_reconciliation_v2_history.py',
                            'run_immutable_google_writer_source_overlays.py',
                            'run_sandbox_preview_append_only_v1_history.py',
                            'run_sandbox_preview_workflow_v1_history.py',
                            'run_messages_integrated_v1_history_addendum.py'):
            helper_source=ROOT/'validation'/helper_name
            if not helper_source.is_file():
                helper_source=INFRA_ROOT/'validation'/helper_name
            if helper_source.is_file():
                shutil.copy2(helper_source,root/'validation'/helper_name)
        # This byte-pinned fixture is consumed from the working-tree root by
        # the historical Preview digest runner, rather than from validation/.
        preview_runtime_fixture='sandbox_runtime_messages_integrated_v1_86ea864.py'
        root_runtime_fixture=ROOT/preview_runtime_fixture
        if not root_runtime_fixture.is_file():
            root_runtime_fixture=INFRA_ROOT/preview_runtime_fixture
        if root_runtime_fixture.is_file():
            shutil.copy2(root_runtime_fixture,root/preview_runtime_fixture)
        snapshot_tree=ROOT/'validation/legacy_snapshots'
        if snapshot_tree.is_dir():
            shutil.copytree(snapshot_tree,root/'validation/legacy_snapshots',
                            dirs_exist_ok=True,ignore=shutil.ignore_patterns('__pycache__'))
        fixture_target=root/'validation/fixtures'
        fixture_target.mkdir(parents=True,exist_ok=True)
        validation_target=root/'validation'
        validation_target.mkdir(parents=True,exist_ok=True)
        c246_manifest_relative=Path('validation/c246_historical_integrity_snapshots_v1.json')
        c246_runner_relative=c246_manifest_relative.with_name(f'run_{c246_manifest_relative.stem}.py')
        copy_pinned_release_file(ROOT,root,c246_runner_relative,C246_RUNNER_SHA256)
        for relative_path,expected_sha256 in C246_STAGING_FILE_SHA256.items():
            copy_pinned_release_file(ROOT,root,relative_path,expected_sha256)
        v2_archive=ROOT/'validation/fixtures/pqm_sync_ui_integrated_v2_0d7e059.zip'
        if mode!='historical_integrity' and not v2_archive.is_file():
            v2_archive.parent.mkdir(parents=True,exist_ok=True)
            archive_env=os.environ.copy()
            archive_env['PQM_INTEGRATED_V2_ARCHIVE_OUT']=str(v2_archive)
            materialized=subprocess.run(
                [sys.executable,str(ROOT/'validation/run_integrated_writer_ui_v2_history.py')],
                cwd=old_cwd,env=archive_env,check=False)
            if materialized.returncode:
                raise RuntimeError('Integrated v2 immutable snapshot could not be staged')
        fixture_names=('supplier_classification_parent_integrity_6b9830b.zip', 'supplier_classification_parent_6b9830b.json', 'messages_v1_test_parent.zip',
                             'google_writer_supplier_types_integration_v1_97788.zip',
                             'integrated_classification_v1_overlay_6b9830b.zip', 'integrated_writer_v1_overlay_64f7fda.zip',
                             'messages_parent_c246edef.zip',
                             'protocol_integrity_history.zip',
                             'nazk_authority_parent_c246.zip',
                             'nazk_authority_request_v1.json',
                             'nazk_integrity_baseline_de77401.zip',
                             'column_widths_baseline_4625498.zip',
                             'nazk_preview_baseline_f394d4c.zip',
                             'appeals_scenario_v11_tail.zip',
                             'appeals_scenario_v11_api_tail.zip',
                             'table_widths_v11_tail.zip',
                             'dst_parent_94c5e37.zip',
                             'dst_v5_parent_overrides.zip',
                             'nazk_recovery_v2_parent_overrides.zip',
                             'nazk_recovery_testfix_parent_override.zip',
                             'nazk_recovery_baseline_990483_server.py',
                             'nazk_recovery_test_v2_compat.zip',
                             'nazk_recovery_v4_tree_overrides.zip',
                             'messages_integrated_v1_overrides.zip',
                             'messages_search_header_v2_overrides.zip',
                             'messages_search_header_v2_runner_40da.zip',
                             'messages_header_polish_v3_baseline_40da.zip',
                             'edr_google_nazk_baseline_40da.zip',
                             'edr_google_nazk_personal_theme_baseline_40da.zip',
                             'edr_google_nazk_reconcile_v1_candidate_a40aa70.zip',
                             'edr_google_nazk_contract_v2_baseline_64f7fda.zip',
                             'google_edr_timezone_alias_v1_baseline_6c310.zip',
                             'messages_integrated_v1_appjs_baseline_6c310.zip',
                             'edr_preview_skipped_v1_6b9830b.zip',
                             'google_writer_supplier_types_v1_97788.zip',
                             'google_edr_date_only_midnight_v1_97788.zip',
                             'supplier_classification_v3_baseline_59177.zip',
                             'supplier_manual_classification_v4_baseline_e0fed.zip',
                             'edr_status_evidence_v1_15b8.zip',
                             'date_only_edr_status_integrated_v1_12329.zip',
                             'date_only_status_integrated_v2_a1f8.zip',
                             'preview_digest_contract_v1_baseline_3a63ac.zip',
                             'checkpointed_apply_v1_exact_c8a97d6.zip',
                             'release_checks_baseline_0347404.yml',
                             'sandbox_preview_append_only_v1_exact_067e2e8.zip',
                             'sandbox_preview_workflow_v1_exact_067e2e8.zip',
                             'partial_reconciliation_first_append_only_v1_exact_1fd48f4.zip',
                              'prepared_append_only_retry_v1_exact_d386586.zip',
                             'google_writer_receipt_recovery_v1_exact_24554fef.zip',
                             'google_writer_all_scope_receipt_recovery_v1_9037e57.zip',
                             'google_writer_legacy_source_snapshots_v1_run_local_release.py',
                             'google_writer_historical_integrity_snapshots_v1_compact.zip',
                             'pqm_sync_ui_integrated_v1_3eda816.zip',
                             'pqm_sync_ui_integrated_v2_0d7e059.zip',
                            'pqm_sync_ui_integrated_v3_8c6ba07.zip',
                            'pqm_sync_ui_integrated_v4_654bd0de.zip',
                             'legacy_append_reconciliation_v1_exact_1111eb9.zip',
                             'legacy_append_reconciliation_v2_exact_98eb5d5.zip',
                             'google_writer_legacy_reconciliation_v3_immutable.zip',
                             'google_writer_legacy_sheet_bounds_v1_immutable.zip')
        for fixture_name in fixture_names:
            fixture_source=release_fixture_source(ROOT,INFRA_ROOT,fixture_name,mode)
            if fixture_name=='google_writer_historical_integrity_snapshots_v1_compact.zip':
                fixture_source=INFRA_ROOT/'validation/fixtures'/fixture_name
            if not fixture_source.is_file():
                if mode=='historical_integrity':
                    continue
                raise FileNotFoundError(f'Candidate release fixture missing: {fixture_name}')
            shutil.copy2(fixture_source,fixture_target/fixture_name)
        history_ledger=INFRA_ROOT/'validation/google_writer_historical_integrity_snapshots_v1.json'
        if history_ledger.is_file():
            shutil.copy2(history_ledger,validation_target/'google_writer_historical_integrity_snapshots_v1.json')
        copy_candidate_manifests(ROOT, validation_target, mode)
        for helper in ('nazk_preview_fixture.py', 'nazk_preview_browser_fixture.py'):
            shutil.copy2(ROOT/'validation'/helper, root/'validation'/helper)
        # The runner is itself pinned by the column-width integrity variant.
        shutil.copy2(INFRA_ROOT/'validation/run_local_release.py',root/'validation/run_local_release.py')
        shutil.copy2(ROOT/'validation/docker_release_gate.py',root/'validation/docker_release_gate.py')
        # The integrated UI integrity manifest now guards the required host-runner
        # browser workflow, so include that exact CI file in the disposable tree.
        workflow_source=ROOT/'.github/workflows/release-checks.yml'
        workflow_target=root/'.github/workflows/release-checks.yml'
        workflow_target.parent.mkdir(parents=True,exist_ok=True)
        shutil.copy2(workflow_source,workflow_target)
        # Node regressions run against this same disposable source fixture.
        for source in (ROOT/'validation').glob('*.cjs'):
            shutil.copy2(source,root/'validation'/source.name)
        # Delivered tests assume runtime DOCX copies have already been installed.
        shutil.copytree(root/'templates', root/'data/templates', dirs_exist_ok=True)
        os.environ.update(HOST='127.0.0.1',PORT='8080',PQM_ENV='local',PQM_DATA_DIR=str(root/'data'),PQM_DB_PATH=str(root/'data/pqm.sqlite3'),
                          PQM_RELEASE_SCHEMA_ONLY='0',PQM_AUTH_ENABLED='0',PQM_USERS_JSON='',
                          PQM_ENABLE_SCHEDULER='0',PQM_ENABLE_PROZORRO_SCHEDULER='0',PQM_ENABLE_VIOLATION_SCHEDULER='0',
                          PQM_ENABLE_NAZK_SCHEDULER='0',PQM_ENABLE_GOOGLE='0',PQM_ENABLE_BROWSER='0',
                          PQM_ENABLE_BIDS_UPDATE='0',PQM_ENABLE_POWERBI='0',PQM_BIDS_MODE='disabled')
        original_connect=socket.socket.connect
        original_getfqdn=socket.getfqdn
        socket.getfqdn=lambda name='':name or 'localhost'
        def isolated_connect(sock,address):
            if isinstance(address,tuple) and address[0] not in {'127.0.0.1','localhost','::1'}:
                raise RuntimeError('Outbound network forbidden in release tests')
            return original_connect(sock,address)
        socket.socket.connect=isolated_connect
        os.chdir(root)
        sys.path.insert(0,str(root))
        try:
            install_windows_sqlite_uri_compatibility()
            import server
            server.init_db()
            server.init_reference_tables(server.DB_PATH)
            import scheduler_runtime
            with closing(server.db()) as con:
                with con:scheduler_runtime.migrate(con)
            suite=unittest.defaultTestLoader.discover(str(root),pattern=sys.argv[1] if len(sys.argv)>1 else 'test_*.py')
            if mode=='historical_integrity' or full_candidate_run or mode=='baseline_candidate':
                suite=selected_suite(suite,'historical_integrity' if mode=='historical_integrity' else 'candidate')
            result=unittest.TextTestRunner(verbosity=2).run(suite)
            if mode=='historical_integrity':
                integrated_v1_history=subprocess.run(
                    [sys.executable,str(ROOT/'validation/run_integrated_writer_ui_v1_history.py')],
                    cwd=old_cwd,check=False)
                integrated_v2_history=subprocess.run(
                    [sys.executable,str(ROOT/'validation/run_integrated_writer_ui_v2_history.py')],
                    cwd=old_cwd,check=False)
                return 0 if result.wasSuccessful() and integrated_v1_history.returncode==0 and integrated_v2_history.returncode==0 else 1
            if not full_candidate_run:
                return 0 if result.wasSuccessful() else 1
            candidate_ok=result.wasSuccessful()
            v1_overlay=subprocess.run(
                [sys.executable, str(ROOT/'validation/run_messages_integrated_v1_history_addendum.py')],
                cwd=old_cwd, check=False)
            v2_overlay=subprocess.run(
                [sys.executable, str(ROOT/'validation/run_classification_parent_integrity.py'),'--messages-v2'],
                cwd=old_cwd, check=False)
            v3_overlay=subprocess.run(
                [sys.executable, str(ROOT/'validation/run_messages_header_polish_v3_integrity.py')],
                cwd=old_cwd, check=False)
            edr_v1_overlay=subprocess.run(
                [sys.executable, str(ROOT/'validation/run_sandbox_edr_google_nazk_reconcile_v1_integrity.py')],
                cwd=old_cwd, check=False)
            google_timezone_v1_overlay=subprocess.run(
                [sys.executable, str(ROOT/'validation/run_google_edr_timezone_alias_v1_integrity.py')],
                cwd=old_cwd, check=False)
            classification_parent_overlay=subprocess.run(
                [sys.executable,str(ROOT/'validation/run_classification_parent_integrity.py')],
                cwd=old_cwd,check=False)
            classification_v3_overlay=subprocess.run(
                [sys.executable,str(ROOT/'validation/run_supplier_classification_v3_integrity.py')],
                cwd=old_cwd,check=False)
            manual_classification_v4_overlay=subprocess.run(
                [sys.executable,str(ROOT/'validation/run_supplier_manual_classification_v4_integrity.py')],
                cwd=old_cwd,check=False)
            source_integrity_overlays=subprocess.run(
                [sys.executable,str(ROOT/'validation/run_integrated_source_integrity_overlays.py')],
                cwd=old_cwd,check=False)
            date_only_previous_contract_overlays=subprocess.run(
                [sys.executable,str(ROOT/'validation/run_date_only_previous_contract_overlays.py')],
                cwd=old_cwd,check=False)
            date_only_status_v2_overlay=subprocess.run(
                [sys.executable,str(ROOT/'validation/run_date_only_status_integrated_v2_history.py')],
                cwd=old_cwd,check=False)
            preview_digest_v1_overlay=subprocess.run(
                [sys.executable,str(ROOT/'validation/run_preview_digest_contract_v1_integrity.py')],
                cwd=old_cwd,check=False)
            checkpointed_apply_v1_overlay=subprocess.run(
                [sys.executable,str(ROOT/'validation/run_checkpointed_apply_v1_integrity.py')],
                cwd=old_cwd,check=False)
            partial_reconciliation_second_v1_overlay=subprocess.run(
                [sys.executable,str(ROOT/'validation/run_partial_reconciliation_second_v1_history.py')],
                cwd=old_cwd,check=False)
            sandbox_preview_append_only_v1_overlay=subprocess.run(
                [sys.executable,str(ROOT/'validation/run_sandbox_preview_append_only_v1_history.py')],
                cwd=old_cwd,check=False)
            sandbox_preview_workflow_v1_overlay=subprocess.run(
                [sys.executable,str(ROOT/'validation/run_sandbox_preview_workflow_v1_history.py')],
                cwd=old_cwd,check=False)
            first_append_only_v1_overlay=subprocess.run(
                [sys.executable,str(ROOT/'validation/run_partial_reconciliation_first_append_only_v1_history.py')],
                cwd=old_cwd,check=False)
            prepared_retry_v1_overlay=subprocess.run(
                [sys.executable,str(ROOT/'validation/run_prepared_append_only_retry_v1_history.py')],
                cwd=old_cwd,check=False)
            receipt_recovery_v1_overlay=subprocess.run(
                [sys.executable,str(ROOT/'validation/run_google_writer_receipt_recovery_v1_history.py')],
                cwd=old_cwd,check=False)
            all_scope_recovery_v1_overlay=subprocess.run(
                [sys.executable,str(ROOT/'validation/run_google_writer_all_scope_receipt_recovery_v1_history.py')],
                cwd=old_cwd,check=False)
            legacy_append_reconciliation_v1_overlay=subprocess.run(
                [sys.executable,str(ROOT/'validation/run_legacy_append_reconciliation_v1_history.py')],
                cwd=old_cwd,check=False)
            legacy_append_reconciliation_v2_overlay=subprocess.run(
                [sys.executable,str(ROOT/'validation/run_legacy_append_reconciliation_v2_history.py')],
                cwd=old_cwd,check=False)
            immutable_google_writer_source_overlays=subprocess.run(
                [sys.executable,str(ROOT/'validation/run_immutable_google_writer_source_overlays.py')],
                cwd=old_cwd,check=False)
            # c246 contracts are run by the mandatory workflow snapshot step
            # before the container is built. The release image intentionally
            # has no .git directory, so do not attempt a second Git-backed run
            # from inside that image.
            writer_history_snapshots=subprocess.run(
                [sys.executable,str(root/'validation/run_google_writer_historical_integrity_snapshots_v1.py')],
                cwd=old_cwd,check=False)
            integrated_v1_history=subprocess.run(
                [sys.executable,str(ROOT/'validation/run_integrated_writer_ui_v1_history.py')],
                cwd=old_cwd,check=False)
            integrated_v2_history=subprocess.run(
                [sys.executable,str(ROOT/'validation/run_integrated_writer_ui_v2_history.py')],
                cwd=old_cwd,check=False)
            integrated_v3_history=subprocess.run(
                [sys.executable,str(ROOT/'validation/run_integrated_writer_ui_v3_history.py')],
                cwd=old_cwd,check=False)
            integrated_v4_history=subprocess.run(
                [sys.executable,str(ROOT/'validation/run_integrated_writer_ui_v4_history.py')],
                cwd=old_cwd,check=False)
            integrated_v5_current=subprocess.run(
                [sys.executable,'-B','-m','unittest','-v',
                 'test_google_writer_integrated_candidate_integrity_v5'],
                cwd=ROOT,check=False)
            return 0 if candidate_ok and v1_overlay.returncode==0 and v2_overlay.returncode==0 and v3_overlay.returncode==0 and edr_v1_overlay.returncode==0 and google_timezone_v1_overlay.returncode==0 and classification_parent_overlay.returncode==0 and classification_v3_overlay.returncode==0 and manual_classification_v4_overlay.returncode==0 and source_integrity_overlays.returncode==0 and date_only_previous_contract_overlays.returncode==0 and date_only_status_v2_overlay.returncode==0 and preview_digest_v1_overlay.returncode==0 and checkpointed_apply_v1_overlay.returncode==0 and partial_reconciliation_second_v1_overlay.returncode==0 and sandbox_preview_append_only_v1_overlay.returncode==0 and sandbox_preview_workflow_v1_overlay.returncode==0 and first_append_only_v1_overlay.returncode==0 and prepared_retry_v1_overlay.returncode==0 and receipt_recovery_v1_overlay.returncode==0 and all_scope_recovery_v1_overlay.returncode==0 and legacy_append_reconciliation_v1_overlay.returncode==0 and legacy_append_reconciliation_v2_overlay.returncode==0 and immutable_google_writer_source_overlays.returncode==0 and writer_history_snapshots.returncode==0 and integrated_v1_history.returncode==0 and integrated_v2_history.returncode==0 and integrated_v3_history.returncode==0 and integrated_v4_history.returncode==0 and integrated_v5_current.returncode==0 else 1
        finally:
            socket.socket.connect=original_connect
            socket.getfqdn=original_getfqdn
            os.chdir(old_cwd)
            gc.collect()  # Release cyclic SQLite handles before Windows cleanup.
            logging.shutdown()

if __name__=='__main__':raise SystemExit(main())
