import base64
import hashlib
import io
import json
import sqlite3
import tempfile
import unittest
from datetime import datetime, timezone
from pathlib import Path
from contextlib import closing

import google_writer_execution as execution


TEST_REQUEST_ID = 'd' * 32
TEST_RECONCILIATION_ID = 'e' * 32
TEST_ACTOR = 'sandbox-admin'
TEST_DIGEST = base64.urlsafe_b64encode(hashlib.sha256(b'test plan').digest()).decode().rstrip('=')
TEST_NOW = datetime(2026, 11, 3, 12, 0, tzinfo=timezone.utc)


class PartialReconciliationTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(dir=Path(__file__).parent)
        self.path = str(Path(self.temp.name) / 'sandbox.sqlite3')
        self.old_fingerprint = execution.PARTIAL_RECONCILIATION_REQUEST_FINGERPRINT
        self.old_profiles = execution.PARTIAL_RECONCILIATION_PROFILES
        execution.PARTIAL_RECONCILIATION_REQUEST_FINGERPRINT = execution.request_id_fingerprint(TEST_REQUEST_ID)
        execution.PARTIAL_RECONCILIATION_PROFILES = dict(self.old_profiles)
        execution.PARTIAL_RECONCILIATION_PROFILES[
            execution.PARTIAL_RECONCILIATION_REQUEST_FINGERPRINT
        ] = self.old_profiles[execution._PARTIAL_RECONCILIATION_FIRST_FINGERPRINT]
        with closing(sqlite3.connect(self.path)) as con, con:
            execution.migrate(con)
            con.execute('''INSERT INTO google_writer_runs(
              request_id,environment,trigger,actor,revision,started_at,finished_at,status,result_json)
              VALUES(?,?,?,?,?,?,?,?,?)''',(
                TEST_REQUEST_ID,'SANDBOX','manual','original-operator',3,
                '2026-11-03T12:00:00+00:00','2026-11-03T12:01:00+00:00',
                'outcome_unknown',json.dumps({'status':'OUTCOME_UNKNOWN_HOLD_NO_RETRY'})))

    def tearDown(self):
        execution.PARTIAL_RECONCILIATION_REQUEST_FINGERPRINT = self.old_fingerprint
        execution.PARTIAL_RECONCILIATION_PROFILES = self.old_profiles
        self.temp.cleanup()

    def prepare(self, reconciliation_id=TEST_RECONCILIATION_ID, fingerprint=None):
        return execution.prepare_partial_reconciliation(
            self.path,'SANDBOX',reconciliation_id,
            fingerprint or execution.PARTIAL_RECONCILIATION_REQUEST_FINGERPRINT,
            TEST_ACTOR,now=TEST_NOW)

    def receipt(self, prepared):
        profile = execution.partial_reconciliation_profile(prepared['request_fingerprint'])
        return {
            'environment':'SANDBOX',
            'scriptId':execution.IDENTITIES['SANDBOX'][0],
            'spreadsheetId':execution.IDENTITIES['SANDBOX'][1],
            'contract':execution.CONTRACT,
            'requestId':prepared['request_id'],
            'status':'RECONCILED_PARTIAL',
            'reconciliationId':prepared['reconciliation_id'],
            'requestFingerprint':prepared['request_fingerprint'],
            'evidenceDigest':prepared['evidence_digest'],
            'digest':TEST_DIGEST,
            'counts':profile['result_counts']
        }

    def state(self):
        with closing(sqlite3.connect(self.path)) as con:
            run=con.execute('SELECT status,result_json FROM google_writer_runs WHERE request_id=?',(TEST_REQUEST_ID,)).fetchone()
            audit=con.execute('''SELECT state,original_status,original_result_json,apps_script_receipt_json
              FROM google_writer_run_reconciliations WHERE request_id=?''',(TEST_REQUEST_ID,)).fetchone()
        return run,audit

    def test_prepare_keeps_unknown_hold_and_persists_original_evidence(self):
        prepared=self.prepare()
        run,audit=self.state()
        self.assertEqual(prepared['state'],'prepared')
        self.assertEqual(run[0],'outcome_unknown')
        self.assertEqual(json.loads(run[1]),{'status':'OUTCOME_UNKNOWN_HOLD_NO_RETRY'})
        self.assertEqual(audit[0:2],('prepared','outcome_unknown'))
        self.assertEqual(json.loads(audit[2]),{'status':'OUTCOME_UNKNOWN_HOLD_NO_RETRY'})
        self.assertEqual(audit[3],'{}')

    def test_mismatch_and_production_fail_before_any_reconciliation_record(self):
        with self.assertRaises(ValueError): self.prepare(fingerprint='0'*24)
        with self.assertRaises(PermissionError):
            execution.prepare_partial_reconciliation(self.path,'PROD',TEST_RECONCILIATION_ID,
              execution.PARTIAL_RECONCILIATION_REQUEST_FINGERPRINT,TEST_ACTOR,now=TEST_NOW)
        self.assertEqual(self.state()[0][0],'outcome_unknown')
        self.assertIsNone(self.state()[1])

    def test_second_run_profile_is_separate_and_preparation_keeps_hold(self):
        test_fingerprint = execution.request_id_fingerprint(TEST_REQUEST_ID)
        second_profile = execution.PARTIAL_RECONCILIATION_PROFILES[
            '18a4aba10c1c13ab3bf59f56'
        ]
        profiles = dict(execution.PARTIAL_RECONCILIATION_PROFILES)
        profiles[test_fingerprint] = second_profile
        old_profiles = execution.PARTIAL_RECONCILIATION_PROFILES
        execution.PARTIAL_RECONCILIATION_PROFILES = profiles
        try:
            prepared = self.prepare(fingerprint=test_fingerprint)
            result = execution.finalize_partial_reconciliation(
                self.path, TEST_RECONCILIATION_ID, TEST_ACTOR,
                self.receipt(prepared), now=TEST_NOW)
        finally:
            execution.PARTIAL_RECONCILIATION_PROFILES = old_profiles
        self.assertEqual(prepared['evidence'], second_profile['evidence'])
        self.assertEqual(prepared['evidence']['initial_plan'],
            {'append':401,'update':2,'conflict':2})
        self.assertEqual(prepared['evidence']['verified_append_by_tab'], {'ФОП':46,'ЮО':4})
        self.assertEqual(prepared['evidence']['blank_sheet_source_date_state'], {'empty_string':36})
        self.assertEqual(prepared['evidence']['blank_sheet_source_precision_state'], {'missing':36})
        self.assertEqual(prepared['evidence']['updates_disposition'], 'UNVERIFIED_NO_HISTORIC_PLAN')
        self.assertEqual(prepared['state'], 'prepared')
        self.assertEqual(result['status'], 'RECONCILED_PARTIAL')
        run, audit = self.state()
        self.assertEqual(run[0], 'partial')
        self.assertEqual(audit[0:2], ('reconciled_partial', 'outcome_unknown'))
        with closing(sqlite3.connect(self.path)) as con:
            evidence_json = con.execute(
                'SELECT evidence_json FROM google_writer_run_reconciliations WHERE request_id=?',
                (TEST_REQUEST_ID,)).fetchone()[0]
        self.assertEqual(json.loads(evidence_json), second_profile['evidence'])
        self.assertEqual(json.loads(run[1])['original_status'], 'outcome_unknown')

    def test_concurrent_unknown_or_running_state_fails_closed(self):
        other='f'*32
        with closing(sqlite3.connect(self.path)) as con, con:
            con.execute('DROP INDEX ix_google_writer_single_lane')
            con.execute('''INSERT INTO google_writer_runs(request_id,environment,trigger,actor,revision,started_at,status,result_json)
              VALUES(?,?,?,?,?,?,?,?)''',(other,'SANDBOX','manual','other',3,'2026-11-03T12:02:00+00:00',
              'outcome_unknown','{}'))
        with self.assertRaises(RuntimeError): self.prepare()
        with closing(sqlite3.connect(self.path)) as con, con:
            con.execute("DELETE FROM google_writer_runs WHERE request_id=?",(other,))
            con.execute("UPDATE google_writer_runs SET status='running' WHERE request_id=?",(TEST_REQUEST_ID,))
        with self.assertRaises(RuntimeError): self.prepare()
        self.assertIsNone(self.state()[1])

    def test_invalid_remote_receipt_keeps_sqlite_hold(self):
        prepared=self.prepare()
        bad=self.receipt(prepared)
        bad['evidenceDigest']='A'*43
        with self.assertRaises(PermissionError):
            execution.finalize_partial_reconciliation(self.path,TEST_RECONCILIATION_ID,TEST_ACTOR,bad,now=TEST_NOW)
        self.assertEqual(self.state()[0][0],'outcome_unknown')
        self.assertEqual(self.state()[1][0],'prepared')

    def test_finalize_is_audited_partial_and_idempotent(self):
        prepared=self.prepare()
        result=execution.finalize_partial_reconciliation(
            self.path,TEST_RECONCILIATION_ID,TEST_ACTOR,self.receipt(prepared),now=TEST_NOW)
        self.assertEqual(result['status'],'RECONCILED_PARTIAL')
        self.assertFalse(result['idempotent'])
        run,audit=self.state()
        self.assertEqual(run[0],'partial')
        self.assertEqual(json.loads(run[1])['status'],'RECONCILED_PARTIAL')
        self.assertEqual(audit[0:2],('reconciled_partial','outcome_unknown'))
        self.assertEqual(json.loads(audit[2]),{'status':'OUTCOME_UNKNOWN_HOLD_NO_RETRY'})
        self.assertNotEqual(audit[3],'{}')
        retry=self.prepare()
        self.assertTrue(retry['idempotent'])
        again=execution.finalize_partial_reconciliation(
            self.path,TEST_RECONCILIATION_ID,TEST_ACTOR,self.receipt(prepared),now=TEST_NOW)
        self.assertTrue(again['idempotent'])

    def test_different_reconciliation_id_cannot_take_over_prepared_run(self):
        self.prepare()
        with self.assertRaises(RuntimeError): self.prepare(reconciliation_id='a'*32)
        self.assertEqual(self.state()[0][0],'outcome_unknown')

    def test_execution_client_signs_the_exact_reconciliation_evidence_and_validates_receipt(self):
        self_id=TEST_REQUEST_ID
        evidence=execution.PARTIAL_RECONCILIATION_EVIDENCE
        evidence_raw=json.dumps(evidence,ensure_ascii=False,sort_keys=True,separators=(',',':'))
        evidence_digest=base64.urlsafe_b64encode(hashlib.sha256(evidence_raw.encode()).digest()).decode().rstrip('=')
        calls=[]
        def opener(request,timeout):
            calls.append((request,timeout))
            body=json.loads(request.data)
            message=json.loads(body['parameters'][0]['payload'])
            receipt={k:message[k] for k in ('environment','scriptId','spreadsheetId','contract','requestId')}
            receipt.update(status='RECONCILED_PARTIAL',digest=TEST_DIGEST,
                reconciliationId=TEST_RECONCILIATION_ID,
                requestFingerprint=execution.PARTIAL_RECONCILIATION_REQUEST_FINGERPRINT,
                evidenceDigest=evidence_digest,
                counts={'verified_append_rows':50,'unverified_original_updates':2,'accepted_date_only_formats':12})
            return io.BytesIO(json.dumps({'done':True,'response':{'result':receipt}}).encode())
        client=execution.ExecutionClient('SANDBOX','TEST_DEPLOYMENT_NOT_CLOUD',
          'TEST_ONLY_SECRET_0123456789_ABCDEFGHIJ',
          lambda env:{'environment':env,'access_token':'TEST_ONLY','scopes':sorted(execution.PROJECT_SCOPES),
                      'expires_at':TEST_NOW.timestamp()+3600},
          configured=True,opener=opener,clock=lambda:TEST_NOW)
        result=client.invoke('reconcile_partial',self_id,TEST_ACTOR,trigger='manual',manual_authorized=True,
          reconciliation_id=TEST_RECONCILIATION_ID,
          request_fingerprint=execution.PARTIAL_RECONCILIATION_REQUEST_FINGERPRINT,evidence=evidence)
        request,timeout=calls[0]
        message=json.loads(json.loads(request.data)['parameters'][0]['payload'])
        self.assertEqual(timeout,390)
        self.assertEqual(message['evidenceDigest'],evidence_digest)
        self.assertEqual(message['evidence'],evidence)
        self.assertEqual(result['status'],'RECONCILED_PARTIAL')
        self.assertNotIn('TEST_ONLY',json.dumps(result))
        with self.assertRaises(ValueError):
            client.invoke('reconcile_partial',self_id,TEST_ACTOR,trigger='scheduled',
              reconciliation_id=TEST_RECONCILIATION_ID,
              request_fingerprint=execution.PARTIAL_RECONCILIATION_REQUEST_FINGERPRINT,evidence=evidence)


class AppendOnlyFirstChunkAuditReconciliationTests(unittest.TestCase):
    request_id = 'ab1d69b6d7c6427f8abdffea35830948'
    actor = 'original-sandbox-operator'
    recon_id = 'f' * 32

    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(dir=Path(__file__).parent, prefix='append-only-audit-recon-')
        self.path = str(Path(self.temp.name) / 'sandbox.sqlite3')
        with closing(sqlite3.connect(self.path)) as con, con:
            execution.migrate(con)
        self.profile = execution.partial_reconciliation_profile(
            execution.request_id_fingerprint(self.request_id))
        self.assertIsNotNone(self.profile)
        self.details = self._details()
        self.snapshot = execution.store_preview_plan(self.path, self.request_id, self.actor, self.details)
        claimed = execution.claim_run(self.path, 'SANDBOX', self.request_id, self.actor, 'manual',
            manual_authorized=True, plan_scope='APPEND_ONLY',
            plan_digest=self.details['append_only_digest'], details_digest=self.snapshot['details_digest'])
        self.assertTrue(claimed['claimed'])
        execution.hold_unknown_run(self.path, self.request_id, attempted_chunk=0,
            digest=self.details['append_only_digest'], checkpoint_digest=None)

    def tearDown(self):
        self.temp.cleanup()

    def _details(self):
        full_digest = base64.urlsafe_b64encode(hashlib.sha256(b'full-preview').digest()).decode().rstrip('=')
        append_digest = base64.urlsafe_b64encode(hashlib.sha256(b'append-only-preview').digest()).decode().rstrip('=')
        appends = [{'operation':'APPEND','tab':'ФОП','cells':[{'column':'A','formula':True}]}
                   for _ in range(351)]
        return {'version':1,'environment':'SANDBOX','plan_digest':full_digest,
            'append_only_digest':append_digest,'counts':{'append':351,'update':2,'conflict':2,'error':0},
            'appends':appends,'updates':[{'operation':'UPDATE','cells':[]} for _ in range(2)],
            'conflicts':[{'reason':'routing_mismatch'} for _ in range(2)],'errors':[]}

    def _prepare(self):
        fingerprint = execution.request_id_fingerprint(self.request_id)
        return execution.prepare_partial_reconciliation(self.path,'SANDBOX',self.recon_id,
            fingerprint,'sandbox-admin',now=TEST_NOW)

    def _receipt(self, prepared):
        return {'environment':'SANDBOX','scriptId':execution.IDENTITIES['SANDBOX'][0],
            'spreadsheetId':execution.IDENTITIES['SANDBOX'][1],'contract':execution.CONTRACT,
            'requestId':self.request_id,'status':'RECONCILED_PARTIAL','reconciliationId':self.recon_id,
            'requestFingerprint':prepared['request_fingerprint'],'evidenceDigest':prepared['evidence_digest'],
            'digest':self.details['append_only_digest'],'counts':self.profile['result_counts'],
            **self.profile['receipt_fields']}

    def _state(self):
        with closing(sqlite3.connect(self.path)) as con:
            run=con.execute('SELECT status,result_json FROM google_writer_runs WHERE request_id=?',
                (self.request_id,)).fetchone()
            recon=con.execute('''SELECT state,evidence_json,original_result_json,apps_script_receipt_json
                FROM google_writer_run_reconciliations WHERE request_id=?''',(self.request_id,)).fetchone()
        return run,recon

    def test_audit_only_profile_is_bound_to_saved_snapshot_and_never_creates_checkpoint(self):
        prepared=self._prepare()
        self.assertEqual(prepared['evidence']['checkpoint_present'],False)
        self.assertEqual(prepared['evidence']['audit']['full_matches'],25)
        self.assertEqual(prepared['evidence']['initial_plan']['append'],351)
        result=execution.finalize_partial_reconciliation(self.path,self.recon_id,'sandbox-admin',
            self._receipt(prepared),now=TEST_NOW)
        self.assertEqual(result['status'],'RECONCILED_PARTIAL')
        run,recon=self._state()
        self.assertEqual(run[0],'partial')
        self.assertEqual(recon[0],'reconciled_partial')
        evidence=json.loads(recon[1])
        self.assertFalse(evidence['checkpoint_present'])
        self.assertEqual(evidence['recovery_disposition'],'AUDIT_EVIDENCE_ONLY_NEW_PREVIEW_REQUIRED')
        self.assertFalse(json.loads(recon[3])['checkpointPresent'])
        self.assertFalse(json.loads(recon[3])['resumeAuthorized'])
        retry=execution.prepare_partial_reconciliation(self.path,'SANDBOX',self.recon_id,
            execution.request_id_fingerprint(self.request_id),'sandbox-admin',now=TEST_NOW)
        self.assertTrue(retry['idempotent'])

    def test_audit_only_profile_rejects_snapshot_or_checkpoint_binding_changes(self):
        with closing(sqlite3.connect(self.path)) as con, con:
            con.execute("UPDATE google_writer_runs SET result_json=json_set(result_json,'$.attempted_checkpoint_digest',?) WHERE request_id=?",
                (TEST_DIGEST,self.request_id))
        with self.assertRaises(RuntimeError): self._prepare()
        self.assertIsNone(self._state()[1])

    def test_audit_only_profile_rejects_changed_saved_preview_details(self):
        with closing(sqlite3.connect(self.path)) as con, con:
            con.execute("UPDATE google_writer_preview_plans SET details_json='{}' WHERE request_id=?",
                (self.request_id,))
        with self.assertRaises(RuntimeError): self._prepare()
        self.assertIsNone(self._state()[1])

    def test_execution_client_validates_audit_only_receipt_and_never_treats_it_as_resume(self):
        prepared=self._prepare()
        response_override={'counts':self.profile['result_counts'],**self.profile['receipt_fields']}
        calls=[]
        def opener(request, timeout):
            calls.append((request,timeout))
            body=json.loads(request.data)
            message=json.loads(body['parameters'][0]['payload'])
            receipt={key:message[key] for key in ('environment','scriptId','spreadsheetId','contract','requestId')}
            receipt.update(status='RECONCILED_PARTIAL',digest=self.details['append_only_digest'],
                reconciliationId=self.recon_id,requestFingerprint=prepared['request_fingerprint'],
                evidenceDigest=prepared['evidence_digest'],**response_override)
            return io.BytesIO(json.dumps({'done':True,'response':{'result':receipt}}).encode())
        client=execution.ExecutionClient('SANDBOX','TEST_DEPLOYMENT_NOT_CLOUD',
            'TEST_ONLY_SECRET_0123456789_ABCDEFGHIJ',
            lambda env:{'environment':env,'access_token':'TEST_ONLY','scopes':sorted(execution.PROJECT_SCOPES),
                'expires_at':TEST_NOW.timestamp()+3600},configured=True,opener=opener,clock=lambda:TEST_NOW)
        result=client.invoke('reconcile_partial',self.request_id,'sandbox-admin',trigger='manual',
            manual_authorized=True,reconciliation_id=self.recon_id,
            request_fingerprint=prepared['request_fingerprint'],evidence=prepared['evidence'])
        self.assertEqual(result['counts'],self.profile['result_counts'])
        self.assertFalse(result['checkpointPresent'])
        self.assertFalse(result['resumeAuthorized'])
        self.assertEqual(result['nextAction'],'NEW_PREVIEW_REQUIRED')
        self.assertEqual(len(calls),1)
        response_override['counts']={'audit_confirmed_existing_append_rows':24,'checkpoint_receipts':0}
        with self.assertRaises(execution.ExecutionOutcomeUnknown):
            client.invoke('reconcile_partial',self.request_id,'sandbox-admin',trigger='manual',
                manual_authorized=True,reconciliation_id=self.recon_id,
                request_fingerprint=prepared['request_fingerprint'],evidence=prepared['evidence'])
        self.assertEqual(len(calls),2)

    def test_audit_only_finalize_rejects_wrong_audit_count_or_resume_claim(self):
        prepared=self._prepare()
        bad=self._receipt(prepared)
        bad['counts']={'audit_confirmed_existing_append_rows':24,'checkpoint_receipts':0}
        with self.assertRaises(PermissionError):
            execution.finalize_partial_reconciliation(self.path,self.recon_id,'sandbox-admin',bad,now=TEST_NOW)
        bad=self._receipt(prepared);bad['resumeAuthorized']=True
        with self.assertRaises(PermissionError):
            execution.finalize_partial_reconciliation(self.path,self.recon_id,'sandbox-admin',bad,now=TEST_NOW)
        self.assertEqual(self._state()[0][0],'outcome_unknown')
        self.assertEqual(self._state()[1][0],'prepared')


if __name__ == '__main__':
    unittest.main()
