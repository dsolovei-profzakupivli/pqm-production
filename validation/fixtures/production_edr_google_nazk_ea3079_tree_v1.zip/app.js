const API = '/api';
const fieldMap = {
  protocolNumber:'protocol_number', protocolDate:'protocol_date', publicationDate:'publication_date',
  protocolOfficer:'protocol_officer', protocolRemarks:'protocol_remarks', protocolDecision:'protocol_decision', marketplaceDecision:'marketplace_decision', complianceStatus:'compliance_status', complianceComments:'compliance_comments', managerName:'manager_name', documentPackage:'document_package', contractDetails:'contract_details', authorityReview:'authority_review', mvsSealReview:'mvs_seal_review', notes:'notes'
};
let protocolOfficers=[];
let authorizedOfficerItems=[];
async function loadAuthorizedOfficers(activeOnly=true){
  const data=await request(`${API}/admin/officers${activeOnly?'?active=1':''}`);
  authorizedOfficerItems=data.items||[];
  if(activeOnly)protocolOfficers=authorizedOfficerItems.filter(x=>x.active).map(x=>x.full_name);
  return authorizedOfficerItems;
}
function officerOptions(current=''){
  const currentKey=String(current||'').trim().toLocaleUpperCase('uk-UA');
  const items=[...protocolOfficers];
  if(current&&!items.some(v=>v.toLocaleUpperCase('uk-UA')===currentKey))items.unshift(current);
  return `<option value="">Не визначено</option>`+items.map(v=>`<option value="${esc(v)}" ${v.toLocaleUpperCase('uk-UA')===currentKey?'selected':''}>${esc(formatOfficerName(v))}</option>`).join('');
}
function marketplaceApplicationsUrl(base,supplierCode){
  if(!base)return'';
  try{const url=new URL(base);url.searchParams.set('page','1');url.searchParams.set('contributor_name_or_srn',supplierCode);return url.toString()}
  catch{return`${base}${base.includes('?')?'&':'?'}page=1&contributor_name_or_srn=${encodeURIComponent(supplierCode)}`}
}
const protocolDecisions=[['','Не визначено'],['admit','Так'],['reject','Ні']];
const marketplaceDecisions=[['','Не виконано'],['admit','Допустити'],['reject','Відхилити']];
const marketplaceFilterLabels={__empty__:'Не виконано',admit:'Допустити',reject:'Відхилити'};
const complianceStatuses=[['','Не визначено'],['approved','Погоджено'],['rejected','Не погоджено']];
let remarksRow=null,remarksItems=[],remarksSelected=new Set();
const columns = [
  {key:'select',label:'',width:42,pin:'left',system:true},{key:'number',label:'№',width:55,pin:'left',system:true},
  {key:'participant',label:'Назва учасника',width:260,pin:'left'},{key:'edrpou',label:'ЄДРПОУ / РНОКПП',width:140},{key:'clarity',label:'CP',width:48},
  {key:'qualificationId',label:'Ідентифікатор відбору',width:205},{key:'frameworkTitle',label:'Назва фреймворку',width:260,visible:false},{key:'dkCode',label:'Код ДК',width:125},
  {key:'marketplaceLink',label:'Майданчик',width:52},{key:'prozorroLink',label:'Prozorro',width:76},
  {key:'receivedDate',label:'Дата надходження',width:155},{key:'documents',label:'Документи',width:95},
  {key:'protocolNumber',label:'№ протоколу',width:120},{key:'protocolDate',label:'Дата протоколу',width:130},
  {key:'publicationDate',label:'Дата публікації рішення',width:150},{key:'protocolOfficer',label:'УО протоколу',width:165},
  {key:'reviewOfficer',label:'УО (розгляд)',width:165},
  {key:'protocolRemarks',label:'Зауваження до протоколу',width:280},
  {key:'protocolDecision',label:'Рішення УО',width:135},
  {key:'marketplaceDecision',label:'Дія на майданчику',width:175},
  {key:'complianceStatus',label:'Комплаєнс',width:150},{key:'complianceComments',label:'Коментарі комплаєнс',width:280},
  {key:'managerName',label:'Прізвище, ім’я, по батькові керівника',width:260},
  {key:'documentPackage',label:'Пакет документів',width:165},{key:'contractDetails',label:'Реквізити договору',width:230},{key:'decision',label:'Статус',width:155},
  {key:'documentCheckStatus',label:'Перевірка документів',width:175},{key:'documentCheckedAt',label:'Перевірено',width:145},
  {key:'registryStatus',label:'Статус у відборі',width:150},
  {key:'registryValidUntil',label:'Строк дії у реєстрі',width:145},
  {key:'registryStatusDate',label:'Дата зміни статусу',width:155},
  {key:'registryDocuments',label:'Документи реєстру',width:125},
  {key:'notes',label:'Коментарі / зауваження',width:260}
].map((c,i)=>({...c,visible:c.visible!==false,order:i}));
const kpiDefinitions=[['applications','Заявки'],['suppliers','Постачальники'],['decision_yes','Так'],['decision_no','Ні'],['decision_undefined','Не визначено'],['pending','Очікують рішення'],['admitted','Допущено'],['rejected','Відхилено'],['registry_active','Активні у відборі'],['registry_inactive','Неактивні у відборі'],['officers','Розподіл заявок за УО']];
const defaultKpis=name=>/розгляд/i.test(name)?['applications','suppliers','decision_yes','decision_no','decision_undefined','officers']:kpiDefinitions.map(([key])=>key);
const activeKey='pqm.server.activeProfile.v2',localRoleKey='pqm.local.role.v1';
const filterStateKey='pqm.server.filters.v1';
let profiles=[{id:'local-default',name:'Основний реєстр',columns:structuredClone(columns),kpis:defaultKpis('Основний реєстр'),is_system:true}],currentMe=null;
let activeProfileId=localStorage.getItem(activeKey)||'local-default', rows=[], selected=new Set(), activeRow=null, activeDocsRow=null, lastDocumentCheck=null, lastProtocolPayload=null;
const applicationSelection=PqmApplicationSelection.create(selected);
let rowsFilterSignature=null,selectAllResultsPending=false;
let page=1,pages=1,total=0,loading=false,searchTimer,loadRowsGeneration=0;
let statsSignature='';
let statsGeneration=0,profilesGeneration=0,registryReloadPromise=null;
let profileLayoutGeneration=0,profilesMetadataReady=false;
let statsPending=null;
function invalidateRegistryStats(){statsSignature='';statsGeneration++}
let officerFilter='';
let categoryFilter='';
let sortKey='receivedDate',sortDirection='desc';
let multiSort=[];
function sortIndicator(key){const i=multiSort.findIndex(x=>x.key===key);return i<0?(multiSort.length?'':sortKey===key?(sortDirection==='asc'?' ↑':' ↓'):''):` ${multiSort[i].direction==='asc'?'↑':'↓'}${String(i+1).split('').map(d=>'⁰¹²³⁴⁵⁶⁷⁸⁹'[Number(d)]).join('')}`}
function applyProfileSort(){multiSort=structuredClone(profile().sorts||[]);if(multiSort.length){sortKey=multiSort[0].key;sortDirection=multiSort[0].direction}}
const sortableColumns=new Set(['participant','edrpou','qualificationId','dkCode','receivedDate','documents','protocolNumber','protocolDate','publicationDate','protocolOfficer','protocolRemarks','protocolDecision','marketplaceDecision','complianceStatus','complianceComments','managerName','documentPackage','decision','registryStatus','registryValidUntil','registryStatusDate','notes']);
let frameworkOptions=[];
const filterSelections={supplier:new Set(),status:new Set(),marketplace:new Set(),registry:new Set(),framework:new Set(),dk:new Set()};
const $=s=>document.querySelector(s), $$=s=>[...document.querySelectorAll(s)];
const sharedFilterSurfaceSelector=[
  '.history-filters','.supplier-filter-field','.frameworks-toolbar',
  '.reference-toolbar','.procurement-filter-grid','.admin-framework-toolbar',
  '.requests-toolbar','.operational-task-toolbar','.work-queue-toolbar',
  '.edr-monitoring-toolbar','.edr-monitoring-filter-grid'
].join(',');
function filterControlHasValue(control){
  if(!control||control.disabled||control.matches('[type="hidden"],[type="file"],.multi-search'))return false;
  if(control.matches('[type="checkbox"],[type="radio"]'))return control.checked;
  return Boolean(String(control.value||'').trim());
}
function syncSharedFilterPresentation(scope=document){
  const roots=[];
  if(scope instanceof Element&&scope.matches(sharedFilterSurfaceSelector))roots.push(scope);
  roots.push(...scope.querySelectorAll(sharedFilterSurfaceSelector));
  [...new Set(roots)].forEach(root=>{
    root.querySelectorAll('input,select').forEach(control=>{
      if(control.closest('.multi-panel')||control.matches('[type="hidden"],[type="file"],.multi-search'))return;
      control.classList.toggle('filter-active',filterControlHasValue(control));
    });
  });
  scope.querySelectorAll('.multi-filter').forEach(details=>{
    const active=[...details.querySelectorAll('input[type="checkbox"],input[type="radio"]')].some(filterControlHasValue);
    details.classList.toggle('filter-active',active);
  });
  scope.querySelectorAll('.advanced-filters,.supplier-advanced-filters').forEach(details=>{
    const active=[...details.querySelectorAll('input,select')].some(filterControlHasValue)||Boolean(details.querySelector('.multi-filter.filter-active'));
    details.classList.toggle('filter-active',active);
  });
}
const esc=(v='')=>String(v).replace(/[&<>"']/g,x=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[x]));
const validSupplierName=value=>{const text=String(value??'').trim();return text&&!['-','—'].includes(text)?text:''};
const supplierDisplayName=(edr={},fallback='')=>validSupplierName(edr.short_name)||validSupplierName(edr.full_name)||validSupplierName(fallback)||'—';
const titleCaseWord=value=>{const text=String(value||'').toLocaleLowerCase('uk-UA');return text?text[0].toLocaleUpperCase('uk-UA')+text.slice(1):''};
const formatOfficerName=value=>{const parts=String(value||'').trim().split(/\s+/).filter(Boolean);if(parts.length<2)return parts.map(titleCaseWord).join(' ');return `${parts.slice(0,-1).map(titleCaseWord).join(' ')} ${parts.at(-1).toLocaleUpperCase('uk-UA')}`};
const formatQueueOfficer=value=>{const formatted=formatOfficerName(value);if(!formatted)return'Не призначено';const parts=formatted.split(/\s+/);if(parts.length<2)return esc(formatted);return `<span>${esc(parts.slice(0,-1).join(' '))}</span><span>${esc(parts.at(-1))}</span>`};
const role=()=>$('#roleSelect').value;
let currentAuthUser='';
let currentAccount=null;
function userAvatarUrl(username){return `${API}/users/${encodeURIComponent(username)}/avatar?v=${Date.now()}`}
function showCurrentUserAvatar(username,hasAvatar=true){const image=$('#currentUserAvatar');currentAuthUser=username||'';if(!username||!hasAvatar){image.hidden=true;image.removeAttribute('src');return}image.onerror=()=>{image.hidden=true};image.onload=()=>{image.hidden=false};image.src=userAvatarUrl(username)}
const requestsRefreshState={runtimeLoaded:false,sandboxMode:false,sandboxOperational:false,sandboxProzorroRead:false,running:false,starting:false};
function updateRequestsRefreshAvailability(change={}){
  Object.assign(requestsRefreshState,change);
  const button=$('#requestsRefresh');if(!button)return;
  const permitted=currentMe?.permissions?.['appeals.update']===true;
  const sandboxAllowed=!requestsRefreshState.sandboxMode||(requestsRefreshState.sandboxOperational&&requestsRefreshState.sandboxProzorroRead);
  button.disabled=!permitted||!requestsRefreshState.runtimeLoaded||!sandboxAllowed||requestsRefreshState.running||requestsRefreshState.starting;
  button.title=!permitted?'Дія недоступна без права оновлення звернень':!requestsRefreshState.runtimeLoaded?'Очікування конфігурації середовища':!sandboxAllowed?'Оновлення звернень вимкнено в SANDBOX':requestsRefreshState.running||requestsRefreshState.starting?'Оновлення звернень триває':'';
}
function applyRoleCapabilities(me){
  if(!me)return;
  document.body.dataset.authRole=me.role||'viewer';
  const admin=me.role==='admin',viewer=me.role==='viewer';
  if(!admin&&activeModule==='administration')showModule('applications');
  const adminNav=$('#administrationNav');if(adminNav)adminNav.hidden=!admin||adminNav.dataset.navVisible==='false';
  $$('[data-admin-only]').forEach(element=>element.hidden=!admin);
  const taskTemplates=$('#operationalTaskTemplates');if(taskTemplates)taskTemplates.hidden=!admin;
  const requestsTemplates=$('#requestsTemplates');if(requestsTemplates)requestsTemplates.hidden=!admin;
  const requestsDeclension=$('#requestsDeclension');if(requestsDeclension)requestsDeclension.disabled=!(me.permissions?.['declension.read']??admin);
  const messagesNav=$('#messagesNav');if(messagesNav)messagesNav.hidden=!(me.permissions?.['messages.read']??true);
  const operationalTasksNav=$('#operationalTasksNav');if(operationalTasksNav)operationalTasksNav.hidden=!(me.permissions?.['tasks.read']??admin);
  const taskDeclension=$('#operationalTaskDeclension');if(taskDeclension)taskDeclension.disabled=!(me.permissions?.['tasks.read']??admin);
  const navigationTab=$('[data-admin-tab="navigation"]');if(navigationTab)navigationTab.hidden=!admin;
  const metadataAdd=$('#adminMetadataAdd');if(metadataAdd)metadataAdd.hidden=!(me.permissions?.['admin.manage']??admin);
  if(!admin){const navigationPanel=$('#adminNavigationPanel');if(navigationPanel)navigationPanel.replaceChildren()}
  ['#resetBtn','#supplierRegistryRefresh','#supplierEdrSync','#supplierNazkReviewSync','#frameworksRefresh',
   '#refNazkRefresh','#refAmcuRefresh','#refAmcuUploadBtn','#bidsDataRefresh'].forEach(selector=>{
    const element=$(selector);if(!element)return;
    element.dataset.roleDisabled=admin?'0':'1';
    element.disabled=!admin||element.dataset.runtimeDisabled==='1'||(selector==='#bidsDataRefresh'&&(element.dataset.bidsReady!=='1'||element.dataset.bidsRunning==='1'));
    if(!admin)element.title='Дія доступна лише адміністратору';
    else if(element.dataset.runtimeDisabled!=='1')element.title='';
  });
  updateRequestsRefreshAvailability();
  document.body.classList.toggle('role-viewer',viewer);
  if(window.pqmApplyNavigationAccess)window.pqmApplyNavigationAccess(me);
  renderManualBidsUpdateState(manualBidsFeatureState);
  updatePowerbiAvailability();
}
const presenceLabels={working:'Працюю',away:'Відійшов',vacation:'У відпустці'};
function applyAccountAppearance(account){if(globalThis.PqmThemeUI)PqmThemeUI.apply(account?.color_scheme);else{document.documentElement.dataset.theme='light';document.body.dataset.theme='light'}document.body.dataset.density=account?.density||'comfortable';const name=account?.display_name||account?.username||'Мій кабінет';if($('#accountDisplayName'))$('#accountDisplayName').textContent=name;const presence=account?.presence_status||'working';if($('#accountPresence')){$('#accountPresence').textContent=presenceLabels[presence]||presenceLabels.working;$('#accountPresence').dataset.presence=presence}}
async function loadAccountSettings(applyStart=false){const account=await request(`${API}/account`);currentAccount=account;applyAccountAppearance(account);showCurrentUserAvatar(account.username,account.has_avatar);if(applyStart&&account.start_view&&!new URLSearchParams(location.search).has('view'))showModule(account.start_view);return account}
async function loadAuthenticatedRole(){try{const me=await request(`${API}/auth/me`),select=$('#roleSelect');currentMe=me;if(me.role&&select.querySelector(`option[value="${me.role}"]`))select.value=me.role;select.disabled=Boolean(me.authenticated);select.title=me.authenticated?`Роль визначена обліковим записом: ${me.username}`:'';showCurrentUserAvatar(me.username);applyRoleCapabilities(me);try{await loadAccountSettings(true)}catch{}return me}catch{return null}}
function toastType(text){const value=String(text||'').toLocaleLowerCase('uk-UA');if(/помил|не вдалося|failed|недоступ|пошкоджен/.test(value))return'error';if(/уваг|перевір|неповн|заблок|поперед/.test(value))return'warning';return'info'}
function toast(text,type=''){const stack=$('#toast'),kind=type||toastType(text),duration={info:5000,success:5000,warning:7000,error:10000}[kind]||5000,item=document.createElement('div');item.className=`toast toast-${kind}`;item.innerHTML=`<span>${esc(text)}</span><button type="button" aria-label="Закрити повідомлення">×</button>`;stack.append(item);if(stack.showPopover&&!stack.matches(':popover-open'))stack.showPopover();let remaining=duration,started=Date.now(),timer;const close=()=>{clearTimeout(timer);item.classList.remove('show');setTimeout(()=>{item.remove();if(!stack.children.length&&stack.matches(':popover-open'))stack.hidePopover()},250)},start=()=>{started=Date.now();timer=setTimeout(close,remaining)};item.querySelector('button').onclick=close;item.onmouseenter=()=>{clearTimeout(timer);remaining=Math.max(0,remaining-(Date.now()-started))};item.onmouseleave=start;requestAnimationFrame(()=>item.classList.add('show'));start()}
async function copyText(value,message='Скопійовано'){try{await navigator.clipboard.writeText(value)}catch{const area=document.createElement('textarea');area.value=value;area.style.position='fixed';area.style.opacity='0';document.body.append(area);area.select();document.execCommand('copy');area.remove()}toast(message)}
function profile(){return profiles.find(p=>p.id===activeProfileId)||profiles[0]}
function saveProfiles(){localStorage.setItem(activeKey,activeProfileId)}
async function loadProfiles(){const generation=++profilesGeneration,layoutGeneration=profileLayoutGeneration,preserveLayout=applicationsRegistryInitialized,data=await request(`${API}/application-profiles`);if(generation!==profilesGeneration)return false;if(!Array.isArray(data.items))throw new Error('Некоректний список профілів');const keepLayout=preserveLayout||layoutGeneration!==profileLayoutGeneration;profiles=data.items.map(p=>{const local=keepLayout&&profiles.find(item=>item.id===p.id);return {...p,kpis:local?structuredClone(local.kpis):Array.isArray(p.kpis)?p.kpis:defaultKpis(p.name),columns:local?structuredClone(local.columns):(p.columns?.length?p.columns:structuredClone(columns)),sorts:local?structuredClone(local.sorts||[]):p.sorts}});if(!profiles.length)profiles=[{id:'local-default',name:'Основний реєстр',columns:structuredClone(columns),kpis:defaultKpis('Основний реєстр'),is_system:true}];if(!profiles.some(p=>p.id===activeProfileId)){const defaultSystem=profiles.find(p=>p.is_system),personal=defaultSystem&&profiles.find(p=>!p.is_system&&p.source_system_profile_id===defaultSystem.id);activeProfileId=personal?.id||defaultSystem?.id||profiles[0].id}saveProfiles();renderProfiles();if(!keepLayout)applyProfileSort();profilesMetadataReady=true;return true}
function normalizeProfiles(){profiles.forEach(p=>{columns.forEach((base,i)=>{let c=p.columns.find(x=>x.key===base.key);if(!c)p.columns.push({...base,order:i});else{c.label=base.label;c.system=base.system;if(c.pin!=='left')c.pin='';if(!Number.isFinite(Number(c.width)))c.width=base.width}});if(!Array.isArray(p.kpis))p.kpis=defaultKpis(p.name)})}
function applyKpiVisibility(){
  const order=profile().kpis||[],enabled=new Set(order),cards=$('#kpiCards'),officers=$('#officerCards');
  [...cards.children].forEach(card=>{const key=card.dataset.kpiCard;card.hidden=!enabled.has(key);card.style.order=String(Math.max(0,order.indexOf(key))*1000)});
  officers.style.setProperty('--officer-kpi-order',String(Math.max(0,order.indexOf('officers'))*1000));
  cards.hidden=![...cards.children].some(card=>!card.hidden);
  officers.hidden=!enabled.has('officers');
}
async function loadSearchFields(){try{const data=await request(`${API}/applications/search-fields`),labels=(data.items||[]).map(item=>item.label).filter(Boolean),input=$('#searchInput');if(labels.length)input.title=`Глобальний пошук: ${labels.join(', ')}`}catch(error){console.warn('Search fields metadata unavailable',error)}}
function displayDate(value){if(!value)return '';const text=String(value).trim();if(/^\d{4}-\d{2}-\d{2}$/.test(text)||/^\d{1,2}[./]\d{1,2}[./]\d{4}$/.test(text))return displayDateOnly(text);const d=new Date(text);if(Number.isNaN(d.valueOf()))return text;const parts=Object.fromEntries(new Intl.DateTimeFormat('uk-UA',{timeZone:'Europe/Kyiv',day:'2-digit',month:'2-digit',year:'numeric',hour:'2-digit',minute:'2-digit',hourCycle:'h23'}).formatToParts(d).map(part=>[part.type,part.value]));return`${parts.day}.${parts.month}.${parts.year}, ${parts.hour}:${parts.minute}`}
function displayDateOnly(value){if(!value)return '';const text=String(value).trim(),iso=text.match(/^(\d{4})-(\d{2})-(\d{2})$/),ua=text.match(/^(\d{1,2})[./](\d{1,2})[./](\d{4})$/);if(iso)return`${iso[3]}.${iso[2]}.${iso[1]}`;if(ua)return`${ua[1].padStart(2,'0')}.${ua[2].padStart(2,'0')}.${ua[3]}`;const d=new Date(text);if(Number.isNaN(d.valueOf()))return text;const parts=Object.fromEntries(new Intl.DateTimeFormat('uk-UA',{timeZone:'Europe/Kyiv',day:'2-digit',month:'2-digit',year:'numeric'}).formatToParts(d).map(part=>[part.type,part.value]));return`${parts.day}.${parts.month}.${parts.year}`}
const edrStatusPresentation=Object.freeze({'Зареєстровано':'✅ Зареєстровано','Неактуально':'⚪ Неактуально','Немає інформації':'⚪ Немає інформації','В стані припинення':'🟡 В стані припинення','Порушено справу про банкрутство':'🟡 Порушено справу про банкрутство','Припинено':'🔴 Припинено','Банкрут':'🔴 Банкрут'});
function displayEdrStatus(value){return edrStatusPresentation[String(value||'').trim()]||value||'—'}
function addCalendarDays(value,days=1){const match=String(value||'').match(/^(\d{4})-(\d{2})-(\d{2})$/);if(!match)return'';const result=new Date(Date.UTC(Number(match[1]),Number(match[2])-1,Number(match[3])+days));return result.toISOString().slice(0,10)}
function mapRow(x){const supplierDocuments=x.documents||[],decisionDocuments=x.decision_documents||[];return {id:x.id,participant:x.supplier_name||'',edrpou:x.supplier_code||'',supplierNote:x.supplier_note||'',supplierNoteUpdatedAt:x.supplier_note_updated_at||'',supplierNoteUpdatedBy:x.supplier_note_updated_by||'',qualificationId:x.pretty_id||'',frameworkTitle:x.framework_title||'',dkCode:x.dk_code||'',experienceSearch:(x.document_check_categories||{}).experience||'neutral',category:x.category||'',marketplaceLink:x.marketplace_url||'',prozorroLink:x.pretty_id&&x.supplier_code?`https://prozorro.gov.ua/uk/framework/${encodeURIComponent(x.pretty_id)}/submissions?framework_tenderer=${encodeURIComponent(x.supplier_code)}`:'',receivedDate:displayDate(x.date_published),supplierDocuments,decisionDocuments,documents:[...supplierDocuments,...decisionDocuments],protocolNumber:x.protocol_number||'',protocolDate:x.protocol_date||'',publicationDate:x.publication_date||'',protocolOfficer:x.protocol_officer||'',reviewOfficer:x.review_officer||'',protocolRemarks:x.protocol_remarks||'',protocolDecision:x.protocol_decision||'',marketplaceDecision:x.marketplace_decision||'',complianceStatus:x.compliance_status||'',complianceComments:x.compliance_comments||'',managerName:x.manager_name||x.manager_name_display||'',managerNameDisplay:x.manager_name_display||x.manager_name||'',managerNameDisplaySource:x.manager_name_display_source||'',managerNameDisplaySourceDate:x.manager_name_display_source_date||'',managerNameSource:x.manager_name_source||'',managerNameSourceSubmissionId:x.manager_name_source_submission_id||'',documentPackage:x.document_package||'',contractDetails:x.contract_details||'',documentCheckStatus:x.document_check_status||'',documentCheckSummary:x.document_check_summary||'',documentCheckCategories:x.document_check_categories||{},documentCheckedAt:displayDate(x.document_checked_at),formedProtocolId:x.formed_protocol_id||'',legacyProtocol:!!x.legacy_protocol,generatedProtocolNumber:x.generated_protocol_number||'',generatedProtocolDate:x.generated_protocol_date||'',generatedProtocolDecision:x.generated_protocol_decision||'',protocolGeneratedAt:x.protocol_generated_at||'',authorityReview:x.authority_review||'',mvsSealReview:x.mvs_seal_review||'',decision:x.decision||'Очікує рішення',registryStatus:x.registry_status||'',registryValidUntil:displayDateOnly(x.registry_valid_until),registryStatusDate:displayDateOnly(x.registry_status_date),registryDocuments:x.registry_documents||[],amcuMatch:Boolean(x.amcu_match),nazkMatch:Boolean(x.nazk_match),nazkReviewResult:x.nazk_review_result||'',nazkCertificateRequired:Boolean(x.nazk_certificate_required),nazkCertificateChecked:Boolean(x.nazk_certificate_checked),nazkControlId:x.nazk_control_id||null,nazkState:x.nazk_state||'not_required',nazkPresentationState:x.nazk_presentation_state??x.nazk_state??'',nazkCanApprove:x.nazk_can_approve!==false,nazkStateReason:x.nazk_state_reason||'',notes:x.notes||''}}
async function request(url,options={}){const headers={...(options.headers||{})};const localRole=$('#roleSelect')?.value;if(localRole)headers['X-PQM-Local-Role']=localRole;const r=await fetch(url,{...options,headers}),type=r.headers.get('content-type')||'',text=await r.text();let body={};if(type.includes('application/json')){try{body=JSON.parse(text)}catch{throw new Error('Сервер повернув пошкоджену JSON-відповідь')}}else if(text.trim().startsWith('{')||text.trim().startsWith('[')){try{body=JSON.parse(text)}catch{throw new Error('Сервер повернув неочікувану відповідь')}}else throw new Error(r.ok?'Сервер повернув HTML замість даних. Оновіть PQM і повторіть спробу.':`Помилка сервера ${r.status}`);if(!r.ok){const error=new Error(body.error||body.message||'Помилка запиту');Object.assign(error,body,{httpStatus:r.status});throw error}return body}
async function initializeLoginGate(){
  const gate=$('#loginGate'),shell=$('#applicationShell');
  try{const me=await request(`${API}/auth/me`);gate.hidden=true;shell.hidden=false;applyRoleCapabilities(me)}catch{gate.hidden=false;shell.hidden=true}
}
$('#loginForm').onsubmit=async event=>{event.preventDefault();const error=$('#loginError');error.textContent='';try{const response=await fetch(`${API}/login`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({username:$('#loginUsername').value.trim(),password:$('#loginPassword').value})});const data=await response.json();if(!response.ok)throw new Error(data.error||'Не вдалося увійти');location.reload()}catch(exc){error.textContent=exc.message;$('#loginPassword').value='';$('#loginPassword').focus()}};
$('#logoutBtn').onclick=async()=>{await fetch(`${API}/logout`,{method:'POST'});location.reload()};
function renderAccountAvatar(account){const preview=$('#accountAvatarPreview'),placeholder=$('#accountAvatarPlaceholder'),remove=$('#accountAvatarDelete');preview.hidden=!account.has_avatar;placeholder.hidden=Boolean(account.has_avatar);remove.hidden=!account.has_avatar;if(account.has_avatar)preview.src=userAvatarUrl(account.username)}
globalThis.PqmThemeUI?.install();
if($('#accountColorScheme'))$('#accountColorScheme').onchange=event=>PqmThemeUI.apply(event.target.value);
$('#accountSettingsDialog').addEventListener('close',()=>applyAccountAppearance(currentAccount));
$('#accountSettingsBtn').onclick=async()=>{try{const account=await loadAccountSettings(false);$('#accountIdentity').textContent=`${account.username} · ${account.role==='admin'?'Адміністратор':account.role==='officer'?'УО':'Глядач'}`;$('#accountDisplayNameInput').value=account.display_name||'';$('#accountPresenceStatus').value=account.presence_status||'working';$('#accountStartView').value=account.start_view||'applications';$('#accountDensity').value=account.density||'comfortable';if($('#accountColorScheme'))$('#accountColorScheme').value=account.color_scheme==='dark'?'dark':'light';$('#accountPasswordFields').hidden=!account.managed;$('#accountManagedNotice').hidden=account.managed;renderAccountAvatar(account);$('#accountSettingsDialog').showModal()}catch(error){toast(error.message)}};
$('#accountSettingsClose').onclick=()=>$('#accountSettingsDialog').close();
$('#accountAvatarUpload').onclick=()=>$('#accountAvatarFile').click();
$('#accountAvatarFile').onchange=async event=>{const file=event.target.files[0];event.target.value='';if(!file)return;if(file.size>2*1024*1024)return toast('Максимальний розмір фото — 2 МБ');if(!['image/png','image/jpeg','image/webp'].includes(file.type))return toast('Дозволено лише PNG, JPEG або WebP');try{const bytes=new Uint8Array(await file.arrayBuffer());let binary='';for(let i=0;i<bytes.length;i+=32768)binary+=String.fromCharCode(...bytes.subarray(i,i+32768));await request(`${API}/account/avatar`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({content_type:file.type,content:btoa(binary)})});const account=await loadAccountSettings(false);renderAccountAvatar(account);toast('Фото профілю оновлено')}catch(error){toast(error.message)}};
$('#accountAvatarDelete').onclick=async()=>{if(!confirm('Видалити ваше фото профілю?'))return;try{await request(`${API}/account/avatar`,{method:'DELETE'});const account=await loadAccountSettings(false);renderAccountAvatar(account);toast('Фото профілю видалено')}catch(error){toast(error.message)}};
$('#accountSettingsForm').onsubmit=async event=>{
  event.preventDefault();
  const newPassword=$('#accountNewPassword').value;
  if(newPassword!==$('#accountNewPasswordConfirm').value)return toast('Нові паролі не збігаються');
  try{
    const accountUpdate={username:currentAuthUser,display_name:$('#accountDisplayNameInput').value,presence_status:$('#accountPresenceStatus').value,density:$('#accountDensity').value,...($('#accountColorScheme')?{color_scheme:$('#accountColorScheme').value}:{})};
    const startView=$('#accountStartView').value;
    const themeOnly=$('#accountColorScheme')&&!newPassword&&currentAccount&&
      accountUpdate.display_name===(currentAccount.display_name||'')&&
      accountUpdate.presence_status===(currentAccount.presence_status||'working')&&
      accountUpdate.density===(currentAccount.density||'comfortable')&&startView===(currentAccount.start_view||'applications');
    const payload=themeOnly?{color_scheme:accountUpdate.color_scheme}:{...accountUpdate,start_view:startView,current_password:$('#accountCurrentPassword').value,new_password:newPassword};
    const data=await request(`${API}/account`,{method:'PATCH',headers:{'Content-Type':'application/json'},body:JSON.stringify(payload)});
    currentAccount={...currentAccount,...accountUpdate,start_view:startView};
    applyAccountAppearance(currentAccount);$('#accountSettingsDialog').close();
    if(data.reauthenticate){toast('Пароль змінено. Увійдіть повторно');setTimeout(()=>location.reload(),900)}else toast('Налаштування кабінету збережено');
  }catch(error){
    applyAccountAppearance(currentAccount);
    if($('#accountColorScheme'))$('#accountColorScheme').value=currentAccount?.color_scheme==='dark'?'dark':'light';
    toast(error.message);
  }
};
void initializeLoginGate();
function updateMultiSummary(id,placeholder,selection,labelFor=value=>value){const summary=$(`#${id} summary`),values=[...selection];summary.textContent=!values.length?placeholder:values.length===1?labelFor(values[0]):`${placeholder}: ${values.length}`}
function syncFilterUrl(){const url=new URL(location.href);[['protocol_number',$('#protocolNumberFilter').value.trim()],['search',$('#searchInput').value],['category',categoryFilter],['officer',officerFilter],['date_from',$('#dateFromFilter').value],['date_to',$('#dateToFilter').value]].forEach(([key,value])=>value?url.searchParams.set(key,value):url.searchParams.delete(key));history.replaceState(null,'',url)}
function clearApplicationDeepLinkFilter(){
  deepLinkSubmissionId='';
  const url=new URL(location.href);
  url.searchParams.delete('submission_id');
  url.searchParams.delete('nazk_control');
  history.replaceState(null,'',url);
}
function syncPrimaryFilters(){if($('#applicationCategoryFilter'))$('#applicationCategoryFilter').value=categoryFilter;if($('#applicationOfficerFilter'))$('#applicationOfficerFilter').value=officerFilter}
function saveFilterState(){localStorage.setItem(filterStateKey,JSON.stringify({search:$('#searchInput').value,protocolNumber:$('#protocolNumberFilter').value,dateFrom:$('#dateFromFilter').value,dateTo:$('#dateToFilter').value,protocolDecision:$('#protocolDecisionFilter').value,complianceStatus:$('#complianceStatusFilter').value,officer:officerFilter,category:categoryFilter,sortKey,sortDirection,selections:Object.fromEntries(Object.entries(filterSelections).map(([key,value])=>[key,[...value]]))}));syncPrimaryFilters();syncFilterUrl()}
function restoreFilterState(){try{const state=JSON.parse(localStorage.getItem(filterStateKey)||'null')||{};const query=new URLSearchParams(location.search);$('#searchInput').value=query.get('search')??state.search??'';$('#dateFromFilter').value=query.get('date_from')??state.dateFrom??'';$('#dateToFilter').value=query.get('date_to')??state.dateTo??'';$('#protocolNumberFilter').value=query.get('protocol_number')??state.protocolNumber??'';$('#protocolDecisionFilter').value=state.protocolDecision||'';$('#complianceStatusFilter').value=state.complianceStatus||'';officerFilter=query.get('officer')??state.officer??'';categoryFilter=query.get('category')??state.category??'';sortKey=state.sortKey||'receivedDate';sortDirection=state.sortDirection==='asc'?'asc':'desc';Object.entries(state.selections||{}).forEach(([key,values])=>{if(!filterSelections[key]||!Array.isArray(values))return;filterSelections[key].clear();values.forEach(value=>filterSelections[key].add(value))});$$('.multi-filter input[type="checkbox"]').forEach(input=>{input.checked=Object.values(filterSelections).some(selection=>selection.has(input.value))});syncPrimaryFilters()}catch{localStorage.removeItem(filterStateKey)}}
async function loadPrimaryFilterOptions(){try{const data=await request(`${API}/admin/frameworks`),categories=[...new Set((data.items||[]).map(x=>x.category).filter(Boolean))].sort(new Intl.Collator('uk-UA').compare);$('#applicationCategoryFilter').innerHTML='<option value="">Усі категорії</option>'+categories.map(value=>`<option value="${esc(value)}">${esc(value)}</option>`).join('');$('#applicationOfficerFilter').innerHTML='<option value="">Усі УО протоколу</option><option value="__unassigned__">Не призначено</option>'+protocolOfficers.map(value=>`<option value="${esc(value)}">${esc(formatOfficerName(value))}</option>`).join('');syncPrimaryFilters()}catch(error){console.warn('Primary filters unavailable',error)}}
function renderDynamicFilter(id,items,selection,valueFor,labelFor,placeholder,onChange=()=>{page=1;loadRows()}){
  const details=$(`#${id}`),query=details.querySelector('.multi-search').value.trim().toLocaleLowerCase('uk-UA');
  const visible=items.filter(item=>labelFor(item).toLocaleLowerCase('uk-UA').includes(query));
  details.querySelector('.multi-options').innerHTML=visible.map(item=>{const value=valueFor(item);return `<label><input type="checkbox" value="${esc(value)}" ${selection.has(value)?'checked':''}> <span>${esc(labelFor(item))}</span></label>`}).join('')||'<p class="muted">Нічого не знайдено</p>';
  details.querySelectorAll('.multi-options input').forEach(input=>input.onchange=()=>{input.checked?selection.add(input.value):selection.delete(input.value);updateMultiSummary(id,placeholder,selection,value=>{const item=items.find(candidate=>valueFor(candidate)===value);return item?labelFor(item):value});onChange()});
  updateMultiSummary(id,placeholder,selection,value=>{const item=items.find(candidate=>valueFor(candidate)===value);return item?labelFor(item):value});
}
async function loadFrameworks(){
  try {
    const data=await request(`${API}/frameworks`);
    frameworkOptions=data.items;
    renderDynamicFilter('frameworkFilter',frameworkOptions,filterSelections.framework,item=>item.id,item=>`${item.pretty_id} · ${item.title||''} · ${item.applications_count}`,'Усі відбори');
    const dkOptions=[...new Set(frameworkOptions.map(item=>item.dk_code).filter(Boolean))].sort().map(code=>({code}));
    const supplierDkOptions=$('#supplierRegistryDkOptions');
    if(supplierDkOptions)supplierDkOptions.innerHTML=dkOptions.map(item=>`<option value="${esc(item.code)}"></option>`).join('');
    const supplierFramework=$('#supplierRegistryFramework');
    if(supplierFramework){const selected=new Set(Array.from(supplierFramework.selectedOptions,option=>option.value));supplierFramework.innerHTML='<option value="">Усі відбори</option>'+frameworkOptions.map(item=>`<option value="${esc(item.id)}">${esc(item.pretty_id||item.id)} · ${esc(item.title||'')} · ${esc(item.dk_code||'')}</option>`).join('');for(const option of supplierFramework.options)option.selected=selected.has(option.value);}
    renderDynamicFilter('dkFilter',dkOptions,filterSelections.dk,item=>item.code,item=>item.code,'Усі коди ДК');
    renderSupplierScopeFilters();
  } catch(e) { toast(e.message) }
}
async function loadSupplierOptions(){try{const q=new URLSearchParams({search:$('#supplierCodeFilter .multi-search').value});const data=await request(`${API}/supplier-options?${q}`);renderDynamicFilter('supplierCodeFilter',data.items,filterSelections.supplier,item=>item.code,item=>`${item.code} · ${item.name||''} (${item.applications_count})`,'Коди ЄДРПОУ')}catch(e){toast(e.message)}}
let deepLinkSubmissionId='';
function currentFilterParams(){return {search:$('#searchInput').value,status:[...filterSelections.status].join(','),marketplace_decision:[...filterSelections.marketplace].join(','),registry_status:[...filterSelections.registry].join(','),supplier_codes:[...filterSelections.supplier].join(','),framework_id:[...filterSelections.framework].join(','),dk_code:[...filterSelections.dk].join(','),protocol_number:$('#protocolNumberFilter').value.trim(),protocol_decision:$('#protocolDecisionFilter').value,compliance_status:$('#complianceStatusFilter').value,date_from:$('#dateFromFilter').value,date_to:$('#dateToFilter').value,officer:officerFilter,category:categoryFilter,submission_id:deepLinkSubmissionId}}
function updateApplicationFilterStyles(){
  const toggle=(selector,active)=>$(selector)?.classList.toggle('filter-active',Boolean(active));
  toggle('#searchInput',$('#searchInput').value.trim());
  toggle('#statusFilter',filterSelections.status.size);
  toggle('#marketplaceDecisionFilter',filterSelections.marketplace.size);
  toggle('#applicationCategoryFilter',categoryFilter);
  toggle('#applicationOfficerFilter',officerFilter);
  toggle('#registryStatusFilter',filterSelections.registry.size);
  toggle('#supplierCodeFilter',filterSelections.supplier.size);
  toggle('#frameworkFilter',filterSelections.framework.size);
  toggle('#dkFilter',filterSelections.dk.size);
  toggle('#protocolNumberFilter',$('#protocolNumberFilter').value.trim());
  toggle('#protocolDecisionFilter',$('#protocolDecisionFilter').value);
  const decisionValue=$('#protocolDecisionFilter').value;
  const decisionKeys={admit:'decision_yes',reject:'decision_no',__empty__:'decision_undefined'};
  $$('.decision-kpi').forEach(card=>card.classList.toggle('active',decisionKeys[decisionValue]===card.dataset.kpiCard));
  toggle('#complianceStatusFilter',$('#complianceStatusFilter').value);
  toggle('#dateFromFilter',$('#dateFromFilter').value);
  toggle('#dateToFilter',$('#dateToFilter').value);
  const advanced=[$('#protocolNumberFilter').value.trim(),filterSelections.registry.size,filterSelections.supplier.size,filterSelections.framework.size,filterSelections.dk.size,$('#protocolDecisionFilter').value,$('#complianceStatusFilter').value,$('#dateFromFilter').value,$('#dateToFilter').value];
  const count=advanced.filter(Boolean).length,details=$('.advanced-filters'),summary=details?.querySelector(':scope>summary');
  details?.classList.toggle('filter-active',count>0);if(summary)summary.textContent=count?`Фільтри · ${count}`:'Фільтри';
  syncSharedFilterPresentation($('#applicationsView'));
}
async function loadStats(){const signature=new URLSearchParams(currentFilterParams()).toString();if(statsPending&&statsPending.signature===signature&&statsPending.generation===statsGeneration)return statsPending.promise;const promise=loadStatsData();const pending={signature,generation:statsGeneration,promise};statsPending=pending;try{return await promise}finally{if(statsPending===pending)statsPending=null}}
async function loadStatsData(){const q=new URLSearchParams(currentFilterParams()),signature=q.toString();if(signature===statsSignature)return true;const generation=++statsGeneration;try{const data=await request(`${API}/stats?${q}`);if(generation!==statsGeneration||signature!==new URLSearchParams(currentFilterParams()).toString())return false;statsSignature=signature;$$('[data-kpi]').forEach(el=>el.textContent=Number(data[el.dataset.kpi]||0).toLocaleString('uk-UA'));$('#officerCards').innerHTML=(data.officers||[]).map(item=>`<button type="button" class="officer-card ${item.officer==='Не визначено'?'unassigned':''} ${item.officer===officerFilter?'active':''}" data-officer="${esc(item.officer)}" title="${esc(formatOfficerName(item.officer))}"><span title="${esc(formatOfficerName(item.officer))}">${esc(globalThis.PqmUi?PqmUi.compactOfficer(formatOfficerName(item.officer)):formatOfficerName(item.officer))}</span><strong>${Number(item.applications||0).toLocaleString('uk-UA')}</strong></button>`).join('');$$('#officerCards [data-officer]').forEach(card=>card.onclick=()=>{officerFilter=officerFilter===card.dataset.officer?'':card.dataset.officer;page=1;statsSignature='';loadRows()});return true}catch(e){if(generation===statsGeneration){statsSignature='';toast(e.message)}return false}}
function syncApplicationSelection(){
  const cleared=applicationSelection.sync(currentFilterParams());
  if(cleared)toast(`Фільтри змінено: попередній вибір ${cleared} заявок очищено. Виберіть потрібні результати знову.`);
  return applicationSelection.scope;
}
function applicationRowsCurrent(){
  return !loading&&rowsFilterSignature===PqmApplicationSelection.signature(currentFilterParams());
}
function selectApplicationPage(on=true){
  syncApplicationSelection();if(!applicationRowsCurrent()||selectAllResultsPending)return;
  applicationSelection.page(rows,on);render();
}
function updateApplicationSelectionControls(){
  const ready=applicationRowsCurrent()&&!selectAllResultsPending;
  const pageButton=$('#selectApplicationsPage'),allButton=$('#selectApplicationsAll');
  pageButton.disabled=!ready||!rows.length;allButton.disabled=!ready||!total;
  pageButton.onclick=()=>selectApplicationPage();allButton.onclick=selectAllApplicationResults;
  const header=$('#selectAll'),count=rows.filter(row=>selected.has(row.id)).length;
  if(header){header.disabled=!ready;header.checked=Boolean(rows.length)&&count===rows.length;header.indeterminate=count>0&&count<rows.length;header.title='Вибрати всі на сторінці'}
}
function bulkSelectionRow(item){
  const row={id:item.id,participant:item.supplier_name||'',historicalReadOnly:Boolean(item.historical_read_only),nazkCanApprove:item.nazk_can_approve!==false,bulkValues:{...item.values}};
  for(const [key,field]of Object.entries(fieldMap))row[key]=item.values[field]??'';
  return row;
}
async function selectAllApplicationResults(){
  if(selectAllResultsPending||bulkInFlight||!applicationRowsCurrent())return;
  const scope=syncApplicationSelection(),revision=applicationSelection.revision,filters={...currentFilterParams()};
  selectAllResultsPending=true;render();
  try{
    const data=await bulkRequest(`${API}/applications/selection?${new URLSearchParams(filters)}`);
    if(scope!==PqmApplicationSelection.signature(currentFilterParams()))return;
    if(!Array.isArray(data.items)||data.total!==data.items.length||data.items.some(item=>typeof item.id!=='string'||!item.values))throw new Error('Неповна вибірка заявок');
    if(applicationSelection.all(data.items.map(bulkSelectionRow),scope,revision))toast(`Вибрано всі результати: ${selected.size}. Склад вибірки зафіксовано.`);
  }catch(error){toast(`Не вдалося вибрати всі результати: ${error.message}`)}
  finally{selectAllResultsPending=false;render()}
}
async function loadRows(){
  const filterSignature=syncApplicationSelection();
  const generation=++loadRowsGeneration;
  invalidateRegistryStats();
  let refreshStats=false,succeeded=false;
  updateApplicationFilterStyles();saveFilterState();loading=true;render();
  try{
    const q=new URLSearchParams({...currentFilterParams(),page,size:'50',sort:sortKey,direction:sortDirection,sorts:JSON.stringify(multiSort)});
    const data=await request(`${API}/applications?${q}`);
    if(generation!==loadRowsGeneration||filterSignature!==PqmApplicationSelection.signature(currentFilterParams()))return false;
    rows=data.items.map(mapRow);page=data.page;pages=data.pages||1;total=data.total;rowsFilterSignature=filterSignature;applicationSelection.remember(rows);
    refreshStats=true;succeeded=true;
  }catch(e){
    if(generation===loadRowsGeneration)toast(`Не вдалося оновити реєстр: ${e.message}. Показано останні доступні дані.`,'error')
  }finally{
    if(generation===loadRowsGeneration){loading=false;render();if(refreshStats)void loadStats()}
  }
  return succeeded;
}
function bindStaticMulti(id,selection,placeholder,labelFor=value=>value){const details=$(`#${id}`);details.onchange=e=>{if(!e.target.matches('input[type="checkbox"]'))return;e.target.checked?selection.add(e.target.value):selection.delete(e.target.value);updateMultiSummary(id,placeholder,selection,labelFor);page=1;loadRows()};updateMultiSummary(id,placeholder,selection,labelFor)}
function displayKpiDate(value){return displayDateOnly(value).replace(/(\d{2}\.\d{2}\.)\d{2}(\d{2})$/,'$1$2')}
function getCols(){return [...profile().columns].filter(c=>c.visible).sort((a,b)=>a.order-b.order).map(c=>({...c,width:c.key==='marketplaceLink'?52:Number(c.width)||120}))}
function syncTableScroll(){const top=$('#tableScrollTop'),bottom=$('#tableScroll'),spacer=top.firstElementChild;spacer.style.width=`${bottom.scrollWidth}px`;if(top.dataset.bound)return;top.dataset.bound='true';top.onscroll=()=>{if(bottom.scrollLeft!==top.scrollLeft)bottom.scrollLeft=top.scrollLeft};bottom.onscroll=()=>{if(top.scrollLeft!==bottom.scrollLeft)top.scrollLeft=bottom.scrollLeft}}
function offsets(cols){let left=0,out={};cols.forEach(c=>{if(c.pin==='left'){out[c.key]=left;left+=Number(c.width)||120}});return out}
const mapRowWithHistoricalState=mapRow;
mapRow=function(x){const row=mapRowWithHistoricalState(x);row.historicalReadOnly=Boolean(x.historical_read_only);row.historicalSource=x.historical_source||{};row.reviewCompleted=Boolean(x.review_completed);return row};
function historicalApplicationMarker(row){return row?.historicalReadOnly?'<span class="historical-application-marker" title="Історичні дані з MedData" aria-label="Історичні дані з MedData">ⓘ</span>':''}
function historicalApplicationBadge(row){return row?.historicalReadOnly?'<span class="historical-application-badge" title="Історичні дані з MedData">Історичні дані з MedData</span>':''}
function locked(row,key){return Boolean(row.historicalReadOnly)||role()==='viewer'||['Допущено','Відхилено'].includes(row.decision)||(Boolean(row.marketplaceDecision)&&role()!=='admin')}
function applicationNazkMarker(row){
  const state=row.nazkPresentationState;
  if(state==='needs_check'){
    const rejected=row.decision==='Відхилено'||row.protocolDecision==='reject';
    if(row.historicalReadOnly||rejected)return '<span class="registry-flag nazk" title="Стан НАЗК-перевірки цієї заявки; редагування недоступне">НАЗК · перевірити довідку</span>';
    return '<button type="button" class="nazk-control-open">НАЗК · перевірити довідку</button>';
  }
  if(state==='refuted')return '<span class="registry-flag nazk refuted" title="Довідку цієї заявки перевірено; збіг НАЗК спростовано">НАЗК · Спростовано</span>';
  if(state==='confirmed')return '<span class="registry-flag nazk confirmed" title="Перевіркою цієї заявки збіг НАЗК підтверджено">НАЗК · підтверджено</span>';
  // An application decision (including legacy not_current) is not NAZK evidence.
  return '';
}
function cell(row,col,n,left){const attrs=(extra='')=>`class="${[col.pin==='left'?'sticky':'',extra].filter(Boolean).join(' ')}" data-column-key="${col.key}" style="width:${col.width}px;min-width:${col.width}px;max-width:${col.width}px;${col.pin==='left'?`left:${left}px`:''}"`;
  if(col.key==='select')return `<td ${attrs()}><input class="row-check" type="checkbox" ${!applicationRowsCurrent()||selectAllResultsPending?'disabled':''} ${selected.has(row.id)?'checked':''} ${row.historicalReadOnly?'title="Історичну заявку можна вибрати для перегляду або Chat; business-зміни заблоковані"':''}>${historicalApplicationMarker(row)}</td>`;
  if(col.key==='protocolNumber'&&row.formedProtocolId)return `<td ${attrs()}><button type="button" class="protocol-number-link" data-formed-protocol="${esc(row.formedProtocolId)}">${esc(row.protocolNumber)}</button></td>`;
  if(col.key==='protocolNumber'&&row.legacyProtocol)return `<td ${attrs()}><span title="Legacy: сформований раніше">${esc(row.protocolNumber)||'—'} <span class="legacy-protocol-marker" aria-label="Legacy: сформований раніше">ⓘ</span></span>${row.decision==='Очікує рішення'&&role()!=='viewer'&&!row.historicalReadOnly?`<button type="button" class="ghost compact-row-action" data-release-legacy="${esc(row.id)}">Скасувати позначку</button>`:''}</td>`;
  if(col.key==='number')return `<td ${attrs()}>${(page-1)*50+n}</td>`;
  if(col.key==='participant'){const nazkMarker=applicationNazkMarker(row),amcuBlocked=row.decision==='Очікує рішення'&&row.amcuMatch;const note=`<button type="button" class="supplier-note-open ${row.supplierNote?'has-note':''}" title="${esc(row.supplierNote||'Додати спільну примітку постачальника')}">◆</button>`;return `<td ${attrs('participant-note-cell')}>${note}<div class="copy-cell"><div class="cell-main">${esc(row.participant)}${nazkMarker}${amcuBlocked?'<small class="application-amcu-blocked">Постачальник наявний в реєстрі АМКУ · рішення лише «Ні»</small>':''}</div><button class="copy-btn" data-copy-key="participant" title="Копіювати назву" aria-label="Копіювати назву">⧉</button></div></td>`}
  if(col.key==='edrpou')return `<td ${attrs()}><div class="supplier-code-actions"><div class="copy-cell"><span>${esc(row.edrpou)||'<span class="muted">—</span>'}</span>${row.edrpou?'<button class="copy-btn" data-copy-key="edrpou" title="Копіювати ЄДРПОУ / РНОКПП" aria-label="Копіювати ЄДРПОУ / РНОКПП">⧉</button>':''}</div>${row.edrpou?'<button type="button" class="supplier-history-open supplier-profile-icon" title="Всі заявки постачальника" aria-label="Всі заявки постачальника">📋</button>':''}</div></td>`;
  if(col.key==='clarity')return `<td ${attrs('link-cell')}>${row.edrpou?`<a class="external-link clarity-link" href="https://clarity-project.info/edr/${encodeURIComponent(row.edrpou)}" target="_blank" rel="noopener" title="Відкрити в Clarity Project" aria-label="Clarity Project">CP</a>`:'<span class="muted">—</span>'}</td>`;
  if(col.key==='marketplaceLink'||col.key==='prozorroLink'){const url=row[col.key],label=col.key==='marketplaceLink'?'Відкрити на майданчику':'Відкрити в Prozorro';return `<td ${attrs('link-cell')}>${url?`<a class="external-link" href="${esc(url)}" target="_blank" rel="noopener" title="${label}" aria-label="${label}">&#128279;</a>`:'<span class="muted">—</span>'}</td>`}
  if(col.key==='documents')return `<td ${attrs()}><button class="paperclip" title="Відкрити документи">📎 <span>${row.documents.length}</span></button></td>`;
  if(col.key==='registryDocuments')return `<td ${attrs()}><button class="registry-paperclip paperclip" title="Відкрити документи реєстру" ${row.registryDocuments.length?'':'disabled'}>📎 <span>${row.registryDocuments.length}</span></button></td>`;
  if(col.key==='dkCode'){const found=row.experienceSearch==='ok';return `<td ${attrs()}>${esc(row.dkCode)||'<span class="muted">—</span>'} <span class="contract-experience-marker ${found?'found':'neutral'}" title="${found?'Знайдено договір-кандидат':'Договір-кандидат не знайдено або пошук ще не завершено'}">${found?'+':'−'}</span></td>`}
  if(col.key==='documentCheckStatus'){const labels={signature:'КЕП',mvs:'МВС'},badges=Object.entries(labels).map(([key,label])=>{const status=(row.documentCheckCategories||{})[key]||'empty';return`<span class="doc-category-badge ${esc(status)}">${esc(label)}${status==='empty'?' · не перевірено':''}</span>`}).join('');return `<td ${attrs()}><button class="check-result-card compact" title="Відкрити збережений результат перевірки">${badges}</button></td>`}
  if(col.key==='managerName'&&row.managerNameSource==='previous_application'){const isLocked=locked(row,col.key);return `<td ${attrs(`auto-filled ${isLocked?'locked':'cell-editable'}`)} data-key="${isLocked?'':'managerName'}" title="Автоматично перенесено з останньої попередньої заявки цього ЄДРПОУ. Перевірте значення.">${esc(row.managerName)}</td>`}
  if(col.key==='decision'){const c=row.decision==='Допущено'?'admit':row.decision==='Відхилено'?'reject':'wait';return `<td ${attrs()}><span class="status ${c}">${row.decision}</span></td>`}
  if(col.key==='registryStatus'){if(!row.registryStatus)return `<td ${attrs()}><span class="muted">—</span></td>`;const c=row.registryStatus==='Активний'?'admit':row.registryStatus.startsWith('Неактивний')?'reject':'wait';return `<td ${attrs()}><span class="status ${c}">${esc(row.registryStatus)}</span></td>`}
  if(col.key==='protocolDecision'){const label=protocolDecisions.find(([value])=>value===row.protocolDecision)?.[1]||'Не визначено',c=row.protocolDecision==='admit'?'admit':row.protocolDecision==='reject'?'reject':'wait',actionLocked=Boolean(row.marketplaceDecision),isLocked=locked(row,col.key)||actionLocked,title=actionLocked?'Щоб змінити Рішення УО, спочатку скиньте дію на майданчику':'';return `<td ${attrs(isLocked?'locked':'cell-editable')} data-key="${isLocked?'':'protocolDecision'}" title="${title}"><span class="status ${c}">${label}</span></td>`}
  if(col.key==='marketplaceDecision'){const label=marketplaceDecisions.find(([value])=>value===row.marketplaceDecision)?.[1]||'Не виконано',c=row.marketplaceDecision==='admit'?'admit':row.marketplaceDecision==='reject'?'reject':'wait',rowLocked=locked(row,col.key),missing=[];if(!row.protocolDecision)missing.push('Рішення УО');if(!row.managerName)missing.push('ПІБ керівника');if(!row.protocolNumber)missing.push('№ протоколу');if(!row.protocolDate)missing.push('дату протоколу');if(row.complianceStatus==='rejected'&&!row.complianceComments)missing.push('коментар комплаєнс');const formed=Boolean(row.protocolGeneratedAt)&&row.generatedProtocolNumber===row.protocolNumber&&row.generatedProtocolDate===row.protocolDate&&row.generatedProtocolDecision===row.protocolDecision;if(!formed)missing.push('сформований протокол із поточними даними');const isLocked=rowLocked||missing.length>0,title=rowLocked&&row.marketplaceDecision?'Рядок заблоковано виконаною дією на майданчику':missing.length?`Недоступно: ${missing.join(', ')}`:'';return `<td ${attrs(isLocked?'locked':'cell-editable')} data-key="${isLocked?'':'marketplaceDecision'}" title="${title}"><span class="status ${c}">${label}</span></td>`}
  if(col.key==='complianceStatus'){const label=complianceStatuses.find(([value])=>value===row.complianceStatus)?.[1]||'Не визначено',c=row.complianceStatus==='approved'?'admit':row.complianceStatus==='rejected'?'reject':'wait',decisionLocked=Boolean(row.protocolDecision),isLocked=locked(row,col.key)||decisionLocked,title=decisionLocked?'Щоб змінити комплаєнс, спочатку встановіть Рішення УО «Не визначено»':!row.nazkCanApprove?'Погодження Комплаєнс недоступне. Спочатку перевірте довідку НАЗК у складі цієї заявки та зафіксуйте результат «Спростовано».':'';return `<td ${attrs(isLocked?'locked':'cell-editable')} data-key="${isLocked?'':'complianceStatus'}" title="${title}"><span class="status ${c}">${label}</span>${!row.nazkCanApprove&&!decisionLocked?'<small>Спочатку перевірте довідку НАЗК</small>':''}</td>`}
  const edit=fieldMap[col.key],isLocked=edit&&locked(row,col.key),displayValue=['protocolOfficer','reviewOfficer'].includes(col.key)?formatOfficerName(row[col.key]):row[col.key];return `<td ${attrs(`${edit&&!isLocked?'cell-editable':''} ${isLocked?'locked':''}`.trim())} data-key="${edit?col.key:''}">${esc(displayValue)||'<span class="muted">—</span>'}</td>`}
function render(){const cols=getCols(),left=offsets(cols),shown=rows,table=$('#applicationsTable'),tableWidth=cols.reduce((sum,c)=>sum+c.width,0);table.style.width=`${tableWidth}px`;table.style.minWidth=`${tableWidth}px`;$('#applicationsTable thead').innerHTML=`<tr>${cols.map(c=>{const sortable=sortableColumns.has(c.key),arrow=sortKey===c.key?(sortDirection==='asc'?' ↑':' ↓'):'',heading=c.key==='marketplaceLink'?'<img class="marketplace-header-mark" src="/assets/zakupivli-pro-mark.svg" alt="" aria-hidden="true">':`${c.label}<span class="sort-arrow">${arrow}</span>`;return `<th class="${c.pin==='left'?'sticky':''} ${sortable?'sortable':''} ${c.key==='marketplaceLink'?'marketplace-header':''}" data-column-key="${c.key}" data-sort="${sortable?c.key:''}" title="${c.key==='marketplaceLink'?'Майданчик Zakupivli.Pro':''}" style="width:${c.width}px;min-width:${c.width}px;max-width:${c.width}px;${c.pin==='left'?`left:${left[c.key]}px`:''}">${c.key==='select'?'<input id="selectAll" type="checkbox">':heading}</th>`}).join('')}</tr>`;
  $('#applicationsTable tbody').innerHTML=loading?`<tr><td colspan="${cols.length}">Завантаження…</td></tr>`:shown.map((r,i)=>{const pending=r.decision==='Очікує рішення',applicationNazk=r.nazkPresentationState,submissionNazk=pending&&applicationNazk==='needs_check',risk=pending&&r.amcuMatch?'registry-risk-amcu':submissionNazk?'registry-risk-nazk':pending&&applicationNazk==='confirmed'?'registry-risk-amcu':pending&&applicationNazk==='possible'?'registry-risk-nazk':'',rowTitle=pending&&r.amcuMatch?'Постачальник є у чинному реєстрі АМКУ — рішення «Так» заблоковано; доступне лише «Ні»':submissionNazk?'НАЗК · перевірити довідку цієї заявки':risk==='registry-risk-amcu'?'Наявність у реєстрі НАЗК підтверджено перевіркою цієї заявки':risk==='registry-risk-nazk'?'Знайдено збіг ПІБ керівника з реєстром НАЗК — потрібна ручна перевірка':'';return `<tr data-id="${r.id}" class="${activeRow===r.id?'active':''} ${risk} ${r.reviewCompleted?'application-review-completed':''} ${r.historicalReadOnly?'historical-read-only':''}" title="${rowTitle}">${cols.map(c=>cell(r,c,i+1,left[c.key])).join('')}</tr>`}).join('');
  $('#resultInfo').textContent=`${total} заявок у базі`;$('#footerInfo').innerHTML=`Сторінка ${page} із ${pages} · ${total} записів &nbsp; <button id="prevPage" class="ghost" ${page<=1?'disabled':''}>←</button> <button id="nextPage" class="ghost" ${page>=pages?'disabled':''}>→</button>`;
  const historicalSelected=applicationSelection.entries().some(row=>row.historicalReadOnly);$('#selectedCount').textContent=selected.size?`(${selected.size})`:'';$('#bulkBtn').disabled=!selected.size||role()==='viewer'||historicalSelected||!applicationRowsCurrent()||selectAllResultsPending;$('#bulkBtn').title=historicalSelected?'Історичні заявки MedData можна передавати в Chat, але не змінювати масово':'';applyKpiVisibility();bindTable();requestAnimationFrame(syncTableScroll)}
const renderBeforeAmcuPendingMarker=render;
render=function(){
  renderBeforeAmcuPendingMarker();
  $$('#applicationsTable tbody tr[data-id]').forEach(tr=>{
    const row=rows.find(item=>item.id===tr.dataset.id);
    if(!row||row.decision!=='Очікує рішення'||!row.amcuMatch)return;
    tr.classList.add('registry-risk-amcu');
    tr.title='Постачальник є у чинному реєстрі АМКУ — рішення «Так» заблоковано; доступне лише «Ні»';
    const cell=tr.querySelector('.cell-main');
    if(cell&&!cell.querySelector('.application-amcu-blocked'))cell.insertAdjacentHTML('beforeend','<small class="application-amcu-blocked">Постачальник наявний в реєстрі АМКУ · рішення лише «Ні»</small>');
  });
};
const editCellBeforeAmcuGuard=editCell;
editCell=function(td,row){
  editCellBeforeAmcuGuard(td,row);
  if(row.decision==='Очікує рішення'&&row.amcuMatch&&['protocolDecision','marketplaceDecision'].includes(td.dataset.key)){
    td.querySelectorAll('option[value="admit"]').forEach(option=>option.remove());
  }
};
function bindTable(){updateApplicationSelectionControls();$('#prevPage')?.addEventListener('click',()=>{page--;loadRows()});$('#nextPage')?.addEventListener('click',()=>{page++;loadRows()});$('#selectAll')?.addEventListener('change',e=>{selectApplicationPage(e.target.checked)});
  $$('#applicationsTable th[data-sort]:not([data-sort=""])').forEach(th=>{const indicator=th.querySelector('.sort-arrow');if(indicator)indicator.textContent=sortIndicator(th.dataset.sort);th.onclick=e=>{const key=th.dataset.sort;if(e.shiftKey){if(!multiSort.length)multiSort=[{key:sortKey,direction:sortDirection}];const i=multiSort.findIndex(x=>x.key===key);if(i<0)multiSort.push({key,direction:'asc'});else if(multiSort[i].direction==='asc')multiSort[i].direction='desc';else multiSort.splice(i,1)}else{const previous=multiSort.find(x=>x.key===key);multiSort=[{key,direction:(previous?.direction||(sortKey===key?sortDirection:''))==='asc'?'desc':'asc'}]}if(multiSort.length){sortKey=multiSort[0].key;sortDirection=multiSort[0].direction}profile().sorts=structuredClone(multiSort);if(!profile().is_system)persistProfileLayout();page=1;loadRows()}});
  $$('#applicationsTable tbody tr[data-id]').forEach(tr=>{const row=rows.find(r=>r.id===tr.dataset.id);tr.onclick=()=>{activeRow=row.id;render()};tr.querySelector('.supplier-history-open')?.addEventListener('click',e=>{e.stopPropagation();activeRow=row.id;openSupplierHistory(row.edrpou)});tr.querySelector('.supplier-note-open')?.addEventListener('click',e=>{e.stopPropagation();openSupplierNote(row)});tr.querySelector('.nazk-control-open')?.addEventListener('click',e=>{e.stopPropagation();openSubmissionNazkControl(row)});tr.querySelector('.row-check')?.addEventListener('click',e=>e.stopPropagation());tr.querySelector('.row-check')?.addEventListener('change',e=>{if(applicationRowsCurrent()&&!selectAllResultsPending){applicationSelection.toggle(row,e.target.checked);render()}});tr.querySelectorAll('.copy-btn').forEach(button=>button.onclick=e=>{e.stopPropagation();copyText(row[button.dataset.copyKey])});tr.querySelectorAll('.external-link').forEach(link=>link.onclick=e=>e.stopPropagation());tr.querySelector('.check-result-card')?.addEventListener('click',e=>{e.stopPropagation();openSavedDocumentCheck(row)});tr.querySelector('.paperclip:not(.registry-paperclip)')?.addEventListener('click',e=>{e.stopPropagation();openDocs(row,row.documents,'Документи заявки та кваліфікації')});tr.querySelector('.registry-paperclip')?.addEventListener('click',e=>{e.stopPropagation();openDocs(row,row.registryDocuments,'Документи рішення у реєстрі')});tr.querySelectorAll('td[data-key]:not([data-key=""])').forEach(td=>td.onclick=e=>{e.stopPropagation();editCell(td,row)})})}

let supplierNoteRow=null;
function openSupplierNote(row){supplierNoteRow=row;$('#supplierNoteSubtitle').textContent=`${row.participant} · ${row.edrpou}`;$('#supplierNoteText').value=row.supplierNote||'';const viewer=role()==='viewer';$('#supplierNoteText').disabled=viewer;$('#supplierNoteSave').hidden=viewer;$('#supplierNoteClear').hidden=viewer||!row.supplierNote;$('#supplierNoteMeta').textContent=row.supplierNoteUpdatedAt?`Оновлено ${displayDate(row.supplierNoteUpdatedAt)} · ${row.supplierNoteUpdatedBy||'—'}`:'Примітку ще не додано';$('#supplierNoteDialog').showModal()}
async function saveSupplierNote(note,successMessage){if(!supplierNoteRow)return;try{const data=await request(`${API}/suppliers/${encodeURIComponent(supplierNoteRow.edrpou)}/note`,{method:'PATCH',headers:{'Content-Type':'application/json'},body:JSON.stringify({note})});rows.filter(row=>row.edrpou===supplierNoteRow.edrpou).forEach(row=>{row.supplierNote=data.note;row.supplierNoteUpdatedAt=data.updated_at;row.supplierNoteUpdatedBy=data.updated_by});$('#supplierNoteDialog').close();renderInPlace();toast(successMessage)}catch(error){toast(error.message)}}
$('#supplierNoteSave').onclick=e=>{e.preventDefault();saveSupplierNote($('#supplierNoteText').value,'Спільну примітку збережено')};
$('#supplierNoteClear').onclick=()=>saveSupplierNote('','Спільну примітку очищено');
async function saveField(row,key,value){await request(`${API}/applications/${row.id}`,{method:'PATCH',headers:{'Content-Type':'application/json'},body:JSON.stringify({role:role(),user:$('#roleSelect').selectedOptions[0].text,[fieldMap[key]]:value})});invalidateRegistryStats();void loadStats()}
function buildRemarksText(){
  const chosen=remarksItems.filter(item=>remarksSelected.has(String(item.id)));if(!chosen.length)return '';
  const points=[];chosen.forEach(item=>{if(!points.includes(item.point))points.push(item.point)});
  const bodies=chosen.map(item=>item.text.trim().replace(/[.;]+$/,'')).filter(Boolean);
  return `Не виконано вимоги ${points.join(', ')} «Кваліфікаційних та інших вимог до учасника» (${bodies.join('; ')}).`;
}
function renderInPlace(){const scroller=$('#tableScroll'),top=scroller?.scrollTop||0,left=scroller?.scrollLeft||0;render();if(scroller){scroller.scrollTop=top;scroller.scrollLeft=left}}
async function refreshOneRow(row){const scroller=$('#tableScroll'),top=scroller?.scrollTop||0,left=scroller?.scrollLeft||0,generation=loadRowsGeneration+1;const ok=await loadRows();if(generation===loadRowsGeneration&&scroller){scroller.scrollTop=top;scroller.scrollLeft=left;syncTableScroll()}return ok}
function renderRemarksCatalog(){
  const query=$('#remarksSearch').value.trim().toLocaleLowerCase('uk-UA');
  const shown=remarksItems.filter(item=>!query||`${item.point} ${item.text} ${item.tag} ${item.category}`.toLocaleLowerCase('uk-UA').includes(query));
  $('#remarksCatalog').innerHTML=shown.length?shown.map(item=>`<label class="remark-option"><input type="checkbox" value="${esc(item.id)}" ${remarksSelected.has(String(item.id))?'checked':''}><strong>${esc(item.point)}</strong><span>${esc(item.text)}${item.category||item.tag?`<small>${esc([item.category,item.tag].filter(Boolean).join(' · '))}</small>`:''}</span><span class="remark-actions"><button type="button" class="remark-edit" data-id="${esc(item.id)}" title="Редагувати шаблон">✎</button><button type="button" class="remark-disable" data-id="${esc(item.id)}" title="Прибрати з довідника">×</button></span></label>`).join(''):'<p class="muted" style="padding:16px">Варіантів не знайдено</p>';
  $$('#remarksCatalog input[type="checkbox"]').forEach(input=>input.onchange=()=>{input.checked?remarksSelected.add(input.value):remarksSelected.delete(input.value);$('#remarksPreview').value=buildRemarksText()});
}
async function loadRemarksCatalog(force=false){
  $('#remarksCatalog').innerHTML='<p class="muted" style="padding:16px">Завантаження довідника…</p>';
  const data=await request(`${API}/remarks-catalog${force?'?refresh=1':''}`);remarksItems=data.items||[];renderRemarksCatalog();
  $('#remarksSource').textContent=`${remarksItems.length} варіантів · ${data.source==='local-database'?'локальний редагований довідник':data.source==='google-sheet'?'імпортовано з Google Sheets':data.source==='local-cache'?'локальна збережена копія':'початковий локальний довідник'}`;
}
async function addRemarkTemplate(){
  const point=prompt('Пункт кваліфікаційних вимог:','п. ');if(point===null)return;const text=prompt('Текст зауваження (без вступу «Не виконано вимоги…»):','');if(text===null)return;
  try{await request(`${API}/remarks-catalog`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({point,text})});await loadRemarksCatalog(false);toast('Пункт додано до локального довідника')}catch(error){toast(error.message)}
}
async function editRemarkTemplate(id){
  const item=remarksItems.find(value=>String(value.id)===String(id));if(!item)return;const point=prompt('Пункт кваліфікаційних вимог:',item.point);if(point===null)return;const text=prompt('Текст шаблону:',item.text);if(text===null)return;
  try{await request(`${API}/remarks-catalog/${encodeURIComponent(id)}`,{method:'PATCH',headers:{'Content-Type':'application/json'},body:JSON.stringify({point,text})});await loadRemarksCatalog(false);toast('Шаблон оновлено')}catch(error){toast(error.message)}
}
async function disableRemarkTemplate(id){
  if(!confirm('Прибрати цей шаблон із довідника? Уже збережені тексти у заявках не зміняться.'))return;
  try{await request(`${API}/remarks-catalog/${encodeURIComponent(id)}`,{method:'PATCH',headers:{'Content-Type':'application/json'},body:JSON.stringify({active:false})});remarksSelected.delete(String(id));await loadRemarksCatalog(false);toast('Шаблон прибрано')}catch(error){toast(error.message)}
}
async function openRemarksDialog(row){
  remarksRow=row;remarksSelected.clear();$('#remarksSearch').value='';$('#remarksPreview').value=row.protocolRemarks||'';
  $('#remarksPicker').hidden=true;
  $('#remarksSubtitle').textContent=`${row.participant} · остаточний текст визначає УО`;$('#remarksDialog').showModal();
  try{const [selection]=await Promise.all([request(`${API}/applications/${encodeURIComponent(row.id)}/remark-selections`),loadRemarksCatalog(false)]);remarksSelected=new Set((selection.remark_ids||[]).map(String));renderRemarksCatalog()}catch(error){$('#remarksCatalog').innerHTML=`<p class="muted" style="padding:16px">${esc(error.message)}</p>`}
}
async function saveRemarks(){
  if(!remarksRow)return;const value=$('#remarksPreview').value.trim();
  if(remarksRow.protocolDecision==='admit'&&value!=='Без зауважень')return toast('Рішення УО «Так» неможливе: заявка має зауваження до протоколу');
  if(remarksRow.protocolDecision==='reject'&&value==='Без зауважень'&&remarksRow.complianceStatus==='approved')return toast('Немає підстав для відхилення згідно з рішенням комплаєнс та відсутністю зауважень.');
  try{await saveField(remarksRow,'protocolRemarks',value);await request(`${API}/applications/${encodeURIComponent(remarksRow.id)}/remark-selections`,{method:'PATCH',headers:{'Content-Type':'application/json'},body:JSON.stringify({remark_ids:[...remarksSelected]})});remarksRow.protocolRemarks=value;$('#remarksDialog').close();render();toast(value?'Зауваження збережено':'Поле зауважень очищено')}catch(error){toast(error.message)}
}
function editCell(td,row){
  const key=td.dataset.key;
  if(locked(row,key)){toast(role()==='viewer'?'Роль «Перегляд» не може редагувати':'Після рішення доступна лише примітка');return}
  if(td.querySelector('input,select'))return;
  if(key==='protocolRemarks'){openRemarksDialog(row);return}
  const old=row[key]||'',editor=(key==='protocolOfficer'||key==='protocolDecision'||key==='marketplaceDecision'||key==='complianceStatus')?document.createElement('select'):document.createElement('input');
  if(key==='protocolOfficer')editor.innerHTML=['',...protocolOfficers].map(value=>`<option value="${esc(value)}">${value?esc(formatOfficerName(value)):'Не вибрано'}</option>`).join('');
  if(key==='protocolDecision')editor.innerHTML=protocolDecisions.filter(([value])=>!row.amcuMatch||value!=='admit').map(([value,label])=>`<option value="${value}">${label}</option>`).join('');
  if(key==='marketplaceDecision')editor.innerHTML=marketplaceDecisions.filter(([value])=>!row.amcuMatch||value!=='admit').map(([value,label])=>`<option value="${value}">${label}</option>`).join('');
  if(key==='complianceStatus')editor.innerHTML=complianceStatuses.map(([value,label])=>`<option value="${value}" ${value==='approved'&&!row.nazkCanApprove?'disabled':''}>${label}</option>`).join('');
  if(key==='protocolDecision'&&!row.complianceStatus){editor.querySelector('option[value="admit"]')?.setAttribute('disabled','');editor.querySelector('option[value="reject"]')?.setAttribute('disabled','')}
  if(key==='protocolDecision'&&row.complianceStatus==='rejected')editor.querySelector('option[value="admit"]')?.setAttribute('disabled','');
  if(key==='marketplaceDecision')editor.querySelector(`option[value="${row.protocolDecision==='admit'?'reject':'admit'}"]`)?.setAttribute('disabled','');
  if(key==='complianceStatus'&&row.protocolDecision==='admit')editor.querySelector('option[value="rejected"]').disabled=true;
  editor.value=old;td.innerHTML='';td.append(editor);editor.focus();if(editor.select)editor.select();
  editor.onkeydown=e=>{if(e.key==='Enter')editor.blur();if(e.key==='Escape'){editor.value=old;editor.blur()}};
  if(key==='protocolOfficer'||key==='protocolDecision'||key==='complianceStatus')editor.onchange=()=>editor.blur();
  if(key==='marketplaceDecision')editor.onchange=()=>{const label=marketplaceDecisions.find(([value])=>value===editor.value)?.[1];if(editor.value&&!confirm(`Підтвердити дію «${label}»? Вона має бути виконана одночасно на майданчику.`))editor.value=old;editor.blur()};
  editor.onblur=async()=>{const value=editor.value.trim();if(value!==old){if(key==='protocolDecision'&&value==='admit'&&row.protocolRemarks.trim()!=='Без зауважень'){toast('Рішення УО «Так» неможливе: заявка має зауваження до протоколу');return renderInPlace()}if(key==='protocolDecision'&&value==='reject'&&row.protocolRemarks.trim()==='Без зауважень'&&row.complianceStatus==='approved'){toast('Немає підстав для відхилення згідно з рішенням комплаєнс та відсутністю зауважень.');return renderInPlace()}try{$('#saveState').classList.add('saving');$('#saveState').innerHTML='<i></i> Збереження…';await saveField(row,key,value);row[key]=value;toast('Зміну збережено');if(key==='managerName'){statsSignature='';await refreshOneRow(row);$('#saveState').classList.remove('saving');$('#saveState').innerHTML='<i></i> Усі зміни збережено';return}}catch(e){row[key]=old;toast(e.message)}}$('#saveState').classList.remove('saving');$('#saveState').innerHTML='<i></i> Усі зміни збережено';renderInPlace()};
}
function documentSelectionKey(row){return `pqm-document-selection:${row.id}`}
function getDocumentSelection(row){try{return JSON.parse(localStorage.getItem(documentSelectionKey(row))||'{}')}catch{return {}}}
function saveDocumentSelection(row){const selection={};$$('#docsList .doc-analysis-tag:checked').forEach(input=>{(selection[input.dataset.index]??=[]).push(input.value)});if(Object.keys(selection).length)localStorage.setItem(documentSelectionKey(row),JSON.stringify(selection));else localStorage.removeItem(documentSelectionKey(row));return selection}
function openDocs(row,documents=row.documents,kind='Документи'){activeDocsRow=row;const title=$('#docsDialog h2');title.textContent=kind;$('#docsSubtitle').innerHTML=`${esc(row.participant)} · ${esc(row.qualificationId)} ${historicalApplicationBadge(row)}`;$('#archiveDownloadBtn').href=`${API}/applications/${encodeURIComponent(row.id)}/archive`;const selectable=documents===row.documents,selection=getDocumentSelection(row);$('#verifyDocumentsBtn').hidden=!selectable;const renderDocuments=(items,withChecks)=>items.map((d,index)=>`<div class="doc"><span class="doc-icon">${esc((d.format||d.title||'FILE').split('/').pop().slice(0,4).toUpperCase())}</span><div class="doc-main"><strong>${esc(d.title||'Документ')}</strong><small>${esc(d.documentType||'Документ Prozorro')} · ${esc(displayDate(d.dateModified||d.datePublished))}</small>${withChecks?`<div class="doc-analysis-tags">${[['signature','Підпис заявки'],['mvs','Витяг МВС'],['mvs_signature','Печатка МВС']].map(([value,label])=>`<label><input class="doc-analysis-tag" data-index="${index}" type="checkbox" value="${value}" ${(selection[index]||[]).includes(value)?'checked':''}> ${label}</label>`).join('')}</div>`:''}</div><a class="ghost" href="${esc(d.url||'#')}" target="_blank" rel="noopener">Відкрити</a></div>`).join('');if(selectable){const seen=new Set(),supplier=(row.supplierDocuments||[]).filter(d=>{const key=d.url||d.id;if(!key||seen.has(key))return false;seen.add(key);return true}),decision=(row.decisionDocuments||[]).filter(d=>{const key=d.url||d.id;if(!key||seen.has(key))return false;seen.add(key);return true}),sections=[];if(supplier.length)sections.push(`<section class="history-document-group" data-document-group="supplier"><h3>Документи постачальника <span>${supplier.length}</span></h3>${renderDocuments(supplier,true)}</section>`);if(decision.length)sections.push(`<section class="history-document-group" data-document-group="decision"><h3>Документи розгляду заявки <span>${decision.length}</span></h3>${renderDocuments(decision,false)}</section>`);$('#docsList').innerHTML=sections.join('')||'<p class="muted">Документів немає</p>'}else $('#docsList').innerHTML=documents.length?renderDocuments(documents,false):'<p class="muted">Документів немає</p>';$$('#docsList .doc-analysis-tag').forEach(input=>input.onchange=()=>saveDocumentSelection(row));$('#docsDialog').showModal()}
function openHistoryDocuments(row,groups){activeDocsRow=row;$('#docsDialog h2').textContent='Документи історичної заявки';$('#docsSubtitle').innerHTML=`${esc(row.participant)} · ${esc(row.qualificationId)} ${historicalApplicationBadge(row)}`;$('#archiveDownloadBtn').href=`${API}/applications/${encodeURIComponent(row.id)}/archive`;$('#verifyDocumentsBtn').hidden=true;const labels={supplier:'Документи постачальника',decision:'Документи розгляду заявки',registry:'Документи реєстру'},seen=new Set(),sections=[];
  for(const key of ['supplier','decision','registry']){const documents=(groups[key]||[]).filter(document=>{const id=document.url||document.id;if(!id||seen.has(id))return false;seen.add(id);return true});if(!documents.length)continue;sections.push(`<section class="history-document-group" data-document-group="${key}"><h3>${labels[key]} <span>${documents.length}</span></h3>${documents.map(d=>`<div class="doc"><span class="doc-icon">${esc((d.format||d.title||'FILE').split('/').pop().slice(0,4).toUpperCase())}</span><div class="doc-main"><strong>${esc(d.title||'Документ')}</strong><small>${esc(d.documentType||'Документ Prozorro')} · ${esc(displayDate(d.dateModified||d.datePublished))}</small></div><a class="ghost" href="${esc(d.url||'#')}" target="_blank" rel="noopener">Відкрити</a></div>`).join('')}</section>`)}
  $('#docsList').innerHTML=sections.join('')||'<p class="muted">Документів немає</p>';$('#docsDialog').showModal()}
async function downloadApplicationArchive(event){event.preventDefault();const link=$('#archiveDownloadBtn');if(link.classList.contains('disabled'))return;const old=link.textContent;link.classList.add('disabled');link.textContent='Завантаження…';try{const headers={},localRole=$('#roleSelect')?.value;if(localRole)headers['X-PQM-Local-Role']=localRole;const response=await fetch(link.href,{headers});if(!response.ok){const body=await response.json().catch(()=>({}));throw new Error(body.error||`Помилка сервера ${response.status}`)}const blob=await response.blob(),disposition=response.headers.get('content-disposition')||'',match=disposition.match(/filename="?([^";]+)"?/i),filename=match?.[1]||'PQM-documents.zip',url=URL.createObjectURL(blob),download=document.createElement('a');download.href=url;download.download=filename;document.body.append(download);download.click();download.remove();URL.revokeObjectURL(url);const failed=Number(response.headers.get('X-PQM-Failed-Count')||0);if(failed){let names=[];try{names=JSON.parse(decodeURIComponent(response.headers.get('X-PQM-Failed-Documents')||''))}catch{}toast(`ZIP неповний: не завантажено ${failed} файл(и): ${names.join(', ')||'перелік міститься в архіві'}`,'warning')}else toast('Усі документи завантажено','success')}catch(error){toast(error.message,'error')}finally{link.classList.remove('disabled');link.textContent=old}}
$('#archiveDownloadBtn').onclick=downloadApplicationArchive;
function renderBusinessRows(item){if(item.key!=='contract_experience'||!item.rows?.length)return '';return `<div class="contract-experience-links">${item.rows.slice(0,3).map(row=>`<a href="${esc(row.url)}" target="_blank" rel="noopener"><strong>${esc(row.contract_id||'Договір')}</strong><small>${esc(displayDate(row.date_modified))} · ${esc(row.buyer||'Замовник не зазначений')}</small></a>`).join('')}</div>`}
function renderDocumentCheck(data){lastDocumentCheck=data;$('#documentCheckSubtitle').textContent=`${data.supplier_name} · ${data.supplier_code} · ${data.pretty_id}${data.checked_at?` · збережено ${displayDate(data.checked_at)}`:''}`;const status=data.counts.error?'error':data.counts.warning?'warning':data.counts.ok?'ok':'neutral',headline=status==='error'?'Виявлено помилки':status==='warning'?'Є зауваження':status==='ok'?'Перевірки пройдено':'Довідкова інформація';const groups=[['Підпис заявки',item=>!item.key.startsWith('mvs_')&&item.key!=='contract_experience'],['Витяг з МВС',item=>item.key.startsWith('mvs_')],['Досвід у Prozorro',item=>item.key==='contract_experience']];const row=item=>`<div class="check-row ${item.status} ${item.rows?.length?'with-table':''} ${item.key==='organization'?'informational':''}"><i>${item.key==='contract_experience'?(item.rows?.length?'+':'−'):item.status==='ok'?'✓':item.status==='error'?'×':'!'}</i><strong>${esc(item.label)}</strong><span>${esc(item.detail)}</span>${renderBusinessRows(item)}</div>`;const sections=groups.map(([title,test])=>{const items=data.checks.filter(test);return items.length?`<section class="check-section"><h3>${title}</h3><div class="check-list">${items.map(row).join('')}</div></section>`:''}).join('');$('#documentCheckBody').innerHTML=`<div class="check-summary ${status}"><strong>${headline}</strong><span>Успішно <b>${data.counts.ok||0}</b></span><span>Попередження <b>${data.counts.warning||0}</b></span><span>Помилки <b>${data.counts.error||0}</b></span></div><div class="check-sections">${sections}</div>${data.notice?`<div class="check-notice">${esc(data.notice)}</div>`:''}`;$('#officialSignatureCheck').href=data.official_verification_url;if(!$('#documentCheckDialog').open)$('#documentCheckDialog').showModal()}
async function openSavedDocumentCheck(row){activeDocsRow=row;if(!row.documentCheckStatus)return verifyDocuments();$('#documentCheckBody').innerHTML='<p class="check-loading">Завантаження збереженого результату…</p>';$('#documentCheckSubtitle').textContent=`${row.participant} · ${row.edrpou}`;if(!$('#documentCheckDialog').open)$('#documentCheckDialog').showModal();try{const data=await request(`${API}/applications/${encodeURIComponent(row.id)}/document-check-result?t=${Date.now()}`);renderDocumentCheck(data)}catch(error){$('#documentCheckBody').innerHTML=`<div class="check-notice error">${esc(error.message)}</div>`}}
async function verifyDocuments(){if(!activeDocsRow)return;const selection=$('#docsDialog').open?saveDocumentSelection(activeDocsRow):getDocumentSelection(activeDocsRow),selectionParam=Object.keys(selection).length?`&selection=${encodeURIComponent(JSON.stringify(selection))}`:'';if($('#docsDialog').open)$('#docsDialog').close();$('#documentCheckBody').innerHTML='<p class="check-loading">Перевірка вибраних КЕП/МВС…</p>';$('#documentCheckSubtitle').textContent=`${activeDocsRow.participant} · ${activeDocsRow.edrpou}`;if(!$('#documentCheckDialog').open)$('#documentCheckDialog').showModal();try{const started=await request(`${API}/applications/${encodeURIComponent(activeDocsRow.id)}/verify-documents/start?t=${Date.now()}${selectionParam}`);let job=started;let attempt=0;while(job.status==='running'){await new Promise(resolve=>setTimeout(resolve,750));job=await request(`${API}/document-check-jobs/${encodeURIComponent(started.job_id)}?t=${Date.now()}`);attempt++;if(attempt%8===0)$('#documentCheckBody').innerHTML=`<p class="check-loading">Перевірка триває… ${Math.round(attempt*0.75)} с</p>`}if(job.status==='error')throw new Error(job.error||'Не вдалося перевірити документи');if(job.status!=='complete')throw new Error('Не вдалося отримати результат перевірки');renderDocumentCheck(job.result);activeDocsRow.documentCheckStatus=job.result.counts.error?'error':job.result.counts.warning?'warning':job.result.counts.ok?'ok':'neutral';activeDocsRow.documentCheckCategories=Object.fromEntries(Object.entries(job.result.category_results||{}).map(([key,value])=>[key,value.status]));activeDocsRow.documentCheckedAt=displayDate(job.result.checked_at||new Date().toISOString());renderInPlace()}catch(error){$('#documentCheckBody').innerHTML=`<div class="check-notice error">${esc(error.message)}</div>`}}
async function saveDocumentReview(){if(!activeDocsRow)return;const authority=$('#authorityReviewSelect')?.value||'',mvsSeal=$('#mvsSealReviewSelect')?.value||'';try{await saveField(activeDocsRow,'authorityReview',authority);await saveField(activeDocsRow,'mvsSealReview',mvsSeal);activeDocsRow.authorityReview=authority;activeDocsRow.mvsSealReview=mvsSeal;if(lastDocumentCheck){lastDocumentCheck.authority_review=authority;lastDocumentCheck.mvs_seal_review=mvsSeal}toast('Ручні підтвердження збережено');await loadRows()}catch(error){toast(error.message)}}
function renderProfiles(){normalizeProfiles();$('#profileSelect').innerHTML=profiles.map(p=>`<option value="${p.id}" ${p.id===activeProfileId?'selected':''}>${p.is_system?'Системний':'Мій'}: ${esc(p.name)}</option>`).join('');const p=profile(),admin=currentMe?.role==='admin';$('#createSystemProfileBtn').hidden=!admin;$('#renameProfileBtn').disabled=p.is_system&&!admin;$('#deleteProfileBtn').disabled=p.is_system&&!admin;$('#restoreProfileBtn').disabled=!(p.source_system_profile_id||p.is_system)}
let profileSaveTimer;function persistProfileLayout(){const p=profile();if(!p||p.id==='local-default'||(p.is_system&&currentMe?.role!=='admin'))return;profileLayoutGeneration++;clearTimeout(profileSaveTimer);const payload={columns:p.columns};if(currentMe?.role!=='viewer'){payload.kpis=p.kpis;payload.sorts=p.sorts||multiSort}profileSaveTimer=setTimeout(()=>request(`${API}/application-profiles/${encodeURIComponent(p.id)}`,{method:'PATCH',headers:{'Content-Type':'application/json'},body:JSON.stringify(payload)}).catch(error=>toast(error.message)),250)}
const persistProfileColumns=persistProfileLayout;
function applicationProfileColumns(p=profile()){return p.columns.map(c=>({...c,width:c.key==='marketplaceLink'?52:c.width}))}
window.addEventListener('pqm:table-widths-ready',()=>render());
async function ensurePersonalApplicationProfile(){
  let p=profile();if(!p.is_system)return p;
  const sourceId=p.id,existing=profiles.find(item=>!item.is_system&&item.source_system_profile_id===sourceId);
  if(existing){activeProfileId=existing.id;saveProfiles();renderProfiles();return existing}
  try{
    const payload={name:`Мій вигляд: ${p.name}`,columns:applicationProfileColumns(p),source_system_profile_id:sourceId};if(currentMe.role!=='viewer'){payload.kpis=p.kpis;payload.sorts=p.sorts||[]}
    const created=await request(`${API}/application-profiles`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(payload)});
    await loadProfiles();activeProfileId=created.id;saveProfiles();renderProfiles();return profile();
  }catch(error){
    await loadProfiles().catch(()=>{});const raced=profiles.find(item=>!item.is_system&&item.source_system_profile_id===sourceId);
    if(raced){activeProfileId=raced.id;saveProfiles();renderProfiles();return raced}
    throw error;
  }
}
document.addEventListener('pqm:table-column-resize',async event=>{
  if(event.target?.id!=='applicationsTable'||!currentMe?.role)return;
  try{const p=await ensurePersonalApplicationProfile(),column=p.columns.find(item=>item.key===event.detail.key);if(column){column.width=event.detail.width;persistProfileLayout();render()}}
  catch(error){toast(error.message||'Не вдалося зберегти персональну ширину','error')}
});
async function columnsDialog(){
  if(!currentMe?.role)return;
  let p;try{p=await ensurePersonalApplicationProfile()}catch(error){toast(error.message||'Не вдалося відкрити персональні налаштування','error');return}
  const box=$('#columnsList');let search=$('#columnSettingsSearch');
  if(!search){search=document.createElement('input');search.id='columnSettingsSearch';search.placeholder='Знайти колонку…';box.before(search)}search.value='';
  const draw=()=>{const ordered=[...p.columns].sort((a,b)=>a.order-b.order),term=search.value.trim().toLocaleLowerCase('uk');box.innerHTML=ordered.map((c,i)=>({c,i})).filter(({c})=>!term||(c.label||'Вибір').toLocaleLowerCase('uk').includes(term)).map(({c,i})=>`<div class="column-item" data-key="${c.key}"><span class="col-drag" draggable="${!term}" title="Перетягнути" aria-label="Перетягнути">⠿</span><input class="col-visible" type="checkbox" ${c.visible?'checked':''} ${c.system?'disabled':''}><strong>${esc(c.label||'Вибір')}</strong><input class="col-width" type="number" min="40" max="1200" ${c.key==='marketplaceLink'?'disabled title="Стандартна ширина 52 px"':''} value="${c.key==='marketplaceLink'?52:c.width}"><select class="col-pin"><option value="">Не закр.</option><option value="left" ${c.pin==='left'?'selected':''}>Ліворуч</option></select><button type="button" class="icon-btn col-up" ${i===0?'disabled':''}>↑</button><button type="button" class="icon-btn col-down" ${i===ordered.length-1?'disabled':''}>↓</button></div>`).join('')};
  const move=(from,to)=>{const ordered=[...p.columns].sort((a,b)=>a.order-b.order);if(from<0||to<0||to>=ordered.length)return;const [moved]=ordered.splice(from,1);ordered.splice(to,0,moved);ordered.forEach((c,i)=>c.order=i);persistProfileColumns();draw();render()};
  let reset=$('#applicationColumnWidthsReset');if(!reset){reset=document.createElement('button');reset.type='button';reset.id='applicationColumnWidthsReset';reset.textContent='Відновити стандартні ширини';$('#columnsDialog footer').prepend(reset)}reset.onclick=()=>{columns.forEach(base=>{const column=p.columns.find(item=>item.key===base.key);if(column)column.width=base.key==='marketplaceLink'?52:base.width});persistProfileLayout();draw();render()};
  search.oninput=draw;draw();
  box.onchange=e=>{const item=e.target.closest('.column-item');if(!item)return;const c=p.columns.find(x=>x.key===item.dataset.key);if(e.target.matches('.col-visible'))c.visible=e.target.checked;if(e.target.matches('.col-width'))c.width=Math.max(40,Math.min(1200,Math.round(Number(e.target.value)||120)));if(e.target.matches('.col-pin'))c.pin=e.target.value;persistProfileColumns();render()};
  box.onclick=e=>{const b=e.target.closest('.col-up,.col-down'),item=e.target.closest('.column-item');if(!b||!item)return;const ordered=[...p.columns].sort((a,b)=>a.order-b.order),from=ordered.findIndex(x=>x.key===item.dataset.key);move(from,from+(b.classList.contains('col-up')?-1:1))};
  box.ondragstart=e=>{if(search.value.trim()||!e.target.matches('.col-drag'))return e.preventDefault();e.dataTransfer.setData('text/plain',e.target.closest('.column-item').dataset.key)};
  box.ondragover=e=>{if(!search.value.trim())e.preventDefault()};
  box.ondrop=e=>{e.preventDefault();if(search.value.trim())return;const target=e.target.closest('.column-item');if(!target)return;const ordered=[...p.columns].sort((a,b)=>a.order-b.order);move(ordered.findIndex(c=>c.key===e.dataTransfer.getData('text/plain')),ordered.findIndex(c=>c.key===target.dataset.key))};
  $('#columnsDialog').showModal()
}
function cardsDialog(){const p=profile(),box=$('#cardsList');const draw=()=>{const ordered=[...(p.kpis||[]),...kpiDefinitions.map(([key])=>key).filter(key=>!(p.kpis||[]).includes(key))];box.innerHTML=ordered.map((key,index)=>{const label=kpiDefinitions.find(item=>item[0]===key)?.[1]||key,enabled=(p.kpis||[]).includes(key);return`<div class="card-profile-item" data-key="${key}"><label><input type="checkbox" ${enabled?'checked':''}> <span>${label}</span></label><button type="button" class="icon-btn card-up" ${index===0?'disabled':''}>↑</button><button type="button" class="icon-btn card-down" ${index===ordered.length-1?'disabled':''}>↓</button></div>`}).join('')};draw();box.onchange=e=>{const item=e.target.closest('.card-profile-item');if(!item||!e.target.matches('input[type="checkbox"]'))return;const key=item.dataset.key,current=p.kpis||[];p.kpis=e.target.checked?[...current.filter(x=>x!==key),key]:current.filter(x=>x!==key);persistProfileLayout();draw();applyKpiVisibility()};box.onclick=e=>{const button=e.target.closest('.card-up,.card-down'),item=e.target.closest('.card-profile-item');if(!button||!item)return;const all=[...box.querySelectorAll('.card-profile-item')].map(node=>node.dataset.key),from=all.indexOf(item.dataset.key),to=button.classList.contains('card-up')?from-1:from+1;if(to<0||to>=all.length)return;[all[from],all[to]]=[all[to],all[from]];const enabled=new Set(p.kpis||[]);p.kpis=all.filter(key=>enabled.has(key));persistProfileLayout();draw();applyKpiVisibility()};$('#cardsDialog').showModal()}
function openProtocolDialog(){lastProtocolPayload=null;const selectedRows=applicationSelection.entries();$('#checkProtocolNumber').value=selectedRows.find(row=>row.protocolNumber)?.protocolNumber||rows.find(row=>row.protocolNumber)?.protocolNumber||'';$('#checkDateFrom').value=$('#dateFromFilter').value;$('#checkDateTo').value=$('#dateToFilter').value;$('#protocolSummary').className='protocol-summary muted';$('#protocolSummary').textContent=`Буде перевірено поточну відбірку: ${total} заявок.`;$('#protocolIssues').innerHTML='';$('#generateProtocolBtn').disabled=true;$('#protocolDialog').showModal()}
async function checkProtocol(e){e.preventDefault();try{const payload={protocol_number:$('#checkProtocolNumber').value.trim(),date_from:$('#checkDateFrom').value,date_to:$('#checkDateTo').value,filters:currentFilterParams(),submission_ids:selected.size?[...selected]:undefined};const data=await request(`${API}/protocol/readiness`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(payload)});lastProtocolPayload=data.ready?payload:null;const summary=$('#protocolSummary');summary.className=`protocol-summary ${data.ready?'ready':'blocked'}`;summary.textContent=data.ready?`Перевірку пройдено: ${data.total} заявок · Рішення УО «Так» — ${data.admitted} · «Ні» — ${data.rejected}${data.warning_count?` · попереджень ${data.warning_count}`:''}`:`Не готово: ${data.total} заявок · Рішення УО не визначено — ${data.unresolved} · помилок ${data.error_count}`;const issues=data.items.filter(item=>item.errors.length||item.warnings.length);$('#protocolIssues').innerHTML=issues.map(item=>`<div class="protocol-issue"><strong>${esc(item.supplier_name)} · ${esc(item.supplier_code)} · ${esc(item.pretty_id)}</strong>${item.errors.map(error=>`<span>${esc(error)}</span>`).join('')}${item.warnings.map(warning=>`<span class="muted">${esc(warning)}</span>`).join('')}</div>`).join('')||(data.ready?'<p class="muted">Контрольних зауважень немає. Протокол можна формувати.</p>':'<p class="muted">Заявок для протоколу не знайдено.</p>');$('#generateProtocolBtn').disabled=!data.ready}catch(error){lastProtocolPayload=null;$('#generateProtocolBtn').disabled=true;toast(error.message)}}
async function generateProtocol(){if(!lastProtocolPayload)return;const button=$('#generateProtocolBtn'),old=button.textContent;button.disabled=true;button.textContent='Формування…';try{const data=await request(`${API}/protocol/generate`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(lastProtocolPayload)});const link=document.createElement('a');link.href=data.download_url;link.download=data.filename;document.body.appendChild(link);link.click();link.remove();$('#protocolSummary').className='protocol-summary ready';$('#protocolSummary').textContent=`Протокол № ${data.protocol_number} сформовано: ${data.total} заявок · допущено ${data.admitted} · відхилено ${data.rejected}`;toast('Протокол сформовано та завантажено');await loadRows()}catch(error){toast(error.message);button.disabled=false}finally{button.textContent=old}}
let bulkInFlight=false,bulkOperation=null,bulkOperationScope=null;
function openBulk(){
  if(bulkInFlight)return;
  syncApplicationSelection();if(!selected.size||!applicationRowsCurrent()||selectAllResultsPending)return;
  bulkOperation=null;bulkOperationScope=null;$('#bulkSummary').textContent='';$('#bulkResults').textContent='';$('#bulkRetryBtn').hidden=true;$('#bulkRetryBtn').onclick=()=>runBulkOperation(true);
  if(applicationSelection.entries().some(row=>row.historicalReadOnly)){toast('Історичні заявки MedData доступні лише для перегляду та передачі в Chat');return}
  $('#bulkDialog header p').textContent=`Вибрано заявок: ${selected.size}. Позначте лише поля, які потрібно змінити.`;
  const labels={protocolNumber:'Номер протоколу',protocolDate:'Дата протоколу / публікації рішення',protocolOfficer:'УО протоколу',protocolDecision:'Рішення УО',complianceStatus:'Комплаєнс',complianceComments:'Коментарі комплаєнс',managerName:'Прізвище, ім’я, по батькові керівника',protocolRemarks:'Зауваження до протоколу'};
  const control=key=>key==='protocolRemarks'?`<div class="bulk-remarks"><label><input type="radio" name="bulkRemarksMode" value="none" checked> Без зауважень</label><label><input type="radio" name="bulkRemarksMode" value="text"> Однаковий текст</label><textarea data-bulk="${key}" rows="3" hidden></textarea></div>`:key==='protocolOfficer'?`<select data-bulk="${key}"><option value="">Не вибрано</option>${protocolOfficers.map(value=>`<option value="${esc(value)}">${esc(formatOfficerName(value))}</option>`).join('')}</select>`:key==='protocolDecision'?`<select data-bulk="${key}">${protocolDecisions.map(([value,label])=>`<option value="${value}">${label}</option>`).join('')}</select>`:key==='complianceStatus'?`<select data-bulk="${key}">${complianceStatuses.map(([value,label])=>`<option value="${value}">${label}</option>`).join('')}</select>`:`<input data-bulk="${key}">`;
  $('#bulkFields').innerHTML=`<div class="bulk-grid-heading"><span>Застосувати</span><span>Поле</span><span>Значення</span></div>`+Object.keys(labels).map(key=>`<div class="form-field bulk-progressive ${key==='protocolRemarks'?'bulk-remarks-row':''}"><input type="checkbox" data-enable="${key}" aria-label="Застосувати поле «${labels[key]}»"><label>${labels[key]}</label><div class="bulk-control" data-bulk-control="${key}">${control(key)}${['protocolNumber','protocolDate','protocolOfficer'].includes(key)?`<label class="bulk-clear"><input type="checkbox" data-clear="${key}" aria-label="Очистити поле «${labels[key]}»"> Очистити</label>`:''}</div></div>`).join('');
  const syncBulkButton=()=>{$('#applyBulkBtn').disabled=!$$('[data-enable]:checked').length};
  $$('[data-enable]').forEach(item=>{const controlBox=$(`[data-bulk-control="${item.dataset.enable}"]`),setEnabled=()=>{controlBox.querySelectorAll('input,select,textarea').forEach(control=>control.disabled=!item.checked);const clear=controlBox.querySelector('[data-clear]');if(clear)controlBox.querySelector('[data-bulk]').disabled=!item.checked||clear.checked;syncBulkButton()};item.onchange=setEnabled;const clear=controlBox.querySelector('[data-clear]');if(clear)clear.onchange=setEnabled;setEnabled()});
  $$('[name="bulkRemarksMode"]').forEach(item=>item.onchange=()=>{$('[data-bulk="protocolRemarks"]').hidden=item.value!=='text'});
  syncBulkButton();
  $('#bulkDialog').showModal();
}
async function applyBulk(e){
  e.preventDefault();if(bulkInFlight||bulkOperation)return;syncApplicationSelection();if(!selected.size||!applicationRowsCurrent()||selectAllResultsPending)return;if(applicationSelection.entries().some(row=>row.historicalReadOnly)){toast('Масові зміни historical MedData applications заборонені');return}const changes={},cleared=new Set();
  $$('[data-enable]:checked').forEach(x=>{const key=x.dataset.enable;if($(`[data-clear="${key}"]`)?.checked){changes[fieldMap[key]]='';cleared.add(fieldMap[key]);return}changes[fieldMap[key]]=key==='protocolRemarks'&&$('[name="bulkRemarksMode"]:checked').value==='none'?'Без зауважень':$(`[data-bulk="${key}"]`).value.trim()});
  if(!Object.keys(changes).length)return toast('Оберіть поля');
  if(Object.entries(changes).some(([key,value])=>!cleared.has(key)&&!String(value||'').trim()))return toast('Вкажіть значення для кожного вибраного поля');
  if(Object.hasOwn(changes,'protocol_date'))changes.publication_date=changes.protocol_date;
  const chosen=applicationSelection.entries();
  if(chosen.length!==selected.size)return toast('Не підтверджено склад вибірки. Виберіть заявки знову.');
  const effective=(row,key,rowKey)=>Object.hasOwn(changes,key)?changes[key]:row[rowKey];
  const admitWithRemarks=chosen.filter(row=>effective(row,'protocol_decision','protocolDecision')==='admit'&&String(effective(row,'protocol_remarks','protocolRemarks')||'').trim()!=='Без зауважень');
  if(admitWithRemarks.length)return toast(`Рішення УО «Так» неможливе: ${admitWithRemarks.length} заявок мають зауваження до протоколу`);
  const rejectWithoutGrounds=chosen.filter(row=>effective(row,'protocol_decision','protocolDecision')==='reject'&&String(effective(row,'protocol_remarks','protocolRemarks')||'').trim()==='Без зауважень'&&effective(row,'compliance_status','complianceStatus')==='approved');
  if(rejectWithoutGrounds.length)return toast(`Немає підстав для відхилення у ${rejectWithoutGrounds.length} заявках: комплаєнс погоджено та зауважень немає.`);
  if(changes.compliance_status==='approved'){const blocked=chosen.filter(row=>!row.nazkCanApprove);if(blocked.length)return toast(`Комплаєнс не погоджено: спочатку перевірте довідку НАЗК у ${blocked.length} заявках`)}
  const missingCompliance=chosen.some(row=>effective(row,'protocol_decision','protocolDecision')&&!effective(row,'compliance_status','complianceStatus'));if(missingCompliance)return toast('Спочатку визначте рішення комплаєнс');
  const changesLockedCompliance=Object.hasOwn(changes,'compliance_status')&&chosen.some(row=>changes.compliance_status!==row.complianceStatus&&row.protocolDecision);if(changesLockedCompliance)return toast('Щоб змінити комплаєнс, спочатку встановіть Рішення УО «Не визначено»');
  const conflict=chosen.some(row=>effective(row,'protocol_decision','protocolDecision')==='admit'&&effective(row,'compliance_status','complianceStatus')==='rejected');if(conflict)return toast('Рішення УО «Так» неможливе, коли комплаєнс не погоджено');
  const reverse=Object.fromEntries(Object.entries(fieldMap).map(([rowKey,key])=>[key,rowKey]));
  const labels={protocol_number:'Номер протоколу',protocol_date:'Дата протоколу',publication_date:'Дата публікації',protocol_officer:'УО протоколу',protocol_decision:'Рішення УО',protocol_remarks:'Зауваження',compliance_status:'Комплаєнс',compliance_comments:'Коментарі комплаєнс',manager_name:'ПІБ керівника'};
  if(!window.confirm(`Змінити ${chosen.length} заявок у зафіксованій вибірці?\n${Object.entries(changes).map(([key,value])=>`${labels[key]||key}: ${JSON.stringify(value)}`).join('\n')}\nЗаявки поза цією вибіркою не змінюватимуться.`))return;
  bulkOperationScope=PqmApplicationSelection.signature(currentFilterParams());
  bulkOperation=PqmBulkSave.create(chosen.map(row=>{
    const expected=Object.fromEntries(Object.keys(changes).map(key=>[key,String(row.bulkValues?.[key]??row[reverse[key]]??'')]));
    return {id:row.id,expected};
  }),changes);
  await runBulkOperation(false);
}
async function bulkRequest(url,options={}){
  const controller=new AbortController(),timer=setTimeout(()=>controller.abort(),30000);
  try{return await request(url,{...options,cache:'no-store',signal:controller.signal})}finally{clearTimeout(timer)}
}
async function runBulkOperation(retry){
  if(bulkInFlight||!bulkOperation)return;
  if(retry&&bulkOperationScope!==PqmApplicationSelection.signature(currentFilterParams()))return toast('Фільтри змінено: повтор старої вибірки заблоковано. Поверніть початкові фільтри або створіть новий вибір.');
  bulkInFlight=true;
  const dialog=$('#bulkDialog'),controls=[...dialog.querySelectorAll('input,select,textarea,button')].map(control=>[control,control.disabled]);
  controls.forEach(([control])=>control.disabled=true);
  dialog.oncancel=event=>event.preventDefault();
  $('#bulkSummary').textContent='Збереження та звірка… Не закривайте сторінку.';
  try{
    const counts=await PqmBulkSave.run(bulkOperation,{
      read:async(id,fields)=>(await bulkRequest(`${API}/applications/${encodeURIComponent(id)}/bulk-state?fields=${encodeURIComponent(fields.join(','))}`)).values,
      write:(id,desired,expected)=>bulkRequest(`${API}/applications/${encodeURIComponent(id)}`,{method:'PATCH',headers:{'Content-Type':'application/json'},body:JSON.stringify({...desired,_expected_values:expected})})
    },{retry,onProgress:(processed,count)=>{$('#bulkSummary').textContent=`Опрацьовано ${processed} із ${count}. Загальна вибірка: ${bulkOperation.length}.`;}});
    for(const item of bulkOperation)if(item.status==='confirmed')applicationSelection.remove(item.id);
    $('#bulkSummary').textContent=`Опрацьовано ${counts.total} заявок. Збереження підтверджено: ${counts.confirmed}. Не підтверджено: ${counts.unconfirmed}. Конфлікти: ${counts.conflict}. Помилки: ${counts.error}.`;
    $('#bulkResults').innerHTML=bulkOperation.filter(item=>item.status!=='confirmed').map(item=>`<p>${esc(item.id)} — ${esc(item.detail)}${item.attempts>=2?' · Ліміт двох спроб вичерпано':''}</p>`).join('');
    try{await loadRows()}catch(error){toast('Підсумок збережено на екрані; не вдалося оновити таблицю')}
  }catch(error){
    $('#bulkSummary').textContent='Операцію перервано. Не вважайте непідтверджені записи незбереженими. Потрібна звірка.';
    for(const item of bulkOperation)if(item.status==='pending')item.status='unconfirmed';
  }finally{
    controls.forEach(([control,disabled])=>control.disabled=disabled);
    $('#applyBulkBtn').disabled=true;
    $('#bulkRetryBtn').hidden=!bulkOperation.some(item=>item.status==='unconfirmed'&&item.attempts<2);
    $('#bulkRetryBtn').disabled=false;
    dialog.oncancel=null;bulkInFlight=false;
  }
}
let auditPage=1,auditPages=1;
let auditRows=[],auditSearchController;
function auditFilterParams(){const q=new URLSearchParams({page:String(auditPage),size:'100'});$$('#auditDialog [data-audit-filter]').forEach(input=>q.set(input.dataset.auditFilter,input.value.trim()));return q}
function auditValueCell(value,index){const text=String(value||'');return text.length>160||text.split('\n').length>3?`<button type="button" class="audit-long-value" data-audit-row="${index}" title="Переглянути повний текст">${esc(text)}</button>`:esc(text)||'—'}
function renderAudit(data){auditPages=Math.max(1,Number(data.pages||1));if(auditPage>auditPages){auditPage=auditPages;loadAudit();return}auditRows=data.items;$('#auditBody').innerHTML=data.items.length?data.items.map((a,index)=>`<tr><td>${esc(displayDate(a.changed_at))}</td><td>${esc(a.changed_by)}</td><td>${esc(a.submission_id)}</td><td>${esc(a.field_name)}</td><td>${auditValueCell(a.old_value,index)}</td><td>${auditValueCell(a.new_value,index)}</td></tr>`).join(''):'<tr><td colspan="6">Змін за цими фільтрами немає</td></tr>';const total=Number(data.total||0),from=total?(auditPage-1)*100+1:0,to=Math.min(auditPage*100,total);$('#auditPageInfo').textContent=`${from}–${to} із ${total.toLocaleString('uk-UA')} · сторінка ${auditPage} із ${auditPages}`;$('#auditPrev').disabled=auditPage<=1;$('#auditNext').disabled=auditPage>=auditPages}
function auditController(){return auditSearchController||(auditSearchController=PqmAuditSearch.create({clientId:crypto.randomUUID(),request:q=>request(`${API}/audit?${q}`),params:auditFilterParams,render:renderAudit,clear:()=>{auditRows=[];$('#auditBody').replaceChildren();$('#auditPageInfo').textContent='Пошук…';$('#auditPrev').disabled=true;$('#auditNext').disabled=true},error:error=>{$('#auditPageInfo').textContent=error.message;$('#auditBody').innerHTML='<tr><td colspan="6">Результат не отримано. Уточніть умови пошуку або повторіть спробу.</td></tr>'}}))}
function loadAudit(){return auditController().load()}
async function openAudit(){auditPage=1;$('#auditDialog').show();await loadAudit()}
function renderProfileFallback(){
  if(!profiles.length)profiles=[{id:'local-default',name:'Основний реєстр',columns:structuredClone(columns),kpis:defaultKpis('Основний реєстр'),is_system:true}];
  if(profilesMetadataReady&&!profiles.some(item=>item.id===activeProfileId))activeProfileId=profiles[0].id;
  renderProfiles();
}
async function reloadApplicationsRegistry({reloadMetadata=true}={}){
  if(registryReloadPromise)return registryReloadPromise;
  registryReloadPromise=reloadApplicationsRegistryData({reloadMetadata}).finally(()=>{registryReloadPromise=null});
  return registryReloadPromise;
}
async function reloadApplicationsRegistryData({reloadMetadata=true}={}){
  const failures=[];
  if(reloadMetadata){
    const primary=await Promise.allSettled([loadProfiles(),loadAuthorizedOfficers(),loadSearchFields()]);
    primary.forEach((result,index)=>{if(result.status==='rejected')failures.push(['profiles','officers','search fields'][index])});
    if(primary[0].status==='fulfilled'&&primary[0].value===false)failures.push('profiles stale');
    if(primary[0].status==='rejected')renderProfileFallback();
    const secondary=await Promise.allSettled([loadPrimaryFilterOptions(),loadFrameworks(),loadSupplierOptions()]);
    secondary.forEach((result,index)=>{if(result.status==='rejected')failures.push(['filter options','frameworks','supplier options'][index])});
  }
  invalidateRegistryStats();
  const [rowsOk,statsOk]=await Promise.all([loadRows(),loadStats()]);
  if(!rowsOk)failures.push('applications');
  if(!statsOk)failures.push('stats');
  return {ok:!failures.length,failures};
}
function setProzorroSyncButtonIdle(){
  const button=$('#resetBtn');
  button.textContent='Оновити з Prozorro';
  button.disabled=currentMe?currentMe.role!=='admin':role()!=='admin';
}
const waitFor=milliseconds=>new Promise(resolve=>setTimeout(resolve,milliseconds));
async function restoreRegistryAfterSync(message,type='info'){
  setProzorroSyncButtonIdle();
  const result=await reloadApplicationsRegistry({reloadMetadata:true});
  if(!result.ok)toast(`Реєстр відновлено частково. Недоступно: ${result.failures.join(', ')}`,'warning');
  toast(message,type);
}
async function pollProzorroSync(){
  let consecutiveErrors=0;
  while(true){
    await waitFor(2000);
    try{
      const health=await request(`${API}/health?t=${Date.now()}`),state=health.sync||{};
      consecutiveErrors=0;
      $('#resetBtn').textContent=state.message||'Синхронізація триває…';
      if(!state.running){
        const failed=/помил|failed/i.test(String(state.message||''));
        await restoreRegistryAfterSync(state.message||'Оновлення завершено',failed?'error':'success');
        return;
      }
    }catch(error){
      consecutiveErrors+=1;
      if(consecutiveErrors>=3){await restoreRegistryAfterSync(`Не вдалося отримати стан синхронізації: ${error.message}`,'error');return}
    }
  }
}
async function sync(){
  const button=$('#resetBtn');button.disabled=true;button.textContent='Запуск синхронізації…';
  try{
    await request(`${API}/sync`,{method:'POST',headers:{'Content-Type':'application/json'},body:'{}'});
    toast('Синхронізацію розпочато');
    await pollProzorroSync();
  }catch(error){
    await restoreRegistryAfterSync(error.message,'error');
  }
}
function syncStatusPresentation(state){
  const unavailable=state.scheduler_enabled===false,stopped=state.scheduler_enabled===true&&state.scheduler_running===false;
  const schedule=unavailable?'Автооновлення вимкнено':stopped?'Планувальник не працює':state.scheduler_running&&state.next_run_at?`Наступне автооновлення: ${displayDate(state.next_run_at)}`:'Стан автооновлення невідомий';
  const last=state.updated_at?`Остання спроба: ${displayDate(state.updated_at)}`:state.last_data_sync_at?`Дані синхронізовано: ${displayDate(state.last_data_sync_at)}`:'Немає даних про попереднє оновлення';
  return {text:state.running?`${state.message||'Синхронізація триває…'} · ${schedule}`:`${last} · ${schedule}`,
    running:!!state.running,error:stopped||String(state.message||'').startsWith('Помилка'),title:state.message||''};
}
async function refreshSyncStatus(){try{const h=await request(`${API}/health?t=${Date.now()}`),view=syncStatusPresentation(h.sync||{}),el=$('#syncStatus');el.className=`sync-status${view.running?' running':view.error?' error':''}`;el.textContent=view.text;el.title=view.title}catch{const el=$('#syncStatus');el.className='sync-status error';el.textContent='Не вдалося перевірити стан автооновлення'}}
const moduleNames=['workQueue','operationalTasks','applications','suppliers','edrMonitoring','history','frameworks','procurements','references','requests','messages','administration'];
function storedModule(){const query=new URLSearchParams(location.search).get('view');if(moduleNames.includes(query))return query;try{const value=localStorage.getItem('pqm.activeModule');return moduleNames.includes(value)?value:'applications'}catch{return 'applications'}}
let activeModule=storedModule(),supplierRegistryTimer,supplierRegistryPage=1,supplierRegistryPages=1,supplierRegistryItems=[],supplierRegistryRisk='',supplierRegistryLoading=false,supplierRiskCountsLoading=false,supplierRegistrySelectedCodes=new Set(),frameworkRequestSequence=0;
let edrMonitoringPage=1,edrMonitoringPages=1,edrMonitoringItems=[],edrMonitoringTotal=0,edrMonitoringTimer,edrMonitoringSelected=new Set(),edrMonitoringSort='freshness',edrMonitoringDirection='asc';
let edrMonitoringLoadSequence=0;
const edrMonitoringStatusSelections={prozorro_status:new Set(),edr_status:new Set()};
const edrMonitoringTable=document.querySelector('.edr-monitoring-table');
if(edrMonitoringTable){edrMonitoringTable.dataset.systemTable='edr-monitoring';edrMonitoringTable.dataset.visibilityControl='1';edrMonitoringTable.tHead.rows[0].cells[0].dataset.columnFixed='1'}
if($('#edrMonitoringColumns'))$('#edrMonitoringColumns').hidden=true;
function showModule(name){if(!moduleNames.includes(name)||(name==='administration'&&currentMe&&currentMe.role!=='admin'))name='applications';activeModule=name;try{localStorage.setItem('pqm.activeModule',name)}catch{}const url=new URL(location.href);url.searchParams.set('view',name);history.replaceState(null,'',url);window.scrollTo(0,0);moduleNames.forEach(module=>{const view=$(module==='frameworks'?'#frameworkAnalyticsView':`#${module}View`),nav=$(`#${module}Nav`);if(view)view.hidden=module!==name;if(nav)nav.classList.toggle('nav-active',module===name)});const titles={history:'Історія заявок',workQueue:'Робота УО',operationalTasks:'Операційні задачі',applications:'Реєстр заявок',suppliers:'База постачальників',edrMonitoring:'Перевірка ЄДР',frameworks:'Відбори',procurements:'Закупівлі за відборами',references:'Довідники',requests:'Звернення замовників',messages:'Повідомлення',administration:'Адміністрування'};document.title=`PQM — ${titles[name]||'Реєстр заявок'}`;if(name==='references')loadReferencesView();if(name==='operationalTasks')loadOperationalTasks();if(name==='messages'&&window.loadChats)window.loadChats()}
async function loadQualifiedSuppliers(){const body=$('#supplierRegistryBody');body.innerHTML='<tr><td colspan="7">Завантаження…</td></tr>';try{const q=new URLSearchParams({search:$('#supplierRegistrySearch').value.trim(),status:$('#supplierRegistryStatus').value,page:'1',size:'100'}),data=await request(`${API}/suppliers-registry?${q}`);$('#supplierRegistryTotal').textContent=Number(data.total||0).toLocaleString('uk-UA');$('#supplierRegistryActive').textContent=Number(data.active||0).toLocaleString('uk-UA');body.innerHTML=data.items.length?data.items.map(item=>`<tr data-supplier-code="${esc(item.code)}"><td><strong>${esc(item.name||'Назву не отримано')}</strong><small>Картка: кваліфікації · Bids (буде додано)</small></td><td>${esc(item.code)}</td><td>${Number(item.qualifications_count||0).toLocaleString('uk-UA')}</td><td><span class="supplier-status-count">${Number(item.active_count||0).toLocaleString('uk-UA')}</span></td><td><span class="supplier-status-count inactive">${Number(item.inactive_count||0).toLocaleString('uk-UA')}</span>${item.suspended_count?` <small>Призупинено: ${Number(item.suspended_count).toLocaleString('uk-UA')}</small>`:''}</td><td>${esc((item.dk_codes||'').split(',').filter(Boolean).sort().join(', '))||'—'}</td><td>${esc(displayDate(item.last_qualification))||'—'}</td></tr>`).join(''):'<tr><td colspan="7">У синхронізованих реєстрах постачальників записів не знайдено</td></tr>';$('#supplierRegistryFooter').textContent=`Показано ${data.items.length} із ${Number(data.total||0).toLocaleString('uk-UA')} постачальників`}catch(error){body.innerHTML=`<tr><td colspan="7">${esc(error.message)}</td></tr>`}}
async function refreshSupplierRegistry(){try{$('#supplierRegistryRefresh').disabled=true;await request(`${API}/sync`,{method:'POST',headers:{'Content-Type':'application/json'},body:'{}'});toast('Синхронізацію реєстрів розпочато');const timer=setInterval(async()=>{const health=await request(`${API}/health?t=${Date.now()}`);if(!health.sync.running){clearInterval(timer);$('#supplierRegistryRefresh').disabled=false;await loadQualifiedSuppliers();toast(health.sync.message)}},2000)}catch(error){$('#supplierRegistryRefresh').disabled=false;toast(error.message)}}
let supplierRegistryReloadPending=false;
function supplierRegistryFilterParams(){
  const params=new URLSearchParams({search:$('#supplierRegistrySearch').value.trim(),entity_type:$('#supplierRegistryType').value,status:$('#supplierRegistryStatus').value,edr_status:$('#supplierRegistryEdrStatus').value,freshness:$('#supplierRegistryFreshness').value,verification_from:$('#supplierRegistryVerifiedFrom').value,verification_to:$('#supplierRegistryVerifiedTo').value,admission_from:$('#supplierRegistryAdmittedFrom').value,admission_to:$('#supplierRegistryAdmittedTo').value,dk_code:$('#supplierRegistryDk').value.trim(),risk:supplierRegistryRisk});
  for(const option of $('#supplierRegistryFramework').selectedOptions)if(option.value)params.append('framework_id',option.value);
  return params;
}
function renderSupplierScopeFilters(){
  const dkControl=$('#supplierRegistryDk'),frameworkControl=$('#supplierRegistryFramework');
  const dkSelection=new Set(dkControl.value.split(',').filter(Boolean)),frameworkSelection=new Set([...frameworkControl.selectedOptions].map(option=>option.value).filter(Boolean));
  const scopes=[
    {id:'supplierRegistryDkFilter',items:[...new Set(frameworkOptions.map(item=>item.dk_code).filter(Boolean))].sort(),selection:dkSelection,value:item=>item,label:item=>item,placeholder:'Усі коди ДК',save:()=>{dkControl.value=[...dkSelection].sort().join(',')}},
    {id:'supplierRegistryFrameworkFilter',items:frameworkOptions,selection:frameworkSelection,value:item=>item.id,label:item=>`${item.pretty_id||item.id} · ${item.title||''} · ${item.dk_code||''}`,placeholder:'Усі відбори',save:()=>{for(const option of frameworkControl.options)option.selected=frameworkSelection.has(option.value)}}
  ];
  for(const scope of scopes){
    const details=$('#'+scope.id);if(!details)continue;
    const changed=()=>{scope.save();supplierRegistryPage=1;loadQualifiedSuppliersFiltered()};
    const draw=()=>{renderDynamicFilter(scope.id,scope.items,scope.selection,scope.value,scope.label,scope.placeholder,changed);if(scope.id==='supplierRegistryFrameworkFilter'&&scope.selection.size){const summary=details.querySelector('summary');summary.textContent=`Відбори · ${scope.selection.size}`;summary.title=scope.items.filter(item=>scope.selection.has(scope.value(item))).map(scope.label).join('\n')}};
    details.querySelector('.multi-search').oninput=draw;
    details.querySelector('[data-clear-scope]').onclick=()=>{scope.selection.clear();changed();draw()};
    draw();
  }
}
$('#supplierRegistryFramework').onchange=()=>{renderSupplierScopeFilters();supplierRegistryPage=1;loadQualifiedSuppliersFiltered()};
function updateSupplierEdrExportLinks(){
  {
    const params=new URLSearchParams({type:'ALL',mode:'filtered'});
    if($('#supplierRegistrySearch').value.trim())params.set('search',$('#supplierRegistrySearch').value.trim());
    if($('#supplierRegistryStatus').value)params.set('status',$('#supplierRegistryStatus').value);
    if($('#supplierRegistryEdrStatus').value)params.set('edr_status',$('#supplierRegistryEdrStatus').value);
    if($('#supplierRegistryFreshness').value)params.set('freshness',$('#supplierRegistryFreshness').value);
    if($('#supplierRegistryVerifiedFrom').value)params.set('verification_from',$('#supplierRegistryVerifiedFrom').value);
    if($('#supplierRegistryVerifiedTo').value)params.set('verification_to',$('#supplierRegistryVerifiedTo').value);
    if($('#supplierRegistryAdmittedFrom').value)params.set('admission_from',$('#supplierRegistryAdmittedFrom').value);
    if($('#supplierRegistryAdmittedTo').value)params.set('admission_to',$('#supplierRegistryAdmittedTo').value);
    if($('#supplierRegistryDk').value.trim())params.set('dk_code',$('#supplierRegistryDk').value.trim());
    if(supplierRegistryRisk)params.set('risk',supplierRegistryRisk);
    $('#supplierEdrExportFiltered').href=`${API}/supplier-edr-export?${params}`;
  }
  $('#supplierEdrExportSelected').disabled=!supplierRegistrySelectedCodes.size;
}
function updateSupplierRegistrySelection(total){
  $('#supplierRegistrySelectionInfo').textContent=`Знайдено: ${Number(total||0).toLocaleString('uk-UA')} · Вибрано: ${supplierRegistrySelectedCodes.size.toLocaleString('uk-UA')}`;
  const pageCodes=supplierRegistryItems.map(item=>String(item.code));
  const selector=$('#supplierRegistrySelectPage'),selectedOnPage=pageCodes.filter(code=>supplierRegistrySelectedCodes.has(code)).length;
  selector.checked=Boolean(pageCodes.length)&&selectedOnPage===pageCodes.length;
  selector.indeterminate=selectedOnPage>0&&selectedOnPage<pageCodes.length;
  updateSupplierEdrExportLinks();
}
function updateSupplierFilterAppearance(){
  let active=false;
  document.querySelectorAll('#suppliersView .supplier-filter-field').forEach(field=>{
    const control=field.querySelector('input,select');
    const selected=control.multiple?[...control.selectedOptions].some(option=>option.value):Boolean(control.value.trim());active=active||selected;
    control.classList.toggle('filter-active',selected);
    field.querySelector('details')?.classList.toggle('filter-active',selected);
  });
  $('#supplierRegistryReset').disabled=!active&&!supplierRegistryRisk;
  updateSupplierEdrExportLinks();
  syncSharedFilterPresentation($('#suppliersView'));
}
async function loadSupplierRiskCounts(){
  if(supplierRiskCountsLoading)return;
  supplierRiskCountsLoading=true;
  try{
    const data=await request(`${API}/suppliers-registry-risk-counts`);
    $('#supplierRegistryAmcu').textContent=Number(data.amcu_total||0).toLocaleString('uk-UA');
    $('#supplierRegistryNazk').textContent=Number(data.nazk_total||0).toLocaleString('uk-UA');
  }catch{}finally{supplierRiskCountsLoading=false}
}
$('#supplierRegistryReset').onclick=()=>{
  clearTimeout(supplierRegistryTimer);
  document.querySelectorAll('#suppliersView .supplier-filter-field input,#suppliersView .supplier-filter-field select').forEach(control=>{control.value='';if(control.multiple)for(const option of control.options)option.selected=false});
  renderSupplierScopeFilters();
  supplierRegistryRisk='';supplierRegistryPage=1;supplierRegistrySelectedCodes.clear();
  updateSupplierFilterAppearance();loadQualifiedSuppliersFiltered();
};
async function loadQualifiedSuppliersFiltered(){
  renderSupplierScopeFilters();
  updateSupplierFilterAppearance();
  if(supplierRegistryLoading){supplierRegistryReloadPending=true;return}
  supplierRegistryLoading=true;
  const body=$('#supplierRegistryBody');
  body.innerHTML='<tr><td colspan="9">Завантаження…</td></tr>';
  try {
    const q=supplierRegistryFilterParams();q.set('page',String(supplierRegistryPage));q.set('size','100');
    const data=await request(`${API}/suppliers-registry?${q}`);
    const edrSelect=$('#supplierRegistryEdrStatus'),selectedEdr=edrSelect.value;
    const edrOptions=[...new Set([...(data.edr_statuses||[]),...(selectedEdr?[selectedEdr]:[])])];
    edrSelect.innerHTML='<option value="">Усі статуси ЄДР</option>'+edrOptions.map(value=>`<option value="${esc(value)}">${esc(value)}</option>`).join('');
    edrSelect.value=selectedEdr;
    supplierRegistryPages=Math.max(1,Number(data.pages||1));
    if(supplierRegistryPage>supplierRegistryPages){supplierRegistryPage=supplierRegistryPages;supplierRegistryLoading=false;return loadQualifiedSuppliersFiltered()}
    $('#supplierRegistryTotal').textContent=Number(data.registered_total||0).toLocaleString('uk-UA');
    $('#supplierRegistryActive').textContent=Number(data.active||0).toLocaleString('uk-UA');
    $('#supplierRegistryCandidates').textContent=Number(data.not_registered||0).toLocaleString('uk-UA');
    $$('.supplier-filter-kpi').forEach(card=>card.classList.toggle('active',card.dataset.risk===supplierRegistryRisk));
    supplierRegistryItems=data.items||[];
    body.innerHTML=data.items.length?data.items.map(item=>{
      const candidate=item.registry_state==='not_registered',event=item.last_registry_event||{},last=event.date||item.last_qualification||item.last_application,amcu=Boolean(item.amcu_match),edr=item.edr_profile||{},applicationNazk=item.nazk_application_state||{},completedApplicationNazk=['refuted','confirmed'].includes(applicationNazk.state)?applicationNazk.state:'',nazkState=completedApplicationNazk||item.nazk_presentation_state||(applicationNazk.state!=='not_required'?applicationNazk.state:Boolean(item.nazk_match)?'inactive':'not_required'),nazk=nazkState!=='not_required',nazkLabel={waiting_response:'очікується відповідь',on_request:'на запит',needs_check:'перевірити',needs_supplier_review:'потребує перевірки',refuted:'Спростовано',confirmed:'підтверджено',inactive:'неактуально'}[nazkState]||'неактуально';
      const eventLabel=event.status==='terminated'?'Виключення':event.status==='suspended'?'Призупинення':event.status==='active'?'Включення до реєстру':'';
      const amcuClass=amcu?(Number(item.active_count||0)>0?'supplier-amcu-active':'supplier-amcu-inactive'):'';
      const nazkTitle={waiting_response:'Незавершена НАЗК-робота: очікується відповідь',on_request:'Є чинний supplier-level запит',confirmed:'Наявність у НАЗК підтверджено',refuted:'Наявність у НАЗК спростовано для останньої релевантної заявки',inactive:'Збіг у реєстрі НАЗК є, але актуальної дії для УО немає',needs_check:'Потрібна ручна перевірка нової заявки',needs_supplier_review:'Поточний керівник має збіг із НАЗК — потрібно визначити подальшу дію'}[nazkState]||'Стан НАЗК';
      return `<tr data-supplier-code="${esc(item.code)}" class="${candidate?'supplier-candidate':''} ${amcuClass||nazk?'supplier-nazk':''} ${nazkState==='confirmed'?'supplier-amcu-active':''}"><td><strong>${esc(supplierDisplayName(edr,item.name))}</strong>${amcu?`<span class="registry-flag amcu" title="АМКУ · ${Number(item.active_count||0)>0?'є активні кваліфікації':'лише неактивні кваліфікації'}">АМКУ</span>`:''}${nazk?`<span class="registry-flag nazk ${esc(nazkState)}" title="${nazkTitle}">НАЗК · ${nazkLabel}</span>`:''}</td><td>${esc(item.code)}</td><td><span class="supplier-registry-state ${esc(item.prozorro_status==='Ще не в реєстрі'?'candidate':'registered')}">${esc(item.prozorro_status||'Ще не в реєстрі')}</span></td><td>${Number(item.applications_count||0).toLocaleString('uk-UA')}</td><td>${Number(item.qualifications_count||0).toLocaleString('uk-UA')}</td><td><span class="supplier-status-count">${Number(item.active_count||0).toLocaleString('uk-UA')}</span></td><td><span class="supplier-status-count inactive">${Number(item.inactive_count||0).toLocaleString('uk-UA')}</span></td><td>${esc((item.dk_codes||'').split(',').filter(Boolean).sort().join(', '))||'—'}</td><td>${esc(displayDate(last))||'—'}${eventLabel?`<small>${esc(eventLabel)}</small>`:''}</td></tr>`
    }).join(''):'<tr><td colspan="9">За вибраними умовами записів не знайдено</td></tr>';
    body.querySelectorAll('tr[data-supplier-code]').forEach(row=>{const item=supplierRegistryItems.find(x=>String(x.code)===row.dataset.supplierCode);if(!item)return;row.classList.remove('supplier-amcu','supplier-amcu-active','supplier-amcu-inactive','supplier-nazk');const state=item.nazk_application_state?.state||'not_required';if(item.amcu_match)row.classList.add(Number(item.active_count||0)>0?'supplier-amcu-active':'supplier-amcu-inactive');else if(state==='confirmed')row.classList.add('supplier-amcu-active');else if(state!=='not_required'||item.nazk_match)row.classList.add('supplier-nazk')});
    body.querySelectorAll('.supplier-registry-check').forEach(input=>input.onchange=event=>{
      const code=event.target.closest('tr').dataset.supplierCode;
      event.target.checked?supplierRegistrySelectedCodes.add(code):supplierRegistrySelectedCodes.delete(code);
      updateSupplierRegistrySelection(Number(data.total||0));
    });
    const total=Number(data.total||0),from=total?(supplierRegistryPage-1)*100+1:0,to=Math.min(supplierRegistryPage*100,total);
    $('#supplierRegistryPageInfo').textContent=`Показано ${from}–${to} із ${total.toLocaleString('uk-UA')} записів · сторінка ${supplierRegistryPage} із ${supplierRegistryPages}`;
    $('#supplierRegistryPrev').disabled=supplierRegistryPage<=1;
    $('#supplierRegistryNext').disabled=supplierRegistryPage>=supplierRegistryPages;
    updateSupplierRegistrySelection(total);
  } catch(error) {
    body.innerHTML='<tr><td colspan="9"><span class="controlled-load-error">Не вдалося завантажити базу постачальників. Перевірте стан сервера та повторіть спробу.</span></td></tr>';
  } finally {
    supplierRegistryLoading=false;
    if(supplierRegistryReloadPending){supplierRegistryReloadPending=false;loadQualifiedSuppliersFiltered()}
  }
}
function openSupplierProfile(code){const item=supplierRegistryItems.find(row=>String(row.code)===String(code));if(!item)return;const edr=item.edr_profile||{};$('#supplierProfileTitle').textContent=edr.short_name||item.name||'Картка постачальника';$('#supplierProfileSubtitle').textContent=`ЄДРПОУ / РНОКПП: ${item.code}`;$('#supplierProfileBody').innerHTML=`<dl class="supplier-profile-grid"><div><dt>Повна назва з ЄДР</dt><dd>${esc(edr.full_name)||'—'}</dd></div><div><dt>Скорочена назва з ЄДР</dt><dd>${esc(edr.short_name)||'—'}</dd></div><div><dt>ПІБ керівника</dt><dd>${esc(item.current_manager)||'—'}${item.current_manager_source?`<small>${esc({supplier_managers:'Історія керівників',edr_profile:'Підтверджено ЄДР',application:'Остання заявка'}[item.current_manager_source]||item.current_manager_source)}</small>`:''}</dd></div><div><dt>Статус у реєстрі (ЄДР)</dt><dd>${esc(displayEdrStatus(edr.edr_status))}</dd></div><div><dt>Дата перевірки ЄДР</dt><dd>${esc(displayDateOnly(item.edr_verification_date))||'—'}${item.edr_verification_officer?`<small>${esc(item.edr_verification_officer)}</small>`:''}</dd></div><div><dt>Джерело</dt><dd>${edr.source_sheet?`Google-таблиця · вкладка ${esc(edr.source_sheet)}`:'Ще не синхронізовано'}</dd></div></dl>`;$('#supplierProfileDialog').showModal()}
const loadSupplierRegistryBeforeCardActions=loadQualifiedSuppliersFiltered;
loadQualifiedSuppliersFiltered=async function(){
  await loadSupplierRegistryBeforeCardActions();
  $$('#supplierRegistryBody tr[data-supplier-code]').forEach(row=>{
    const code=row.dataset.supplierCode,item=supplierRegistryItems.find(value=>String(value.code)===code);
    if(!/^[0-9]+$/.test(code)||!item)return;
    const cell=row.children[1];if(!cell||cell.querySelector('.supplier-card-action'))return;
    installSupplierCodeAction(cell,()=>openSupplierProfile(row.dataset.supplierCode));
  });
};
function installSupplierCodeAction(cell,open){
  const line=document.createElement('span');line.className='supplier-code-line';
  const code=document.createElement('span');code.className='supplier-code-value';code.textContent=cell.textContent.trim();
  const action=document.createElement('button');action.type='button';action.className='supplier-card-action';
  action.textContent='↗';action.title='Відкрити картку постачальника';action.setAttribute('aria-label',action.title);
  action.onclick=event=>{event.stopPropagation();open()};
  line.append(code,action);cell.classList.add('supplier-code-action-cell');cell.replaceChildren(line);
}
function supplierEdrDatesHtml(edr){
  return `<div><dt title="Дата перевірки ЄДР із джерела Google Sheets">Дата перевірки</dt><dd>${esc(displayDateOnly(edr.edr_checked_at))||'—'}</dd></div><div><dt>Синхронізовано з Google Sheets</dt><dd>${esc(displayDate(edr.synced_at))||'—'}</dd></div>`;
}
function nazkRegistrySourceNotice(record){
  if(record.current_registry_present!==false)return '';
  const provenance=record.registry_source==='missing_evidence'
    ?'Історичний доказ потребує перевірки.'
    :`Історичний WEB-знімок від ${esc(displayDateOnly(record.evidence_observed_at))||'—'}.`;
  return `<small class="nazk-registry-source-notice">Відсутній у поточному реєстрі НАЗК. ${provenance} Це не результат перевірки особи.</small>`;
}
function supplierNazkEvidenceHtml(check){
  const set=check.nazk_evidence||check.evidence_set||{},records=set.registry_facts||set.registry_records||[],evidence=set.responses_info||set.evidence||[],documents=set.documents||[];
  const facts=records.map(x=>`<li><strong>${esc(x.source_id||'—')}</strong> · ${esc(x.full_name||'—')}${x.court_case_number?` · справа ${esc(x.court_case_number)}`:''}${nazkRegistrySourceNotice(x)}${x.decision_url?` · <a href="${esc(x.decision_url)}" target="_blank" rel="noopener">джерело</a>`:''}</li>`).join('');
  const items=evidence.map(x=>`<li>${x.uploaded_document_name?`<strong>${esc(x.uploaded_document_name)}</strong> · `:''}${esc(displayDateOnly(x.evidence_date))||'дата не зазначена'}${x.document_number?` · № ${esc(x.document_number)}`:''}${x.short_summary?` · ${esc(x.short_summary)}`:''}${x.evidence_url?` · <a href="${esc(x.evidence_url)}" target="_blank" rel="noopener">Посилання</a>`:''}${x.comment?`<small>${esc(x.comment)}</small>`:''}${x.source_response_id?`<small>Provenance: response #${esc(x.source_response_id)}</small>`:''}</li>`).join('');
  const docs=documents.map(x=>`<li>${esc(displayDateOnly(x.document_date))||'—'}${x.document_number?` · № ${esc(x.document_number)}`:''} · ${esc(x.title||'Документ')}${x.url?` · <a href="${esc(x.url)}" target="_blank" rel="noopener">відкрити</a>`:''}</li>`).join('');
  return `<details class="supplier-nazk-evidence"><summary>Підстава / документ · ${frameworkNumber(evidence.length+documents.length)}</summary><small>НАЗК-перевірка #${esc(set.nazk_check_id||check.id||'—')}</small>${facts?`<strong>Запис Реєстру НАЗК</strong><ul>${facts}</ul>`:''}${items?`<strong>Отримані відповіді / інформація</strong><ul>${items}</ul>`:''}${docs?`<strong>Документи</strong><ul>${docs}</ul>`:''}</details>`;
}
function supplierProfileOverviewHtml(cardSupplierName,code,contact,contacts,supplierNote,viewer){
  return `<section class="supplier-profile-overview">
    <section class="supplier-profile-section supplier-profile-contacts"><h3>Контакти з останньої заявки</h3>${contact.email||contact.telephone||contact.name?`<div class="supplier-contact-card"><strong>${esc(contact.name)||'Контактна особа не зазначена'}</strong><p>${contact.email?`<a href="mailto:${esc(contact.email)}">${esc(contact.email)}</a>`:'—'}${contact.telephone?` · <a href="tel:${esc(contact.telephone)}">${esc(contact.telephone)}</a>`:''}${contact.fax?` · факс ${esc(contact.fax)}`:''}</p>${contact.url?`<p><a href="${esc(contact.url)}" target="_blank" rel="noopener">Вебсайт</a></p>`:''}<small>${esc(displayDate(contact.submission_date))||'—'} · ${esc(contact.framework_id||'—')} · заявка ${esc(contact.submission_id||'—')}</small></div>`:'<p>Контактів у заявках не знайдено</p>'}${contacts.history?.length?`<details class="supplier-contact-history"><summary>Попередні контакти · ${contacts.history.length}</summary>${contacts.history.map(x=>`<div class="supplier-contact-card"><strong>${esc(x.name)||'—'}</strong><p>${x.email?`<a href="mailto:${esc(x.email)}">${esc(x.email)}</a>`:'—'}${x.telephone?` · <a href="tel:${esc(x.telephone)}">${esc(x.telephone)}</a>`:''}</p><small>${esc(displayDate(x.submission_date))||'—'} · ${esc(x.framework_id||'—')}</small></div>`).join('')}</details>`:''}</section>
    <section class="supplier-profile-section supplier-shared-note"><h3>Спільна примітка постачальника</h3><textarea id="supplierProfileNote" rows="3" ${viewer?'readonly':''}>${esc(supplierNote.note||'')}</textarea><small>${supplierNote.updated_at?`Оновлено ${esc(displayDate(supplierNote.updated_at))} · ${esc(supplierNote.updated_by||'—')}`:'Примітку ще не додано'}</small>${viewer?'':'<button type="button" class="ghost" id="supplierProfileNoteSave">Зберегти примітку</button>'}</section></section>`;
}
function compactSupplierNote(section,note,viewer){
  const editor=section.querySelector('#supplierProfileNote'),save=section.querySelector('#supplierProfileNoteSave');
  if(!editor)return;
  const text=String(note||'').trim(),action=document.createElement('button'),preview=document.createElement('p'),cancel=document.createElement('button');
  action.type=cancel.type='button';action.className='ghost supplier-note-toggle';cancel.className='ghost supplier-note-cancel';
  action.textContent=text?'Редагувати':'+ Додати примітку';cancel.textContent='Скасувати';
  preview.className='supplier-note-preview';preview.textContent=text;preview.title=text;
  const meta=section.querySelector('small');
  editor.hidden=true;if(save)save.hidden=true;cancel.hidden=true;
  if(!text)preview.hidden=true;
  if(viewer)action.hidden=true;
  section.querySelector('h3').after(preview,action);
  editor.after(cancel);
  action.onclick=()=>{preview.hidden=true;action.hidden=true;editor.hidden=false;if(save)save.hidden=false;cancel.hidden=false;if(meta)meta.hidden=false;editor.focus()};
  cancel.onclick=()=>{editor.value=note||'';editor.hidden=true;if(save)save.hidden=true;cancel.hidden=true;preview.hidden=!text;action.hidden=viewer;if(meta)meta.hidden=!text};
  if(meta)meta.hidden=!text;
}
function decorateSupplierEdrCard(body,code,edr,supplierNote){
  const sharedNote=body.querySelector('.supplier-profile-overview > .supplier-shared-note');
  compactSupplierNote(sharedNote,supplierNote.note,role()==='viewer');
  const section=body.querySelector('.supplier-profile-edr');
  const fields=[...section.querySelectorAll('.supplier-profile-grid>div')];
  const field=label=>fields.find(row=>row.querySelector('dt')?.textContent===label)?.querySelector('dd');
  const status=field('Статус у реєстрі (ЄДР)');if(status)status.textContent=displayEdrStatus(edr.edr_status);
  const actions=document.createElement('div');actions.className='supplier-edr-actions';
  const clarity=document.createElement('a');clarity.href=`https://clarity-project.info/edr/${encodeURIComponent(code)}`;clarity.target='_blank';clarity.rel='noopener';clarity.textContent='↗ Clarity Project';actions.append(clarity);
  section.querySelector('h3').after(actions);
  const metadata=document.createElement('dl');metadata.className='supplier-edr-metadata';
  const grid=section.querySelector('.supplier-profile-grid');
  for(const label of ['Статус у Prozorro','Статус у реєстрі (ЄДР)','Актуальність ЄДР','Дата перевірки','Синхронізовано з Google Sheets']){
    const row=fields.find(item=>item.querySelector('dt')?.textContent===label);if(row)metadata.append(row);
  }
  grid.after(metadata);
  const googleRowPath=`${API}/${document.documentElement.dataset.pqmEnvironment==='sandbox'?'sandbox/supplier-google-row':'supplier-google-row'}/${encodeURIComponent(code)}`;
  request(googleRowPath).then(()=>{
    if(!section.isConnected||$('#supplierProfileSubtitle').textContent!==`ЄДРПОУ / РНОКПП: ${code}`)return;
    const link=document.createElement('a');link.href=`${googleRowPath}?open=1`;link.target='_blank';link.rel='noopener';link.textContent='↗ Google ЄДР';
    actions.append(link);
  }).catch(()=>{});
}
function formatLegacyCardDates(root,values){
  if(!root)return;
  for(const value of values.filter(Boolean)){
    const raw=String(value).trim(),formatted=displayDate(raw);
    if(raw===formatted||!/^(?:\d{4}-\d{2}-\d{2})/.test(raw))continue;
    const walker=document.createTreeWalker(root,NodeFilter.SHOW_TEXT);
    while(walker.nextNode())walker.currentNode.nodeValue=walker.currentNode.nodeValue.replaceAll(raw,formatted);
  }
}
openSupplierProfile=async function(code,context={}){
  const dialog=$('#supplierProfileDialog'),body=$('#supplierProfileBody');
  $('#supplierProfileTitle').textContent='Картка постачальника';$('#supplierProfileSubtitle').innerHTML=`ЄДРПОУ / РНОКПП: <strong>${esc(code)}</strong>`;body.innerHTML='<p class="muted">Завантаження картки…</p>';if(!dialog.open)dialog.showModal();
  try{
    const data=await request(`${API}/supplier-profile/${encodeURIComponent(code)}`),edr=data.edr_profile||{},edrCanonical=data.edr_canonical||{},supplierNote=data.supplier_note||{},currentManager=data.current_manager||{},summary=data.summary||{},stats=data.bids_summary||{},requestStats=data.violation_summary||{},nazkReview=data.nazk_review||{},nazkRegistry=data.nazk||[],nazkHistory=data.nazk_check_history||[],supplierNazkHistory=data.supplier_nazk_checks||[],supplierNazkWorkflow=data.supplier_nazk_workflow||{},contacts=data.contacts||{},contact=contacts.current||{},applicationGroups=data.application_history_groups||[];
    // A completed submission check is returned in both collections for context.
    // Keep it only in the application history in the presentation layer.
    const submissionNazkCheckIds=new Set(nazkHistory.map(item=>String(item.check_id||'')).filter(Boolean));
    const supplierOnlyNazkHistory=supplierNazkHistory.filter(item=>!submissionNazkCheckIds.has(String(item.id||'')));
    const latestFactualSupplierNazkCheck=supplierOnlyNazkHistory.find(item=>item.workflow_status==='completed'&&['confirmed','refuted'].includes(item.result));
    if(latestFactualSupplierNazkCheck){
      const factualIndex=supplierOnlyNazkHistory.indexOf(latestFactualSupplierNazkCheck);
      if(factualIndex>0)supplierOnlyNazkHistory.unshift(...supplierOnlyNazkHistory.splice(factualIndex,1));
    }
    let cardSupplierName=validSupplierName(edr.full_name);
    if(!cardSupplierName&&Object.hasOwn(data,'latest_submission_name'))cardSupplierName=validSupplierName(data.latest_submission_name);
    if(!cardSupplierName&&!Object.hasOwn(data,'latest_submission_name')){
      try{
        const latest=await request('/api/application-history?'+new URLSearchParams({code:String(data.code),size:'1',page:'1',sorts:JSON.stringify([{key:'date',direction:'desc'}])}));
        cardSupplierName=validSupplierName(latest.items?.[0]?.supplier_name);
      }catch{toast('Не вдалося отримати назву постачальника з останньої заявки')}
    }
    cardSupplierName=cardSupplierName||'—';
    $('#supplierProfileTitle').textContent=cardSupplierName;
    $('#supplierProfileSubtitle').innerHTML=`ЄДРПОУ / РНОКПП: <strong>${esc(data.code)}</strong>`;
    const qStatus=value=>({active:'Активна',terminated:'Неактивна',expired:'Неактивна · строк відбору сплив',suspended:'Призупинена'}[value]||value||'—');
    const nazkStateLabels={needs_check:'Потребує перевірки',needs_supplier_review:'Потребує перевірки',waiting_response:'Очікується відповідь',on_request:'На запит',refuted:'Спростовано',confirmed:'Підтверджено',inactive:'Неактуально',not_required:'Немає збігу'};
    const nazkState=data.nazk_presentation_state||'not_required',nazkStateLabel=nazkStateLabels[nazkState]||nazkState;
    const nazkPerson=supplierNazkWorkflow.manager_name||supplierNazkHistory.find(x=>x.workflow_status==='completed')?.manager_name||edr.manager_name||nazkRegistry[0]?.full_name||'—';
    body.innerHTML=`${supplierProfileOverviewHtml(cardSupplierName,data.code,contact,contacts,supplierNote,role()==='viewer')}${String(edr.edr_notes||'').trim()?`<section class="supplier-profile-section"><h3>Примітка з Google</h3><p class="source-note-text">${esc(edr.edr_notes)}</p><small class="muted">Джерело: Google Sheet · лише для читання</small></section>`:''}
<section class="supplier-profile-section supplier-profile-edr"><h3>Керівник та відомості з ЄДР</h3><dl class="supplier-profile-grid"><div><dt>Актуальний відомий керівник</dt><dd><strong>${esc(currentManager.manager_name||edr.manager_name)||'—'}</strong>${currentManager.source?`<small class="supplier-manager-source">${esc(currentManager.source)}${currentManager.source.startsWith('Google Sheets')?'':` · Оновлено відомості про керівника: ${esc(displayDate(currentManager.updated_at||currentManager.valid_from))}`}</small>`:''}</dd></div><div><dt>ПІБ керівника у snapshot ЄДР</dt><dd>${esc(edr.manager_name)||'—'}</dd></div><div><dt>Повна назва з ЄДР</dt><dd>${esc(edr.full_name)||'—'}</dd></div><div><dt>Скорочена назва з ЄДР</dt><dd>${esc(edr.short_name)||'—'}</dd></div><div><dt>Статус у Prozorro</dt><dd><strong>${esc(edrCanonical.prozorro_status||'Ще не в реєстрі')}</strong></dd></div><div><dt>Актуальність ЄДР</dt><dd><strong class="edr-freshness ${esc(edrCanonical.bucket||'not_checked')}">${esc(edrCanonical.marker||'⚪ Не перевірено')}</strong></dd></div><div><dt>Статус у реєстрі (ЄДР)</dt><dd>${esc(displayEdrStatus(edr.edr_status))}</dd></div>${supplierEdrDatesHtml(edr)}</dl></section>
    <section class="supplier-profile-section supplier-nazk-context"><h3>НАЗК</h3><div class="supplier-nazk-current ${nazkState==='confirmed'?'danger':nazkState==='refuted'?'safe':nazkState==='inactive'?'inactive':nazkState==='not_required'?'':'warning'}"><span>Поточний стан НАЗК</span><strong>НАЗК · ${esc(nazkStateLabel)}</strong><p>ПІБ, якого перевіряємо: <b>${esc(nazkPerson)}</b></p>${nazkRegistry.length?`<p class="supplier-nazk-match-line"><b>${esc(nazkRegistry[0].full_name||'—')}</b> · ${esc(nazkRegistry[0].offense_name||'запис у Реєстрі НАЗК')} · ${esc(displayDateOnly(nazkRegistry[0].sentence_date))||'дата не зазначена'}</p>`:''}</div><details class="supplier-nazk-all-history"><summary>Історія перевірок НАЗК</summary>
    <section class="supplier-profile-section registry-profile-block ${nazkRegistry.length?'warning':''}"><h3>Запис(и) у Реєстрі НАЗК · ${frameworkNumber(nazkRegistry.length)}</h3><div class="supplier-profile-table"><table><thead><tr><th>ПІБ</th><th>Порушення</th><th>Вид стягнення</th><th>№ судової справи</th><th>Дата рішення</th><th>Набрання законної сили</th><th>№ наказу</th><th>Дата наказу</th><th>Рішення</th></tr></thead><tbody>${nazkRegistry.map(x=>`<tr><td><strong>${esc(x.full_name||'—')}</strong><small>ID: ${esc(x.source_id||'—')}</small></td><td>${esc(x.offense_name||'—')}</td><td>${esc(x.punishment||'—')}</td><td>${esc(x.court_case_number||'—')}</td><td>${esc(displayDateOnly(x.sentence_date))||'—'}</td><td>${esc(displayDateOnly(x.punishment_start))||'—'}</td><td>${esc(x.decree_number||'—')}</td><td>${esc(displayDateOnly(x.decree_date))||'—'}</td><td>${x.decision_url?`<a href="${esc(x.decision_url)}" target="_blank" rel="noopener">Відкрити рішення</a>`:'—'}</td></tr>`).join('')||'<tr><td colspan="9">Записів не знайдено</td></tr>'}</tbody></table></div></section>
    <section class="supplier-profile-section registry-profile-block ${supplierNazkWorkflow.workflow_status==='waiting_response'?'warning':supplierNazkWorkflow.workflow_status==='needs_review'?'warning':''}"><h3>НАЗК · supplier-level перевірка</h3>${supplierNazkWorkflow.id?`<p><strong>${esc(supplierNazkWorkflow.manager_name||'—')}</strong> · ${supplierNazkWorkflow.workflow_status==='needs_review'?'Потребує перевірки':'Очікується відповідь'}</p>${supplierNazkWorkflow.comment?`<p>${esc(supplierNazkWorkflow.comment)}</p>`:''}${supplierNazkWorkflow.workflow_status==='needs_review'?`<label>Коментар<textarea id="supplierNazkRequestComment"></textarea></label><button type="button" class="primary" id="supplierNazkRequestSent">Запит направлено</button>`:`<div class="request-form-grid"><label>Результат<select id="supplierNazkResult"><option value="refuted">Спростовано</option><option value="confirmed">Підтверджено</option></select></label><label>Дата документа/відповіді<input type="date" id="supplierNazkEvidenceDate"></label><label class="wide">Посилання на документ<input type="url" id="supplierNazkDocumentUrl" placeholder="https://..."></label><label class="wide">Коментар<textarea id="supplierNazkCompleteComment"></textarea></label></div><button type="button" class="primary" id="supplierNazkComplete">Завершити перевірку</button>`}`:'<p>Незавершеної supplier-level роботи немає</p>'}${supplierOnlyNazkHistory.length?`<details class="supplier-nazk-completed-history"><summary>Завершені supplier-level перевірки · ${frameworkNumber(supplierOnlyNazkHistory.length)} · остання: ${supplierOnlyNazkHistory[0].result==='refuted'?'спростовано':supplierOnlyNazkHistory[0].result==='confirmed'?'підтверджено':esc(supplierOnlyNazkHistory[0].result||'без результату')} ${esc(displayDateOnly(supplierOnlyNazkHistory[0].completed_at||supplierOnlyNazkHistory[0].started_at))}</summary><div class="supplier-profile-table"><table><thead><tr><th>ПІБ</th><th>Стан</th><th>Результат</th><th>Дата</th><th>Документ</th><th>Коментар</th></tr></thead><tbody>${supplierOnlyNazkHistory.map(x=>`<tr><td>${esc(x.manager_name||'—')}</td><td>${esc(x.workflow_status||'—')}</td><td>${x.result==='refuted'?'Спростовано':x.result==='confirmed'?'Підтверджено':'—'}</td><td>${esc(displayDate(x.completed_at||x.started_at))||'—'}</td><td>${x.document_url?`<a href="${esc(x.document_url)}" target="_blank" rel="noopener">${esc(x.document_title||'Відкрити')}</a>`:'—'}</td><td>${esc(x.comment||'—')}</td></tr>`).join('')}</tbody></table></div></details>`:'<p class="muted">Supplier-level історії немає</p>'}</section>
    <section class="supplier-profile-section"><h3>Перевірки НАЗК у заявках</h3>${nazkHistory.length?`<details class="supplier-nazk-completed-history"><summary>Завершені перевірки · ${frameworkNumber(nazkHistory.length)} · остання: ${nazkHistory[0].result==='refuted'?'спростовано':nazkHistory[0].result==='confirmed'?'підтверджено':esc(nazkHistory[0].result||'без результату')} ${esc(displayDateOnly(nazkHistory[0].checked_at))}</summary><div class="supplier-profile-table"><table><thead><tr><th>ПІБ / постачальник</th><th>Заявка / відбір</th><th>Дата заявки</th><th>Результат</th><th>Доказ</th><th>Перевірено</th><th>Коментар</th></tr></thead><tbody>${nazkHistory.map(x=>`<tr><td><strong>${esc(x.manager_name||'—')}</strong><small>${esc(x.supplier_name||'—')}</small></td><td>${esc(x.submission_id||'—')}<small>${esc(x.framework_id||'—')}</small></td><td>${esc(displayDate(x.date_published))||'—'}</td><td><strong>${x.result==='refuted'?'Спростовано':x.result==='confirmed'?'Підтверджено':esc(x.result||'—')}</strong></td><td>${x.document_url?`<a href="${esc(x.document_url)}" target="_blank" rel="noopener">${esc(x.document_title||'Відкрити документ')}</a>`:esc(x.document_title||'—')}<small>Дата довідки: ${esc(displayDateOnly(x.evidence_date))||'—'}</small></td><td>${esc(displayDate(x.checked_at))||'—'}<small>${esc(x.checked_by||'—')}</small></td><td>${esc(x.comment||'—')}</td></tr>`).join('')}</tbody></table></div></details>`:'<p class="muted">Завершених submission-level перевірок не знайдено</p>'}</section>
    <details class="supplier-nazk-legacy"><summary>Legacy-історія${nazkReview.result?' · є запис':''}</summary>    <section class="supplier-profile-section registry-profile-block ${!nazkReview.is_current_manager&&nazkReview.result?'':nazkReview.result==='підтверджено'?'danger':['спростовано','ні','не актуально','неактуально'].includes(nazkReview.result)?'safe':(nazkReview.result||data.nazk?.length)?'warning':''}"><h3>НАЗК · legacy-історія ${nazkReview.result?(!nazkReview.is_current_manager?'· попередній керівник':`· ${esc(nazkReview.result.toUpperCase())}`):''}</h3>${nazkReview.result?`${!nazkReview.is_current_manager?`<p><strong>Маркер не актуальний:</strong> перевірка стосується попереднього керівника. Поточний керівник — ${esc(edr.manager_name||'не зазначено')}.</p>`:''}<p><strong>${esc(nazkReview.manager_name||'—')}</strong> · ${esc(nazkReview.result)}${nazkReview.case_number?` · справа ${esc(nazkReview.case_number)}`:''}${nazkReview.decision_date?` · ${esc(nazkReview.decision_date)}`:''}</p><p>${esc(nazkReview.comment)||'Без коментаря'}${nazkReview.evidence_url?` · <a href="${esc(nazkReview.evidence_url)}" target="_blank" rel="noopener">документ підтвердження</a>`:''}</p><small>Перевірено: ${esc(nazkReview.checked_at||'—')} · ${esc(nazkReview.officer||'—')} · рядок ${frameworkNumber(nazkReview.source_row)}</small>`:'<p>Legacy-перевірок немає</p>'}</section></details></details>
    </section>
    <section class="supplier-profile-section registry-profile-block ${data.amcu?.length?(Number(summary.active_count||0)>0?'danger':'safe'):''}"><h3>АМКУ · ${frameworkNumber(data.amcu?.length)}</h3>${(data.amcu||[]).map(x=>`<p><strong>${esc(x.decision_no||'—')}</strong> · ${esc(displayDateOnly(x.decision_date))||'—'} · ${esc(x.authority||'—')}${x.court_case_no?` · справа ${esc(x.court_case_no)}`:''}</p>`).join('')||'<p>Записів не знайдено</p>'}</section>
    <section class="supplier-profile-section"><h3>Статистика</h3><div class="supplier-profile-stats"><div><span>Кваліфікації</span><strong>${frameworkNumber(summary.qualifications_count)}</strong></div><div><span>Активних</span><strong>${frameworkNumber(summary.active_count)}</strong></div><div><span>Неактивних</span><strong>${frameworkNumber(summary.inactive_count)}</strong></div><button type="button" class="supplier-stat-drill" ${currentMe?.ui_features?.supplier_bids_ready===true?'':'hidden'} data-supplier-drill="participations"><span>Участей у закупівлях</span><strong>${frameworkNumber(stats.participations)}</strong><small>Остання участь: ${esc(displayDateOnly(stats.last_participation_date))||'—'}</small><small>Відкрити список →</small></button><button type="button" class="supplier-stat-drill" ${currentMe?.ui_features?.supplier_bids_ready===true?'':'hidden'} data-supplier-drill="wins"><span>Перемог</span><strong>${frameworkNumber(stats.wins)}</strong><small>Відкрити перемоги →</small></button><div class="supplier-request-stat ${(Number(requestStats.current_month||0)>=Number(requestStats.current_month_limit||3)||Number(requestStats.three_calendar_months||0)>=Number(requestStats.three_calendar_months_limit||5))?'threshold-reached':''}" title="${esc(requestStats.thresholds_note||'')}"><span>Звернення</span><p><b>Подано:</b> ${frameworkNumber(requestStats.submitted)}</p><p><b>Задоволено:</b> ${frameworkNumber(requestStats.satisfied)}</p><small>Місяць (${esc(displayKpiDate(requestStats.current_month_from))}–${esc(displayKpiDate(requestStats.calculated_to))}): <b>${frameworkNumber(requestStats.current_month)} / ${frameworkNumber(requestStats.current_month_limit)}</b></small><small>3 місяці (${esc(displayKpiDate(requestStats.three_calendar_months_from))}–${esc(displayKpiDate(requestStats.calculated_to))}): <b>${frameworkNumber(requestStats.three_calendar_months)} / ${frameworkNumber(requestStats.three_calendar_months_limit)}</b></small></div></div></section>
    <section class="supplier-profile-section"><h3>Кваліфікації за відборами</h3><div class="supplier-profile-table"><table><thead><tr><th>Назва відбору</th><th>Код ДК</th><th>Технічний ID</th><th>Кваліфікація</th><th>Заявки</th></tr></thead><tbody>${applicationGroups.map(group=>{const q=group.current_qualification||{},url=marketplaceApplicationsUrl(group.marketplace_url||q.marketplace_url,data.code);return`<tr><td><strong>${esc(group.framework_title||'—')}</strong></td><td>${esc(group.dk_code||'—')}</td><td><small>${esc(group.framework_pretty_id||'—')}</small></td><td>${q.id?`<span class="supplier-qualification-badge ${q.status==='active'?'active':'inactive'}">${esc(qStatus(q.status))}</span>${q.event_date?`<small>${esc(displayDate(q.event_date))}</small>`:''}`:'—'}</td><td>${url?`<a href="${esc(url)}" target="_blank" rel="noopener">Всі заявки на майданчику</a>`:'<small>Посилання не заповнено у довіднику</small>'}</td></tr>`}).join('')||'<tr><td colspan="5">Відборів не знайдено</td></tr>'}</tbody></table></div></section>
    <section class="supplier-profile-section"><h3>Звернення замовників · ${frameworkNumber(data.violation_reports?.length)}</h3><div class="supplier-profile-table"><table><thead><tr><th>Звернення</th><th>Дата</th><th>Підстава</th><th>Статус</th><th>Результат розгляду</th><th>Дата рішення</th></tr></thead><tbody>${(data.violation_reports||[]).map(x=>`<tr><td><strong>${esc(x.report_id||'—')}</strong><small>${esc(x.authority_name||'')}</small></td><td>${esc(displayDate(x.date_published))||'—'}</td><td>${esc(requestLabel(x.reason,requestReasonLabels))}</td><td>${esc(requestLabel(x.status,requestStatusLabels))}</td><td>${esc(requestLabel(x.decision_resolution,requestStatusLabels))}${x.decision_description?`<small>${esc(x.decision_description)}</small>`:''}</td><td>${esc(displayDate(x.decision_date))||'—'}</td></tr>`).join('')||'<tr><td colspan="6">Звернень не знайдено</td></tr>'}</tbody></table></div></section>`;
    const supplierCompletedNazk=[...body.querySelectorAll('.supplier-nazk-completed-history')].find(node=>node.querySelector('summary')?.textContent.includes('supplier-level'));
    const supplierCompletedSummary=supplierCompletedNazk?.querySelector('summary');
    if(supplierCompletedSummary&&latestFactualSupplierNazkCheck){
      const factualLabel=latestFactualSupplierNazkCheck.result==='refuted'?'Спростовано':'Підтверджено';
      supplierCompletedSummary.textContent=`Завершені supplier-level перевірки · ${frameworkNumber(supplierOnlyNazkHistory.length)} · остання: ${factualLabel} ${displayDateOnly(latestFactualSupplierNazkCheck.result_at||latestFactualSupplierNazkCheck.completed_at)}`;
    }
    const completedNazkRows=supplierCompletedNazk?.querySelectorAll('tbody tr')||[];
    completedNazkRows.forEach((row,index)=>{
      const check=supplierOnlyNazkHistory[index];
      if(!check)return;
      const set=check.nazk_evidence||check.evidence_set||{};
      row.innerHTML=`<td>${esc(set.person_name||check.manager_name||'—')}${check.workflow_status==='legacy_archived'?'<small>Архівний workflow</small>':''}</td><td>${esc(set.person_rnokpp||set.person_tax_id||'—')}</td><td>${check.result==='refuted'?'Спростовано':check.result==='confirmed'?'Підтверджено':'—'}</td><td>${esc(displayDate(set.result_at||check.completed_at||check.started_at))||'—'}</td><td>${esc(formatOfficerName(set.responsible_officer?.name||set.responsible_uo_name||check.responsible_uo_name)||'—')}</td><td>${supplierNazkEvidenceHtml(check)}</td><td>${esc(check.comment||'—')}</td>`;
    });
    const completedNazkHead=supplierCompletedNazk?.querySelector('thead tr');
    if(completedNazkHead)completedNazkHead.innerHTML='<th>ПІБ</th><th>РНОКПП</th><th>Результат</th><th>Дата</th><th>УО</th><th>Підстава / документ</th><th>Коментар</th>';
    decorateSupplierEdrCard(body,String(data.code),edr,supplierNote);
    formatLegacyCardDates(body.querySelector('.supplier-nazk-legacy'),[nazkReview.decision_date,nazkReview.checked_at]);
    const statsBlock=body.querySelector('.supplier-profile-stats');
    body.querySelector('.supplier-profile-overview').after(statsBlock.closest('section'));
    statsBlock.closest('section').after(body.querySelector('.supplier-profile-edr'));
    statsBlock.insertAdjacentHTML('afterbegin',`<button type="button" class="supplier-stat-drill" id="supplierAllApplications"><span>Всі заявки постачальника</span><strong>${frameworkNumber(applicationGroups.reduce((n,g)=>n+g.applications_count,0))}</strong><small>Відкрити історію →</small></button>`);
    $('#supplierAllApplications').onclick=()=>openSupplierHistory(code);
    const appealTotal=statsBlock.querySelector('.supplier-request-stat>p');if(appealTotal)appealTotal.outerHTML=`<strong title="Подано звернень">${frameworkNumber(requestStats.submitted)}</strong>`;
    const updateSupplierNazk=async payload=>{try{await request(`${API}/suppliers/${encodeURIComponent(code)}/nazk-check`,{method:'PATCH',headers:{'Content-Type':'application/json'},body:JSON.stringify({check_id:supplierNazkWorkflow.id,...payload})});toast('Стан НАЗК оновлено');await openSupplierProfile(code);await loadQualifiedSuppliersFiltered();if(activeModule==='work_queue')await loadWorkQueue()}catch(error){toast(error.message)}};
    if($('#supplierNazkRequestSent'))$('#supplierNazkRequestSent').onclick=()=>updateSupplierNazk({action:'request_sent',comment:$('#supplierNazkRequestComment').value});
    if($('#supplierNazkComplete'))$('#supplierNazkComplete').onclick=()=>updateSupplierNazk({action:'complete',result:$('#supplierNazkResult').value,evidence_date:$('#supplierNazkEvidenceDate').value,document_url:$('#supplierNazkDocumentUrl').value,comment:$('#supplierNazkCompleteComment').value});
    if($('#supplierProfileNoteSave'))$('#supplierProfileNoteSave').onclick=async()=>{try{await request(`${API}/suppliers/${encodeURIComponent(code)}/note`,{method:'PATCH',headers:{'Content-Type':'application/json'},body:JSON.stringify({note:$('#supplierProfileNote').value})});toast('Спільну примітку збережено');await openSupplierProfile(code,context)}catch(error){toast(error.message)}};
    $$('[data-supplier-drill]').forEach(button=>button.onclick=()=>openSupplierProcurements(code,button.dataset.supplierDrill==='wins'));
  }catch(error){body.innerHTML=`<p class="error">${esc(error.message)}</p>`}
};
let supplierEdrOauth={};
let supplierProcurementPage=1,supplierProcurementPages=1;
async function loadSupplierProcurements(){
  const code=$('#procurementSupplierCode').value.replace(/\D/g,'');
  if(!code)return;
  const body=$('#procurementSupplierBody');body.innerHTML='<tr><td colspan="6">Завантаження…</td></tr>';
  const params={page:supplierProcurementPage,size:'50',result:$('#procurementResult').value,dk_code:$('#procurementDkCodes').value,search:$('#procurementSearch').value.trim(),year:$('#procurementYear').value.trim(),date_from:$('#procurementDateFrom').value,date_to:$('#procurementDateTo').value};
  try{const data=await request(`${API}/supplier-procurements/${encodeURIComponent(code)}?${new URLSearchParams(params)}`);supplierProcurementPage=data.page;supplierProcurementPages=data.pages;const summary=data.summary||{};$('#procurementSupplierSummary').innerHTML=`<button type="button" data-procurement-result=""><span>Участей</span><strong>${frameworkNumber(summary.participations)}</strong></button><button type="button" data-procurement-result="wins"><span>Перемог</span><strong>${frameworkNumber(summary.wins)}</strong></button>`;$('#procurementTopDk').innerHTML=(data.top_dk||[]).map(x=>`<button type="button" data-procurement-dk="${esc(x.dk_code)}" title="${esc(x.dk_name||'')}">${esc(x.dk_code)} · ${frameworkNumber(x.procurements)}</button>`).join('');$('#procurementDkOptions').innerHTML=(data.top_dk||[]).map(x=>`<option value="${esc(x.dk_code)}">${esc(x.dk_name||'')}</option>`).join('');body.innerHTML=(data.items||[]).map(x=>`<tr><td><a href="https://prozorro.gov.ua/uk/tender/${encodeURIComponent(x.tender_id)}" target="_blank" rel="noopener">${esc(x.tender_id)}</a><small>${esc(x.title||'')}</small><small>${esc(x.dk_code||'')} ${esc(x.dk_name||'')}</small></td><td>${esc(displayDate(x.tender_date))||'—'}</td><td>${esc(x.buyer_name||'—')}</td><td>${esc(x.status||'—')}</td><td>${x.won?'<strong class="supplier-win">Перемога</strong>':'Участь'}</td><td>${frameworkNumber(x.amount)} ${esc(x.currency||'')}</td></tr>`).join('')||'<tr><td colspan="6">Записів не знайдено</td></tr>';$('#procurementSupplierInfo').textContent=`${Number(data.total||0).toLocaleString('uk-UA')} записів · сторінка ${data.page} із ${data.pages}`;$('#procurementSupplierPrev').disabled=data.page<=1;$('#procurementSupplierNext').disabled=data.page>=data.pages}catch(error){body.innerHTML=`<tr><td colspan="6">${esc(error.message)}</td></tr>`}
}
function openSupplierProcurements(code,winsOnly=false){$('#supplierProfileDialog').close();showModule('procurements');$('#procurementSupplierCode').value=code;$('#procurementResult').value=winsOnly?'wins':'';$('#procurementSearch').value=$('#procurementDkCodes').value=$('#procurementYear').value=$('#procurementDateFrom').value=$('#procurementDateTo').value='';supplierProcurementPage=1;loadSupplierProcurements()}

let adminFrameworkItems=[],adminFrameworkSort='pretty_id',adminFrameworkDirection='asc';
function renderAdminFrameworks(){
  const search=$('#adminFrameworkSearch').value.trim().toLocaleLowerCase('uk-UA'),status=$('#adminFrameworkStatus').value,category=$('#adminFrameworkCategory').value,officer=$('#adminFrameworkOfficer').value;
  let items=adminFrameworkItems.filter(x=>(!search||[x.pretty_id,x.title,x.dk_code].some(v=>String(v||'').toLocaleLowerCase('uk-UA').includes(search)))&&(!status||x.status===status)&&(!category||x.category===category)&&(!officer||(officer==='__unassigned__'?!x.responsible_officer:x.responsible_officer===officer)));
  const collator=new Intl.Collator('uk-UA',{numeric:true,sensitivity:'base'}),dir=adminFrameworkDirection==='asc'?1:-1;
  items.sort((a,b)=>collator.compare(String(a[adminFrameworkSort]||''),String(b[adminFrameworkSort]||''))*dir);
  $('#adminFrameworkCount').textContent=`Показано ${items.length} із ${adminFrameworkItems.length}`;
  $$('#adminFrameworksPanel [data-admin-sort]').forEach(th=>{th.classList.toggle('active-sort',th.dataset.adminSort===adminFrameworkSort);th.dataset.direction=th.dataset.adminSort===adminFrameworkSort?adminFrameworkDirection:''});
  $('#adminFrameworksBody').innerHTML=items.map(x=>`<tr data-directory-id="${esc(x.directory_id)}"><td><strong>${esc(x.pretty_id)}</strong><small>${esc(x.title||'')}</small></td><td>${esc(x.dk_code||'—')}</td><td><input data-admin-field="category" list="adminFrameworkCategoryOptions" value="${esc(x.category||'')}"></td><td><input data-admin-field="marketplace_url" value="${esc(x.marketplace_url||'')}"></td><td><select data-admin-field="responsible_officer">${officerOptions(x.responsible_officer)}</select></td><td><strong>${esc(x.status||'—')}</strong><small>${x.valid_until?`до ${esc(displayDateOnly(x.valid_until))}`:(x.missing_end_date?'немає кінцевої дати':'немає актуальних даних Prozorro')}</small></td><td>${x.pretty_id?`<a href="https://prozorro.gov.ua/uk/framework/${encodeURIComponent(x.pretty_id)}" target="_blank" rel="noopener">Відкрити</a>`:'—'}</td><td><button class="primary admin-framework-save">Зберегти</button></td></tr>`).join('')||'<tr><td colspan="8">За вибраними умовами відборів немає</td></tr>';
  $$('.admin-framework-save').forEach(button=>button.onclick=async()=>{const row=button.closest('tr'),payload={};row.querySelectorAll('[data-admin-field]').forEach(input=>payload[input.dataset.adminField]=input.value.trim());try{await request(`${API}/admin/frameworks/${encodeURIComponent(row.dataset.directoryId)}`,{method:'PATCH',headers:{'Content-Type':'application/json'},body:JSON.stringify(payload)});toast('Службові дані відбору збережено');await loadAdminFrameworks();if(activeModule==='workQueue')await loadWorkQueue()}catch(error){toast(error.message)}});
}
async function loadAdminFrameworks(){const body=$('#adminFrameworksBody');body.innerHTML='<tr><td colspan="8">Завантаження…</td></tr>';try{if(!protocolOfficers.length)await loadAuthorizedOfficers();const data=await request(`${API}/admin/frameworks`);adminFrameworkItems=data.items||[];const categories=[...new Set(adminFrameworkItems.map(x=>x.category).filter(Boolean))].sort(new Intl.Collator('uk-UA').compare),officers=[...new Set(adminFrameworkItems.map(x=>x.responsible_officer).filter(Boolean))].sort(new Intl.Collator('uk-UA').compare);const selectedCategory=$('#adminFrameworkCategory').value,selectedOfficer=$('#adminFrameworkOfficer').value;$('#adminFrameworkCategory').innerHTML='<option value="">Усі категорії</option>'+categories.map(v=>`<option ${v===selectedCategory?'selected':''}>${esc(v)}</option>`).join('');$('#adminFrameworkOfficer').innerHTML='<option value="">Усі УО</option><option value="__unassigned__">Не призначено</option>'+officers.map(v=>`<option ${v===selectedOfficer?'selected':''}>${esc(v)}</option>`).join('');$('#adminFrameworkCategoryOptions').innerHTML=categories.map(v=>`<option value="${esc(v)}">`).join('');renderAdminFrameworks()}catch(error){body.innerHTML=`<tr><td colspan="8">${esc(error.message)}</td></tr>`}}
async function addAdminFramework(){
  const prettyId=prompt('ID відбору');if(prettyId===null)return;
  const dkCode=prompt('Код ДК');if(dkCode===null)return;
  const category=prompt('Категорія','')??'';
  const marketplaceUrl=prompt('Посилання на майданчик','')??'';
  try{await request(`${API}/admin/frameworks`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({pretty_id:prettyId,dk_code:dkCode,category,marketplace_url:marketplaceUrl})});toast('Відбір додано до службового довідника');await loadAdminFrameworks()}catch(error){toast(error.message)}
}
async function importNewAdminFrameworks(){
  if(!confirm('Імпортувати лише нові відбори з Google? Наявні значення PQM не будуть змінені.'))return;
  try{const data=await request(`${API}/admin/frameworks/import-new`,{method:'POST',headers:{'Content-Type':'application/json'},body:'{}'});toast(`Імпортовано: ${Number(data.imported||0)} · наявних: ${Number(data.existing_conflicts||0)} · пропущено: ${Number(data.skipped||0)}`);await loadAdminFrameworks()}catch(error){toast(error.message)}
}
async function loadAdminOfficers(){const body=$('#adminOfficersBody');body.innerHTML='<tr><td colspan="5">Завантаження…</td></tr>';try{const items=await loadAuthorizedOfficers(false);body.innerHTML=items.map(x=>`<tr data-officer-id="${x.id}"><td><strong>${esc(x.full_name)}</strong></td><td><input data-officer-role value="${esc(x.role||'УО')}"></td><td><label><input data-officer-active type="checkbox" ${x.active?'checked':''}> ${x.active?'Активна':'Історична'}</label></td><td>${Number(x.active_frameworks||0).toLocaleString('uk-UA')}</td><td><button class="primary admin-officer-save">Зберегти</button></td></tr>`).join('');$$('.admin-officer-save').forEach(button=>button.onclick=async()=>{const row=button.closest('tr');await request(`${API}/admin/officers/${row.dataset.officerId}`,{method:'PATCH',headers:{'Content-Type':'application/json'},body:JSON.stringify({role:row.querySelector('[data-officer-role]').value,active:row.querySelector('[data-officer-active]').checked})});toast('Довідник УО оновлено');await loadAdminOfficers()})}catch(error){body.innerHTML=`<tr><td colspan="5">${esc(error.message)}</td></tr>`}}
function filterAdminTemplates(){const query=$('#adminTemplateSearch')?.value.trim().toLocaleLowerCase('uk-UA')||'';$$('#adminTemplatesBody tr[data-search]').forEach(row=>row.hidden=Boolean(query&&!row.dataset.search.includes(query)))}
function filterAdminMetadata(){const query=$('#adminMetadataSearch')?.value.trim().toLocaleLowerCase('uk-UA')||'';$$('#adminDocumentMetadata .admin-metadata-item').forEach(item=>item.hidden=Boolean(query&&!item.dataset.search.includes(query)))}
function setAdminConfigExpanded(sectionId,contentId,buttonId,expanded){const section=$(`#${sectionId}`),content=$(`#${contentId}`),button=$(`#${buttonId}`);if(!section||!content||!button)return;content.hidden=!expanded;section.classList.toggle('is-collapsed',!expanded);button.textContent=expanded?'Згорнути':'Розгорнути';button.setAttribute('aria-expanded',String(expanded))}
async function loadAdminTemplates(){const body=$('#adminTemplatesBody');body.innerHTML='<tr><td colspan="5">Завантаження…</td></tr>';try{const data=await request(`${API}/admin/templates`);body.innerHTML=(data.items||[]).map(x=>`<tr data-search="${esc([x.name,x.key,x.filename].join(' ').toLocaleLowerCase('uk-UA'))}"><td><strong>${esc(x.name)}</strong></td><td><code>${esc(x.key)}</code></td><td>${esc(x.filename)}</td><td>${esc(displayDate(x.modified_at))}</td><td class="admin-template-actions"><a class="ghost button-link" href="${API}/admin/templates/${encodeURIComponent(x.key)}/download">Завантажити</a><button type="button" class="primary" data-template-replace="${esc(x.key)}">Замінити шаблон</button></td></tr>`).join('')||'<tr><td colspan="5">Шаблони не знайдено</td></tr>';$$('[data-template-replace]').forEach(button=>button.onclick=()=>{const input=$('#adminTemplateFile');input.dataset.templateKey=button.dataset.templateReplace;input.click()});filterAdminTemplates();await loadAdminDocumentMetadata()}catch(error){console.error('Template list unavailable',error);body.innerHTML='<tr><td colspan="5">Не вдалося завантажити шаблони. Повторіть спробу.</td></tr>'}}
let adminMetadataCatalog={items:[],document_types:[]};
function metadataFieldOptions(fields){return(fields||[]).map(field=>`<option value="${esc(field.key)}" data-search="${esc([field.label,field.description,field.group,field.key].join(' ').toLocaleLowerCase('uk-UA'))}">${esc(field.label)} · ${esc(field.key)}</option>`).join('')}
function filterMetadataFieldSelect(search,select,fields){const q=search.value.trim().toLocaleLowerCase('uk-UA');select.innerHTML=metadataFieldOptions((fields||[]).filter(field=>!q||[field.label,field.description,field.group,field.key].join(' ').toLocaleLowerCase('uk-UA').includes(q)))}
function insertMetadataField(textarea,select){if(!select.value)return;textarea.setRangeText(`{{${select.value}}}`,textarea.selectionStart,textarea.selectionEnd,'end');textarea.focus()}
async function loadAdminDocumentMetadata(){
  const root=$('#adminDocumentMetadata');if(!root)return;root.innerHTML='<p class="muted">Завантаження…</p>';
  try{
    const data=await request(`${API}/admin/document-metadata`);adminMetadataCatalog=data;
    root.innerHTML=(data.items||[]).map(item=>{
      const search=[item.label,item.document_type,item.metadata_key,item.template_text,item.description,item.active?'активні':'неактивні',...(item.used_fields||[]),...(item.fields||[]).flatMap(field=>[field.label,field.description,field.group,field.key])].join(' ').toLocaleLowerCase('uk-UA');
      return`<details class="admin-metadata-item ${item.active?'':'is-inactive'}" open data-document-type="${esc(item.document_type)}" data-metadata-key="${esc(item.metadata_key)}" data-search="${esc(search)}"><summary><div><strong>${esc(item.label)}</strong><small>${esc(item.document_type)} · ${esc(item.metadata_key)}</small></div><span class="admin-metadata-summary-state"><b>${item.active?'Активні':'Неактивні'}</b> · Версія ${Number(item.version)}</span></summary><div class="admin-metadata-body"><div class="admin-metadata-edit-grid"><label>Назва метаданих<input data-metadata-label value="${esc(item.label)}"></label><label>Статус<select data-metadata-active><option value="1" ${item.active?'selected':''}>Активні</option><option value="0" ${item.active?'':'selected'}>Неактивні</option></select></label><label class="wide">Опис<textarea data-metadata-description rows="2">${esc(item.description||'')}</textarea></label><label class="wide">Шаблон тексту<textarea data-metadata-template rows="3">${esc(item.template_text)}</textarea></label></div><div class="admin-metadata-fields"><input type="search" data-metadata-search placeholder="Пошук поля за українською назвою, описом, групою або key"><select data-metadata-field>${metadataFieldOptions(item.fields)}</select><button type="button" class="ghost" data-metadata-insert>Вставити поле</button><button type="button" class="ghost" data-metadata-validate>Перевірити</button><button type="button" class="primary" data-metadata-save>Зберегти</button></div><p class="muted">Використані поля: ${(item.used_fields||[]).map(esc).join(', ')||'немає'}${item.used?' · Уже використано у сформованому документі':''}</p>${item.validation_error?`<p class="request-warning">${esc(item.validation_error)}</p>`:''}<p role="alert"></p></div></details>`
    }).join('')||'<p class="muted">Для чинних runtime-документів метадані ще не налаштовані.</p>';
    root.querySelectorAll('.admin-metadata-item').forEach(bindAdminDocumentMetadata);filterAdminMetadata()
  }catch(error){root.innerHTML=`<p class="request-warning">${esc(error.message)}</p>`}
}
function bindAdminDocumentMetadata(card){
  const search=card.querySelector('[data-metadata-search]'),select=card.querySelector('[data-metadata-field]'),textarea=card.querySelector('[data-metadata-template]'),alert=card.querySelector('[role="alert"]'),fields=adminMetadataCatalog.items.find(item=>item.document_type===card.dataset.documentType&&item.metadata_key===card.dataset.metadataKey)?.fields||[],endpoint=`${API}/admin/document-metadata/${encodeURIComponent(card.dataset.documentType)}/${encodeURIComponent(card.dataset.metadataKey)}`;
  search.oninput=()=>filterMetadataFieldSelect(search,select,fields);
  card.querySelector('[data-metadata-insert]').onclick=()=>insertMetadataField(textarea,select);
  const payload=()=>({label:card.querySelector('[data-metadata-label]').value,description:card.querySelector('[data-metadata-description]').value,template_text:textarea.value,active:card.querySelector('[data-metadata-active]').value==='1'});
  card.querySelector('[data-metadata-validate]').onclick=async()=>{alert.textContent='Перевірка…';try{const result=await request(endpoint,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({...payload(),validate_only:true})});alert.textContent=`Шаблон валідний. Поля: ${(result.used_fields||[]).join(', ')||'немає'}`}catch(error){alert.textContent=error.message}};
  card.querySelector('[data-metadata-save]').onclick=async event=>{const button=event.currentTarget;button.disabled=true;alert.textContent='Збереження…';try{const result=await request(endpoint,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(payload())});toast(result.changed?'Метадані документа збережено':'Змін немає');await loadAdminDocumentMetadata()}catch(error){alert.textContent=error.message;button.disabled=false}}
}
function suggestedMetadataKey(value){const map={а:'a',б:'b',в:'v',г:'h',ґ:'g',д:'d',е:'e',є:'ye',ж:'zh',з:'z',и:'y',і:'i',ї:'yi',й:'y',к:'k',л:'l',м:'m',н:'n',о:'o',п:'p',р:'r',с:'s',т:'t',у:'u',ф:'f',х:'kh',ц:'ts',ч:'ch',ш:'sh',щ:'shch',ь:'',ю:'yu',я:'ya'};return[...value.toLocaleLowerCase('uk-UA')].map(char=>map[char]??char).join('').normalize('NFKD').replace(/[^a-z0-9]+/g,'_').replace(/^_+|_+$/g,'').slice(0,64)}
async function loadCreateMetadataFields(){
  const documentType=$('#adminMetadataDocumentType').value,search=$('#adminMetadataFieldSearch'),select=$('#adminMetadataField');
  try{const data=await request(`${API}/admin/template-fields?document_type=${encodeURIComponent(documentType)}`);select._fields=(data.items||[]).filter(field=>field.binding_status==='VALID'&&field.active&&!field.deprecated);filterMetadataFieldSelect(search,select,select._fields)}catch(error){$('#adminMetadataCreateStatus').textContent=error.message}
}
function newMetadataPayload(){return{document_type:$('#adminMetadataDocumentType').value,label:$('#adminMetadataLabel').value,metadata_key:$('#adminMetadataKey').value,description:$('#adminMetadataDescription').value,template_text:$('#adminMetadataTemplate').value,active:$('#adminMetadataActive').value==='1'}}
function openAdminMetadataCreate(){
  const dialog=$('#adminMetadataDialog'),types=adminMetadataCatalog.document_types||[];$('#adminMetadataDocumentType').innerHTML=types.map(item=>`<option value="${esc(item.key)}">${esc(item.label)} · ${esc(item.key)}</option>`).join('');
  ['adminMetadataLabel','adminMetadataKey','adminMetadataDescription','adminMetadataTemplate','adminMetadataFieldSearch'].forEach(id=>$(`#${id}`).value='');delete $('#adminMetadataKey').dataset.touched;$('#adminMetadataActive').value='1';$('#adminMetadataCreateStatus').textContent='';loadCreateMetadataFields();dialog.showModal()
}
$('#adminMetadataAdd')?.addEventListener('click',openAdminMetadataCreate);
$('#adminMetadataDocumentType')?.addEventListener('change',loadCreateMetadataFields);
$('#adminMetadataFieldSearch')?.addEventListener('input',()=>filterMetadataFieldSelect($('#adminMetadataFieldSearch'),$('#adminMetadataField'),$('#adminMetadataField')._fields||[]));
$('#adminMetadataInsert')?.addEventListener('click',()=>insertMetadataField($('#adminMetadataTemplate'),$('#adminMetadataField')));
$('#adminMetadataLabel')?.addEventListener('input',()=>{const key=$('#adminMetadataKey');if(!key.dataset.touched)key.value=suggestedMetadataKey($('#adminMetadataLabel').value)});
$('#adminMetadataKey')?.addEventListener('input',event=>event.currentTarget.dataset.touched=event.currentTarget.value?'1':'');
$('#adminMetadataValidate')?.addEventListener('click',async()=>{const status=$('#adminMetadataCreateStatus');status.textContent='Перевірка…';try{const result=await request(`${API}/admin/document-metadata`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({...newMetadataPayload(),validate_only:true})});status.textContent=`Шаблон валідний. Поля: ${(result.used_fields||[]).join(', ')||'немає'}`}catch(error){status.textContent=error.message}});
$('#adminMetadataCreateSave')?.addEventListener('click',async event=>{const button=event.currentTarget,status=$('#adminMetadataCreateStatus');button.disabled=true;status.textContent='Збереження…';try{await request(`${API}/admin/document-metadata`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(newMetadataPayload())});$('#adminMetadataDialog').close();toast('Метадані документа створено');await loadAdminDocumentMetadata()}catch(error){status.textContent=error.message}finally{button.disabled=false}});
$('#adminTemplateSearch')?.addEventListener('input',filterAdminTemplates);
$('#adminMetadataSearch')?.addEventListener('input',filterAdminMetadata);
$('#adminTemplatesToggle')?.addEventListener('click',event=>setAdminConfigExpanded('adminTemplatesSection','adminTemplatesContent','adminTemplatesToggle',event.currentTarget.getAttribute('aria-expanded')!=='true'));
$('#adminMetadataToggle')?.addEventListener('click',event=>setAdminConfigExpanded('adminMetadataSection','adminMetadataContent','adminMetadataToggle',event.currentTarget.getAttribute('aria-expanded')!=='true'));
async function replaceAdminTemplate(){const input=$('#adminTemplateFile'),file=input.files[0],key=input.dataset.templateKey;if(!file||!key)return;try{const bytes=new Uint8Array(await file.arrayBuffer());let binary='';for(let i=0;i<bytes.length;i+=32768)binary+=String.fromCharCode(...bytes.subarray(i,i+32768));await request(`${API}/admin/templates/${encodeURIComponent(key)}/replace`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({filename:file.name,content:btoa(binary)})});toast('Шаблон перевірено та замінено');await loadAdminTemplates()}catch(error){toast(error.message)}finally{input.value='';delete input.dataset.templateKey}}
let adminTab=(()=>{try{return localStorage.getItem('pqm.adminTab')||'frameworks'}catch{return'frameworks'}})();
async function setAdminTab(name){if(!['frameworks','remarks','templates','sync','officers','navigation'].includes(name))name='frameworks';adminTab=name;try{localStorage.setItem('pqm.adminTab',name)}catch{}$$('[data-admin-tab]').forEach(b=>b.classList.toggle('active',b.dataset.adminTab===name));['Frameworks','Remarks','Templates','Sync','Officers','Navigation'].forEach(panel=>{$(`#admin${panel}Panel`).hidden=panel.toLowerCase()!==name});await authReady;if(name==='frameworks')loadAdminFrameworks();else if(name==='remarks')loadReferenceRemarks();else if(name==='templates')loadAdminTemplates();else if(name==='sync'){loadBidsSyncStatus();loadPowerbiStatus();loadRuntimeFeatures()}else if(name==='navigation'&&window.loadNavigationEditor)window.loadNavigationEditor();else loadAdminOfficers()}
async function loadSupplierEdrStatus(){
  try{
    const data=await request(`${API}/supplier-edr-sync-status?t=${Date.now()}`),state=data.state||{},last=data.last,oauth=data.oauth||{};
    supplierEdrOauth=oauth;
    const button=$('#supplierEdrSync');
    button.removeAttribute('aria-busy');
    button.textContent=!oauth.enabled?'Google вимкнено':oauth.client_state==='access_denied'?'Немає доступу до OAuth':!oauth.configured?'Потрібен OAuth Client ID':!oauth.authorized?'Підключити Google':'Перевірити зміни ЄДР';
    button.disabled=Boolean(state.running)||!oauth.enabled||!oauth.configured;
    button.title=!oauth.enabled?'Google integration вимкнено':oauth.authorized?'Імпортує дані з Google Sheets; не запускає нову перевірку в ЄДР':'';
    const monitoringButton=$('#edrMonitoringSync');
    if(monitoringButton){monitoringButton.disabled=Boolean(state.running)||!oauth.enabled||!oauth.configured;monitoringButton.textContent=!oauth.enabled?'Google вимкнено':!oauth.configured?'Потрібен OAuth Client ID':supplierEdrReconnectRequired?'Повторно підключити Google':!oauth.authorized?'Підключити Google':'Синхронізувати дані ЄДР';monitoringButton.title=button.title}
    $('#supplierEdrSyncStatus').textContent=oauth.message||(!oauth.configured
      ?'OAuth client config відсутній.'
      :!oauth.authorized?'OAuth налаштовано · потрібно один раз увійти через Google'
      :state.running?(state.message||'Синхронізація триває…')
      :last?`Довідник ЄДР: ${Number(data.total||0).toLocaleString('uk-UA')} записів · остання синхронізація ${displayDate(last.finished_at||last.started_at)} · ${last.status==='completed'?'успішно':'помилка'}`
      :'Google підключено · довідник ЄДР ще не синхронізовано');
    return {...state,oauth};
  }catch(error){console.error('Supplier EDR status request failed',error);$('#supplierEdrSyncStatus').textContent='Не вдалося отримати стан синхронізації ЄДР. Основна база постачальників залишається доступною.';return{}}
}
async function connectSupplierGoogle(){
  const popup=window.open('about:blank','pqm-google-oauth','width=620,height=760');
  if(!popup){toast('Браузер заблокував вікно входу. Дозвольте спливаючі вікна для цієї адреси PQM');return}
  popup.document.write('<meta charset="utf-8"><body style="font:16px system-ui;padding:32px">Підготовка безпечного входу Google…</body>');
  popup.document.close();
  try{
    const data=await request(`${API}/google-oauth/start`,{method:'POST',headers:{'Content-Type':'application/json'},body:'{}'});
    popup.location.href=data.authorization_url;
  }catch(error){popup.document.body.innerHTML=`<h2>Не вдалося відкрити Google</h2><p>${esc(error.message)}</p>`;toast(error.message)}
}
let supplierEdrTimer=null,supplierEdrPreview=null,supplierEdrReconnectRequired=false;
let supplierEdrReviewCategory='all',supplierEdrReviewSearch='',supplierEdrReviewPage=1;
const supplierEdrMetricLabels={total_rows:'Всього рядків',matched:'Зіставлено',unmatched:'Не зіставлено',legacy_ineligible:'Legacy/ineligible',eligible:'Готові до застосування',skipped:'Пропущено без бізнес-змін',conflict:'Конфлікти',skipped_unverified_timestamp:'Пропущено без точного timestamp',skipped_ineligible:'Пропущено: не відповідає умовам',changed_suppliers:'Постачальники зі змінами',no_op_suppliers:'Без змін',blocked_suppliers:'Заблоковано',malformed_blocked:'Інші некоректні дані',newer_verification_accepted:'Новіший timestamp Google',same_date_same_officer_equivalent:'Той самий timestamp й УО',same_datetime_officer_preserved:'Той самий timestamp; зміни УО не прийняті',older_verification_preserved:'Старіша Google перевірка без змін',blank_verification_preserved:'Порожня дата — пропущено',date_only_verification_preserved:'Історична дата без часу — пропущено',current_date_only_same_day_blocked:'Дата PQM без часу — потрібен пізніший день',initial_verification_accepted:'Перша перевірка',manager_identity_changes:'Реальні зміни керівника',manager_representation_enrichments:'Уточнення ПІБ',manager_reestablishments:'Відновлено відомого керівника',newly_established_managers:'Вперше встановлено керівника',manager_removals:'Підтверджені видалення керівника',edr_status_changes:'Зміна статусу ЄДР',full_name_changes:'Зміна повної назви',short_name_changes:'Зміна скороченої назви',current_supplier_name_changes:'Зміна current supplier name',verification_event_changes:'Зміна verification event',google_mirror_updates:'Оновлення G/J/K/M',google_mirror_clears:'Очищення G/J/K/M',termination_changes:'Очищення/зміна припинення',factual_status_protected:'Фактичний статус захищено',conflicts:'Конфлікти'};
async function previewSupplierEdrSync(){
  const button=$('#supplierEdrSync');button.disabled=true;
  try{
    button.textContent='Формування preview…';
    const data=await request(`${API}/supplier-edr-sync/preview`,{method:'POST',headers:{'Content-Type':'application/json'},body:'{}'});
    supplierEdrPreview=data;
    const metrics=Object.entries(supplierEdrMetricLabels).map(([key,label])=>`<article><span>${esc(label)}</span><strong>${Number(data.summary?.[key]||0).toLocaleString('uk-UA')}</strong></article>`).join('');
    const conflicts=Number(data.conflicts_total||0);
    $('#supplierEdrPreviewBody').innerHTML=`<div class="edr-preview-grid">${metrics}</div><p><strong>Fingerprint:</strong> <code>${esc(data.source_fingerprint)}</code></p>${conflicts?`<p class="sync-note error">Apply заблоковано: ${conflicts.toLocaleString('uk-UA')} конфліктів. Перегляньте source data.</p>`:'<p class="sync-note success">Конфліктів немає. Apply можливий лише після явного підтвердження.</p>'}`;
    if(Array.isArray(data.details)&&data.details_complete===true){
      supplierEdrReviewCategory='all';supplierEdrReviewSearch='';supplierEdrReviewPage=1;
      $('#supplierEdrPreviewBody').insertAdjacentHTML('beforeend',`<section class="edr-review-section"><h3>Деталі змін</h3><p>${Number(data.details_total||0).toLocaleString('uk-UA')} деталей · повний список, показано сторінками</p><div class="edr-review-filters"><label>Категорія <select id="supplierEdrReviewCategory"><option value="all">Усі зміни</option><option value="skipped">Пропущені рядки</option><option value="edr_status">Статус ЄДР</option><option value="verification">Перевірка I/L</option><option value="names_manager">Назви / керівник</option><option value="gjkm">G/J/K/M</option><option value="clears">Очищення</option><option value="conflicts">Конфлікти</option></select></label><label>Пошук за кодом або назвою <input id="supplierEdrReviewSearch" type="search"></label></div><div id="supplierEdrReviewRows"></div><nav class="edr-review-pages"><button id="supplierEdrReviewPrev" type="button">←</button><span id="supplierEdrReviewPageInfo"></span><button id="supplierEdrReviewNext" type="button">→</button></nav></section>`);
      $('#supplierEdrReviewCategory').onchange=e=>{supplierEdrReviewCategory=e.target.value;supplierEdrReviewPage=1;renderSupplierEdrReviewDetails()};
      $('#supplierEdrReviewSearch').oninput=e=>{supplierEdrReviewSearch=e.target.value.trim().toLocaleLowerCase('uk-UA');supplierEdrReviewPage=1;renderSupplierEdrReviewDetails()};
      $('#supplierEdrReviewPrev').onclick=()=>{supplierEdrReviewPage--;renderSupplierEdrReviewDetails()};
      $('#supplierEdrReviewNext').onclick=()=>{supplierEdrReviewPage++;renderSupplierEdrReviewDetails()};
      renderSupplierEdrReviewDetails();
    }
    $('#supplierEdrPreviewApply').disabled=conflicts>0||!Array.isArray(data.details)||!data.details_complete||!data.state_digest;
    $('#supplierEdrPreviewDialog').showModal();
  }catch(error){
    if(error.phase==='oauth_token_refresh'&&error.google_error==='invalid_grant'){
      supplierEdrReconnectRequired=true;
      toast('Підключення Google потребує повторної авторизації. Натисніть «Повторно підключити Google».','error');
    }else toast(error.message);
  }finally{await loadSupplierEdrStatus()}
}
function renderSupplierEdrReviewDetails(){
  if(!Array.isArray(supplierEdrPreview?.details))return;
  const size=25,category=supplierEdrReviewCategory,query=supplierEdrReviewSearch;
  const rows=supplierEdrPreview.details.filter(row=>(category==='all'||row.category===category||category==='clears'&&row.action==='clear')&&(!query||String(row.supplier_code||'').toLocaleLowerCase('uk-UA').includes(query)||String(row.supplier_name||'').toLocaleLowerCase('uk-UA').includes(query)));
  const pages=Math.max(1,Math.ceil(rows.length/size));supplierEdrReviewPage=Math.min(pages,Math.max(1,supplierEdrReviewPage));
  const current=rows.slice((supplierEdrReviewPage-1)*size,supplierEdrReviewPage*size);
  const value=x=>esc(typeof x==='object'?JSON.stringify(x):String(x??''));
  $('#supplierEdrReviewRows').innerHTML=current.map(row=>`<article class="edr-review-row"><strong>${esc(row.supplier_code)} · ${esc(row.supplier_name||'')}</strong><small>${esc(row.field)} · ${esc(row.action)} · ${esc(typeof row.reason==='string'?row.reason:JSON.stringify(row.reason))}</small><dl><div><dt>Поточне PQM</dt><dd>${value(row.current_pqm_value)}</dd></div><div><dt>Google</dt><dd>${value(row.google_value)}</dd></div><div><dt>План PQM</dt><dd>${value(row.planned_pqm_value)}</dd></div></dl></article>`).join('')||'<p>За цим фільтром змін немає.</p>';
  $('#supplierEdrReviewPageInfo').textContent=`${rows.length} результатів · сторінка ${supplierEdrReviewPage} з ${pages}`;
  $('#supplierEdrReviewPrev').disabled=supplierEdrReviewPage===1;
  $('#supplierEdrReviewNext').disabled=supplierEdrReviewPage===pages;
}
async function startSupplierEdrSync(){
  try{
    if(!supplierEdrPreview?.source_fingerprint)throw new Error('Спочатку виконайте preview');
    if(!window.confirm('Застосувати саме показаний preview Google → PQM?'))return;
    $('#supplierEdrSync').disabled=true;
    await request(`${API}/supplier-edr-sync`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({confirmed:true,source_fingerprint:supplierEdrPreview.source_fingerprint,state_digest:supplierEdrPreview.state_digest})});
    $('#supplierEdrPreviewDialog').close();supplierEdrPreview=null;
    $('#supplierEdrSyncStatus').textContent='Синхронізацію довідника ЄДР розпочато…';
    clearInterval(supplierEdrTimer);
    supplierEdrTimer=setInterval(async()=>{
      const state=await loadSupplierEdrStatus();
      if(!state.running){
        clearInterval(supplierEdrTimer);supplierEdrTimer=null;
        toast(state.error?'Синхронізація ЄДР завершилася з помилкою':'Довідник постачальників з ЄДР оновлено');
        try{await loadQualifiedSuppliersFiltered()}catch{}
        if(activeModule==='edrMonitoring')try{await loadEdrMonitoring()}catch{}
      }
    },2000);
  }catch(error){$('#supplierEdrSync').disabled=false;toast(error.message)}
}

function edrMonitoringParams(){return{search:$('#edrMonitoringSearch').value.trim(),dk_code:$('#edrMonitoringDk').value.trim(),entity_type:$('#edrMonitoringType').value,prozorro_status:[...edrMonitoringStatusSelections.prozorro_status].join(','),edr_status:[...edrMonitoringStatusSelections.edr_status].join(','),edr_names:$('#edrMonitoringNames').value,freshness:$('#edrMonitoringFreshness').value,verification_from:$('#edrMonitoringVerifiedFrom').value,verification_to:$('#edrMonitoringVerifiedTo').value,application_from:$('#edrMonitoringApplicationFrom').value,application_to:$('#edrMonitoringApplicationTo').value,sort:edrMonitoringSort,direction:edrMonitoringDirection,page:String(edrMonitoringPage),size:'100'}}
const edrMonitoringBaseParams=edrMonitoringParams;
edrMonitoringParams=function(){return{...edrMonitoringBaseParams(),edr_full_name:$('#edrMonitoringFullName').value,edr_short_name:$('#edrMonitoringShortName').value}};
const edrMonitoringStorageKey='pqm.edrMonitoringFilters.v1';
const edrMonitoringPersistedKeys=['search','dk_code','entity_type','edr_names','edr_full_name','edr_short_name','freshness','verification_from','verification_to','application_from','application_to'];
const edrMonitoringControls={search:'edrMonitoringSearch',dk_code:'edrMonitoringDk',entity_type:'edrMonitoringType',edr_names:'edrMonitoringNames',edr_full_name:'edrMonitoringFullName',edr_short_name:'edrMonitoringShortName',freshness:'edrMonitoringFreshness',verification_from:'edrMonitoringVerifiedFrom',verification_to:'edrMonitoringVerifiedTo',application_from:'edrMonitoringApplicationFrom',application_to:'edrMonitoringApplicationTo'};
function saveEdrMonitoringFilters(){try{const values=Object.fromEntries(edrMonitoringPersistedKeys.map(key=>[key,$(`#${edrMonitoringControls[key]}`).value]));localStorage.setItem(edrMonitoringStorageKey,JSON.stringify({...values,prozorro_status:[...edrMonitoringStatusSelections.prozorro_status],edr_status:[...edrMonitoringStatusSelections.edr_status],sort:edrMonitoringSort,direction:edrMonitoringDirection}))}catch{}}
function restoreEdrMonitoringFilters(){try{const state=JSON.parse(localStorage.getItem(edrMonitoringStorageKey)||'null');if(!state||typeof state!=='object')return;edrMonitoringPersistedKeys.forEach(key=>{const control=$(`#${edrMonitoringControls[key]}`);if(control&&typeof state[key]==='string')control.value=state[key]});for(const key of ['prozorro_status','edr_status'])if(Array.isArray(state[key]))edrMonitoringStatusSelections[key]=new Set(state[key].filter(value=>typeof value==='string'));edrMonitoringSort=state.sort||edrMonitoringSort;edrMonitoringDirection=state.direction==='desc'?'desc':'asc'}catch{try{localStorage.removeItem(edrMonitoringStorageKey)}catch{}}}
restoreEdrMonitoringFilters();
function edrMonitoringExportUrl(){const params=new URLSearchParams({...edrMonitoringParams(),type:'ALL',mode:'filtered',view:'edr_monitoring'});params.delete('page');params.delete('size');return`${API}/supplier-edr-export?${params}`}
const edrMonitoringFilterLabels={search:'Пошук',dk_code:'Код ДК',entity_type:'Тип',prozorro_status:'Статус Prozorro',edr_status:'Статус ЄДР',edr_names:'Назви ЄДР',freshness:'Актуальність',verification_from:'Перевірено від',verification_to:'Перевірено до',application_from:'Остання заявка від',application_to:'Остання заявка до'};
Object.assign(edrMonitoringFilterLabels,{edr_full_name:'Повна назва з ЄДР',edr_short_name:'Скорочена назва з ЄДР'});
function updateEdrMonitoringMultiSummary(id,selection){const summary=$(`#${id} summary`);if(!summary)return;summary.textContent=!selection.size?'Усі':selection.size===1?[...selection][0]:`Вибрано: ${selection.size}`}
function bindEdrMonitoringStatusMulti(id,key){const details=$(`#${id}`),selection=edrMonitoringStatusSelections[key];details.querySelectorAll('input[type="checkbox"]').forEach(input=>{input.checked=selection.has(input.value);input.onchange=()=>{input.checked?selection.add(input.value):selection.delete(input.value);updateEdrMonitoringMultiSummary(id,selection);edrMonitoringPage=1;updateEdrMonitoringFilters();loadEdrMonitoring()}});updateEdrMonitoringMultiSummary(id,selection)}
function renderEdrMonitoringEdrStatuses(values){const panel=$('#edrMonitoringEdr .multi-panel');panel.innerHTML=(values||[]).map(value=>`<label><input type="checkbox" value="${esc(value)}"> ${esc(displayEdrStatus(value))}</label>`).join('');bindEdrMonitoringStatusMulti('edrMonitoringEdr','edr_status')}
function clearEdrMonitoringFilter(key,statusValue=''){if(edrMonitoringStatusSelections[key]){statusValue?edrMonitoringStatusSelections[key].delete(statusValue):edrMonitoringStatusSelections[key].clear();bindEdrMonitoringStatusMulti(key==='prozorro_status'?'edrMonitoringProzorro':'edrMonitoringEdr',key)}else{const controls={search:'#edrMonitoringSearch',dk_code:'#edrMonitoringDk',entity_type:'#edrMonitoringType',edr_names:'#edrMonitoringNames',freshness:'#edrMonitoringFreshness',verification_from:'#edrMonitoringVerifiedFrom',verification_to:'#edrMonitoringVerifiedTo',application_from:'#edrMonitoringApplicationFrom',application_to:'#edrMonitoringApplicationTo'};if(controls[key])$(controls[key]).value=''}edrMonitoringPage=1;updateEdrMonitoringFilters();loadEdrMonitoring()}
function edrMonitoringFilterDisplay(key,value){const controls={entity_type:'#edrMonitoringType',edr_names:'#edrMonitoringNames',freshness:'#edrMonitoringFreshness'},select=controls[key]?$(controls[key]):null;return select?.selectedOptions?.[0]?.textContent||value}
const edrMonitoringFilterDisplayBase=edrMonitoringFilterDisplay;
edrMonitoringFilterDisplay=function(key,value){if(key==='edr_full_name'||key==='edr_short_name'){const control=$(`#${edrMonitoringControls[key]}`);return control.selectedOptions[0]?.textContent||value}return edrMonitoringFilterDisplayBase(key,value)};
function updateEdrMonitoringFilters(){const params=edrMonitoringParams(),statusKeys=['prozorro_status','edr_status'],baseKeys=Object.keys(edrMonitoringFilterLabels).filter(key=>!statusKeys.includes(key)),baseActive=baseKeys.filter(key=>params[key]),statusChips=statusKeys.flatMap(key=>[...edrMonitoringStatusSelections[key]].map(value=>({key,value}))),advanced=['entity_type','edr_names','freshness','verification_from','verification_to','application_from','application_to'],count=advanced.filter(key=>params[key]).length+statusChips.length,activeCount=baseActive.length+statusChips.length;$('#edrMonitoringFilterSummary').textContent=count?`Фільтри · ${count}`:'Фільтри';$('#edrMonitoringReset').hidden=!activeCount;const chips=$('#edrMonitoringChips');chips.hidden=!activeCount;chips.innerHTML=baseActive.map(key=>`<button type="button" data-edr-filter-remove="${key}"><span>${esc(edrMonitoringFilterLabels[key])}: ${esc(edrMonitoringFilterDisplay(key,params[key]))}</span> ×</button>`).join('')+statusChips.map(({key,value})=>`<button type="button" data-edr-filter-remove="${key}" data-edr-filter-value="${esc(value)}"><span>${esc(edrMonitoringFilterLabels[key])}: ${esc(value)}</span> ×</button>`).join('')+(activeCount?'<button type="button" data-edr-filter-clear="all">Очистити всі</button>':'');chips.querySelectorAll('[data-edr-filter-remove]').forEach(button=>button.onclick=()=>clearEdrMonitoringFilter(button.dataset.edrFilterRemove,button.dataset.edrFilterValue||''));const clear=chips.querySelector('[data-edr-filter-clear]');if(clear)clear.onclick=()=>$('#edrMonitoringReset').click();syncSharedFilterPresentation($('#edrMonitoringView'))}
const clearEdrMonitoringFilterBase=clearEdrMonitoringFilter;
clearEdrMonitoringFilter=function(key,statusValue=''){if(key==='edr_full_name'||key==='edr_short_name'){$(`#${edrMonitoringControls[key]}`).value='';edrMonitoringPage=1;updateEdrMonitoringFilters();loadEdrMonitoring();return}return clearEdrMonitoringFilterBase(key,statusValue)};
function applyEdrMonitoringColumns(){/* handled by the shared table_widths_ui component */}
const updateEdrMonitoringFiltersBeforeStatusLabels=updateEdrMonitoringFilters;
updateEdrMonitoringFilters=function(){
  updateEdrMonitoringFiltersBeforeStatusLabels();
  $$('#edrMonitoringChips [data-edr-filter-remove="edr_status"]').forEach(button=>{
    const label=button.querySelector('span');if(label)label.textContent=`Статус ЄДР: ${displayEdrStatus(button.dataset.edrFilterValue)}`;
  });
  const selection=edrMonitoringStatusSelections.edr_status;
  if(selection.size===1)$('#edrMonitoringEdr summary').textContent=displayEdrStatus([...selection][0]);
  const extra=Number(Boolean($('#edrMonitoringFullName').value))+Number(Boolean($('#edrMonitoringShortName').value));
  if(extra){const count=Number($('#edrMonitoringFilterSummary').textContent.match(/\d+/)?.[0]||0)+extra;$('#edrMonitoringFilterSummary').textContent=`Фільтри · ${count}`}
};
function updateEdrMonitoringSelection(){const selected=edrMonitoringSelected.size;$('#edrMonitoringCounts').textContent=`Знайдено: ${edrMonitoringTotal.toLocaleString('uk-UA')} · Вибрано: ${selected.toLocaleString('uk-UA')}`;const exportButton=$('#edrMonitoringExport');exportButton.textContent=`Експорт для ClarityChecker · ${(selected||edrMonitoringTotal).toLocaleString('uk-UA')}`;exportButton.href=edrMonitoringExportUrl();const createButton=$('#edrMonitoringCreateTermination');if(createButton){createButton.hidden=!selected;createButton.textContent=`Створити задачі на виключення · ${selected.toLocaleString('uk-UA')}`}const pageCodes=edrMonitoringItems.map(item=>String(item.supplier_code)),onPage=pageCodes.filter(code=>edrMonitoringSelected.has(code)).length,checkbox=$('#edrMonitoringSelectPage');checkbox.checked=Boolean(pageCodes.length)&&onPage===pageCodes.length;checkbox.indeterminate=onPage>0&&onPage<pageCodes.length;updateEdrMonitoringFilters()}
function decorateEdrMonitoringRows(){
  $$('#edrMonitoringBody td[colspan="12"]').forEach(cell=>cell.colSpan=14);
  const rows=$$('#edrMonitoringBody tr[data-edr-code]');
  rows.forEach((row,index)=>{
    const item=edrMonitoringItems[index];if(!item)return;
    const manager=row.querySelector('[data-edr-column="manager_name"]');
    if(manager&&!row.querySelector('[data-edr-column="edr_full_name"]')){
      for(const [field,value] of [['edr_full_name',item.edr_full_name],['edr_short_name',item.edr_short_name]]){
        const cell=document.createElement('td');cell.dataset.edrColumn=field;
        cell.textContent=String(value||'').trim()||'—';row.insertBefore(cell,manager);
      }
    }
    const status=row.querySelector('[data-edr-column="edr_status"]');
    if(status)status.textContent=displayEdrStatus(item.edr_status);
    const termination=row.querySelector('[data-edr-column="termination_details"]');
    if(termination)termination.textContent=formatEdrTerminationDetails(item)||'—';
    const cell=row.querySelector('[data-edr-column="supplier_code"]');
    if(!cell||!item.supplier_card_available||cell.querySelector('.supplier-card-action'))return;
    installSupplierCodeAction(cell,()=>openSupplierProfile(String(item.supplier_code)));
  });
}
const updateEdrMonitoringSelectionBase=updateEdrMonitoringSelection;
updateEdrMonitoringSelection=function(){decorateEdrMonitoringRows();return updateEdrMonitoringSelectionBase()};

async function previewTerminationExclusions(){
 const codes=[...edrMonitoringSelected].sort();if(!codes.length)return;
 const dialog=$('#terminationExclusionDialog'),body=$('#terminationExclusionPreview'),confirmButton=$('#terminationExclusionConfirm');
 body.innerHTML='<p>Перевірка вибраних постачальників…</p>';confirmButton.disabled=true;dialog.showModal();
 try{
  const preview=await request(`${API}/edr-monitoring/termination-exclusions/preview`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({supplier_codes:codes})});
  body.innerHTML=`<dl class="operational-facts"><div><dt>Вибрано</dt><dd>${preview.selected}</dd></div><div><dt>Відповідають умовам</dt><dd>${preview.eligible}</dd></div><div><dt>Буде створено задач</dt><dd>${preview.to_create}</dd></div><div><dt>Пропущено</dt><dd>${preview.skipped}</dd></div></dl>${preview.items.map(x=>`<p><strong>${esc(x.supplier_name||x.supplier_code)}</strong> · ${esc(x.supplier_code)} — ${esc((x.reasons&&x.reasons.length?x.reasons:[x.reason_label]).join(' · '))}${x.active_qualifications?` · кваліфікацій: ${x.active_qualifications}`:''}</p>`).join('')}`;
  confirmButton.disabled=!preview.to_create;confirmButton.onclick=async()=>{confirmButton.disabled=true;try{const result=await request(`${API}/edr-monitoring/termination-exclusions/create`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({supplier_codes:codes,confirmed:true})});toast(`Створено задач: ${result.created}`,'success');edrMonitoringSelected.clear();dialog.close();await loadEdrMonitoring();await loadOperationalTasks()}catch(error){toast(error.message,'error');confirmButton.disabled=false}};
 }catch(error){body.innerHTML=`<p class="request-warning">${esc(error.message)}</p>`}
}
const edrFreshnessLabels={not_current:'🟣 Неактуально',lt30:'🟢 <30 днів',gt30:'🟡 >30 днів',gt60:'🟠 >60 днів',gt90:'🔴 >90 днів',not_checked:'⚪ Не перевірено'};
function formatEdrTerminationDetails(item){const detail=String(item.termination_details||'').trim().replace(/(?<!,)\s+Запис №/u,', Запис №');const date=String(item.termination_record_date||'').trim(),localized=/^\d{4}-\d{2}-\d{2}$/.test(date)?`${date.slice(8,10)}.${date.slice(5,7)}.${date.slice(0,4)}`:'';const extras=[date,item.termination_record_number].map(value=>String(value||'').trim()).filter(value=>value&&!detail.includes(value)&&(value!==date||!localized||!detail.includes(localized)));return[detail,...extras].filter(Boolean).join(' · ')}
function openGoogleNote(item){$('#googleNoteSubtitle').textContent=`${item.supplier_name||''} · ${item.supplier_code||''}`;$('#googleNoteText').textContent=item.google_note||'';$('#googleNoteDialog').showModal()}
async function edrMonitoringLatestResponse(){saveEdrMonitoringFilters();const sequence=++edrMonitoringLoadSequence,query=new URLSearchParams(edrMonitoringParams()).toString();try{const data=await request(`${API}/edr-monitoring?${query}`);return sequence===edrMonitoringLoadSequence&&query===new URLSearchParams(edrMonitoringParams()).toString()?data:null}catch(error){if(sequence!==edrMonitoringLoadSequence||query!==new URLSearchParams(edrMonitoringParams()).toString())return null;throw error}}
async function loadEdrMonitoring(){const body=$('#edrMonitoringBody');body.innerHTML='<tr><td colspan="12">Завантаження…</td></tr>';const started=performance.now();try{const data=await edrMonitoringLatestResponse();if(!data)return;edrMonitoringItems=data.items||[];edrMonitoringTotal=Number(data.total||0);edrMonitoringPages=Math.max(1,Number(data.pages||1));if(edrMonitoringPage>edrMonitoringPages){edrMonitoringPage=edrMonitoringPages;return loadEdrMonitoring()}renderEdrMonitoringEdrStatuses(data.edr_statuses||[]);$$('#edrMonitoringKpis button strong').forEach(target=>target.textContent='0');Object.entries(data.kpis||{}).forEach(([key,value])=>{const target=$(`#edrMonitoringKpis [data-freshness="${key}"] strong`);if(target)target.textContent=Number(value||0).toLocaleString('uk-UA')});$$('#edrMonitoringKpis button').forEach(button=>button.classList.toggle('active',button.dataset.freshness===$('#edrMonitoringFreshness').value));$$('#edrMonitoringView [data-edr-sort]').forEach(header=>{header.classList.toggle('active-sort',header.dataset.edrSort===edrMonitoringSort);header.dataset.direction=header.dataset.edrSort===edrMonitoringSort?edrMonitoringDirection:''});body.innerHTML=edrMonitoringItems.map(item=>{const termination=[item.termination_details,item.termination_record_date,item.termination_record_number].filter(Boolean).join(' · '),note=item.google_note?`<button type="button" class="edr-supplier-note" title="${esc(item.google_note)}" aria-label="Примітка з Google">📝</button>`:'';return`<tr data-edr-code="${esc(item.supplier_code)}"><td data-edr-column="selected"><input class="edr-monitoring-check" type="checkbox" ${edrMonitoringSelected.has(String(item.supplier_code))?'checked':''} aria-label="Вибрати ${esc(item.supplier_code)}"></td><td data-edr-column="freshness"><span class="edr-freshness ${esc(item.freshness)}">${esc(edrFreshnessLabels[item.freshness]||edrFreshnessLabels.not_checked)}</span></td><td data-edr-column="supplier_code">${esc(item.supplier_code)}</td><td data-edr-column="supplier_name"><span class="supplier-name-with-note">${esc(item.supplier_name)||'—'}${note}</span></td><td data-edr-column="manager_name">${esc(item.manager_name)||'—'}</td><td data-edr-column="edr_status">${esc(item.edr_status)||'—'}</td><td data-edr-column="prozorro_status">${esc(item.prozorro_status)}</td><td data-edr-column="termination_details">${esc(termination)||'—'}</td><td data-edr-column="latest_application_date">${esc(displayDateOnly(item.latest_application_date))||'—'}</td><td data-edr-column="verification_date">${esc(displayDateOnly(item.verification_date))||'—'}</td><td data-edr-column="verification_officer">${esc(item.verification_officer)||'—'}</td><td data-edr-column="google_note"><span class="source-note-text">${esc(item.google_note)||'—'}</span></td></tr>`}).join('')||'<tr><td colspan="12">За вибраними умовами постачальників не знайдено</td></tr>';body.querySelectorAll('.edr-monitoring-check').forEach(input=>input.onchange=event=>{const code=event.target.closest('tr').dataset.edrCode;event.target.checked?edrMonitoringSelected.add(code):edrMonitoringSelected.delete(code);updateEdrMonitoringSelection()});body.querySelectorAll('.edr-supplier-note').forEach(button=>button.onclick=event=>{event.stopPropagation();const item=edrMonitoringItems.find(value=>String(value.supplier_code)===event.target.closest('tr').dataset.edrCode);openGoogleNote(item)});const from=edrMonitoringTotal?(edrMonitoringPage-1)*100+1:0,to=Math.min(edrMonitoringPage*100,edrMonitoringTotal);$('#edrMonitoringPageInfo').textContent=`Показано ${from}–${to} із ${edrMonitoringTotal.toLocaleString('uk-UA')} · сторінка ${edrMonitoringPage} із ${edrMonitoringPages} · ${Number(data.elapsed_ms||performance.now()-started).toLocaleString('uk-UA')} мс`;$('#edrMonitoringPrev').disabled=edrMonitoringPage<=1;$('#edrMonitoringNext').disabled=edrMonitoringPage>=edrMonitoringPages;applyEdrMonitoringColumns();updateEdrMonitoringSelection()}catch(error){body.innerHTML=`<tr><td colspan="12">${esc(error.message)}</td></tr>`}}
async function exportSelectedEdrMonitoring(){const response=await fetch(`${API}/supplier-edr-export`,{method:'POST',headers:{'Content-Type':'application/json','X-PQM-Local-Role':role()},body:JSON.stringify({supplier_codes:[...edrMonitoringSelected].sort()})});if(!response.ok){const body=await response.json().catch(()=>({}));throw new Error(body.error||`Помилка сервера ${response.status}`)}const blob=await response.blob(),url=URL.createObjectURL(blob),link=document.createElement('a');link.href=url;link.download='ClarityChecker_вибрані.csv';document.body.append(link);link.click();link.remove();URL.revokeObjectURL(url)}
let supplierNazkReviewTimer=null;
async function loadSupplierNazkReviewStatus(){
  try{const data=await request(`${API}/supplier-nazk-review-sync-status?t=${Date.now()}`),state=data.state||{},last=data.last,button=$('#supplierNazkReviewSync');
    button.removeAttribute('aria-busy');
    button.disabled=Boolean(state.running)||!Boolean(data.oauth?.enabled)||!Boolean(data.oauth?.configured);
    button.textContent=!data.oauth?.enabled?'Google вимкнено':!data.oauth?.configured?'Потрібен OAuth Client ID':!data.oauth?.authorized?'Підключити Google':'Синхронізувати перевірки НАЗК';
    button.title=!data.oauth?.enabled?'Google integration вимкнено':'';
    $('#supplierNazkReviewSyncStatus').textContent=!data.oauth?.enabled?(data.oauth?.message||'Google integration вимкнено'):data.oauth?.available===false?'Перевірки НАЗК Google Sheets недоступні через стан OAuth вище':state.running?(state.message||'Синхронізація триває…'):
      last?`Перевірки НАЗК: ${Number(data.total||0).toLocaleString('uk-UA')} записів · остання синхронізація ${displayDate(last.finished_at||last.started_at)} · ${last.status==='completed'?'успішно':'помилка'}`:
      'Перевірки НАЗК ще не синхронізовано';return {...state,oauth:data.oauth||{}}
  }catch(error){console.error('Supplier NACP status request failed',error);$('#supplierNazkReviewSyncStatus').textContent='Не вдалося отримати стан синхронізації перевірок НАЗК. Основна база постачальників залишається доступною.';return{}}
}
async function startSupplierNazkReviewSync(){
  try{$('#supplierNazkReviewSync').disabled=true;await request(`${API}/supplier-nazk-review-sync`,{method:'POST',headers:{'Content-Type':'application/json'},body:'{}'});clearInterval(supplierNazkReviewTimer);
    supplierNazkReviewTimer=setInterval(async()=>{const state=await loadSupplierNazkReviewStatus();if(!state.running){clearInterval(supplierNazkReviewTimer);supplierNazkReviewTimer=null;toast(state.error?'Синхронізація перевірок НАЗК завершилася з помилкою':'Перевірки НАЗК оновлено');try{await loadQualifiedSuppliersFiltered()}catch{}}},2000)
  }catch(error){$('#supplierNazkReviewSync').disabled=false;toast(error.message)}
}
$('#searchInput').oninput=()=>{clearTimeout(searchTimer);searchTimer=setTimeout(()=>{page=1;loadRows()},350)};
restoreFilterState();
bindStaticMulti('statusFilter',filterSelections.status,'Статус');bindStaticMulti('marketplaceDecisionFilter',filterSelections.marketplace,'Дія на майданчику',value=>marketplaceFilterLabels[value]||value);bindStaticMulti('registryStatusFilter',filterSelections.registry,'Будь-який стан у відборі');
$('#supplierCodeFilter .multi-search').oninput=()=>{clearTimeout(searchTimer);searchTimer=setTimeout(loadSupplierOptions,300)};
$('#frameworkFilter .multi-search').oninput=()=>renderDynamicFilter('frameworkFilter',frameworkOptions,filterSelections.framework,item=>item.id,item=>`${item.pretty_id} · ${item.title||''} · ${item.applications_count}`,'Усі відбори');
$('#dkFilter .multi-search').oninput=()=>{const items=[...new Set(frameworkOptions.map(item=>item.dk_code).filter(Boolean))].sort().map(code=>({code}));renderDynamicFilter('dkFilter',items,filterSelections.dk,item=>item.code,item=>item.code,'Усі коди ДК')};
$('#dateFromFilter').onchange=$('#dateToFilter').onchange=()=>{page=1;loadRows()};
$('#protocolNumberFilter').onchange=$('#protocolDecisionFilter').onchange=$('#complianceStatusFilter').onchange=()=>{page=1;statsSignature='';loadRows()};
const decisionKpiValues={decision_yes:'admit',decision_no:'reject',decision_undefined:'__empty__'};
$$('.decision-kpi').forEach(card=>{
  const apply=()=>{const next=decisionKpiValues[card.dataset.kpiCard]||'';$('#protocolDecisionFilter').value=$('#protocolDecisionFilter').value===next?'':next;page=1;statsSignature='';loadRows()};
  card.onclick=apply;card.onkeydown=event=>{if(event.key==='Enter'||event.key===' '){event.preventDefault();apply()}};
});
$('#applicationCategoryFilter').onchange=()=>{categoryFilter=$('#applicationCategoryFilter').value;page=1;statsSignature='';loadRows()};
$('#applicationOfficerFilter').onchange=()=>{officerFilter=$('#applicationOfficerFilter').value;page=1;statsSignature='';loadRows()};
$('#clearFiltersBtn').onclick=()=>{clearApplicationDeepLinkFilter();$('#protocolNumberFilter').value='';$('#searchInput').value='';$('#dateFromFilter').value='';$('#dateToFilter').value='';$('#protocolDecisionFilter').value='';$('#complianceStatusFilter').value='';officerFilter='';categoryFilter='';syncPrimaryFilters();Object.values(filterSelections).forEach(selection=>selection.clear());$$('.multi-filter input[type="checkbox"]').forEach(input=>input.checked=false);updateMultiSummary('statusFilter','Статус',filterSelections.status);updateMultiSummary('marketplaceDecisionFilter','Дія на майданчику',filterSelections.marketplace,value=>marketplaceFilterLabels[value]||value);updateMultiSummary('registryStatusFilter','Будь-який стан у відборі',filterSelections.registry);loadFrameworks();loadSupplierOptions();page=1;loadRows()};
document.addEventListener('click',event=>{if(event.target.closest('#applicationsNav')&&activeModule!=='applications')clearApplicationDeepLinkFilter()},true);
$('#columnsBtn').onclick=columnsDialog;$('#bulkBtn').onclick=openBulk;$('#applyBulkBtn').onclick=applyBulk;$('#auditBtn').onclick=openAudit;$('#resetBtn').onclick=sync;
$('#saveProfileBtn').onclick=async()=>{const name=prompt('Назва персонального профілю:','Мій профіль');if(!name)return;try{const data=await request(`${API}/application-profiles`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({name,columns:profile().columns,kpis:profile().kpis,sorts:multiSort,source_system_profile_id:profile().is_system?profile().id:profile().source_system_profile_id})});activeProfileId=data.id;await loadProfiles();render();toast('Персональний профіль збережено')}catch(error){toast(error.message)}};
$('#createSystemProfileBtn').onclick=async()=>{const name=prompt('Назва системного профілю:','Новий системний профіль');if(!name)return;try{const data=await request(`${API}/application-profiles`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({name,is_system:true,columns:profile().columns,kpis:profile().kpis})});activeProfileId=data.id;await loadProfiles();render();toast('Системний профіль створено')}catch(error){toast(error.message)}};
$('#renameProfileBtn').onclick=async()=>{const p=profile();if(p.is_system&&currentMe?.role!=='admin')return toast('Системний профіль може змінювати лише адміністратор');const name=prompt('Нова назва профілю:',p.name);if(!name)return;try{await request(`${API}/application-profiles/${encodeURIComponent(p.id)}`,{method:'PATCH',headers:{'Content-Type':'application/json'},body:JSON.stringify({name,columns:p.columns,kpis:p.kpis})});await loadProfiles();toast('Профіль оновлено')}catch(error){toast(error.message)}};
$('#deleteProfileBtn').onclick=async()=>{const p=profile();if(!confirm(`Видалити профіль «${p.name}»?`))return;try{await request(`${API}/application-profiles/${encodeURIComponent(p.id)}`,{method:'DELETE'});activeProfileId='';await loadProfiles();render();toast('Профіль видалено')}catch(error){toast(error.message)}};
$('#restoreProfileBtn').onclick=async()=>{const p=profile(),source=profiles.find(x=>x.id===p.source_system_profile_id)||(p.is_system?p:null);if(!source)return toast('Для цього профілю не визначено системне джерело');p.columns=structuredClone(source.columns);p.kpis=[...(source.kpis||defaultKpis(source.name))];if(!p.is_system)await request(`${API}/application-profiles/${encodeURIComponent(p.id)}`,{method:'PATCH',headers:{'Content-Type':'application/json'},body:JSON.stringify({columns:p.columns,kpis:p.kpis,sorts:p.sorts||multiSort})});render();toast('Системне розташування інтерфейсу відновлено')};
$('#profileSelect').onchange=e=>{activeProfileId=e.target.value;saveProfiles();applyProfileSort();page=1;loadRows()};$('#clearAuditBtn').style.display='none';
$('#cardsBtn').onclick=cardsDialog;
$('#remarksSearch').oninput=renderRemarksCatalog;$('#addRemarkBtn').onclick=addRemarkTemplate;$('#refreshRemarksBtn').onclick=()=>loadRemarksCatalog(true);$('#saveRemarksBtn').onclick=saveRemarks;
$('#noRemarksBtn').onclick=()=>{$('#remarksPicker').hidden=true;remarksSelected.clear();$('#remarksPreview').value='Без зауважень';renderRemarksCatalog()};
$('#constructorRemarksBtn').onclick=()=>{$('#remarksPicker').hidden=false;renderRemarksCatalog()};
$('#clearRemarksBtn').onclick=()=>{remarksSelected.clear();$('#remarksPreview').value='';$('#remarksPicker').hidden=true;renderRemarksCatalog()};
$('#remarksCatalog').onclick=e=>{const edit=e.target.closest('.remark-edit'),disable=e.target.closest('.remark-disable');if(edit){e.preventDefault();editRemarkTemplate(edit.dataset.id)}if(disable){e.preventDefault();disableRemarkTemplate(disable.dataset.id)}};
$('#verifyDocumentsBtn').onclick=verifyDocuments;$('#rerunDocumentCheckBtn').onclick=verifyDocuments;
$('#protocolBtn').onclick=openProtocolDialog;$('#protocolForm').onsubmit=checkProtocol;$('#generateProtocolBtn').onclick=generateProtocol;
$('#clearFiltersBtn').addEventListener('click',()=>{officerFilter='';categoryFilter='';statsSignature=''},true);
let violationReports=[],requestsTimer,requestsPolling,selectedRequestAuthority='',requestsPage=1,requestsPages=1;
const requestStatusLabels={draft:'Чернетка',pending:'Очікує розгляду',answered:'Надано відповідь',satisfied:'Задоволено',declined:'Відхилено',declinedNoViolation:'Відхилено',cancelled:'Скасовано'};
const requestReasonLabels={contractBreach:'пп. 1 п. 49 — Непідписання договору/ненадання забезпечення в строк',signingRefusal:'пп. 2 п. 49 — Письмова відмова від укладення договору',goodsNonCompliance:'пп. 3 п. 49 — Невиконання зобов’язань за договором',supplierMisconduct:'Недобросовісна поведінка постачальника'};
const queueReasonLabels={contractBreach:'пп. 1 п. 49',signingRefusal:'пп. 2 п. 49',goodsNonCompliance:'пп. 3 п. 49'};
const violationReviewStatusLabels={not_reviewed:'Не розглянуто',in_review:'На розгляді',reviewed:'Розглянуто',completed:'Завершено'};
function queueReasonLabel(value){let result=String(value||'');for(const [technical,label] of Object.entries(queueReasonLabels))result=result.replace(new RegExp(`(^| · )${technical}(?=$| · )`,'g'),(_,prefix)=>`${prefix}${label}`);return result.split(' · ').join('\n')}
function requestLabel(value,map){return map[value]||value||'—'}
function requestDocumentLinks(documents){return (documents||[]).map(doc=>`<a href="${esc(doc.url)}" target="_blank" rel="noopener">${esc(doc.title||'Документ')}</a>`).join('<br>')||'—'}
function requestViolationUrl(item){return item.contract_pretty_id?`https://prozorro.gov.ua/uk/contract/${encodeURIComponent(item.contract_pretty_id)}/violation-reports${item.report_id?`#report-${encodeURIComponent(item.report_id)}`:''}`:''}
function requestBlockingBadge(item){const m=item.blocking_marker;if(!m?.used_for_blocking)return '';return `<small class="blocking-used-badge ${m.highlighting_active?'active':'historical'}" title="${esc(displayDateOnly(m.blocking_start_date))}–${esc(displayDateOnly(m.blocking_end_date))}">${m.highlighting_active?'Використано для блокування':'Було використано для блокування'}</small>`}
function requestTenderLinks(item){const links=[];if(item.tender_pretty_id)links.push(`<a href="https://prozorro.gov.ua/uk/tender/${encodeURIComponent(item.tender_pretty_id)}" target="_blank" rel="noopener">${esc(item.tender_pretty_id)}</a>`);if(item.contract_pretty_id)links.push(`<a href="https://prozorro.gov.ua/uk/contract/${encodeURIComponent(item.contract_pretty_id)}" target="_blank" rel="noopener">${esc(item.contract_pretty_id)}</a>`);const url=requestViolationUrl(item);if(url)links.push(`<a href="${url}" target="_blank" rel="noopener">${esc(item.report_id||'Звернення в Prozorro')}</a>`);return links.join('<br>')||'—'}
function requestAuthorityShortName(item){const name=item.authority_name||item.authority_code||'Адміністратор';if(item.authority_code==='40996564')return'Професійні закупівлі';if(/медичні закупівлі/i.test(name))return'МЗУ';if(/державний оператор тилу/i.test(name))return'ДОТ';if(/агенц.*оборонн.*закуп/i.test(name))return'АОЗ';if(/українські спеціальні системи/i.test(name))return'УСС';return name}
function renderRequestAuthorityCards(items){const box=$('#requestAuthorityCards');box.innerHTML=(items||[]).map(item=>`<button type="button" class="request-authority-card${selectedRequestAuthority===item.authority_code?' active':''}" data-authority-code="${esc(item.authority_code)}" title="${esc(item.authority_name)} · ${esc(item.authority_code)}"><span>${esc(requestAuthorityShortName(item))}</span><strong>${Number(item.count||0).toLocaleString('uk-UA')}</strong></button>`).join('');box.hidden=!box.children.length}
function requestDeadline(item){if(!item.defendant_period_end)return{html:'—',ready:true};const end=new Date(item.defendant_period_end),now=new Date(),ready=now>=end;if(ready)return{html:`<strong>${esc(displayDate(item.defendant_period_end))}</strong><small class="deadline-ready">Строк сплив — можна розглядати</small>`,ready:true};const ms=end-now,days=Math.floor(ms/86400000),hours=Math.floor((ms%86400000)/3600000);return{html:`<strong>${esc(displayDate(item.defendant_period_end))}</strong><small class="deadline-wait">Ще ${days?days+' дн. ':''}${hours} год. — розгляд недоступний</small>`,ready:false}}
function requestStatements(item){const statements=item.defendant_statements||[];if(!statements.length)return'<p class="muted">Пояснення постачальника не надано.</p>';return statements.map((statement,index)=>`<div class="request-statement"><p><strong>Пояснення ${statements.length>1?index+1:''}</strong>${statement.datePublished?` · ${esc(displayDate(statement.datePublished))}`:''}</p><div class="request-long-text">${esc(statement.description||'Текст відсутній').replaceAll('\n','<br>')}</div><div class="request-documents">${requestDocumentLinks(statement.documents)}</div></div>`).join('')}
function populateRequestSelect(id,values,labels,empty){const select=$(id),current=select.value;select.innerHTML=`<option value="">${empty}</option>`+(values||[]).map(value=>`<option value="${esc(value)}">${esc(requestLabel(value,labels))}</option>`).join('');select.value=current}
function requestStatusClass(value){return value==='declinedNoViolation'?'declined':value}
function requestScenarioCell(item,index){const summary=String(item.scenario_summary||'').trim().replace(/^Сценарій:\s*/i,'');const hasSavedJustification=Boolean(String(item.decision_justification||'').trim());return `<div class="request-scenario-cell"><span class="request-scenario-summary">${esc(summary||'—')}${item.scenario_context_source==='saved_facts'?`<small>Збережені факти · ${esc(displayDate(item.scenario_observed_at))}</small>`:''}</span>${hasSavedJustification?`<button type="button" class="ghost request-justification-view" data-view-justification="${index}" aria-label="Переглянути повне обґрунтування" title="Переглянути повне обґрунтування">👁</button>`:''}</div>`}
function showSavedRequestJustification(index){const item=violationReports[Number(index)],dialog=$('#requestJustificationDialog'),body=$('#requestJustificationBody');if(!dialog||!body)return;const text=String(item?.decision_justification||'').trim();$('#requestJustificationTitle').textContent=`Обґрунтування · ${item?.report_id||'Звернення'}`;body.textContent=text||'Обґрунтування для цього звернення ще не сформовано.';if(!dialog.open)dialog.showModal()}
function violationProtocolCell(item,index){const p=item.protocol_summary;if(!p)return '';return `<div class="request-protocol-cell"><div class="request-protocol-heading">${p.number?`<strong>№ ${esc(p.number)}${p.date?` · ${esc(displayDateOnly(p.date))}`:''}</strong>`:''}<a class="ghost button-link supplier-profile-icon" href="${esc(p.url)}" download title="Актуальний протокол рішення" aria-label="Завантажити актуальний протокол">📄</a></div>${p.officer?`<span>${esc(p.officer)}</span>`:''}<div class="request-protocol-copy">${p.askod?`<button type="button" class="ghost" data-protocol-askod="${index}">АСКОД</button>`:''}${p.json_ready?`<button type="button" class="ghost" data-protocol-json="${index}">JSON</button>`:''}</div></div>`}
async function loadViolationReports(){const sequence=loadViolationReports.sequence=(loadViolationReports.sequence||0)+1,moduleAtStart=typeof activeModule==='undefined'?null:activeModule;let queryKey='';const query=()=>new URLSearchParams({search:$('#requestsSearch').value.trim(),status:$('#requestsStatus').value,response_expired:globalThis.PqmUi?.responseExpired?'1':'',reason:$('#requestsReason').value,authority_code:selectedRequestAuthority,date_from:$('#requestsDateFrom').value,date_to:$('#requestsDateTo').value,page:String(requestsPage),size:'100'}),isCurrent=()=>sequence===loadViolationReports.sequence&&moduleAtStart===(typeof activeModule==='undefined'?null:activeModule)&&queryKey===query().toString();const body=$('#requestsBody');body.innerHTML='<tr><td colspan="10">Завантаження…</td></tr>';try{const q=query();queryKey=q.toString();const data=await request(`${API}/violation-reports?${q}`);if(!isCurrent())return;requestsPages=Math.max(1,Number(data.pages||1));if(requestsPage>requestsPages){requestsPage=requestsPages;return loadViolationReports()}violationReports=data.items||[];$('#requestsPending').textContent=Number(data.pending||0).toLocaleString('uk-UA');$('#requestsSatisfied').textContent=Number(data.satisfied||0).toLocaleString('uk-UA');$('#requestsDeclined').textContent=Number(data.declined||0).toLocaleString('uk-UA');$$('#requestQuickFilters [data-status]').forEach(button=>button.classList.toggle('active',button.dataset.status===$('#requestsStatus').value));populateRequestSelect('#requestsStatus',data.statuses,requestStatusLabels,'Усі статуси');populateRequestSelect('#requestsReason',data.reasons,requestReasonLabels,'Усі підстави');renderRequestAuthorityCards(data.authorities);const sync=data.sync||{},syncWasActive=requestsRefreshState.running||requestsRefreshState.starting;updateRequestsRefreshAvailability({running:Boolean(sync.running),starting:false});$('#requestsSyncStatus').textContent=sync.running?(sync.message||'Синхронізація триває…'):(sync.updated_at?`${sync.message} · ${displayDate(sync.updated_at)}`:'Натисніть «Оновити з Prozorro», щоб завантажити офіційний реєстр');body.innerHTML=violationReports.length?violationReports.map((item,index)=>{const deadline=requestDeadline(item),statements=item.defendant_statements||[];return`<tr class="request-row ${item.blocking_marker?.highlighting_active?'request-blocking-active':''}" data-request-index="${index}"><td><strong>${esc(item.report_id||item.id)}</strong>${requestBlockingBadge(item)}</td><td>${esc(displayDate(item.date_published))}</td><td><strong>${esc(item.author_name)||'—'}</strong><small>${esc(item.author_code)}</small></td><td><strong>${esc(item.defendant_name)||'—'}</strong><small>${esc(item.defendant_code)}</small></td><td>${esc(requestLabel(item.reason,requestReasonLabels))}</td><td>${deadline.html}${statements.length?`<small class="statement-received">Пояснення надано: ${statements.length}</small>`:''}</td><td>${requestTenderLinks(item)}</td><td>${requestScenarioCell(item,index)}</td><td><span class="request-status status-${esc(requestStatusClass(item.status))}">${esc(requestLabel(item.status,requestStatusLabels))}</span></td><td>${violationProtocolCell(item,index)}</td></tr>`}).join(''):'<tr><td colspan="10">Звернень за вибраними умовами не знайдено</td></tr>';const total=Number(data.total||0),from=total?(requestsPage-1)*100+1:0,to=Math.min(requestsPage*100,total);$('#requestsPageInfo').textContent=`Показано ${from}–${to} із ${total.toLocaleString('uk-UA')} звернень · сторінка ${requestsPage} із ${requestsPages}`;$('#requestsPrev').disabled=requestsPage<=1;$('#requestsNext').disabled=requestsPage>=requestsPages;if(sync.running&&!requestsPolling)requestsPolling=setInterval(async()=>{try{const fresh=await loadViolationReports();if(fresh&&!fresh.sync?.running){clearInterval(requestsPolling);requestsPolling=null}}catch{}},2500);if(syncWasActive&&!sync.running)await reloadOpenViolationReportDetail();return data}catch(error){if(!isCurrent())return;body.innerHTML=`<tr><td colspan="10">${esc(error.message)}</td></tr>`;throw error}}
const internalDecisionLabels={warning:'Попередження',decline:'Відмова в задоволенні звернення',individual_review:'Індивідуальний розгляд'};
function requestContextBlock(item){const c=item.procurement_context||{},r=item.review||{};if(!c.available)return`<section><h3>Перевірка УО</h3><p class="request-warning">Контекст закупівлі не отримано: ${esc(c.error||'невідома помилка')}</p></section>`;const common=`<div class="request-context-grid"><div><small>Дата визначення переможцем</small><strong>${esc(displayDate(c.winner_selected_at))||'—'}</strong></div><div><small>Award переможця</small><strong>${esc(c.winner_award_id)||'—'}</strong></div></div>`;let reason='';if(item.reason==='contractBreach'){reason=`<div class="request-context-grid"><div><small>5-й календарний день</small><strong>${esc(displayDateOnly(c.day_5))||'—'}</strong></div><div><small>Перенесення вихідного</small><strong>${c.day_5_shifted?'Так':'Ні'}</strong></div><div><small>Граничний строк</small><strong>${esc(displayDateOnly(c.contract_deadline))||'—'}</strong></div><div><small>Забезпечення договору</small><strong>${c.contract_guarantee_required?'Так':'Ні'}${c.contract_guarantee_value!=null?` · ${esc(c.contract_guarantee_value)} ${esc(c.contract_guarantee_unit||'')}`:''}</strong></div></div><label class="request-check"><input type="checkbox" data-review="contract_deadline_extended" ${r.contract_deadline_extended?'checked':''}> Строк укладення договору продовжено до 10 к.д.</label>${c.rejection_present?`<div class="request-result"><strong>Відхилення: ${esc(displayDate(c.rejection_date))||'—'}</strong><p>${esc(c.rejection_title||c.rejection_description||'Підстава не зазначена')}</p>${requestDocumentLinks(c.rejection_documents)}</div>`:`<div class="request-result neutral"><strong>Пропозицію переможця не відхилено.</strong><p>Перевірка дострокового відхилення не застосовується.</p></div>`}`}
if(item.reason==='signingRefusal'){reason=`<div class="request-context-grid"><div><small>3-й календарний день</small><strong>${esc(displayDateOnly(c.day_3))||'—'}</strong></div><div><small>Перенесення вихідного</small><strong>${c.day_3_shifted?'Так':'Ні'}</strong></div><div><small>Гранична дата</small><strong>${esc(displayDateOnly(c.written_refusal_deadline))||'—'}</strong></div></div><div class="request-form-grid"><label>Дата письмової відмови<input type="date" data-review="written_refusal_date" value="${esc(r.written_refusal_date||'')}"></label><label>Вих. №<input data-review="written_refusal_number" value="${esc(r.written_refusal_number||'')}"></label><label>Посилання<input type="url" data-review="written_refusal_url" value="${esc(r.written_refusal_url||'')}"></label></div>`}
if(item.reason==='goodsNonCompliance'){reason=`<fieldset class="request-radio"><legend>Є рішення суду, що набрало законної сили?</legend><label><input type="radio" name="courtFinal" data-review="court_decision_final_present" value="true" ${r.court_decision_final_present===true?'checked':''}> Так</label><label><input type="radio" name="courtFinal" data-review="court_decision_final_present" value="false" ${r.court_decision_final_present===false?'checked':''}> Ні</label></fieldset>`}
const recommendation=item.recommendation||{};return`<section class="request-review"><h3>Перевірка УО</h3>${common}${reason}<div class="request-recommendation"><small>Рекомендація системи</small><strong>${esc(internalDecisionLabels[recommendation.recommended_decision]||'Потрібна оцінка УО')}</strong><p>${esc(recommendation.recommendation_reason||'')}</p></div><div class="request-form-grid"><label>Статус розгляду<select data-review="review_status"><option value="not_reviewed">Не розглянуто</option><option value="in_review">На розгляді</option><option value="completed">Завершено</option></select></label><label>Відповідальна особа<input data-review="assigned_officer" value="${esc(r.assigned_officer||'')}"></label><label>Рішення УО<select data-review="internal_decision"><option value="">Не визначено</option>${Object.entries(internalDecisionLabels).map(([value,label])=>`<option value="${value}" ${r.internal_decision===value?'selected':''}>${label}</option>`).join('')}</select></label><label class="wide">Нотатки<textarea data-review="review_notes">${esc(r.review_notes||'')}</textarea></label><label>Перевірена повна назва замовника<input data-review="customer_verified_full_name" value="${esc(r.customer_verified_full_name||'')}"></label><label>Скорочена назва замовника<input data-review="customer_verified_short_name" value="${esc(r.customer_verified_short_name||'')}"></label><label>Фактична дата договору<input type="date" data-review="actual_contract_date" value="${esc(r.actual_contract_date||'')}"></label><label>№ договору<input data-review="actual_contract_number" value="${esc(r.actual_contract_number||'')}"></label><label>Посилання на договір<input type="url" data-review="actual_contract_url" value="${esc(r.actual_contract_url||'')}"></label></div><button type="button" id="saveViolationReview" class="primary">Зберегти</button></section>`}
function violationDetailHtml(item){const deadline=requestDeadline(item),clarity=item.author_code?` <a href="https://clarity-project.info/edr/${encodeURIComponent(item.author_code)}" target="_blank" rel="noopener">Перевірити в Clarity</a>`:'';return`${item.is_read_only?'<div class="request-readonly">Є офіційне рішення Prozorro — картка доступна лише для перегляду.</div>':''}<section><h3>Замовник</h3><p>${esc(item.author_name)||'—'}${item.author_code?` · ${esc(item.author_code)}`:''}${clarity}</p></section><section><h3>Постачальник</h3><p>${esc(item.defendant_name)||'—'}${item.defendant_code?` · ${esc(item.defendant_code)}`:''}</p>${item.supplier_verified?`<small>Перевірена назва: ${esc(item.supplier_verified.full_name||item.supplier_verified.short_name||'—')}</small>`:''}</section><section><h3>Закупівля, договір і звернення</h3><p>${requestTenderLinks(item)}</p></section><section><h3>Строк надання пояснень</h3><p>${deadline.html}</p></section><section><h3>Підстава звернення</h3><p><strong>${esc(requestLabel(item.reason,requestReasonLabels))}</strong></p><div class="request-long-text">${esc(item.description||'Опис відсутній').replaceAll('\n','<br>')}</div></section><section><h3>Пояснення постачальника</h3>${requestStatements(item)}</section><section><h3>Рішення адміністратора</h3><p><strong>${esc(requestLabel(item.decision_resolution,requestStatusLabels))}</strong>${item.decision_date?` · ${esc(displayDate(item.decision_date))}`:''}</p><div class="request-long-text">${esc(item.decision_description||'Рішення відсутнє').replaceAll('\n','<br>')}</div></section><section class="request-documents"><h3>Документи звернення</h3>${requestDocumentLinks(item.evidence_documents)}</section><section class="request-documents"><h3>Документи рішення</h3>${requestDocumentLinks(item.decision_documents)}</section>${item.is_read_only?'':requestContextBlock(item)}`}
function collectViolationReview(){const payload={};$$('#requestDetailsBody [data-review]').forEach(input=>{const key=input.dataset.review;if(input.type==='radio'){if(input.checked)payload[key]=input.value==='true'}else if(input.type==='checkbox')payload[key]=input.checked;else payload[key]=input.value});return payload}
async function saveViolationReview(reportId){try{const data=await request(`${API}/violation-reports/${encodeURIComponent(reportId)}/review`,{method:'PATCH',headers:{'Content-Type':'application/json'},body:JSON.stringify(collectViolationReview())});$('#requestDetailsBody').innerHTML=violationDetailHtml(data);bindViolationReview(data);bindViolationCardDeclensionActions(data);toast('Розгляд збережено');await loadViolationReports().catch(()=>toast('Розгляд збережено, але реєстр не вдалося оновити','warning'))}catch(error){toast(error.message);try{const fresh=await request(`${API}/violation-reports/${encodeURIComponent(reportId)}`);$('#requestDetailsBody').innerHTML=violationDetailHtml(fresh);bindViolationReview(fresh);bindViolationCardDeclensionActions(fresh)}catch{}}}
function bindViolationReview(item){const save=$('#saveViolationReview');if(save)save.onclick=()=>saveViolationReview(item.id);const status=$('[data-review="review_status"]');if(status&&item.review)status.value=item.review.review_status||'not_reviewed';const rec=item.recommendation?.recommended_decision||'';const decision=$('[data-review="internal_decision"]');if(decision)decision.onchange=()=>{if(decision.value&&rec&&decision.value!==rec)toast('Обране рішення відрізняється від рекомендації системи')};const extension=$('[data-review="contract_deadline_extended"]'),refusal=$('[data-review="written_refusal_date"]');if(extension)extension.onchange=()=>saveViolationReview(item.id);if(refusal)refusal.onchange=()=>saveViolationReview(item.id)}
async function openViolationReportById(reportId){
  if(!reportId)return;
  const source=violationReports.find(item=>String(item.id)===String(reportId)||String(item.report_id)===String(reportId));
  const dialog=$('#requestDetailsDialog');
  $('#requestDetailsTitle').textContent=source?.report_id||'Звернення замовника';
  $('#requestDetailsSubtitle').textContent='Оновлення актуальних даних…';
  $('#requestDetailsBody').innerHTML='<p>Завантаження…</p>';
  if(!dialog.open)dialog.showModal();
  try{
    const item=await request(`${API}/violation-reports/${encodeURIComponent(reportId)}`);
    $('#requestDetailsTitle').textContent=item.report_id||'Звернення замовника';
    $('#requestDetailsSubtitle').textContent=`${displayDate(item.date_published)} · ${requestLabel(item.status,requestStatusLabels)}`;
    $('#requestDetailsBody').innerHTML=violationDetailHtml(item);
    bindViolationReview(item);
    bindViolationCardDeclensionActions(item);
    return item;
  }catch(error){
    $('#requestDetailsBody').innerHTML=`<p class="request-warning">${esc(error.message)}</p>`;
  }
}
async function openViolationReport(index){
  const source=violationReports[index];
  if(source)return openViolationReportById(source.id);
}
async function syncViolationReports(){
  const started=Date.now();
  updateRequestsRefreshAvailability({starting:true});
  try{
    await request(`${API}/violation-reports/sync`,{method:'POST',headers:{'Content-Type':'application/json'},body:'{}'});
    toast('Синхронізацію звернень розпочато');
    await loadViolationReports();
  }catch(error){
    try{
      const state=await request(`${API}/violation-reports?page=1&size=10&t=${Date.now()}`);
      updateRequestsRefreshAvailability({running:Boolean(state.sync?.running),starting:false});
      if(state.sync?.running||Date.parse(state.sync?.updated_at||0)>=started){toast('Оновлення звернень виконується');return}
    }catch{}
    toast(error.message);
    updateRequestsRefreshAvailability({running:false,starting:false});
  }
}
$('#requestsBody').onclick=e=>{const view=e.target.closest('[data-view-justification]');if(view){e.preventDefault();e.stopPropagation();showSavedRequestJustification(view.dataset.viewJustification);return}const row=e.target.closest('.request-row');if(row&&!e.target.closest('a'))openViolationReport(Number(row.dataset.requestIndex))};
$('#requestAuthorityCards').onclick=e=>{const card=e.target.closest('.request-authority-card');if(!card)return;selectedRequestAuthority=selectedRequestAuthority===card.dataset.authorityCode?'':card.dataset.authorityCode;requestsPage=1;loadViolationReports()};
let frameworkPage=1,frameworkPages=1,frameworkSort='cpv_code',frameworkDirection='asc',frameworkTimer;
const frameworkNumber=value=>Number(value||0).toLocaleString('uk-UA');
function frameworkStatus(raw){
  const value=String(raw||'').trim(),key=value.toLowerCase();
  if(['active','активне','активний','активна'].includes(key))return{key:'active',label:'Активний'};
  if(['cancelled','canceled','скасоване','скасований','скасовано'].includes(key))return{key:'closed',label:'Скасований'};
  if(['closed','complete','inactive','disabled','unsuccessful','закрите','закритий','закрито','неактивне','неактивний'].includes(key))return{key:'closed',label:'Закритий'};
  return{key:'other',label:value||'Не визначено'};
}
async function refreshFrameworksFromProzorro(){const button=$('#frameworksRefresh'),old=button.textContent;button.disabled=true;button.textContent='Оновлення…';try{await request(`${API}/frameworks/refresh`,{method:'POST',headers:{'Content-Type':'application/json'},body:'{}'});const timer=setInterval(async()=>{try{const health=await request(`${API}/health?t=${Date.now()}`),state=health.sync||{};button.textContent=state.running?(state.message||'Оновлення…'):'Оновити з Prozorro';if(!state.running){clearInterval(timer);button.disabled=false;frameworkPage=1;await loadFrameworkAnalytics();toast(state.message||'Відбори оновлено')}}catch(error){clearInterval(timer);button.disabled=false;button.textContent='Оновити з Prozorro';toast(error.message)}},1500)}catch(error){button.disabled=false;button.textContent=old;toast(error.message)}}
const frameworkDate=value=>value?displayDate(value):'—';
function frameworkParams(){return new URLSearchParams({page:String(frameworkPage),size:'10',search:$('#frameworksSearch').value.trim(),status:$('#frameworksStatus').value,dk_code:$('#frameworksDk').value.trim(),date_from:$('#frameworksDateFrom').value,date_to:$('#frameworksDateTo').value,sort:frameworkSort,direction:frameworkDirection})}
const selectedRegistryFrameworks=new Set();
function frameworkProzorroLink(framework){const id=framework.pretty_id||framework.id,copy=/^UA-F-/i.test(id||'')?`<button type="button" class="copy-framework-number" data-copy-framework-number="${esc(id)}" title="Копіювати номер відбору" aria-label="Копіювати номер відбору">⧉</button>`:'';return framework.id&&id?`<span class="framework-number"><a href="https://prozorro.gov.ua/uk/framework/${encodeURIComponent(id)}" target="_blank" rel="noopener noreferrer">${esc(id)}</a>${copy}</span>`:esc(id||'—')}
function registryExportUrl(ids){const q=new URLSearchParams({registry_only:'1'});for(const id of ids)q.append('framework_id',id);return `${API}/suppliers-registry/export.xlsx?${q}`}
function updateFrameworkRegistryExport(){const link=$('#frameworksExportSelected');link.hidden=!selectedRegistryFrameworks.size;link.href=registryExportUrl(selectedRegistryFrameworks);link.textContent=`Експорт вибраних (${selectedRegistryFrameworks.size})`}
async function loadFrameworkAnalytics(){
  const seq=++frameworkRequestSequence,body=$('#frameworksBody');
  body.innerHTML='<tr><td colspan="10">Завантаження реєстрів…</td></tr>';
  try{
    const data=await request(`${API}/framework-registry?${frameworkParams()}`);
    if(seq!==frameworkRequestSequence)return;
    frameworkPages=Math.max(1,data.pages||1);
    if(frameworkPage>frameworkPages){frameworkPage=frameworkPages;return loadFrameworkAnalytics()}
    $('#frameworksTotal').textContent=frameworkNumber(data.total);
    $('#frameworkBidsSection').hidden=!data.bids_available;
    body.innerHTML=(data.items||[]).map(item=>{
      const f=item.framework,c=item.counts,status=frameworkStatus(item.source_status);
      return `<tr><td><input type="checkbox" data-registry-framework="${esc(f.id)}" aria-label="Вибрати відбір ${esc(f.pretty_id||f.id)}" ${selectedRegistryFrameworks.has(f.id)?'checked':''}></td><td>${esc(item.cpv_code)}</td><td>${frameworkProzorroLink(f)}<small>${esc(item.agreement_id||'Agreement ще не створено')}</small></td><td>${esc(f.title||'—')}</td><td>${esc(status.label)}</td><td>${frameworkNumber(c.total)}</td><td>${frameworkNumber(c.active)}</td><td>${frameworkNumber(c.suspended)}</td><td>${frameworkNumber(c.terminated)}${c.other?`<small>Некласифіковані: ${frameworkNumber(c.other)}</small>`:''}</td><td><a class="ghost" href="${registryExportUrl([f.id])}">Завантажити реєстр</a></td></tr>`
    }).join('')||'<tr><td colspan="10">Відборів не знайдено</td></tr>';
    body.querySelectorAll('[data-registry-framework]').forEach(box=>box.onchange=()=>{if(box.checked)selectedRegistryFrameworks.add(box.dataset.registryFramework);else selectedRegistryFrameworks.delete(box.dataset.registryFramework);updateFrameworkRegistryExport()});
    body.querySelectorAll('[data-registry-framework=""]').forEach(box=>{box.disabled=true;const link=box.closest('tr').querySelector('a');link.removeAttribute('href');link.textContent='Очікує agreement'});
    $('#frameworksPageInfo').textContent=`Сторінка ${frameworkPage} із ${frameworkPages} · відборів ${frameworkNumber(data.total)}`;
    $('#frameworksPrev').disabled=frameworkPage<=1;$('#frameworksNext').disabled=frameworkPage>=frameworkPages;
    $('#frameworksSyncStatus').textContent=data.status_issues?.length?'У реєстрі є невідомі або неоднозначні статуси. Експорт таких записів заблоковано.':'Локальний кеш Prozorro. Відкриття та експорт не запускають синхронізацію.';
    updateFrameworkRegistryExport();
  }catch(error){if(seq===frameworkRequestSequence)body.innerHTML=`<tr><td colspan="10">${esc(error.message)}</td></tr>`}
}
async function loadFrameworkBidsSection(){
  const body=$('#frameworkBidsBody');body.textContent='Завантаження…';
  try{const data=await request(`${API}/framework-analytics?${frameworkParams()}`);
    if(data.bids_available===false){body.textContent='Дані ProzorroBids недоступні в цьому середовищі.';return}
    body.innerHTML='<table><thead><tr><th>Agreement</th><th>З пропозиціціями</th><th>Без участі</th><th>Закупівлі</th><th>Успішні</th><th>Неуспішні</th><th>Остання закупівля</th><th>Bids</th></tr></thead><tbody>'+(data.items||[]).map(x=>`<tr><td><button type="button" data-bids-agreement="${esc(x.agreement_id)}">${esc(x.agreement_id)}</button></td>${[x.supplier_count,x.suppliers_without_bids,x.tender_count,x.complete_count,x.unsuccessful_count].map(v=>`<td>${v==null?'—':frameworkNumber(v)}</td>`).join('')}<td>${frameworkDate(x.last_tender)}</td><td>${x.bids_count==null?'—':frameworkNumber(x.bids_count)}</td></tr>`).join('')+'</tbody></table>';
    body.querySelectorAll('[data-bids-agreement]').forEach(button=>button.onclick=()=>openFrameworkDetails(button.dataset.bidsAgreement));
  }catch(error){body.textContent=error.message}
}
async function openFrameworkDetails(agreementId){
  const dialog=$('#frameworkDetailsDialog'),body=$('#frameworkDetailsBody');$('#frameworkDetailsTitle').textContent='Відбір';$('#frameworkDetailsSubtitle').textContent=agreementId;body.innerHTML='<p>Завантаження…</p>';dialog.showModal();
  try{const q=frameworkParams(),data=await request(`${API}/framework-analytics/${encodeURIComponent(agreementId)}?${q}`),a=data.agreement||{},status=frameworkStatus(a.source_status);$('#frameworkDetailsTitle').textContent=a.cpv_code?`Відбір · ${a.cpv_code}`:'Відбір';body.innerHTML=`<section class="framework-detail-summary"><div><span>Agreement ID</span><strong>${esc(a.agreement_id||agreementId)}</strong></div><div><span>Статус</span><strong>${esc(status.label)}</strong></div><div><span>Постачальників</span><strong>${frameworkNumber((data.suppliers||[]).length)}</strong></div><div><span>Останнє оновлення</span><strong>${frameworkDate(a.last_search_at)}</strong></div></section><h3>Постачальники та участі</h3><div class="framework-detail-table"><table><thead><tr><th>Постачальник</th><th>ЄДРПОУ / РНОКПП</th><th>Участей</th><th>Bids</th><th>Сума</th></tr></thead><tbody>${(data.suppliers||[]).map(x=>`<tr><td>${esc(x.supplier_name||'—')}</td><td>${esc(x.supplier_id||'—')}</td><td>${frameworkNumber(x.participations)}</td><td>${frameworkNumber(x.bids_count)}</td><td>${frameworkNumber(x.amount)}</td></tr>`).join('')||'<tr><td colspan="5">Участей не знайдено</td></tr>'}</tbody></table></div><h3>Останні закупівлі</h3><div class="framework-detail-table"><table><thead><tr><th>Закупівля</th><th>Дата</th><th>Замовник</th><th>Статус</th><th>Bids</th><th>Очікувана сума</th></tr></thead><tbody>${(data.tenders||[]).map(x=>`<tr><td><a href="https://prozorro.gov.ua/uk/tender/${encodeURIComponent(x.tender_id)}" target="_blank" rel="noopener">${esc(x.tender_id)}</a><small>${esc(x.title||'')}</small></td><td>${frameworkDate(x.tender_date)}</td><td>${esc(x.buyer_name||'—')}</td><td>${esc(x.status||'—')}</td><td>${frameworkNumber(x.bids_count)}</td><td>${frameworkNumber(x.amount)} ${esc(x.currency||'')}</td></tr>`).join('')||'<tr><td colspan="6">Закупівель не знайдено</td></tr>'}</tbody></table></div>`}catch(error){body.innerHTML=`<p class="error">${esc(error.message)}</p>`}
}
openFrameworkDetails=async function(agreementId){
  const dialog=$('#frameworkDetailsDialog'),body=$('#frameworkDetailsBody');
  $('#frameworkDetailsTitle').textContent='Відбір';$('#frameworkDetailsSubtitle').textContent=agreementId;
  body.innerHTML='<p>Завантаження…</p>';dialog.showModal();
  try{
    const q=frameworkParams(),data=await request(`${API}/framework-analytics/${encodeURIComponent(agreementId)}?${q}`);
    const a=data.agreement||{},f=data.framework||{},status=frameworkStatus(f.status||a.source_status),stats=data.analytics||{};
    $('#frameworkDetailsTitle').textContent=f.dk_code?`Відбір · ${f.dk_code}`:a.cpv_code?`Відбір · ${a.cpv_code}`:'Відбір';
    body.innerHTML=`<section class="framework-detail-summary">
      <div><span>1. Код ДК і назва</span><strong>${esc(f.title||f.dk_code||a.cpv_code||'—')}</strong></div>
      <div><span>2. Ідентифікатор відбору</span><strong>${esc(f.pretty_id||'—')}</strong></div>
      <div><span>3. Agreement ID</span><strong>${esc(a.agreement_id||agreementId)}</strong></div>
      <div><span>4. Статус відбору</span><strong>${esc(status.label)}</strong></div>
      <div><span>5. Дата оприлюднення</span><strong>${frameworkDate(f.published_at)}</strong></div>
      <div><span>6. Кінцевий строк подання заявок</span><strong>${frameworkDate(f.applications_until)}</strong></div>
      <div><span>7. Строк дії оголошення</span><strong>${frameworkDate(f.valid_until)}</strong></div>
      <div><span>Оновлення аналітики Bids</span><strong>${frameworkDate(a.last_search_at)}</strong></div>
      <div><span>Кваліфікованих постачальників</span><strong>${frameworkNumber(stats.qualified_suppliers)}</strong></div>
    </section><section class="supplier-profile-stats framework-activity-stats"><div><span>Закупівель</span><strong>${frameworkNumber(stats.total)}</strong></div><div><span>Успішних (complete)</span><strong>${frameworkNumber(stats.complete)}</strong></div><div><span>Неуспішних (unsuccessful)</span><strong>${frameworkNumber(stats.unsuccessful)}</strong></div><div><span>Постачальників з пропозиціями</span><strong>${frameworkNumber(stats.suppliers_with_bids)}</strong></div><div><span>Брали участь у ${new Date().getFullYear()} році</span><strong>${frameworkNumber(stats.suppliers_current_year)}</strong></div><div><span>Не брали участі взагалі</span><strong>${frameworkNumber(stats.suppliers_without_bids)}</strong></div></section><h3>Постачальники та участі</h3><div class="framework-detail-table"><table><thead><tr><th>Постачальник</th><th>ЄДРПОУ / РНОКПП</th><th>Участей</th><th>Перемог</th><th>Сума пропозицій</th></tr></thead><tbody>${(data.suppliers||[]).map(x=>{const nazk=x.nazk_submission_presentation||'',nazkLabel={needs_check:'перевірити',refuted:'спростовано',confirmed:'підтверджено',possible:'можливо'}[nazk]||'',amcuClass=x.amcu_match?(Number(x.active_qualifications||0)>0?'supplier-amcu-active':'supplier-amcu-inactive'):nazk==='confirmed'?'supplier-amcu-active':nazk?'supplier-nazk':'';return`<tr class="${amcuClass}"><td>${esc(x.supplier_name||'—')}${x.amcu_match?`<span class="registry-flag amcu" title="АМКУ · ${Number(x.active_qualifications||0)>0?'є актуальні активні кваліфікації':'актуальних активних кваліфікацій немає'}">АМКУ</span>`:''}${nazkLabel?`<span class="registry-flag nazk" title="НАЗК для заявки ${esc(x.submission_id||'')}">НАЗК · ${esc(nazkLabel)}</span>`:''}</td><td>${esc(x.supplier_id||'—')}</td><td>${frameworkNumber(x.participations)}</td><td>${frameworkNumber(x.wins)}</td><td>${frameworkNumber(x.amount)}</td></tr>`}).join('')||'<tr><td colspan="5">Участей не знайдено</td></tr>'}</tbody></table></div><h3>Останні закупівлі</h3><div class="framework-detail-table"><table><thead><tr><th>Закупівля</th><th>Дата</th><th>Замовник</th><th>Статус</th><th>Bids</th><th>Очікувана сума</th></tr></thead><tbody>${(data.tenders||[]).map(x=>`<tr><td><a href="https://prozorro.gov.ua/uk/tender/${encodeURIComponent(x.tender_id)}" target="_blank" rel="noopener">${esc(x.tender_id)}</a><small>${esc(x.title||'')}</small></td><td>${frameworkDate(x.tender_date)}</td><td>${esc(x.buyer_name||'—')}</td><td>${esc(x.status||'—')}</td><td>${frameworkNumber(x.bids_count)}</td><td>${frameworkNumber(x.amount)} ${esc(x.currency||'')}</td></tr>`).join('')||'<tr><td colspan="6">Закупівель не знайдено</td></tr>'}</tbody></table></div>`;
    body.querySelectorAll('.framework-detail-table:first-of-type tbody tr').forEach((row,index)=>{const supplier=(data.suppliers||[])[index];if(!supplier?.supplier_id)return;row.classList.add('supplier-card-open');row.title='Відкрити картку постачальника';row.onclick=()=>openSupplierProfile(supplier.supplier_id)});
  }catch(error){body.innerHTML=`<p class="error">${esc(error.message)}</p>`}
};
let referenceTab=(()=>{try{const value=localStorage.getItem('pqm.referenceTab');return ['nazk','amcu','declension'].includes(value)?value:'nazk'}catch{return 'nazk'}})(),referenceLoaded=false;
const referencePollTimers={};
const referencePages={nazk:1,amcu:1},referencePageCounts={nazk:1,amcu:1};
function referenceDate(value){return value?esc(displayDate(value)):'—'}
function setReferenceTab(name){if(!['nazk','amcu','declension'].includes(name))name='nazk';referenceTab=name;try{localStorage.setItem('pqm.referenceTab',name)}catch{}$$('[data-ref-tab]').forEach(button=>button.classList.toggle('active',button.dataset.refTab===name));['nazk','amcu','declension'].forEach(tab=>{const panel=$(`#reference${tab[0].toUpperCase()}${tab.slice(1)}`);if(panel)panel.hidden=tab!==name});if(name==='nazk')loadReferenceRegistry('nazk');else if(name==='amcu')loadReferenceRegistry('amcu');else loadDeclensionOverrides()}
function referenceStatusText(state){if(!state)return 'Ще не оновлювався';const count=Number(state.row_count||0).toLocaleString('uk-UA');if(state.status==='running')return 'Оновлення триває…';if(state.status==='error')return `Помилка: ${state.message||'невідома помилка'}`;return `${count} записів${state.updated_at?` · ${referenceDate(state.updated_at)}`:''}`}
async function loadReferenceStatus(){try{const data=await request(`${API}/reference-status?t=${Date.now()}`);$('#refNazkStatus').textContent=referenceStatusText(data.nazk);$('#refAmcuStatus').textContent=referenceStatusText(data.amcu);for(const [selector,kind] of [['#refNazkRefresh','nazk'],['#refAmcuRefresh','amcu'],['#refAmcuUploadBtn','amcu']]){const button=$(selector);button.disabled=data[kind]?.status==='running'||button.dataset.roleDisabled==='1'||button.dataset.runtimeDisabled==='1'}return data}catch(error){$('#refNazkStatus').textContent=$('#refAmcuStatus').textContent=error.message;return {}}}
async function loadReferenceRegistry(kind){
  const body=$(kind==='nazk'?'#refNazkBody':'#refAmcuBody'),search=$(kind==='nazk'?'#refNazkSearch':'#refAmcuSearch').value.trim();
  body.innerHTML='<tr><td colspan="6">Завантаження…</td></tr>';
  try{
    const filters=kind==='amcu'
      ?{date_from:$('#refAmcuDateFrom').value,date_to:$('#refAmcuDateTo').value,authority:$('#refAmcuAuthority').value,supplier_scope:$('#refAmcuSupplierScope').value}
      :{date_from:$('#refNazkDateFrom').value,date_to:$('#refNazkDateTo').value,court:$('#refNazkCourt').value};
    const q=new URLSearchParams({search,page:String(referencePages[kind]),size:'50',...filters}),data=await request(`${API}/${kind}-registry?${q}`);
    referencePageCounts[kind]=Math.max(1,Number(data.pages||1));
    if(referencePages[kind]>referencePageCounts[kind]){referencePages[kind]=referencePageCounts[kind];return loadReferenceRegistry(kind)}
    if(kind==='nazk'){
      const court=$('#refNazkCourt'),selected=court.value;
      if(court.options.length<=1)court.innerHTML='<option value="">Усі суди / органи</option>'+data.courts.map(value=>`<option value="${esc(value)}">${esc(value)}</option>`).join('');
      court.value=selected;
      body.innerHTML=data.items.length?data.items.map(x=>`<tr><td><strong>${esc(x.full_name||'—')}</strong></td><td>${esc(x.offense_name||'—')}</td><td>${esc(x.court_case_number||'—')}</td><td>${esc(x.sentence_date||'—')}</td><td>${esc(x.punishment_start||'—')}</td><td>${x.decision_url?`<a href="${esc(x.decision_url)}" target="_blank" rel="noopener">Відкрити</a>`:'—'}</td></tr>`).join(''):'<tr><td colspan="6">Записів не знайдено</td></tr>';
    }else{
      const authority=$('#refAmcuAuthority'),selected=authority.value;
      if(authority.options.length<=1)authority.innerHTML='<option value="">Усі органи АМКУ</option>'+data.authorities.map(value=>`<option value="${esc(value)}">${esc(value)}</option>`).join('');
      authority.value=selected;
      body.innerHTML=data.items.length?data.items.map(x=>{const registered=Boolean(x.in_supplier_registry),active=Number(x.active_qualifications||0),applicant=Boolean(x.has_application);return `<tr class="${active?'amcu-active-supplier':registered?'amcu-our-supplier':applicant?'amcu-applicant':''}"><td><strong>${esc(x.offender_name||'—')}</strong>${active?`<span class="registry-flag active-supplier" title="У реєстрі PQM є активні кваліфікації: ${active}">Активні: ${active}</span>`:registered?'<span class="registry-flag supplier" title="У реєстрі PQM є лише неактивні кваліфікації">Неактивні</span>':applicant?'<span class="registry-flag applicant" title="Є заявка цього постачальника">Є заявка</span>':''}</td><td>${esc(x.offender_code||'—')}</td><td>${esc(x.decision_no||'—')}</td><td>${esc(x.decision_date||'—')}</td><td>${esc(x.authority||'—')}</td><td>${esc(x.court_case_no||'—')}</td></tr>`}).join(''):'<tr><td colspan="6">Записів не знайдено</td></tr>';
    }
    if(kind==='amcu')body.querySelectorAll('tr').forEach((row,index)=>{const item=data.items[index];if(item?.in_supplier_registry){row.dataset.supplierCode=item.offender_code;row.classList.add('supplier-card-open');row.title='Відкрити картку постачальника';row.onclick=()=>openSupplierProfile(item.offender_code)}});
    const total=Number(data.total||0),from=total?(referencePages[kind]-1)*50+1:0,to=Math.min(referencePages[kind]*50,total),prefix=kind==='nazk'?'refNazk':'refAmcu';
    $(`#${prefix}Info`).textContent=`${from}–${to} із ${total.toLocaleString('uk-UA')} · сторінка ${referencePages[kind]} із ${referencePageCounts[kind]}`;
    $(`#${prefix}Prev`).disabled=referencePages[kind]<=1;$(`#${prefix}Next`).disabled=referencePages[kind]>=referencePageCounts[kind];
  }catch(error){body.innerHTML=`<tr><td colspan="6">${esc(error.message)}</td></tr>`}
}
function pollReferenceRefresh(kind,{silent=false}={}){
  if(referencePollTimers[kind])return;
  const poll={};referencePollTimers[kind]=poll;
  const tick=async()=>{
    try{
      const status=await loadReferenceStatus(),state=status[kind];
      if(state&&state.status!=='running'){
        delete referencePollTimers[kind];
        await loadReferenceRegistry(kind);
        if(!silent)toast(state.status==='ok'?'Довідник оновлено':state.message||'Оновлення завершено з помилкою');
        return;
      }
    }catch{ /* transient poll failure: retry without overlapping requests */ }
    if(referencePollTimers[kind]===poll)poll.timer=setTimeout(tick,1500);
  };
  poll.timer=setTimeout(tick,1500);
}
async function refreshReference(kind){const button=$(kind==='nazk'?'#refNazkRefresh':'#refAmcuRefresh');button.disabled=true;try{await request(`${API}/${kind}-registry/refresh`,{method:'POST',headers:{'Content-Type':'application/json'},body:'{}'});toast('Оновлення запущено у фоні');pollReferenceRefresh(kind)}catch{try{const status=await loadReferenceStatus(),state=status[kind];if(state?.status==='running'){toast('Оновлення виконується у фоні');pollReferenceRefresh(kind);return}}catch{}button.disabled=false;toast('Не вдалося підтвердити запуск. Перевірте поточний стан оновлення.')}}
async function uploadAmcu(){const file=$('#refAmcuFile').files[0];if(!file)return;$('#refAmcuUploadBtn').disabled=true;try{const bytes=new Uint8Array(await file.arrayBuffer());let binary='';for(let i=0;i<bytes.length;i+=32768)binary+=String.fromCharCode(...bytes.subarray(i,i+32768));await request(`${API}/amcu-registry/upload`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({filename:file.name,content:btoa(binary)})});toast('Excel-файл АМКУ передано на обробку');pollReferenceRefresh('amcu')}catch(error){toast(error.message)}finally{$('#refAmcuUploadBtn').disabled=false;$('#refAmcuFile').value=''}}
async function loadReferenceRemarks(){const list=$('#refRemarksList');list.innerHTML='<p class="muted">Завантаження…</p>';try{const data=await request(`${API}/remarks-catalog`);remarksItems=data.items||[];list.innerHTML=remarksItems.length?remarksItems.map(item=>`<article class="reference-remark"><div><strong>${esc(item.point||'Без пункту')}</strong><p>${esc(item.text||'')}</p></div><div><button type="button" onclick="editReferenceRemark('${esc(item.id)}')">Редагувати</button><button type="button" onclick="removeReferenceRemark('${esc(item.id)}')">Прибрати</button></div></article>`).join(''):'<p class="muted">Довідник порожній</p>'}catch(error){list.innerHTML=`<p class="error">${esc(error.message)}</p>`}}
let editingReferenceRemarkId=null;
function openReferenceRemarkEditor(item=null){editingReferenceRemarkId=item?.id??null;$('#referenceRemarkTitle').textContent=item?'Редагування зауваження':'Додавання зауваження';$('#referenceRemarkPoint').value=item?.point||'';$('#referenceRemarkText').value=item?.text||'';$('#referenceRemarkDialog').showModal();$('#referenceRemarkPoint').focus()}
async function saveReferenceRemarkEditor(){const point=$('#referenceRemarkPoint').value.trim(),textValue=$('#referenceRemarkText').value.trim();if(!point||!textValue)return toast('Заповніть пункт вимог і повний текст');const url=editingReferenceRemarkId?`${API}/remarks-catalog/${encodeURIComponent(editingReferenceRemarkId)}`:`${API}/remarks-catalog`,method=editingReferenceRemarkId?'PATCH':'POST';try{await request(url,{method,headers:{'Content-Type':'application/json'},body:JSON.stringify({point,text:textValue})});$('#referenceRemarkDialog').close();await loadReferenceRemarks();toast(editingReferenceRemarkId?'Зауваження оновлено':'Зауваження додано','success')}catch(error){toast(error.message)}}
async function addReferenceRemark(){openReferenceRemarkEditor()}
async function editReferenceRemark(id){const item=remarksItems.find(x=>String(x.id)===String(id));if(item)openReferenceRemarkEditor(item)}
async function removeReferenceRemark(id){if(!confirm('Прибрати шаблон із довідника? Збережені зауваження у заявках не зміняться.'))return;await request(`${API}/remarks-catalog/${encodeURIComponent(id)}`,{method:'PATCH',headers:{'Content-Type':'application/json'},body:JSON.stringify({active:false})});await loadReferenceRemarks()}
const declensionTypeLabels={legal_entity:'Юридична особа',fop:'ФОП',person:'Фізична особа / ПІБ',other:'Інше'};
let declensionItems=[],editingDeclensionId=null,declensionReturnContext=null,activeDeclensionRequest=null,declensionPreviewState=null,declensionOpenSequence=0;
const unresolvedDeclensionsByReport=new Map();
async function loadDeclensionOverrides(){
  const body=$('#declensionBody'),search=$('#declensionSearch').value.trim().toLocaleLowerCase('uk-UA');
  body.innerHTML='<tr><td colspan="8">Завантаження…</td></tr>';
  try{
    const data=await request(`${API}/declension-overrides`),canManage=currentMe?.permissions?.['declension.manage']===true,canDelete=currentMe?.role==='admin';
    declensionItems=data.items||[];
    const visible=declensionItems.filter(item=>!search||Object.values(item).some(value=>String(value||'').toLocaleLowerCase('uk-UA').includes(search)));
    body.innerHTML=visible.map(item=>`<tr data-declension-id="${esc(item.id)}"><td>${item.needs_completion?'<span class="status-badge pending">Потребує заповнення</span>':'<span class="status-badge done">Заповнено</span>'}</td><td>${esc(declensionTypeLabels[item.entity_type]||item.entity_type)}</td><td><strong>${esc(item.original)}</strong></td><td>${esc(item.genitive)||'—'}</td><td>${esc(item.dative)||'—'}</td><td>${esc(item.accusative)||'—'}</td><td>${esc(item.comment)||'—'}</td><td class="declension-actions">${canManage?'<button type="button" class="ghost" data-declension-edit>Редагувати</button>':''}${canDelete?'<button type="button" class="ghost danger" data-declension-delete>Видалити</button>':''}${!canManage&&!canDelete?'—':''}</td></tr>`).join('')||'<tr><td colspan="8">Записів не знайдено</td></tr>';
    $('#declensionInfo').textContent=`${visible.length.toLocaleString('uk-UA')} із ${declensionItems.length.toLocaleString('uk-UA')} записів`;
    $('#declensionAdd').hidden=!canManage;
    return true;
  }catch(error){body.innerHTML=`<tr><td colspan="8">${esc(error.message)}</td></tr>`;return false}
}
function canReadDeclensions(){return currentMe?.permissions?.['declension.read']===true||currentMe?.role==='admin'}
function violationCardDeclensionSubject(item,side){
  const customer=side==='customer',subjectLabel=customer?'Замовник':'Постачальник',identifier=customer?item.author_code:item.defendant_code;
  const original=String(customer?(item.review?.customer_verified_full_name||item.author_name||''):(item.protocol_supplier_names?.full_name?.value||item.supplier_verified?.full_name||item.defendant_name||'')).trim();
  const readiness=[item.protocol_readiness,item.protocol_readiness_individual].filter(Boolean).flatMap(value=>value.declensions||[]);
  const match=readiness.find(entry=>entry.subject_label===subjectLabel&&declensionLookup(entry.original)===declensionLookup(original))||readiness.find(entry=>entry.subject_label===subjectLabel);
  const existing=declensionItems.find(entry=>declensionLookup(entry.original)===declensionLookup(original));
  const upper=original.toLocaleUpperCase('uk-UA');let inferred='other';
  if(upper.includes('ФОП')||upper.includes('ФІЗИЧНА ОСОБА')||upper.includes('ПІДПРИЄМЕЦЬ'))inferred='fop';
  else if(['ТОВАРИСТВО','ПІДПРИЄМСТВО','ТОВ ','ПП ','МКСП'].some(marker=>upper.includes(marker))||String(identifier||'').replace(/\D/g,'').length===8)inferred='legal_entity';
  else if(upper.split(/\s+/).filter(Boolean).length>=2)inferred='person';
  return{original:match?.original||original,entity_type:match?.entity_type||existing?.entity_type||inferred,entity_identifier:identifier,identifier,subject_label:subjectLabel,context_type:'violation_report'};
}
async function openViolationCardDeclension(side,item){
  if(!canReadDeclensions())return;
  const owner=activeDeclensionRequest,sequence=++declensionOpenSequence;
  if(!$('#requestDetailsDialog')?.open||owner!==item)return;
  const subject=violationCardDeclensionSubject(item,side);
  if(!subject.original){toast('Не визначено найменування для відмінювання','error');return}
  const loaded=await loadDeclensionOverrides();
  if(sequence!==declensionOpenSequence||activeDeclensionRequest!==owner||!$('#requestDetailsDialog')?.open)return;
  if(!loaded){toast('Не вдалося завантажити довідник відмінювання','error');return}
  const existing=declensionItems.find(entry=>entry.entity_type===subject.entity_type&&declensionLookup(entry.original)===declensionLookup(subject.original));
  declensionReturnContext={originType:'violation_report_card',reportId:item.id,side};
  const gate=($('#violationProtocolType')?.value==='decline_individual_review'?item.protocol_readiness_individual:item.protocol_readiness)||{};
  const cases=[...(gate.declensions||[]),...(gate.unresolved||[])].filter(entry=>entry.subject_label===subject.subject_label).map(entry=>entry.grammatical_case);
  openDeclensionEditor(existing||{entity_type:subject.entity_type,original:subject.original},cases,{...subject,readOnly:currentMe?.permissions?.['declension.manage']!==true});
}
function violationCardDeclensionButton(side){return canReadDeclensions()?`<button type="button" class="ghost violation-card-declension" data-card-declension-side="${side}">Відмінювання</button>`:''}
function bindViolationCardDeclensionActions(item){$$('#requestDetailsBody [data-card-declension-side]').forEach(button=>{button.onclick=()=>openViolationCardDeclension(button.dataset.cardDeclensionSide,item)});updateViolationCardDeclensionStatus(item)}
function openDeclensionEditor(item=null,neededCase='',requestContext=null){const cases=[...new Set((Array.isArray(neededCase)?neededCase:[neededCase]).filter(value=>['genitive','dative','accusative'].includes(value)))];declensionPreviewState=null;$$('#declensionDialog [data-declension-preview-control]').forEach(node=>node.remove());['#declensionGenitive','#declensionDative','#declensionAccusative'].forEach(selector=>$(selector).oninput=null);$('#declensionSave').disabled=false;editingDeclensionId=item?.id||null;$('#declensionDialogTitle').textContent=editingDeclensionId?'Редагувати відмінювання':'Додати відмінювання';$('#declensionType').value=item?.entity_type||'legal_entity';$('#declensionOriginal').value=item?.original||'';$('#declensionGenitive').value=item?.genitive||'';$('#declensionDative').value=item?.dative||'';$('#declensionAccusative').value=item?.accusative||'';$('#declensionComment').value=item?.comment||'';const readOnly=requestContext?.readOnly===true||currentMe?.permissions?.['declension.manage']!==true;['#declensionType','#declensionOriginal','#declensionGenitive','#declensionDative','#declensionAccusative','#declensionComment'].forEach(selector=>{const field=$(selector);if(field)field.disabled=readOnly});$('#declensionSave').hidden=readOnly;$$('#declensionDialog [data-declension-case]').forEach(label=>{const required=cases.includes(label.dataset.declensionCase);label.classList.toggle('required-case',required);label.hidden=Boolean(requestContext&&cases.length&&!required)});const labels={genitive:'родовий',dative:'давальний',accusative:'знахідний'},subject=requestContext?.subject_label||'';$('#declensionDialogHint').textContent=cases.length?`${subject?subject+' · ':''}для документа потрібні форми: ${cases.map(value=>labels[value]).join(', ')}${requestContext?.entity_identifier?` · ${requestContext.entity_identifier}`:''}.`:'Заповнюйте лише перевірені форми. Порожні відмінки дозволені.';$('#declensionDialog').showModal();(cases.length?$(`#declensionDialog [data-declension-case="${cases[0]}"] input`):$('#declensionOriginal')).focus();if(!requestContext||requestContext.context_type==='violation_report'){const state={readOnly,card:requestContext?.context_type==='violation_report',owner:declensionReturnContext?.originType==='violation_report_card'?activeDeclensionRequest:null};declensionPreviewState=state;$$('#declensionDialog [data-declension-case]').forEach(label=>label.hidden=false);$('#declensionType').disabled=readOnly||state.card;$('#declensionOriginal').disabled=readOnly||state.card;const refresh=()=>prepareDeclensionEditorPreview(state);$('#declensionType').onchange=refresh;$('#declensionOriginal').onchange=refresh;void refresh()}else{$('#declensionType').onchange=null;$('#declensionOriginal').onchange=null}}
function updateViolationCardDeclensionStatus(item){
  const warning=$('#violationProtocolReasons');if(warning){warning.setAttribute('role','status');warning.setAttribute('aria-live','polite')}
  const individual=$('#violationProtocolType')?.value==='decline_individual_review';
  const gate=(individual?item.protocol_readiness_individual:item.protocol_readiness)||{};
  const unresolved=[...(gate.declensions||[]).filter(entry=>entry.status!=='resolved'),...(gate.unresolved||[])];
  $$('#requestDetailsBody [data-card-declension-side]').forEach(button=>{
    const label=button.dataset.cardDeclensionSide==='customer'?'Замовник':'Постачальник';
    const required=unresolved.filter(entry=>entry.subject_label===label);
    button.classList.toggle('needs-declension-review',Boolean(required.length));
    button.title=required.length?'Для обраного протоколу потрібна перевірена відмінкова форма':'Питань не виявлено. Можна перевірити форми вручну; це не гарантія їх правильності.';
    button.setAttribute('aria-label',`Відмінювання: ${label.toLocaleLowerCase('uk-UA')}${required.length?' — потрібна перевірка':''}`);
  });
}
async function refreshOpenViolationDeclensionState(context){
  const dialog=$('#requestDetailsDialog'),target=activeDeclensionRequest;
  if(!dialog?.open||String(target?.id)!==String(context.reportId))return false;
  try{
    const fresh=await request(`${API}/violation-reports/${encodeURIComponent(context.reportId)}?refresh=0`);
    if(!dialog.open||activeDeclensionRequest!==target||String(fresh?.id)!==String(context.reportId))return false;
    target.protocol_readiness=fresh.protocol_readiness;
    target.protocol_readiness_individual=fresh.protocol_readiness_individual;
    unresolvedDeclensionsByReport.delete(String(context.reportId));
    const selector=$('#violationProtocolType');if(selector)selector.dispatchEvent(new Event('change'));
    const gate=(selector?.value==='decline_individual_review'?target.protocol_readiness_individual:target.protocol_readiness)||{};
    const reasons=$('#violationProtocolReasons');if(reasons){reasons.hidden=!(gate.reasons||[]).length;reasons.textContent=(gate.reasons||[]).join(' · ')}
    updateViolationCardDeclensionStatus(target);
    return true;
  }catch{toast('Форму збережено, але не вдалося оновити стан відкритої картки.','error');return false}
}
async function prepareDeclensionEditorPreview(state){
  if(declensionPreviewState!==state)return;
  const original=$('#declensionOriginal').value.trim(),entityType=$('#declensionType').value;
  const token=Symbol('declension-preview');state.token=token;state.loading=true;state.failed=false;
  $('#declensionSave').disabled=true;
  const fields=['genitive','dative','accusative'];
  fields.forEach(name=>{
    const label=$(`#declensionDialog [data-declension-case="${name}"]`),input=label.querySelector('input');
    input.disabled=true;
    let info=label.querySelector('[data-declension-origin]');
    if(!info){info=document.createElement('small');info.dataset.declensionOrigin=name;info.dataset.declensionPreviewControl='1';info.setAttribute('aria-live','polite');label.append(info);
      const confirm=document.createElement('span');confirm.className='declension-form-confirm';confirm.dataset.declensionPreviewControl='1';
      const check=document.createElement('input');check.type='checkbox';check.dataset.confirmDeclension=name;check.setAttribute('aria-label',`Підтвердити форму: ${label.querySelector('span').title||label.querySelector('span').textContent}`);confirm.append(check,document.createTextNode(' Перевірено для збереження'));label.append(confirm);
    }
    info.textContent=original?'Завантаження форм…':'Введіть назву для перегляду форм';info.dataset.source='unresolved';
    const check=label.querySelector('[data-confirm-declension]');check.checked=false;check.disabled=true;
    input.oninput=()=>{check.checked=Boolean(input.value.trim());check.disabled=state.readOnly||!input.value.trim();info.textContent=input.value.trim()?'Ручне виправлення · ще не збережено':'Форма не визначена';info.dataset.source='manual'};
  });
  if(!original){state.loading=false;return}
  try{
    const data=await request(`${API}/declension-overrides?${new URLSearchParams({preview:'1',original,entity_type:entityType})}`);
    if(declensionPreviewState!==state||state.token!==token||!$('#declensionDialog').open)return;
    if(state.owner&&activeDeclensionRequest!==state.owner){$('#declensionDialog').close();declensionPreviewState=null;declensionReturnContext=null;return;}
    if(state.card){editingDeclensionId=data.item?.id||null;if(data.item)$('#declensionComment').value=data.item.comment||'';$('#declensionDialogTitle').textContent=editingDeclensionId?'Редагувати відмінювання':'Додати відмінювання'}
    fields.forEach(name=>{
      const form=data.preview?.[name];if(!form||!['override','automatic','unresolved'].includes(form.source))throw new Error('Некоректна відповідь перегляду');
      const label=$(`#declensionDialog [data-declension-case="${name}"]`),input=label.querySelector('input'),check=label.querySelector('[data-confirm-declension]'),info=label.querySelector('[data-declension-origin]');
      input.value=form.value||'';input.disabled=state.readOnly;check.checked=form.source==='override'&&Boolean(input.value.trim());check.disabled=state.readOnly||!input.value.trim();
      info.dataset.source=form.source;info.textContent=form.source==='override'?'Перевірена форма · збережено':form.source==='automatic'?'Автоматична пропозиція · не перевірено':'Форма не визначена чинним механізмом · потрібне ручне введення';
    });
    state.loading=false;$('#declensionSave').disabled=state.readOnly;
  }catch(error){
    if(declensionPreviewState!==state||state.token!==token)return;
    state.loading=false;state.failed=true;$('#declensionSave').disabled=true;
    $$('#declensionDialog [data-declension-origin]').forEach(info=>info.textContent='Не вдалося отримати форми. Закрийте редактор і спробуйте ще раз.');
    toast(error.message,'error');
  }
}

function declensionLookup(value){return String(value||'').toLocaleLowerCase('uk-UA').replace(/[’'`\-]+/g,' ').replace(/\s+/g,' ').trim()}
function remainingDeclensionItems(items){return(items||[]).filter(entry=>{const row=declensionItems.find(candidate=>candidate.entity_type===entry.entity_type&&declensionLookup(candidate.original)===declensionLookup(entry.original));return!row||!String(row[entry.grammatical_case]||'').trim()})}
async function returnToDeclensionReport(){if(!declensionReturnContext)return;const context=declensionReturnContext;declensionReturnContext=null;$('#declensionBackToRequest').hidden=true;if(context.originType==='operational_task_list'){showModule('operationalTasks');return}if(context.originType==='operational_task'){showModule('operationalTasks');await openOperationalTask(context.taskId);return}if(context.originType==='violation_report_list'){showModule('requests');return}unresolvedDeclensionsByReport.delete(String(context.reportId));showModule('requests');await openViolationReportById(context.reportId)}
async function saveDeclensionEditor(){if(currentMe?.permissions?.['declension.manage']!==true)return;if(declensionPreviewState?.loading||declensionPreviewState?.failed)return;if(declensionPreviewState?.owner&&activeDeclensionRequest!==declensionPreviewState.owner){$('#declensionDialog').close();declensionPreviewState=null;declensionReturnContext=null;toast('Картку змінено. Відкрийте відмінювання для поточного звернення.','warning');return}const payload={entity_type:$('#declensionType').value,original:$('#declensionOriginal').value,genitive:$('#declensionGenitive').value,dative:$('#declensionDative').value,accusative:$('#declensionAccusative').value,comment:$('#declensionComment').value},url=editingDeclensionId?`${API}/admin/declension-overrides/${encodeURIComponent(editingDeclensionId)}`:`${API}/admin/declension-overrides`,method=editingDeclensionId?'PATCH':'POST';if(declensionPreviewState){for(const name of ['genitive','dative','accusative']){const confirmed=$(`#declensionDialog [data-confirm-declension="${name}"]`);if(!confirmed?.checked||!String(payload[name]||'').trim())payload[name]=''}}try{await request(url,{method,headers:{'Content-Type':'application/json'},body:JSON.stringify(payload)});$('#declensionDialog').close();await loadDeclensionOverrides();toast(editingDeclensionId?'Відмінювання оновлено':'Відмінювання додано','success');if(declensionReturnContext?.originType==='violation_report_card'){const context=declensionReturnContext;unresolvedDeclensionsByReport.delete(String(context.reportId));if(await refreshOpenViolationDeclensionState(context))declensionReturnContext=null;return}if(declensionReturnContext?.originType==='violation_report_side'){unresolvedDeclensionsByReport.delete(String(declensionReturnContext.reportId));const context=declensionReturnContext,item=await reloadOpenViolationReportDetail();if(!item)return;const remaining=unresolvedViolationDeclensionsBySide(item.protocol_readiness?.declensions,context.side);if(remaining.length){const next=remaining[0];context.entries=remaining;context.entry=next;const existing=declensionItems.find(candidate=>candidate.entity_type===next.entity_type&&declensionLookup(candidate.original)===declensionLookup(next.original));openDeclensionEditor(existing||{entity_type:next.entity_type,original:next.original},next.grammatical_case,next)}else declensionReturnContext=null;return}if(declensionReturnContext)await returnToDeclensionReport()}catch(error){toast(error.message,'error')}}
async function deleteDeclension(id){const item=declensionItems.find(row=>row.id===id);if(!item||!confirm(`Видалити перевірені форми для «${item.original}»?`))return;try{await request(`${API}/admin/declension-overrides/${encodeURIComponent(id)}`,{method:'DELETE'});await loadDeclensionOverrides();toast('Запис відмінювання видалено','success')}catch(error){toast(error.message,'error')}}
async function openDocumentDeclension(item,context){const entries=context.entries||[item];if(context.originType==='operational_task')$('#operationalTaskDialog').close();else if(context.originType!=='violation_report_side')$('#requestDetailsDialog').close();if(context.originType!=='violation_report_side'){showModule('references');setReferenceTab('declension');$('#declensionBackToRequest').hidden=false;$('#declensionBackToRequest').textContent=`← Назад до ${context.label}`}await loadDeclensionOverrides();const pending=remainingDeclensionItems(entries),target=pending[0]||item;declensionReturnContext={...context,entries,entry:target};if(context.originType!=='violation_report_side')$('#declensionSearch').value=target?.original||'Потребує заповнення';const existing=declensionItems.find(candidate=>candidate.entity_type===target?.entity_type&&declensionLookup(candidate.original)===declensionLookup(target?.original));const matching=pending.filter(entry=>entry.entity_type===target?.entity_type&&declensionLookup(entry.original)===declensionLookup(target?.original));const cases=matching.map(entry=>entry.grammatical_case);openDeclensionEditor(existing||{entity_type:target?.entity_type||'legal_entity',original:target?.original||''},cases,matching[0]||target)}
async function openDeclensionFromValidation(item,report){const entries=report.protocol_readiness?.declensions||unresolvedDeclensionsByReport.get(String(report.id))||[item];return openDocumentDeclension(item,{reportId:report.id,label:report.report_id||report.id,entries})}
async function openDeclensionFromAmcuValidation(item,task,entries){return openDocumentDeclension(item,{originType:'operational_task',taskId:task.id,label:`задачі ${task.supplier_code}`,entries:entries||[item]})}
function documentDeclensionAction(entries,attribute){if(!(entries||[]).length)return'';return `<button type="button" class="ghost" ${attribute}="0">Перевірити відмінювання</button>`}
function unresolvedViolationDeclensionsBySide(entries,side){return(entries||[]).filter(entry=>entry.status!=='resolved'&&entry.subject_label===(side==='customer'?'Замовник':'Постачальник'))}
function violationDeclensionActions(entries){
  if(currentMe?.permissions?.['appeals.review']!==true||currentMe?.permissions?.['declension.manage']!==true)return'';
  const customer=unresolvedViolationDeclensionsBySide(entries,'customer');
  const supplier=unresolvedViolationDeclensionsBySide(entries,'supplier');
  if(!customer.length&&!supplier.length)return'';
  return `<section class="violation-declension-actions"><h3>Відмінювання</h3><div class="violation-inline-actions">${customer.length?'<button type="button" class="ghost" data-check-declension-side="customer">↗ Для замовника</button>':''}${supplier.length?'<button type="button" class="ghost" data-check-declension-side="supplier">↗ Для постачальника</button>':''}</div></section>`;
}
async function openViolationDeclensionSide(side,report){
  const entries=unresolvedViolationDeclensionsBySide(report.protocol_readiness?.declensions,side);
  if(!entries.length)return;
  return openDocumentDeclension(entries[0],{originType:'violation_report_side',side,reportId:report.id,label:report.report_id||report.id,entries});
}
async function loadReferencesView(){if(!referenceLoaded){referenceLoaded=true;setReferenceTab(referenceTab)}const status=await loadReferenceStatus();for(const kind of ['nazk','amcu'])if(status[kind]?.status==='running')pollReferenceRefresh(kind,{silent:true})}
$$('[data-ref-tab]').forEach(button=>button.onclick=()=>setReferenceTab(button.dataset.refTab));
const loadReferenceRegistryBase=loadReferenceRegistry;
loadReferenceRegistry=async function(kind){
  if(kind!=='nazk')return loadReferenceRegistryBase(kind);
  const body=$('#refNazkBody'),search=$('#refNazkSearch').value.trim();body.innerHTML='<tr><td colspan="9">Завантаження…</td></tr>';
  try{const q=new URLSearchParams({search,page:String(referencePages.nazk),size:'50',date_from:$('#refNazkDateFrom').value,date_to:$('#refNazkDateTo').value,court:$('#refNazkCourt').value}),data=await request(`${API}/nazk-registry?${q}`);referencePageCounts.nazk=Math.max(1,Number(data.pages||1));if(referencePages.nazk>referencePageCounts.nazk){referencePages.nazk=referencePageCounts.nazk;return loadReferenceRegistry('nazk')}const court=$('#refNazkCourt'),selected=court.value;if(court.options.length<=1)court.innerHTML='<option value="">Усі суди / органи</option>'+data.courts.map(value=>`<option value="${esc(value)}">${esc(value)}</option>`).join('');court.value=selected;body.innerHTML=data.items.length?data.items.map(x=>`<tr><td><strong>${esc(x.full_name||'—')}</strong><small>ID: ${esc(x.source_id||'—')}</small></td><td>${esc(x.offense_name||'—')}</td><td>${esc(x.punishment||'—')}</td><td>${esc(x.court_case_number||'—')}</td><td>${esc(x.sentence_date||'—')}</td><td>${esc(x.punishment_start||'—')}</td><td>${x.decision_url?`<a href="${esc(x.decision_url)}" target="_blank" rel="noopener">Відкрити</a>`:'—'}</td><td>${esc(x.decree_number||'—')}</td><td>${esc(x.decree_date||'—')}</td></tr>`).join(''):'<tr><td colspan="9">Записів не знайдено</td></tr>';const total=Number(data.total||0),from=total?(referencePages.nazk-1)*50+1:0,to=Math.min(referencePages.nazk*50,total);$('#refNazkInfo').textContent=`${from}–${to} із ${total.toLocaleString('uk-UA')} · сторінка ${referencePages.nazk} із ${referencePageCounts.nazk}`;$('#refNazkPrev').disabled=referencePages.nazk<=1;$('#refNazkNext').disabled=referencePages.nazk>=referencePageCounts.nazk}catch(error){body.innerHTML=`<tr><td colspan="9">${esc(error.message)}</td></tr>`}
};
const loadReferenceRegistryBeforeDatePresentation=loadReferenceRegistry;
loadReferenceRegistry=async function(kind){
  await loadReferenceRegistryBeforeDatePresentation(kind);
  const body=$(kind==='amcu'?'#refAmcuBody':'#refNazkBody');
  const indexes=kind==='amcu'?[3]:[4,5,8];
  body.querySelectorAll('tr').forEach(row=>indexes.forEach(index=>{
    const cell=row.children[index],value=cell?.textContent?.trim();
    if(value&&/^\d{4}-\d{2}-\d{2}$/.test(value))cell.textContent=displayDateOnly(value);
  }));
};
$('#refNazkSearch').oninput=()=>{referencePages.nazk=1;clearTimeout(referenceTimer);referenceTimer=setTimeout(()=>loadReferenceRegistry('nazk'),300)};
$('#refNazkDateFrom').onchange=$('#refNazkDateTo').onchange=$('#refNazkCourt').onchange=()=>{referencePages.nazk=1;loadReferenceRegistry('nazk')};
$('#refAmcuSearch').oninput=()=>{referencePages.amcu=1;clearTimeout(referenceTimer);referenceTimer=setTimeout(()=>loadReferenceRegistry('amcu'),300)};
$('#refAmcuDateFrom').onchange=$('#refAmcuDateTo').onchange=$('#refAmcuAuthority').onchange=$('#refAmcuSupplierScope').onchange=()=>{referencePages.amcu=1;loadReferenceRegistry('amcu')};
let referenceTimer=null;
$('#refNazkRefresh').onclick=()=>refreshReference('nazk');$('#refAmcuRefresh').onclick=()=>refreshReference('amcu');$('#refAmcuUploadBtn').onclick=()=>$('#refAmcuFile').click();$('#refAmcuFile').onchange=uploadAmcu;$('#refRemarkAdd').onclick=addReferenceRemark;
$('#referenceRemarkSave').onclick=saveReferenceRemarkEditor;$('#referenceRemarkDialog').addEventListener('keydown',event=>{if(event.ctrlKey&&event.key==='Enter'){event.preventDefault();saveReferenceRemarkEditor()}});
$('#declensionAdd').onclick=()=>openDeclensionEditor();$('#declensionSave').onclick=saveDeclensionEditor;$('#declensionSearch').oninput=loadDeclensionOverrides;$('#declensionBackToRequest').onclick=()=>returnToDeclensionReport();$('#declensionBody').onclick=event=>{const row=event.target.closest('[data-declension-id]');if(!row)return;const item=declensionItems.find(candidate=>candidate.id===row.dataset.declensionId);if(event.target.closest('[data-declension-edit]'))openDeclensionEditor(item);if(event.target.closest('[data-declension-delete]'))deleteDeclension(row.dataset.declensionId)};
$('#referencesNav').addEventListener('click',()=>{declensionReturnContext=null;$('#declensionBackToRequest').hidden=true});
$('#requestDetailsBody').addEventListener('click',event=>{const action=event.target.closest('[data-go-declension]');if(!action||!activeDeclensionRequest)return;const entries=unresolvedDeclensionsByReport.get(String(activeDeclensionRequest.id))||[];openDeclensionFromValidation(entries[Number(action.dataset.goDeclension)],activeDeclensionRequest)});
$('#refNazkPrev').onclick=()=>{if(referencePages.nazk>1){referencePages.nazk--;loadReferenceRegistry('nazk')}};$('#refNazkNext').onclick=()=>{if(referencePages.nazk<referencePageCounts.nazk){referencePages.nazk++;loadReferenceRegistry('nazk')}};$('#refAmcuPrev').onclick=()=>{if(referencePages.amcu>1){referencePages.amcu--;loadReferenceRegistry('amcu')}};$('#refAmcuNext').onclick=()=>{if(referencePages.amcu<referencePageCounts.amcu){referencePages.amcu++;loadReferenceRegistry('amcu')}};

async function loadBidsSyncStatus(){const button=$('#bidsStatusRefresh');button.disabled=true;$('#bidsSyncHeadline').textContent='Читання великої бази…';try{const data=await request(`${API}/bids-sync-status?t=${Date.now()}`),number=value=>Number(value||0).toLocaleString('uk-UA'),date=value=>value?displayDate(value):'—',dateOnly=value=>value?displayDateOnly(value):'—';$('#bidsAgreements').textContent=number(data.agreements);$('#bidsAgreementsDetail').textContent=`Перевірено: ${number(data.searched_agreements)}`;$('#bidsTenders').textContent=number(data.tenders);$('#bidsTendersDetail').textContent=`Деталізовано: ${number(data.detailed_tenders)}`;$('#bidsCount').textContent=number(data.bids);$('#bidsAwards').textContent=number(data.awards);$('#bidsPending').textContent=number(data.pending_tenders);$('#bidsErrors').textContent=`Помилки: ${number(Number(data.tender_errors||0)+Number(data.agreement_errors||0))}`;$('#bidsCoverage').textContent=`${dateOnly(data.tender_from)} — ${dateOnly(data.tender_to)}`;$('#bidsModifiedTo').textContent=dateOnly(data.modified_to);$('#bidsLastSearch').textContent=date(data.last_search_at);$('#bidsLastDetail').textContent=date(data.last_detail_at);const run=data.last_completed;$('#bidsLastRun').textContent=run?`${date(run.finished_at)} · ${run.mode} · деталізовано ${number(run.details_loaded)}`:'Немає завершених запусків';$('#bidsDatabase').textContent=data.database||'—';$('#bidsSyncBadge').textContent=data.history_complete?'Історію завершено':'Є черга';$('#bidsSyncBadge').className=`bids-sync-badge ${data.history_complete?'complete':'pending'}`;$('#bidsSyncHeadline').textContent=data.history_complete?'Усі знайдені закупівлі деталізовано':'Частина закупівель очікує деталізації';const warning=$('#bidsSyncWarning'),stale=data.stale_open_logs||[];warning.hidden=!stale.length;warning.textContent=stale.length?`У журналі залишилось незакритих старих запусків: ${stale.length}. Вони не активні, оскільки черга деталізації порожня.`:''}catch(error){$('#bidsSyncHeadline').textContent=error.message;$('#bidsSyncBadge').textContent='Помилка';$('#bidsSyncBadge').className='bids-sync-badge error'}finally{button.disabled=false}}
const loadBidsSyncStatusLegacy=loadBidsSyncStatus;
loadBidsSyncStatus=async function(){
  const button=$('#bidsStatusRefresh');button.disabled=true;$('#bidsSyncHeadline').textContent='Отримання поточного стану…';
  try{
    const data=await request(`${API}/bids-sync-status?t=${Date.now()}`),state=data.update||{},number=value=>Number(value||0).toLocaleString('uk-UA'),date=value=>value?displayDate(value):'—',dateOnly=value=>value?displayDateOnly(value):'—';
    $('#bidsAgreements').textContent=number(data.agreements);$('#bidsAgreementsDetail').textContent=`Перевірено: ${number(data.searched_agreements)}`;$('#bidsTenders').textContent=number(data.tenders);$('#bidsTendersDetail').textContent=`Деталізовано: ${number(data.detailed_tenders)}`;$('#bidsCount').textContent=number(data.bids);$('#bidsAwards').textContent=number(data.awards);$('#bidsPending').textContent=number(data.pending_tenders);$('#bidsErrors').textContent=`Поточні проблеми: ${number(Number(data.tender_errors||0)+Number(data.agreement_errors||0))}`;$('#bidsCoverage').textContent=`${dateOnly(data.tender_from)} — ${dateOnly(data.tender_to)}`;$('#bidsModifiedTo').textContent=dateOnly(data.modified_to);$('#bidsLastSearch').textContent=date(data.last_search_at);$('#bidsLastDetail').textContent=date(data.last_detail_at);const run=data.last_completed;$('#bidsLastRun').textContent=run?`${date(run.finished_at)} · ${run.mode} · деталізовано ${number(run.details_loaded)}`:'Немає завершених запусків';$('#bidsDatabase').textContent=data.database||'—';
    $('#bidsSyncBadge').textContent=state.running?'Оновлення триває':state.error?'Помилка':'Готово';$('#bidsSyncBadge').className=`bids-sync-badge ${state.running?'pending':state.error?'error':'complete'}`;$('#bidsSyncHeadline').textContent=state.message||'Поточний стан отримано';const warning=$('#bidsSyncWarning'),stale=data.stale_open_logs||[],abandoned=data.abandoned_runs||[],history=data.run_history_counts||{},diagnostics=data.current_validation_errors||{};warning.hidden=!stale.length;warning.textContent=stale.length?`Історичні незавершені записи: ${stale.length}. Вони не є поточним активним процесом.`:'';$('#bidsSyncHistory').textContent=`Історія запусків: завершено ${number(history.completed)}, помилок ${number(history.failed)}, перервано ${number(history.interrupted)}, abandoned ${number(history.abandoned)}. Поточні search-validation issues: ${number(diagnostics.count)}.`;renderBidsRun(state);
  }catch(error){$('#bidsSyncHeadline').textContent=error.message;$('#bidsSyncBadge').textContent='Помилка';$('#bidsSyncBadge').className='bids-sync-badge error';$('#bidsDataRefresh').dataset.bidsReady='0';$('#bidsDataRefresh').disabled=true}finally{button.disabled=false;clearTimeout(bidsUpdateTimer);if($('#bidsDataRefresh').dataset.runtimeDisabled!=='1'&&($('#bidsDataRefresh').dataset.bidsRunning==='1'||$('#bidsDataRefresh').dataset.bidsReady!=='1'))bidsUpdateTimer=setTimeout(()=>loadBidsSyncStatus(),4000)}
};
let bidsUpdateTimer=null;
function renderBidsRun(state){
 const button=$('#bidsDataRefresh');button.dataset.bidsReady='1';button.dataset.bidsRunning=state.running?'1':'0';
 button.disabled=Boolean(state.running)||currentMe?.role!=='admin'||button.dataset.runtimeDisabled==='1';
 let details=$('#bidsLiveRun');if(!details){details=document.createElement('div');details.id='bidsLiveRun';$('#bidsSyncHeadline').after(details)}
 const status=state.status||(state.running?'running':state.error?'failed':state.updated_at?'completed':'idle');
 const labels={idle:'Не запущено',running:'Виконується',completed:'Завершено',failed:'Помилка'};
 const seconds=state.duration_seconds??(state.started_at?Math.max(0,Math.floor(((state.finished_at?Date.parse(state.finished_at):Date.now())-Date.parse(state.started_at))/1000)):null);
 const date=x=>x?displayDate(x):'—';
 details.innerHTML=`<p><b>${esc(labels[status]||status)}</b> · Run: ${esc(state.run_id||'ID недоступний у поточному runtime')} · PID: ${esc(state.pid??'—')}</p><p>Старт: ${esc(date(state.started_at))} · Тривалість: ${seconds===null?'—':Math.floor(seconds/60)+' хв '+seconds%60+' с'} · Завершення: ${esc(date(state.finished_at))}</p><p>Етап: ${esc(state.stage||state.message||'—')} · Прогрес: ${state.processed==null||state.total==null?'точні дані недоступні':esc(state.processed)+' / '+esc(state.total)}</p><p>Остання активність: ${esc(date(state.last_activity_at))} · Помилки поточного run: ${esc(state.current_run_errors??'невідомо')}</p><p>Остання помилка: ${esc(state.last_error||state.error||'—')}</p>`;
}
async function startBidsUpdate(){if($('#bidsDataRefresh').disabled)return;$('#bidsDataRefresh').disabled=true;try{await request(`${API}/bids-sync`,{method:'POST',headers:{'Content-Type':'application/json'},body:'{}'})}catch(error){toast(error.message)}finally{await loadBidsSyncStatus()}}
let powerbiPollTimer=null;
async function loadPowerbiStatus(){try{const data=await request(`${API}/powerbi-export-status?t=${Date.now()}`),state=data.state||{},mb=Number(data.size_bytes||0)/1048576;$('#powerbiPath').textContent=data.path||'—';$('#powerbiUpdated').textContent=data.updated_at?displayDate(data.updated_at):'Ще не створено';$('#powerbiSize').textContent=data.exists?(mb>=1024?(mb/1024).toLocaleString('uk-UA',{maximumFractionDigits:2})+' ГБ':mb.toLocaleString('uk-UA',{maximumFractionDigits:0})+' МБ'):'—';$('#powerbiRows').textContent=Number(data.total_rows||0).toLocaleString('uk-UA');$('#powerbiDatasets').innerHTML=(data.datasets||[]).map(item=>`<span><strong>${esc(item.name)}</strong>${Number(item.rows||0).toLocaleString('uk-UA')} рядків · ${Number(item.files||0)} файлів</span>`).join('');$('#powerbiStatusMessage').textContent=state.running?state.message:(state.error?state.message:(data.complete?'Набір готовий до оновлення в Power BI.':'Постійний набір ще не створено.'));$('#powerbiExportBtn').disabled=Boolean(state.running);return state}catch(error){$('#powerbiStatusMessage').textContent=error.message;return{}}}
const originalLoadPowerbiStatus=loadPowerbiStatus;
$('#powerbiExportBtn').disabled=true;
function updatePowerbiAvailability(){const button=$('#powerbiExportBtn');if(button)button.disabled=button.dataset.powerbiReady!=='1'||button.dataset.powerbiRunning==='1'||currentMe?.role!=='admin'||button.dataset.runtimeDisabled==='1'}
loadPowerbiStatus=async function(){
  const state=await originalLoadPowerbiStatus();
  if(typeof state.running!=='boolean'){$('#powerbiExportBtn').dataset.powerbiReady='0';updatePowerbiAvailability();return state}
  $('#powerbiExportBtn').dataset.powerbiReady='1';$('#powerbiExportBtn').dataset.powerbiRunning=state.running?'1':'0';updatePowerbiAvailability();
  if(state.running&&!powerbiPollTimer)powerbiPollTimer=setInterval(()=>loadPowerbiStatus(),4000);
  if(!state.running&&powerbiPollTimer){clearInterval(powerbiPollTimer);powerbiPollTimer=null}
  return state;
};
async function startPowerbiExport(){try{$('#powerbiExportBtn').disabled=true;await request(`${API}/powerbi-export`,{method:'POST',headers:{'Content-Type':'application/json'},body:'{}'});await loadPowerbiStatus()}catch(error){toast(error.message);await loadPowerbiStatus()}}
const operationalTaskTypeLabels={amcu_exclusion:'АМКУ · виключення',termination_exclusion:'Припинення · виключення',nazk_check:'НАЗК · перевірка',warning_block:'Блокування за попередженнями'};
const operationalTaskStatusLabels={new:'Нова',in_progress:'В роботі',awaiting_response:'Очікує відповіді',waiting_external:'Очікує зовнішньої відповіді',ready_for_document:'Готова до документа',awaiting_publication:'Очікує публікації',awaiting_sync:'Очікує sync',active_blocking:'Блокування діє',completed:'Виконана',cancelled:'Скасована'};
function operationalTaskStatusLabel(item){return item.task_type==='amcu_exclusion'&&item.status==='awaiting_sync'?'Розглянуто':(operationalTaskStatusLabels[item.status]||item.status)}
const operationalTaskReasonLabels={amcu_match:'Постачальника виявлено в реєстрі АМКУ',supplier_terminated_with_active_qualifications:'У ЄДР зафіксовано припинення постачальника',nazk_match:'Потрібна посткваліфікаційна перевірка НАЗК',person_match_requires_verification:'Збіг у реєстрі НАЗК потребує перевірки',warning_threshold_reached:'Досягнуто поріг попереджень'};
const operationalNazkStateLabels={confirmed:'Підтверджено',refuted:'Спростовано',needs_review:'Потребує перевірки',waiting_response:'Очікується відповідь',completed:'Завершено'};
function operationalCurrentReason(item){if(item.resolution_code==='nazk_record_no_longer_present')return 'Скасовано — запис особи більше відсутній у Реєстрі НАЗК';if(item.resolution_code==='no_active_qualifications')return 'Скасовано — відсутні активні кваліфікації';if(['manager_changed','nazk_not_relevant'].includes(item.resolution_code))return 'Скасовано — змінився керівник';if(item.task_type==='nazk_check'){const state=item.nazk_current_state||{};return operationalNazkStateLabels[state.result]||operationalNazkStateLabels[state.workflow_status]||'Стан НАЗК не визначено'}return operationalTaskReasonLabels[item.source_context?.trigger_reason]||'Операційна дія щодо постачальника'}
// List projection: business trigger, required action and status are separate concepts.
function operationalListTrigger(item){if(item.task_type==='nazk_check')return 'Виявлено запис у Реєстрі НАЗК';return operationalTaskReasonLabels[item.source_context?.trigger_reason]||'Операційна дія щодо постачальника'}
function operationalListAction(item){
  if(['completed','cancelled'].includes(item.status))return '';
  if(item.task_type==='amcu_exclusion'&&item.status==='awaiting_sync')return 'Очікувати підтвердження Prozorro';
  if(item.task_type==='nazk_check'){
    if(['waiting_external','awaiting_response'].includes(item.status))return 'Очікувати / опрацювати відповідь';
    if(['ready_for_document','ready_for_exclusion'].includes(item.status))return 'Підготувати рішення про виключення';
    if(['new','in_progress'].includes(item.status)&&!['confirmed','refuted'].includes(item.nazk_current_state?.result))return 'Перевірити збіг';
    return '';
  }
  return item.needs_action?'Потребує опрацювання':'Очікує наступного етапу';
}
let operationalTaskTimer=null;
let operationalBasisDirection='';
function operationalTaskParams(){return{search:$('#operationalTaskSearch').value.trim(),type:$('#operationalTaskType').value,status_group:$('#operationalTaskStatus').value||'active',officer:$('#operationalTaskOfficer').value,date_from:$('#operationalTaskDateFrom').value,...(operationalBasisDirection?{sort:'latest_basis_date',direction:operationalBasisDirection}:{})}}
function operationalSummaryLink(url,label){const value=String(url||'');if(!/^https?:\/\//i.test(value)&&!value.startsWith('/api/operational-tasks/'))return esc(label);return `<a href="${esc(value)}" target="_blank" rel="noopener">${esc(label)}</a>`}
function operationalCapturedPerson(item){const person=item.source_context?.person_name;return typeof person==='string'?person.trim():''}
function operationalPersonHtml(item){const person=operationalCapturedPerson(item);return person?`<strong>${esc(person)}</strong>`:'<strong class="request-warning" data-person-defect="missing-captured-identity">Дефект даних: не зафіксовано ПІБ особи задачі</strong>'}
function operationalTriggerHtml(item){return esc(operationalListTrigger(item))+(item.task_type==='nazk_check'?`<small>${operationalPersonHtml(item)}</small>`:'')}
function operationalResultHtml(item){return esc(item.result_summary?.label??'')}
function operationalActionColumnVisible(statusFilter){return statusFilter!=='completed'}
function operationalBasisHtml(item){const basis=item.basis_items||[];const entry=x=>`${esc(x.kind==='edr_record'?'Запис ЄДР':x.kind==='warning'?'Звернення':x.kind==='nazk_sentence'?(x.number||x.date?'Рішення з Реєстру НАЗК':'Запис у Реєстрі НАЗК'):'Рішення')}${x.number?` № ${esc(x.number)}`:''}${x.date?` від ${esc(displayDateOnly(x.date))}`:''}${x.reference?` · ${operationalSummaryLink(x.reference,'Документ')}`:''}`;return basis.length?`${entry(basis[0])}${basis.length>1?`<details><summary>Інші підстави (${basis.length-1})</summary>${basis.slice(1).map(x=>`<p>${entry(x)}</p>`).join('')}</details>`:''}`:''}
function operationalDecisionHtml(item){const d=item.officer_decision||{};return `${d.number?`№ ${esc(d.number)}`:''}${d.date?`${d.number?' ':''}від ${esc(displayDateOnly(d.date))}`:''}${d.reference?` ${operationalSummaryLink(d.reference,'Рішення УО')}`:''}${(d.documents||[]).map(x=>`<p>${operationalSummaryLink(x.download_url,x.display_filename||x.filename||'Документ')}${x.pdf_url?` · ${operationalSummaryLink(x.pdf_url,'PDF')}`:''}</p>`).join('')}`}
function operationalQualificationHtml(item){const q=item.qualification_summary;if(!q)return '';const h=q.coverage||{},r=q.residual||{},count=x=>x==null?'—':String(x);return `<section><h3>Кваліфікації, яких стосується рішення</h3><p>Зафіксовано активних: ${count(h.captured_active)} (snapshot: ${esc(displayDateOnly(h.captured_at))||'—'}) · Виключено цим рішенням: ${count(h.historically_excluded)} · Залишилося на момент рішення: ${count(h.historically_remaining)}</p><p>Пов’язаних: ${count(h.linked)} · Зараз активних / неактивних: ${count(h.current_linked_active)} / ${count(h.current_linked_inactive)} · Без поточного source: ${count(h.missing_current)} · Джерело: ${esc(h.provenance)||'—'}</p>${['amcu_exclusion','termination_exclusion'].includes(item.task_type)?`<p class="request-warning">Інформаційно: активних linked targets — ${count(r.linked_active)}; активних поза linked targets — ${count(r.outside_linked_active)}. ${esc(r.limitation)}</p>`:''}</section>`}
function operationalTerminalHtml(item){const decision=operationalDecisionHtml(item);return `<section><h3>Результат</h3><p>${operationalResultHtml(item)||esc(item.status==='cancelled'?'Скасовано':'Виконано; результат не зафіксовано')}</p>${decision?`<h3>Рішення УО</h3>${decision}`:''}${(item.supplier_requests||[]).length?`<h3>Запити постачальнику (не рішення УО)</h3>${item.supplier_requests.map(x=>`<p>${operationalSummaryLink(x.download_url,x.filename||'Запит постачальнику')}</p>`).join('')}`:''}</section>`}
function operationalTaskTypeMarker(type){return `<span class="operational-type-marker" data-task-type="${esc(type)}">${esc(operationalTaskTypeLabels[type]||type)}</span>`}
function renderOperationalTaskTypes(counts){
  const selected=$('#operationalTaskType').value;
  $('#operationalTaskTypes').innerHTML=['nazk_check','amcu_exclusion','warning_block','termination_exclusion'].filter(type=>Number(counts[type])>0).map(type=>`<button type="button" class="operational-type-marker operational-type-kpi${selected===type?' active':''}" data-task-type="${type}" aria-pressed="${selected===type}"><span>${esc(operationalTaskTypeLabels[type])}</span><strong>${Number(counts[type]).toLocaleString('uk-UA')}</strong></button>`).join('');
}
$('#operationalTaskTypes').onclick=event=>{const chip=event.target.closest('button[data-task-type]');if(!chip)return;const filter=$('#operationalTaskType');filter.value=filter.value===chip.dataset.taskType?'':chip.dataset.taskType;loadOperationalTasks()};
function operationalTaskEmptyMessage(){const group=$('#operationalTaskStatus').value||'active',type=$('#operationalTaskType').value;if(type==='amcu_exclusion'&&group==='active')return 'Активних задач АМКУ немає';if(group==='active')return 'Активних операційних задач немає';if(group==='completed')return 'Виконаних задач за вибраними умовами немає';if(group==='cancelled')return 'Скасованих задач за вибраними умовами немає';return 'Задач за вибраними умовами немає'}
let operationalListGeneration=0;
async function loadOperationalTasks(){
  const body=$('#operationalTasksBody');if(!body)return;
  const generation=++operationalListGeneration,showAction=operationalActionColumnVisible($('#operationalTaskStatus').value),colspan=showAction?10:9;
  $('#operationalActionHeader').hidden=!showAction;
  body.innerHTML=`<tr><td colspan="${colspan}">Завантаження…</td></tr>`;
  try{
    const data=await request(`${API}/operational-tasks?${new URLSearchParams(operationalTaskParams())}`),k=data.kpis||{};
    if(generation!==operationalListGeneration)return;
    const kpiKeys=['active','needs_action','awaiting_response','ready_for_document','awaiting_sync','completed'];
    $$('#operationalTaskKpis [data-task-kpi]').forEach(card=>{const value=k[card.dataset.taskKpi]||0,target=card.querySelector('strong');if(target)target.textContent=Number(value).toLocaleString('uk-UA');card.classList.toggle('active',card.dataset.taskKpi===(data.status_group||'active'))});
    renderOperationalTaskTypes(data.type_counts||{});
    $('#operationalActionHeader').hidden=!showAction;
    body.innerHTML=(data.items||[]).map(item=>`<tr data-task-id="${esc(item.id)}" tabindex="0" role="button" aria-label="Відкрити задачу для ${esc(item.supplier_name_snapshot)}"><td>${operationalTaskTypeMarker(item.task_type)}</td><td><strong>${esc(item.supplier_name_snapshot)||'—'}</strong><small>${esc(item.supplier_code)||'—'}</small></td><td>${operationalTriggerHtml(item)}</td><td ${showAction?'':'hidden'}>${esc(operationalListAction(item))}</td><td>${esc(formatOfficerName(item.assigned_officer_name))||'Не призначено'}</td><td>${esc(operationalTaskStatusLabel(item))}</td><td>${esc(displayDate(item.created_at))||'—'}</td><td>${operationalBasisHtml(item)}</td><td>${operationalResultHtml(item)}</td><td>${operationalDecisionHtml(item)}</td></tr>`).join('')||`<tr><td colspan="${showAction?10:9}">${operationalTaskEmptyMessage()}</td></tr>`;
    $('#operationalTasksCount').textContent=`Знайдено задач: ${Number(data.total||0).toLocaleString('uk-UA')}`;
  }catch(error){if(generation!==operationalListGeneration)return;body.innerHTML=`<tr><td colspan="${colspan}" class="request-warning">${esc(error.message)}</td></tr>`;$('#operationalTasksCount').textContent='Помилка завантаження'}
}
$('#operationalTasksNav').onclick=()=>showModule('operationalTasks');
$('#operationalTaskTemplates').onclick=()=>{showModule('administration');setAdminTab('templates')};
$('#requestsTemplates').onclick=()=>{showModule('administration');setAdminTab('templates')};
$('#requestsDeclension').onclick=async()=>{declensionReturnContext={originType:'violation_report_list'};showModule('references');setReferenceTab('declension');$('#declensionSearch').value='';$('#declensionBackToRequest').hidden=false;$('#declensionBackToRequest').textContent='← Назад до звернень';await loadDeclensionOverrides()};
$('#operationalTaskDeclension').onclick=async()=>{declensionReturnContext={originType:'operational_task_list'};showModule('references');setReferenceTab('declension');$('#declensionSearch').value='';$('#declensionBackToRequest').hidden=false;$('#declensionBackToRequest').textContent='← Назад до операційних задач';await loadDeclensionOverrides()};
$('#operationalTaskSearch').oninput=()=>{clearTimeout(operationalTaskTimer);operationalTaskTimer=setTimeout(loadOperationalTasks,300)};
$('#operationalBasisSort').onclick=()=>{operationalBasisDirection=operationalBasisDirection==='desc'?'asc':'desc';$('#operationalBasisSort').textContent=`Дата підстави ${operationalBasisDirection==='asc'?'↑':'↓'}`;loadOperationalTasks()};
function operationalHistoryHtml(events=[]){const labels={supplier_request_generated:'Сформовано запит постачальнику',threshold_reconciled_to_rolling:'Уточнено період підрахунку попереджень',protocol_decision_attached:'Прив’язано протокольне рішення',legacy_blocking_confirmed:'Виконання блокування підтверджено',created:'Задачу створено',assigned:'Призначено відповідальну УО',status_changed:'Статус змінено',request_sent:'Запит направлено',response_received:'Отримано відповідь / інформацію',post_close_information:'Додано інформацію після закриття',amcu_extract_url_added:'Оновлено посилання на витяг АМКУ',nazk_refuted:'НАЗК · Спростовано',nazk_result_refuted:'НАЗК · Спростовано',nazk_confirmed:'НАЗК · Підтверджено',nazk_result_confirmed:'НАЗК · Підтверджено',nazk_insufficient:'НАЗК · Недостатньо інформації',nazk_result_insufficient:'НАЗК · Недостатньо інформації',cancelled_no_active_qualifications:'Скасовано: відсутні активні кваліфікації',cancelled_manager_changed:'Скасовано: змінився керівник'};return `<section><h3>Історія задачі</h3><div class="operational-history">${events.map(x=>`<div><strong>${esc(labels[x.event_type]||x.event_type)}</strong><span>${esc(displayDate(x.created_at))} · ${esc(x.actor||'Система')}</span></div>`).join('')||'<p>Подій ще немає</p>'}</div></section>`}
function operationalActionIcon(kind){
 if(kind==='docx'||kind==='pdf'){
  const label=kind==='docx'?'DOCX':'PDF';
  return `<svg class="operational-file-icon operational-file-icon-${kind}" viewBox="0 0 32 32" aria-hidden="true" focusable="false"><path class="operational-file-sheet" d="M7 2.5h12l6 6V29.5H7z"/><path class="operational-file-fold" d="M19 2.5v6h6"/><rect class="operational-file-label" x="3" y="16" width="26" height="10" rx="2"/><text class="operational-file-type" x="16" y="23.25" text-anchor="middle">${label}</text></svg>`;
 }
 const save='<path d="M5 3h12l2 2v16H5z"/><path d="M8 3v6h8V3M8 21v-7h8v7"/>';
 return `<svg viewBox="0 0 24 24" aria-hidden="true" focusable="false" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">${save}</svg>`;
}
function protocolDocumentActions({docxUrl='',pdfUrl='',pdfAttribute='data-download-protocol-pdf'}){
 return !docxUrl?'':`<div class="protocol-document-actions violation-inline-actions"><a class="ghost button-link icon-button operational-document-download" href="${esc(docxUrl)}" download title="Завантажити DOCX" aria-label="Завантажити DOCX">${operationalActionIcon('docx')}</a><button type="button" class="ghost icon-button operational-document-download" ${pdfAttribute}="${esc(pdfUrl)}" title="Завантажити PDF" aria-label="Завантажити PDF">${operationalActionIcon('pdf')}</button></div>`;
}
function operationalQualificationsHtml(items=[],supplierCode=''){
 const statusLabel=value=>({active:'Активна',terminated:'Неактивна',expired:'Неактивна · строк відбору сплив',suspended:'Призупинена'}[value]||value||'—');
 const rows=items.map(x=>{const url=marketplaceApplicationsUrl(x.marketplace_url,supplierCode);return`<tr><td>${esc(x.dk_code||'—')}</td><td><strong>${esc(x.framework_title||'—')}</strong></td><td><small>${esc(x.framework_pretty_id||x.framework_id||'—')}</small></td><td><span class="status-chip">${esc(statusLabel(x.qualification_status))}</span>${x.qualification_event_date?`<small>${esc(displayDate(x.qualification_event_date))}</small>`:''}</td><td class="link-cell">${url?`<a class="external-link" href="${esc(url)}" target="_blank" rel="noopener" title="Відкрити кваліфікацію на майданчику" aria-label="Відкрити кваліфікацію на майданчику">&#128279;</a>`:'<span class="muted">—</span>'}</td></tr>`}).join('');
 return `<section class="operational-qualifications"><h3>Активні кваліфікації · ${items.length}</h3><div class="operational-table"><table><thead><tr><th>Код ДК</th><th>Назва відбору</th><th>Технічний ID</th><th>Чинна кваліфікація</th><th>Майданчик</th></tr></thead><tbody>${rows||'<tr><td colspan="5">Активних кваліфікацій немає</td></tr>'}</tbody></table></div></section>`;
}
function operationalNazkHtml(item){const n=item.nazk_current_state||{},manager=item.current_manager||{},channels=item.channels||{},records=item.nazk_records||[],terminal=['completed','cancelled'].includes(item.status),channel=x=>channels[x]||{status:'not_sent'},channelLabel={not_sent:'Не направлено',document_prepared:'Документ підготовлено',waiting:'Очікується відповідь',response_received:'Відповідь отримано',closed:'Закрито',cancelled:'Скасовано'};return `<section><h3>Поточний стан НАЗК</h3><dl class="operational-facts"><div><dt>Фактичний результат</dt><dd>${esc(operationalNazkStateLabels[n.result]||operationalNazkStateLabels[n.workflow_status]||'Не визначено')}</dd></div><div><dt>Особа задачі</dt><dd>${esc(n.manager_name||item.source_context?.person_name||'—')} · <b>${item.task_person_is_current?'Поточний керівник':'Попередній керівник'}</b></dd></div><div><dt>Поточний керівник</dt><dd>${esc(manager.manager_name||'Не визначено')}</dd></div><div><dt>РНОКПП</dt><dd>${esc(manager.manager_tax_id||'Не зазначено')}</dd></div></dl></section><section><h3>Дані Реєстру НАЗК</h3>${records.map(x=>`<article class="operational-record"><strong>${esc(x.full_name||'—')}</strong><p>${esc(x.offense_name||x.punishment||'Відомості не зазначені')}</p><small>${esc(x.source_id)} · ${esc(displayDateOnly(x.sentence_date))}${x.court_case_number?` · справа ${esc(x.court_case_number)}`:''}</small>${nazkRegistrySourceNotice(x)}${x.decision_url?`<a href="${esc(x.decision_url)}" target="_blank" rel="noopener">Відкрити джерело</a>`:''}</article>`).join('')||'<p>Пов’язаних записів не знайдено</p>'}</section><section><h3>Зовнішні запити</h3><div class="operational-channels">${[['supplier','Постачальнику'],['nazk','До НАЗК']].map(([key,label])=>`<div><strong>${label}</strong><span>${esc(channelLabel[channel(key).status]||channel(key).status)}</span>${!terminal?`<button type="button" class="ghost operational-request-sent" data-channel="${key}">Зафіксувати направлення</button>`:''}<button type="button" class="ghost operational-document-hook" disabled title="Буде доступно після підключення Конструктора шаблонів">Сформувати запит</button></div>`).join('')}</div></section><section><h3>${terminal?'Інформація після закриття':'Отримані відповіді'}</h3>${(item.responses||[]).map(x=>`<p><strong>${x.source==='nazk'?'НАЗК':'Постачальник'}</strong> · ${esc(displayDateOnly(x.response_date))||'дата не зазначена'} · ${esc(x.summary||'Без короткого змісту')}</p>`).join('')||'<p>Відповідей ще немає</p>'}<button type="button" class="primary operational-add-response">${terminal?'Додати інформацію після закриття':'Додати відповідь / інформацію'}</button></section>`}
function operationalAmcuHtml(item){
 if(item.task_type==='termination_exclusion')return operationalTerminationHtml(item);
 const generation=item.document_generation||{},documents=generation.documents||[],latest=documents[0],declensions=generation.declensions||[],unresolved=generation.unresolved||[];
 const reviewed=item.status==='awaiting_sync';
 const unresolvedHtml=unresolved.length?`<div class="request-warning operational-amcu-declensions"><strong>Потрібні перевірені відмінкові форми:</strong><ul>${unresolved.map(entry=>`<li><span>${esc(entry.original)} · ${esc({genitive:'родовий',dative:'давальний',accusative:'знахідний'}[entry.grammatical_case]||entry.grammatical_case)}</span></li>`).join('')}</ul></div>`:'';
 const documentsHtml=latest?`<div class="operational-generated-control operational-amcu-generated"><div class="operational-document-identity"><strong>Готовий документ · v${Number(latest.version||1)}</strong><span>${esc(latest.display_filename||latest.filename)}</span></div>${resolvedDocumentMetadataHtml(latest.resolved_metadata)}${documents.length>1?`<details><summary>Попередні версії · ${documents.length-1}</summary>${documents.slice(1).map(doc=>`<article class="operational-document-version"><a href="${esc(doc.download_url)}">v${Number(doc.version||1)} · ${esc(doc.display_filename||doc.filename)}</a>${resolvedDocumentMetadataHtml(doc.resolved_metadata)}</article>`).join('')}</details>`:''}</div>`:'';
 const generationError=(generation.errors||[]).filter(error=>!unresolved.length||error!=='Потрібні перевірені відмінкові форми').map(esc).join(' · ');
 const downloadActions=latest?`<a class="ghost button-link icon-button operational-document-download" href="${esc(latest.download_url)}" download title="Завантажити DOCX" aria-label="Завантажити DOCX">${operationalActionIcon('docx')}</a><button type="button" class="ghost icon-button operational-document-download" data-amcu-pdf-url="${esc(latest.pdf_url)}" title="Завантажити PDF" aria-label="Завантажити PDF">${operationalActionIcon('pdf')}</button>`:'';
 const reviewedAction=latest&&item.status==='ready_for_document'?'<button type="button" class="primary operational-amcu-reviewed">Позначити як розглянуто</button>':reviewed?'<span class="operational-ready">Очікується підтвердження виключення з Prozorro</span>':'';
 return `<section class="operational-amcu-section protocol-decision-section"><h3>Рішення АМКУ</h3><div class="operational-table operational-amcu-decisions"><table><thead><tr><th>№ рішення</th><th>Дата</th><th>Орган АМКУ</th><th>Посилання на витяг</th></tr></thead><tbody>${(item.amcu_decisions||[]).map(x=>`<tr><td>${esc(x.decision_no||'—')}</td><td>${esc(displayDateOnly(x.decision_date))||'—'}</td><td>${esc(x.authority||'—')}</td><td><span class="operational-amcu-url-control"><input data-amcu-decision="${esc(x.row_key)}" value="${esc(x.extract_url||'')}" placeholder="https://…" ${reviewed?'disabled':''}><button type="button" class="ghost icon-button operational-amcu-save" data-decision="${esc(x.row_key)}" title="Зберегти посилання на витяг" aria-label="Зберегти посилання на витяг" ${reviewed?'disabled':''}>${operationalActionIcon('save')}</button></span></td></tr>`).join('')||'<tr><td colspan="4">Рішень не знайдено</td></tr>'}</tbody></table></div>${!reviewed?((item.amcu_decisions||[]).some(x=>!x.extract_url)?'<p class="request-warning">Додайте посилання на витяг для всіх рішень АМКУ.</p>':'<p class="operational-ready">Всі рішення мають посилання; задачу можна готувати до документа.</p>'):''}<div class="operational-amcu-action-row"><label>№ протоколу<input data-amcu-protocol-number value="${esc(item.protocol_number||'')}" ${reviewed?'disabled':''}></label><label>Дата протоколу<input type="date" data-amcu-protocol-date value="${esc(String(item.protocol_date||'').slice(0,10))}" ${reviewed?'disabled':''}></label><div class="operational-amcu-document-actions">${documentDeclensionAction(declensions,'data-amcu-declension')}<button type="button" class="ghost operational-generate-amcu" ${!reviewed&&generation.ready&&generation.can_manage?'':'disabled'}>${latest?'Перегенерувати протокол':'Сформувати протокол про виключення'}</button>${downloadActions}${reviewedAction}</div></div>${unresolvedHtml}${!reviewed&&generationError?`<p class="request-warning operational-amcu-generation-error">${generationError}</p>`:''}${documentsHtml}<span class="operational-amcu-document-status" role="alert"></span></section>${operationalQualificationsHtml(item.effective_applications||[],item.supplier_code)}`
}
function operationalWarningHtml(item){const s=item.source_context||{};return `<section><h3>Підстава блокування</h3><dl class="operational-facts"><div><dt>Поріг</dt><dd>${s.threshold_type==='3_in_1_rolling_month'?'3 попередження за 1 календарний місяць':'5 попереджень за 3 календарні місяці'}</dd></div><div><dt>Останнє попередження</dt><dd>${esc(displayDateOnly(s.threshold_reached_at))}</dd></div><div><dt>Початок блокування</dt><dd>${esc(displayDateOnly(s.blocking_start_date))}</dd></div><div><dt>Завершення 90 к.д.</dt><dd>${esc(displayDateOnly(s.blocking_end_date))}</dd></div></dl></section><section><h3>Попередження, використані для блокування</h3><div class="operational-table"><table><thead><tr><th>UA-D</th><th>Дата</th><th>Закупівля</th><th>Замовник</th><th>Посилання</th></tr></thead><tbody>${(item.warnings||[]).map(x=>`<tr><td>${esc(x.report_id||'—')}</td><td>${esc(displayDateOnly(x.warning_date))}</td><td>${esc(x.tender_pretty_id||'—')}</td><td>${esc(x.author_name||'—')}</td><td>${requestViolationUrl(x)?`<a href="${esc(requestViolationUrl(x))}" target="_blank" rel="noopener">Відкрити</a>`:'—'}</td></tr>`).join('')}</tbody></table></div><button type="button" class="ghost operational-document-hook" disabled title="Буде доступно після підключення Конструктора шаблонів">Сформувати протокол про блокування</button></section>`}
function operationalTerminationHtml(item){
 const evidence=item.termination_evidence||{},supplier=item.supplier_snapshot||{},generation=item.document_generation||{},terminal=['completed','cancelled'].includes(item.status);
 const rows=(item.target_qualifications||[]).map(x=>`<tr><td>${esc(x.dk_code||'—')}</td><td><strong>${esc(x.framework_title||'—')}</strong></td><td><small>${esc(x.framework_pretty_id||x.framework_id||x.qualification_id||'—')}</small></td><td><span class="status-chip">${x.effective_active?'Активна':'Більше не активна'}</span></td><td><select data-termination-decision data-qualification-id="${esc(x.qualification_id)}" data-registry-contract-id="${esc(x.registry_contract_id)}" ${terminal?'disabled':''}><option value="">Оберіть рішення</option><option value="exclude" ${x.decision==='exclude'?'selected':''}>Виключити</option><option value="keep" ${x.decision==='keep'?'selected':''}>Не виключати</option></select></td><td><input data-termination-note value="${esc(x.note||'')}" placeholder="Коментар" ${terminal?'disabled':''}></td></tr>`).join('');
 const errors=(generation.errors||[]).map(esc).join(' · ');
 return `<section class="operational-context-card"><h3>Відомості про припинення</h3><dl class="operational-facts"><div><dt>Тип постачальника</dt><dd>${supplier.type==='individual_entrepreneur'?'ФОП':'Юридична особа'}</dd></div><div><dt>Статус ЄДР</dt><dd>${esc(evidence.status||'—')}</dd></div>${evidence.details?`<div><dt>Реквізити припинення</dt><dd>${esc(evidence.details)}</dd></div>`:''}${evidence.record_date?`<div><dt>Дата запису</dt><dd>${esc(displayDateOnly(evidence.record_date))}</dd></div>`:''}${evidence.record_number?`<div><dt>Номер запису</dt><dd>${esc(evidence.record_number)}</dd></div>`:''}</dl></section><section class="operational-qualifications"><h3>Кваліфікації, зафіксовані при створенні · ${(item.target_qualifications||[]).length}</h3><div class="operational-table"><table><thead><tr><th>Код ДК</th><th>Назва відбору</th><th>Технічний ID</th><th>Поточний стан</th><th>Рішення</th><th>Коментар</th></tr></thead><tbody>${rows||'<tr><td colspan="6">Кваліфікацій немає</td></tr>'}</tbody></table></div></section><section class="protocol-decision-section"><h3>Протокольне рішення</h3><div class="operational-amcu-action-row"><label>№ протоколу<input data-termination-protocol-number value="${esc(item.protocol_number||'')}" ${terminal?'disabled':''}></label><label>Дата протоколу<input type="date" data-termination-protocol-date value="${esc(String(item.protocol_date||'').slice(0,10))}" ${terminal?'disabled':''}></label><div>${documentDeclensionAction(generation.declensions,'data-termination-declension')}<button type="button" class="ghost operational-generate-termination" ${!terminal&&item.status!=='awaiting_sync'&&generation.ready&&generation.can_manage?'':'disabled'}>Сформувати протокол про виключення</button></div></div>${!terminal&&errors?`<p class="request-warning">${errors}</p>`:''}${operationalProtocolVersionsHtml(generation.documents||[])}<span class="operational-termination-document-status" role="alert"></span></section>`;
}
let activeOperationalTask=null;
function operationalProtocolVersionsHtml(documents){const row=d=>`<article class="operational-document-version"><strong>${esc(d.display_filename||d.filename)} · v${esc(d.version)}</strong>${protocolDocumentActions({docxUrl:d.download_url,pdfUrl:d.pdf_url||'',pdfAttribute:'data-amcu-pdf-url'})}${resolvedDocumentMetadataHtml(d.resolved_metadata)}</article>`;return documents.length?`<section class="operational-generated-documents">${row(documents[0])}${documents.length>1?`<details><summary>Попередні версії · ${documents.length-1}</summary>${documents.slice(1).map(row).join('')}</details>`:''}</section>`:''}
function installOperationalTerminationDocuments(item,body){if(item.task_type!=='termination_exclusion')return;body.querySelectorAll('[data-amcu-pdf-url]').forEach(b=>b.onclick=()=>downloadAmcuProtocolPdf(b));const entries=item.document_generation?.declensions||[];body.querySelectorAll('[data-termination-declension]').forEach(b=>b.onclick=()=>openDeclensionFromAmcuValidation(entries[0],item,entries));const button=body.querySelector('.operational-generate-termination');if(button)button.onclick=async()=>{button.disabled=true;try{await request(`${API}/operational-tasks/${item.id}/documents/termination-exclusion-protocol`,{method:'POST',headers:{'Content-Type':'application/json'},body:'{}'});toast('Протокол сформовано. Задачу не завершено.');await openOperationalTask(item.id);await loadOperationalTasks()}catch(error){if(error.code==='declension_unresolved')await openDeclensionFromAmcuValidation(error.unresolved[0],item,error.unresolved);else toast(error.message);button.disabled=false}}}
async function openOperationalTask(taskId){const dialog=$('#operationalTaskDialog'),body=$('#operationalTaskBody');body.innerHTML='<p>Завантаження…</p>';dialog.showModal();try{const item=await request(`${API}/operational-tasks/${encodeURIComponent(taskId)}`);activeOperationalTask=item;$('#operationalTaskTitle').textContent=operationalTaskTypeLabels[item.task_type]||'Операційна задача';$('#operationalTaskSubtitle').textContent=`${item.supplier_name_snapshot||''} · ${item.supplier_code||''}`;const typeHtml=item.task_type==='nazk_check'?operationalNazkHtml(item):item.task_type==='amcu_exclusion'?operationalAmcuHtml(item):operationalWarningHtml(item);body.innerHTML=`<section class="operational-task-head"><div><span>${esc(operationalTaskTypeLabels[item.task_type]||item.task_type)}</span><h3>${esc(item.supplier_name_snapshot)||'—'}</h3><p>ЄДРПОУ / РНОКПП: <strong>${esc(item.supplier_code)||'—'}</strong></p></div><dl class="operational-facts"><div><dt>Статус</dt><dd>${esc(operationalTaskStatusLabels[item.status]||item.status)}</dd></div><div><dt>Відповідальна УО</dt><dd>${esc(item.assigned_officer_name)||'Не призначено'}</dd></div><div><dt>Створено</dt><dd>${esc(displayDate(item.created_at))}</dd></div><div><dt>Активних кваліфікацій</dt><dd>${Number(item.effective_active_count||0).toLocaleString('uk-UA')}</dd></div></dl><p>${esc(operationalCurrentReason(item))}</p><button type="button" class="ghost" id="operationalOpenSupplier">Відкрити картку постачальника</button></section>${typeHtml}${operationalHistoryHtml(item.events||[])}`;$('#operationalOpenSupplier').onclick=()=>openSupplierProfile(item.supplier_code,{returnTaskId:item.id});body.querySelectorAll('.operational-amcu-save').forEach(button=>button.onclick=async()=>{const input=button.closest('tr')?.querySelector('[data-amcu-decision]');try{await request(`${API}/operational-tasks/${item.id}/amcu-decisions/${encodeURIComponent(button.dataset.decision)}`,{method:'PATCH',headers:{'Content-Type':'application/json'},body:JSON.stringify({extract_url:input?.value||''})});toast('Посилання на витяг збережено');await openOperationalTask(item.id)}catch(error){toast(error.message)}});body.querySelectorAll('.operational-request-sent').forEach(button=>button.onclick=()=>openOperationalInlineForm(item,'sent',button.dataset.channel));body.querySelector('.operational-add-response')?.addEventListener('click',()=>openOperationalInlineForm(item,'response'));$('#operationalTaskSave').hidden=false;$('#operationalTaskSave').onclick=()=>saveOperationalTask(item)}catch(error){body.innerHTML=`<p class="request-warning">${esc(error.message)}</p>`;$('#operationalTaskSave').hidden=true}}
function openOperationalInlineForm(item,kind,channel='supplier'){const body=$('#operationalTaskBody'),old=body.querySelector('.operational-inline-form');old?.remove();const form=document.createElement('section');form.className='operational-inline-form';form.innerHTML=kind==='sent'?`<h3>Зафіксувати направлення · ${channel==='nazk'?'НАЗК':'Постачальнику'}</h3><div class="request-form-grid"><label>Дата направлення<input type="date" data-op="sent_at"></label><label>Вихідний №<input data-op="outgoing_number"></label><label>Посилання / reference<input data-op="reference_url"></label><label class="wide">Коментар<textarea data-op="comment"></textarea></label></div><button type="button" class="primary">Зберегти направлення</button>`:`<h3>${['completed','cancelled'].includes(item.status)?'Інформація після закриття':'Додати відповідь / інформацію'}</h3><div class="request-form-grid"><label>Джерело<select data-op="source"><option value="supplier">Постачальник</option><option value="nazk">НАЗК</option></select></label><label>Дата відповіді<input type="date" data-op="response_date"></label><label>Вхідний №<input data-op="incoming_number"></label><label>Посилання / reference<input data-op="reference_url"></label><label>Документ / реквізити<input data-op="document_reference"></label><label>Результат інформації<select data-op="information_result"><option value="neutral">Не визначає результат</option><option value="refutes">Спростовує</option><option value="confirms">Підтверджує</option></select></label><label class="wide">Короткий зміст<textarea data-op="summary"></textarea></label></div><button type="button" class="primary">Зберегти інформацію</button>`;body.prepend(form);form.querySelector('button').onclick=async()=>{const payload=Object.fromEntries([...form.querySelectorAll('[data-op]')].map(x=>[x.dataset.op,x.value]));try{await request(kind==='sent'?`${API}/operational-tasks/${item.id}/channels/${channel}/sent`:`${API}/operational-tasks/${item.id}/responses`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(payload)});toast('Інформацію збережено');await openOperationalTask(item.id);await loadOperationalTasks()}catch(error){toast(error.message)}}}
async function saveOperationalTask(item){const next=['amcu_exclusion','termination_exclusion'].includes(item.task_type)&&item.status==='in_progress'?'ready_for_document':item.status==='new'?'in_progress':item.status,payload={status:next,assigned_officer_id:item.assigned_officer_id};if(item.task_type==='amcu_exclusion'){payload.amcu_decisions=[...$('#operationalTaskBody').querySelectorAll('[data-amcu-decision]')].map(input=>({decision_id:input.dataset.amcuDecision,extract_url:input.value}));payload.protocol_number=$('#operationalTaskBody').querySelector('[data-amcu-protocol-number]')?.value||'';payload.protocol_date=$('#operationalTaskBody').querySelector('[data-amcu-protocol-date]')?.value||''}if(item.task_type==='termination_exclusion'){payload.qualification_decisions=[...$('#operationalTaskBody').querySelectorAll('[data-termination-decision]')].map(input=>({qualification_id:input.dataset.qualificationId,registry_contract_id:input.dataset.registryContractId,decision:input.value,note:input.closest('tr')?.querySelector('[data-termination-note]')?.value||''}));payload.protocol_number=$('#operationalTaskBody').querySelector('[data-termination-protocol-number]')?.value||'';payload.protocol_date=$('#operationalTaskBody').querySelector('[data-termination-protocol-date]')?.value||''}try{await request(`${API}/operational-tasks/${item.id}`,{method:'PATCH',headers:{'Content-Type':'application/json'},body:JSON.stringify(payload)});toast(next===item.status?'Задачу збережено':'Статус задачі оновлено');await openOperationalTask(item.id);await loadOperationalTasks()}catch(error){toast(error.message)}}
const operationalNazkHtmlBase=operationalNazkHtml;
operationalNazkHtml=function(item){const terminal=['completed','cancelled'].includes(item.status),confirmed=item.nazk_current_state?.result==='confirmed'&&Number(item.effective_active_count)>0;return operationalNazkHtmlBase(item)+(!terminal?`<section><h3>Результат перевірки</h3><div class="violation-inline-actions"><button class="primary operational-nazk-result" data-result="confirmed">Збіг підтверджено</button><button class="ghost operational-nazk-result" data-result="refuted">Спростовано</button><button class="ghost operational-nazk-result" data-result="insufficient">Недостатньо інформації</button></div></section>`:'')+(confirmed?`<section><h3>Подальші дії</h3><p class="operational-ready">Підстава підтверджена. Активних кваліфікацій: ${Number(item.effective_active_count)}. Статус: готова до виключення.</p><button class="ghost" disabled title="Буде доступно після налаштування Конструктора шаблонів">Сформувати протокольне рішення</button></section>`:'')};
const operationalWarningHtmlBase=operationalWarningHtml;
operationalWarningHtml=function(item){
return `<section><h3>Фактичний стан блокування</h3><p class="${item.blocking_factual_state==='blocked'?'operational-ready':'request-warning'}">${item.blocking_factual_state==='blocked'?'Заблоковано':'Не підтверджено'}</p></section>`+operationalWarningHtmlBase(item)+operationalWarningDecision(item);
};
const openOperationalTaskRendered=openOperationalTask;
function installSharedDetailWindow(dialog){if(!dialog||dialog.dataset.detailWindow)return;dialog.dataset.detailWindow='modal';const form=dialog.querySelector(':scope>form'),header=form?.querySelector(':scope>header'),close=header?.querySelector('.dialog-close');if(!form||!header)return;const toggle=document.createElement('button');toggle.type='button';toggle.className='ghost detail-window-toggle';toggle.textContent='В окреме вікно';toggle.title='Перемкнути modal / floating';header.insertBefore(toggle,close);toggle.onclick=()=>{const floating=dialog.dataset.detailWindow!=='floating';dialog.dataset.detailWindow=floating?'floating':'modal';toggle.textContent=floating?'Повернути в modal':'В окреме вікно';if(floating){const r=form.getBoundingClientRect();form.style.left=`${Math.max(8,r.left)}px`;form.style.top=`${Math.max(8,r.top)}px`}else{form.style.left=form.style.top=''}};installViewportDrag(dialog,form,header,{enabled:()=>dialog.dataset.detailWindow==='floating',resetOnClose:false})}
installSharedDetailWindow($('#operationalTaskDialog'));
installSharedDetailWindow($('#supplierProfileDialog'));
openOperationalTask=async function(taskId){const dialog=$('#operationalTaskDialog');if(dialog.open)dialog.close();const result=await openOperationalTaskRendered(taskId),body=$('#operationalTaskBody');if(['manager_changed','nazk_not_relevant'].includes(activeOperationalTask?.resolution_code)){const summary=body.querySelector('.operational-task-head>p:last-of-type');if(summary)summary.textContent=activeOperationalTask.resolution_text||'Скасовано — зникла підстава для виключення. Особа, щодо якої виявлено НАЗК, більше не є поточним керівником постачальника.'}body.querySelectorAll('.operational-nazk-result').forEach(button=>button.onclick=async()=>{try{await request(`${API}/operational-tasks/${activeOperationalTask.id}/nazk-result`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({result:button.dataset.result})});toast('Результат перевірки збережено');await openOperationalTask(activeOperationalTask.id);await loadOperationalTasks()}catch(error){toast(error.message)}});body.querySelector('.operational-blocking-attach')?.addEventListener('click',async()=>{const payload=Object.fromEntries([...body.querySelectorAll('[data-blocking]')].map(x=>[x.dataset.blocking,x.value]));try{await request(`${API}/operational-tasks/${activeOperationalTask.id}/blocking-decision`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(payload)});toast('Рішення прив’язано');await openOperationalTask(activeOperationalTask.id)}catch(error){toast(error.message)}});body.querySelector('.operational-blocking-complete')?.addEventListener('click',async()=>{try{await request(`${API}/operational-tasks/${activeOperationalTask.id}/blocking-complete`,{method:'POST'});toast('Задачу завершено');await openOperationalTask(activeOperationalTask.id);await loadOperationalTasks()}catch(error){toast(error.message)}});return result};
function operationalTaskHumanState(item){if(['completed','cancelled'].includes(item.status))return item.result_summary?.label||(item.status==='completed'?'Виконано':'Скасовано');if(item.status==='cancelled')return operationalCurrentReason(item);if(item.task_type==='amcu_exclusion'&&item.status==='awaiting_sync')return'Розглянуто · очікується підтвердження Prozorro';if(item.status==='waiting_external')return'НАЗК · Очікується відповідь';if(item.status==='ready_for_document')return'Готова до виключення';if(item.status==='completed'&&item.resolution_code==='nazk_refuted')return'НАЗК · Спростовано';if(item.status==='completed'&&item.resolution_code==='nazk_not_current')return'НАЗК · Не актуально';if(item.task_type==='nazk_check'&&item.nazk_current_state?.result==='confirmed')return'НАЗК · Підтверджено';return item.task_type==='nazk_check'?'НАЗК · Потребує перевірки':'Потребує опрацювання'}
function operationalAssignmentAction(item){return ['completed','cancelled'].includes(item.status)?'':`<button type="button" class="inline-link operational-assign">${item.assigned_officer_id?'Змінити':'Призначити УО'}</button>`}
function operationalCollapsedHistory(events){return `<details class="operational-history-details"><summary>Історія задачі · ${events.length}</summary>${operationalHistoryHtml(events)}</details>`}
function refreshOperationalHistory(item,body){const old=body.querySelector('.operational-history-details');if(old){const open=old.open;old.outerHTML=operationalCollapsedHistory(item.events||[]);body.querySelector('.operational-history-details').open=open}}
function operationalWarningDecision(item,editing=false){
 const d=item.blocking_decision||{},terminal=['completed','cancelled'].includes(item.status);
 const attached=!!(d.decision_date&&d.protocol_number&&d.prozorro_url),ready=attached&&item.blocking_factual_state==='blocked';
 const fields=`<div class="request-form-grid"><label>Дата рішення<input type="date" data-blocking="decision_date" value="${esc(d.decision_date||'')}"></label><label>№ рішення / протоколу<input data-blocking="protocol_number" value="${esc(d.protocol_number||'')}"></label><label class="wide">Посилання на рішення в Prozorro<input data-blocking="prozorro_url" value="${esc(d.prozorro_url||'')}"></label><label>Додатковий document URL<input data-blocking="document_url" value="${esc(d.document_url||'')}"></label><label>Примітка УО<input data-blocking="officer_note" value="${esc(d.officer_note||'')}"></label></div>`;
 return `<section class="operational-warning-decision"><h3>Рішення про блокування</h3>${(!attached||editing)&&!terminal?`${fields}<button type="button" class="primary operational-blocking-attach">Прив’язати рішення</button>${attached?'<button type="button" class="ghost operational-blocking-cancel-edit">Скасувати</button>':''}`:attached?`<a href="${esc(d.prozorro_url)}" target="_blank" rel="noopener">Протокольне рішення від ${esc(displayDateOnly(d.decision_date))} № ${esc(d.protocol_number)}</a>${!terminal?' <button type="button" class="ghost operational-blocking-edit">Редагувати реквізити</button>':''}`:'<p>Рішення не прив’язано</p>'}<p role="alert" class="request-warning" hidden></p>${d.used_for_blocking?'<small>Попередження використано для блокування</small>':''}<div class="violation-inline-actions">${!terminal?`<button type="button" class="primary operational-blocking-complete" ${ready?'':'disabled'}>Позначити виконаною</button>`:''}</div></section>`;
}
function installOperationalWarningActions(item,body){
 if(item.task_type!=='warning_block')return;
 const render=(editing=false)=>{body.querySelector('.operational-warning-decision').outerHTML=operationalWarningDecision(item,editing);installOperationalWarningActions(item,body)};
 body.querySelector('.operational-blocking-edit')?.addEventListener('click',()=>render(true));
 body.querySelector('.operational-blocking-cancel-edit')?.addEventListener('click',()=>render());
 const send=async(button,suffix,payload)=>{
   const error=body.querySelector('.operational-warning-decision [role="alert"]');error.hidden=true;button.disabled=true;
   try{
     const updated=await request(`${API}/operational-tasks/${item.id}/${suffix}`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(payload)});
     Object.assign(item,updated);activeOperationalTask=item;render();refreshOperationalHistory(item,body);
     if(suffix==='blocking-complete')await openOperationalTask(item.id);
     toast(suffix==='blocking-decision'?'Рішення прив’язано':'Задачу завершено');
   }catch(e){error.textContent=e.message;error.hidden=false;button.disabled=false}
 };
 body.querySelector('.operational-blocking-attach')?.addEventListener('click',e=>send(e.currentTarget,'blocking-decision',Object.fromEntries([...body.querySelectorAll('[data-blocking]')].map(x=>[x.dataset.blocking,x.value]))));
 body.querySelector('.operational-blocking-complete')?.addEventListener('click',e=>send(e.currentTarget,'blocking-complete',{}));
}
function installOperationalAssignment(item,body){
  if(['completed','cancelled'].includes(item.status))return;
  const button=body.querySelector('.operational-assign');
  if(!button)return;
  button.onclick=async()=>{
    const cell=button.closest('dd'),original=cell.innerHTML;
    try{
      const officers=await loadAuthorizedOfficers();
      cell.innerHTML=`<select aria-label="Відповідальна УО"><option value="">Не призначено</option>${officers.filter(x=>x.active).map(x=>`<option value="${esc(x.id)}" ${String(x.id)===String(item.assigned_officer_id)?'selected':''}>${esc(x.full_name)}</option>`).join('')}</select><button type="button" class="primary" data-assign-save>Призначити</button><button type="button" class="ghost" data-assign-cancel>Скасувати</button><span role="alert"></span>`;
      cell.querySelector('[data-assign-cancel]').onclick=()=>{cell.innerHTML=original;installOperationalAssignment(item,body)};
      cell.querySelector('[data-assign-save]').onclick=async()=>{
        const save=cell.querySelector('[data-assign-save]');save.disabled=true;
        try{
          const updated=await request(`${API}/operational-tasks/${item.id}`,{method:'PATCH',headers:{'Content-Type':'application/json'},body:JSON.stringify({assigned_officer_id:cell.querySelector('select').value||null})});
          item.assigned_officer_id=updated.assigned_officer_id;item.assigned_officer_name=updated.assigned_officer_name;
          Object.assign(item,updated);activeOperationalTask=item;
          cell.innerHTML=`${esc(item.assigned_officer_name)||'Не призначено'}${operationalAssignmentAction(item)}`;installOperationalAssignment(item,body);refreshOperationalHistory(item,body);toast('Відповідальну УО збережено');
        }catch(error){cell.querySelector('[role="alert"]').textContent=error.message;save.disabled=false}
      };
    }catch(error){toast(error.message)}
  };
}
function installOperationalAmcuActions(item,body){
  if(item.task_type!=='amcu_exclusion')return;
  bindResolvedDocumentMetadata(body);
  body.querySelectorAll('[data-amcu-pdf-url]').forEach(button=>button.onclick=()=>downloadAmcuProtocolPdf(button));
  body.querySelectorAll('.operational-amcu-save').forEach(button=>{
    button.onclick=async event=>{
      event.preventDefault();
      event.stopPropagation();
      const input=button.closest('tr')?.querySelector('[data-amcu-decision]');
      if(!input){toast('Не вдалося знайти поле посилання для цього рішення АМКУ');return}
      button.disabled=true;
      try{
        const updated=await request(`${API}/operational-tasks/${item.id}/amcu-decisions/${encodeURIComponent(button.dataset.decision)}`,{
          method:'PATCH',headers:{'Content-Type':'application/json'},body:JSON.stringify({extract_url:input.value})
        });
        Object.assign(item,updated);activeOperationalTask=item;
        toast('Посилання на витяг збережено');
        await openOperationalTask(item.id);
      }catch(error){toast(error.message);button.disabled=false}
    };
  });
  const reviewed=body.querySelector('.operational-amcu-reviewed');
  if(reviewed)reviewed.onclick=async()=>{
    if(!confirm('Позначити задачу як розглянуту та очікувати підтвердження виключення з Prozorro?'))return;
    reviewed.disabled=true;
    try{
      await request(`${API}/operational-tasks/${item.id}`,{method:'PATCH',headers:{'Content-Type':'application/json'},body:JSON.stringify({
        status:'awaiting_sync',assigned_officer_id:item.assigned_officer_id,
        protocol_number:body.querySelector('[data-amcu-protocol-number]')?.value||'',
        protocol_date:body.querySelector('[data-amcu-protocol-date]')?.value||''
      })});
      toast('Задачу позначено як розглянуту. Очікується sync Prozorro.');
      await openOperationalTask(item.id);await loadOperationalTasks();
    }catch(error){toast(error.message);reviewed.disabled=false}
  };
  const unresolved=item.document_generation?.declensions||item.document_generation?.unresolved||[];
  body.querySelectorAll('[data-amcu-declension]').forEach(button=>button.onclick=()=>
    openDeclensionFromAmcuValidation(unresolved[Number(button.dataset.amcuDeclension)],item,unresolved));
  const generate=body.querySelector('.operational-generate-amcu'),status=body.querySelector('.operational-amcu-document-status');
  if(generate)generate.onclick=async()=>{
    generate.disabled=true;if(status)status.textContent='Формування…';
    const payload={status:item.status,assigned_officer_id:item.assigned_officer_id,
      protocol_number:body.querySelector('[data-amcu-protocol-number]')?.value||'',
      protocol_date:body.querySelector('[data-amcu-protocol-date]')?.value||'',
      amcu_decisions:[...body.querySelectorAll('[data-amcu-decision]')].map(input=>({decision_id:input.dataset.amcuDecision,extract_url:input.value}))};
    try{
      await request(`${API}/operational-tasks/${item.id}`,{method:'PATCH',headers:{'Content-Type':'application/json'},body:JSON.stringify(payload)});
      await request(`${API}/operational-tasks/${item.id}/documents/amcu-exclusion-protocol`,{method:'POST',headers:{'Content-Type':'application/json'},body:'{}'});
      toast('Протокол АМКУ сформовано. Задачу не завершено.');await openOperationalTask(item.id);await loadOperationalTasks();
    }catch(error){
      if(error.code==='declension_unresolved'&&Array.isArray(error.unresolved)&&error.unresolved.length){
        await openDeclensionFromAmcuValidation(error.unresolved[0],item,error.unresolved);
      }else{if(status)status.textContent=error.message;toast(error.message)}
      generate.disabled=false;
    }
  };
}
async function downloadAmcuProtocolPdf(button){
  const url=button.dataset.amcuPdfUrl;button.disabled=true;button.setAttribute('aria-busy','true');
  try{
    const headers={},localRole=$('#roleSelect')?.value;if(localRole)headers['X-PQM-Local-Role']=localRole;
    const response=await fetch(url,{headers}),contentType=response.headers.get('content-type')||'';
    if(!response.ok||!contentType.toLowerCase().includes('application/pdf')){
      let message=`Не вдалося завантажити PDF (HTTP ${response.status})`;
      try{const payload=await response.json();message=payload.error||payload.message||message}catch{}
      throw new Error(message);
    }
    const blob=await response.blob();if(!blob.size)throw new Error('Сервер повернув порожній PDF');
    const signature=new Uint8Array(await blob.slice(0,5).arrayBuffer());
    if(String.fromCharCode(...signature)!=='%PDF-')throw new Error('Сервер повернув некоректний PDF');
    const filename=downloadFilenameFromDisposition(response.headers.get('content-disposition'),'protocol.pdf');
    const objectUrl=URL.createObjectURL(blob),download=document.createElement('a');
    download.href=objectUrl;download.download=filename;document.body.append(download);download.click();download.remove();
    setTimeout(()=>URL.revokeObjectURL(objectUrl),0);toast('PDF завантажено','success');
  }catch(error){toast(error.message||'Не вдалося завантажити PDF','error')}
  finally{button.disabled=false;button.removeAttribute('aria-busy')}
}
function resolvedDocumentMetadataHtml(items){
 const rows=(items||[]).filter(item=>String(item?.resolved_text??'').trim()).map(item=>`<div class="document-resolved-metadata-row" data-metadata-key="${esc(item.metadata_key||'')}"><strong>${esc(item.label||item.metadata_key||'Метадані')}</strong><span>${esc(item.resolved_text)}</span><button type="button" class="ghost" data-copy-resolved-metadata="${esc(item.resolved_text)}">Копіювати</button></div>`).join('');
 return rows?`<div class="document-resolved-metadata">${rows}</div>`:'';
}
function bindResolvedDocumentMetadata(root=document){root.querySelectorAll('[data-copy-resolved-metadata]').forEach(button=>button.onclick=()=>copyText(button.dataset.copyResolvedMetadata||''))}
function operationalSupplierDocumentHtml(item){
 const g=item.document_generation||{},docs=(g.documents||[]).filter(doc=>doc.document_type==='nazk_supplier_request'),latest=docs[0],terminal=['completed','cancelled'].includes(item.status);
 const generate=!terminal?`<button type="button" class="ghost operational-generate-supplier-request" ${g.ready&&g.can_manage?'':'disabled'}>${latest?'Сформувати повторно':'Сформувати запит'}</button>`:'';
 return `<span class="operational-generated-control">${latest?`<span class="operational-document-row"><span><strong>Сформовано:</strong> ${esc(latest.filename)}</span>${protocolDocumentActions({docxUrl:latest.download_url,pdfUrl:latest.pdf_url||'',pdfAttribute:'data-amcu-pdf-url'})}${documentDeclensionAction(g.declensions,'data-nazk-declension')}${generate}</span>${resolvedDocumentMetadataHtml(latest.resolved_metadata)}`:`<span class="operational-document-row">${documentDeclensionAction(g.declensions,'data-nazk-declension')}${generate}</span>`}${(g.errors||[]).length&&!terminal?`<small>${g.errors.map(esc).join(' · ')}</small>`:''}${docs.length>1?`<details><summary>Попередні версії · ${docs.length-1}</summary>${docs.slice(1).map(d=>`<article class="operational-document-version"><a href="${esc(d.download_url)}">${esc(d.filename)}</a>${resolvedDocumentMetadataHtml(d.resolved_metadata)}</article>`).join('')}</details>`:''}<span role="alert"></span></span>`;
}
function operationalNazkAuthorityDocumentHtml(item){
 const g=item.document_generation?.authority_request||{},docs=g.documents||[],latest=docs[0],terminal=['completed','cancelled'].includes(item.status);
 const button=!terminal?`<button type="button" class="ghost operational-generate-authority-request" ${g.ready&&item.document_generation?.can_manage?'':'disabled'}>${latest?'Сформувати повторно':'Сформувати запит до НАЗК'}</button>`:'';
 return `<span class="operational-authority-generated" data-authority-document-control>${latest?`<span class="operational-document-row"><span><strong>Сформовано:</strong> ${esc(latest.filename)}</span>${protocolDocumentActions({docxUrl:latest.download_url})}${button}</span>${resolvedDocumentMetadataHtml(latest.resolved_metadata)}`:`<span class="operational-document-row">${button}</span>`}${(g.errors||[]).length&&!terminal?`<small>${g.errors.map(esc).join(' · ')}</small>`:''}${docs.length>1?`<details><summary>Попередні версії · ${docs.length-1}</summary>${docs.slice(1).map(d=>`<article class="operational-document-version"><a href="${esc(d.download_url)}">${esc(d.filename)}</a>${resolvedDocumentMetadataHtml(d.resolved_metadata)}</article>`).join('')}</details>`:''}<span role="alert"></span></span>`;
}
function installOperationalNazkAuthorityDocument(item,body){
 if(item.task_type!=='nazk_check')return;
 if(['completed','cancelled'].includes(item.status)&&item.document_generation?.authority_request?.documents?.length&&!body.querySelector('[data-authority-document-control]')){const section=document.createElement('section');section.innerHTML='<h3>Запит до НАЗК</h3>'+operationalNazkAuthorityDocumentHtml(item);body.querySelector('.operational-workspace')?.prepend(section);}
 const control=body.querySelector('[data-authority-document-control]'),button=control?.querySelector('.operational-generate-authority-request');
 if(control)bindResolvedDocumentMetadata(control);
 control?.querySelectorAll('[data-amcu-pdf-url]').forEach(b=>b.onclick=()=>downloadAmcuProtocolPdf(b));
 if(!button)return;
 button.onclick=async()=>{
  button.disabled=true;control.querySelector('[role="alert"]').textContent='Формування…';
  try{
   await request(`${API}/operational-tasks/${item.id}/documents/nazk-authority-request`,{method:'POST',headers:{'Content-Type':'application/json'},body:'{}'});
   toast('Запит до НАЗК сформовано. Направлення не зафіксовано.');await openOperationalTask(item.id);await loadOperationalTasks();
  }catch(error){control.querySelector('[role="alert"]').textContent=error.message;button.disabled=false;}
 };
}
function installOperationalSupplierDocument(item,body){
 if(item.task_type!=='nazk_check')return;
 if(['completed','cancelled'].includes(item.status)&&item.document_generation?.documents?.length&&!body.querySelector('.operational-generated-control')){
  const section=document.createElement('section');section.innerHTML='<h3>Сформовані запити постачальнику</h3>'+operationalSupplierDocumentHtml(item);body.querySelector('.operational-workspace').prepend(section);
 }
 const control=body.querySelector('.operational-generated-control'),button=control?.querySelector('.operational-generate-supplier-request');
 if(control)bindResolvedDocumentMetadata(control);
 control?.querySelectorAll('[data-amcu-pdf-url]').forEach(b=>b.onclick=()=>downloadAmcuProtocolPdf(b));
 control?.querySelector('[data-nazk-declension]')?.addEventListener('click',()=>{const entries=item.document_generation?.declensions||[];openDeclensionFromAmcuValidation(entries[0],item,entries)});
 if(!button)return;
 button.onclick=async()=>{
  button.disabled=true;control.querySelector('[role="alert"]').textContent='Формування…';
  try{
   const result=await request(`${API}/operational-tasks/${item.id}/documents/nazk-supplier-request`,{method:'POST',headers:{'Content-Type':'application/json'},body:'{}'});
   item.document_generation.documents=result.documents;item.events=[...(item.events||[]),result.event];
   control.outerHTML=operationalSupplierDocumentHtml(item);refreshOperationalHistory(item,body);installOperationalSupplierDocument(item,body);
   toast('Запит сформовано. Направлення не зафіксовано.');
  }catch(error){control.querySelector('[role="alert"]').textContent=error.message;button.disabled=false;}
 };
}
function operationalNazkRecords(item){return Array.isArray(item.nazk_records)?item.nazk_records:[]}
function operationalNazkContext(item){const n=item.nazk_current_state||{},m=item.current_manager||{},records=operationalNazkRecords(item),terminal=['completed','cancelled'].includes(item.status),personTaxId=n.person_rnokpp||n.person_tax_id||(!terminal?m.manager_tax_id:''),recordRows=records.map(x=>{const name=x.full_name||x.person_name||x.name||'—',violation=x.offense_name||x.violation||'—',punishment=x.punishment||'—',caseNumber=x.court_case_number||x.case_number||x.sentence_number||'—',decisionDate=x.decision_date||x.sentence_date,effectiveDate=x.effective_date||x.punishment_start,sourceId=x.source_id||x.record_id||x.id||'—',sourceUrl=x.source_url||x.decision_url||'';return `<tr><td><strong>${esc(name)}</strong></td><td>${esc(violation)}</td><td>${esc(punishment)}</td><td>${esc(caseNumber)}</td><td>${esc(displayDateOnly(decisionDate))||'—'}</td><td>${esc(displayDateOnly(effectiveDate))||'—'}</td><td>${esc(x.decree_number||'—')}</td><td>${esc(displayDateOnly(x.decree_date))||'—'}</td><td>${esc(sourceId)}${nazkRegistrySourceNotice(x)}</td><td>${sourceUrl?`<a href="${esc(sourceUrl)}" target="_blank" rel="noopener">Відкрити джерело</a>`:'—'}</td></tr>`}).join('');return `<section class="operational-context-card"><h3>Особа та підстава перевірки</h3><dl class="operational-compact-facts"><div><dt>Особа задачі</dt><dd>${esc(n.manager_name||item.source_context?.person_name||'—')} <span class="status-chip">${item.task_person_is_current?'Поточний керівник':'Попередній керівник'}</span></dd></div><div><dt>Поточний керівник</dt><dd>${esc(m.manager_name||'Не визначено')}</dd></div><div class="operational-tax-fact"><dt>РНОКПП перевіреної особи</dt><dd>${personTaxId?esc(personTaxId):(!terminal?'<button type="button" class="inline-link operational-tax-add">Додати</button>':'Не зазначено')}</dd></div></dl><div class="operational-registry-list">${recordRows?`<h4>Запис у Реєстрі НАЗК</h4><div class="operational-table"><table><thead><tr><th>ПІБ</th><th>Порушення</th><th>Вид стягнення</th><th>Справа / рішення</th><th>Дата рішення</th><th>Набрання чинності</th><th>№ наказу</th><th>Дата наказу</th><th>ID запису</th><th>Джерело</th></tr></thead><tbody>${recordRows}</tbody></table></div>`:'<p class="operational-empty">Пов’язаних записів не знайдено</p>'}</div></section>`}
function operationalNazkWorkspace(item){
  const channels=item.channels||{},terminal=['completed','cancelled'].includes(item.status);
  const label={not_sent:'Не направлено',document_prepared:'Документ підготовлено',waiting:'Очікується відповідь',response_received:'Відповідь отримано',closed:'Закрито',cancelled:'Скасовано'};
  const channel=(key,title)=>{const c=channels[key]||{status:'not_sent'};return `<article class="operational-channel-card" data-channel-card="${key}"><h4>${title}</h4><strong>${esc(label[c.status]||c.status)}</strong>${c.sent_at?`<small>${esc(displayDateOnly(c.sent_at))}${c.outgoing_number?` · № ${esc(c.outgoing_number)}`:''}</small>`:''}${c.reference_url?`<a href="${esc(c.reference_url)}" target="_blank" rel="noopener">Відкрити документ/джерело</a>`:''}<div class="violation-inline-actions">${!terminal&&c.status==='not_sent'?`<button type="button" class="ghost operational-request-sent" data-channel="${key}">Зафіксувати направлення</button>`:''}${key==='supplier'?operationalSupplierDocumentHtml(item):operationalNazkAuthorityDocumentHtml(item)}</div></article>`};
  const responses=(item.responses||[]).map(x=>`<article class="operational-response" data-evidence-id="${esc(x.id)}"><div class="operational-response-main"><strong>${x.source==='nazk'?'НАЗК':x.source==='other'?'Інше':'Постачальник'}</strong><span>${esc(displayDateOnly(x.response_date))||'дата не зазначена'}${x.incoming_number?` · № ${esc(x.incoming_number)}`:''}</span>${x.document_reference?`<p><strong>${esc(x.document_reference)}</strong></p>`:''}${x.summary?`<p>${esc(x.summary)}</p>`:''}${x.comment?`<p>${esc(x.comment)}</p>`:''}${x.reference_url?`<a href="${esc(x.reference_url)}" target="_blank" rel="noopener">Посилання</a>`:''}</div>${!terminal?`<button type="button" class="ghost operational-edit-response" data-evidence-id="${esc(x.id)}">Редагувати</button>`:''}</article>`).join('');
  const result=item.nazk_current_state?.result||'needs_review',confirmed=!terminal&&result==='confirmed'&&Number(item.effective_active_count)>0;
  return `${!terminal?`<section><h3>Зовнішні запити</h3><div class="operational-channels">${channel('supplier','Постачальнику')}${channel('nazk','До НАЗК')}</div></section>`:''}<section class="operational-responses"><h3>${terminal?'Отримані відповіді / інформація':'Отримані відповіді / інформація'}</h3>${responses||'<p class="operational-empty">Відповідей ще немає</p>'}${!terminal?'<button type="button" class="primary operational-add-response">Додати відповідь / інформацію</button>':''}</section>${!terminal?`<section class="operational-result-row"><h3>Результат перевірки</h3><p>${result==='confirmed'?'Підтверджено':result==='refuted'?'Спростовано':'Не визначено'}</p><div class="violation-inline-actions"><button type="button" class="primary operational-nazk-result" data-result="confirmed">Збіг підтверджено</button><button type="button" class="ghost operational-nazk-result" data-result="refuted">Спростовано</button><button type="button" class="ghost operational-nazk-result" data-result="insufficient">Недостатньо інформації</button><button type="button" class="ghost operational-nazk-result" data-result="not_current">Не актуально</button></div></section>`:''}${confirmed?`<section><h3>Подальші дії</h3><p class="operational-ready">Підстава для виключення підтверджена. Активних кваліфікацій: ${Number(item.effective_active_count)}. Готова до виключення.</p><button type="button" class="ghost" disabled title="Буде доступно після налаштування Конструктора шаблонів">Сформувати протокольне рішення</button></section>`:''}<details class="operational-history-details"><summary>Історія задачі · ${(item.events||[]).length}</summary>${operationalHistoryHtml(item.events||[]).replace('<section>','<div>').replace('</section>','</div>')}</details>`;
}
function openOperationalSemanticForm(item,kind,channel,anchor,existing=null){
  document.querySelector('.operational-inline-form')?.remove();
  const form=document.createElement('div');form.className='operational-inline-form';
  form.innerHTML=kind==='sent'?`<h4>Зафіксувати направлення</h4><div class="request-form-grid"><label>Дата направлення<input type="date" data-op="sent_at"></label><label>Вихідний №<input data-op="outgoing_number"></label><label>Посилання / reference<input data-op="reference_url"></label><label class="wide">Коментар<textarea data-op="comment"></textarea></label></div><div class="violation-inline-actions"><button type="button" class="primary" data-inline-save>Зберегти</button><button type="button" class="ghost" data-inline-cancel>Скасувати</button></div>`:`<h4>${existing?'Редагувати відповідь / інформацію':'Додати відповідь / інформацію'}</h4><div class="request-form-grid"><label>Джерело<select data-op="source"><option value="supplier">Постачальник</option><option value="nazk">НАЗК</option><option value="other">Інше</option></select></label><label>Дата отримання<input type="date" data-op="response_date"></label><label>Вхідний № / reference<input data-op="incoming_number"></label><label>URL<input data-op="reference_url"></label><label>Документ / реквізити<input data-op="document_reference"></label><label class="wide">Короткий зміст<textarea data-op="summary"></textarea></label><label class="wide">Коментар<textarea data-op="comment"></textarea></label></div><div class="violation-inline-actions"><button type="button" class="primary" data-inline-save>Зберегти</button><button type="button" class="ghost" data-inline-cancel>Скасувати</button></div>`;
  anchor.append(form);
  if(existing)Object.entries(existing).forEach(([key,value])=>{const control=form.querySelector(`[data-op="${key}"]`);if(control)control.value=value||''});
  form.querySelector('[data-inline-cancel]').onclick=()=>form.remove();
  form.querySelector('[data-inline-save]').onclick=async()=>{const payload=Object.fromEntries([...form.querySelectorAll('[data-op]')].map(x=>[x.dataset.op,x.value]));try{const edit=Boolean(existing);await request(kind==='sent'?`${API}/operational-tasks/${item.id}/channels/${channel}/sent`:edit?`${API}/operational-tasks/${item.id}/responses/${existing.id}`:`${API}/operational-tasks/${item.id}/responses`,{method:edit?'PATCH':'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(payload)});toast('Інформацію збережено');await openOperationalTask(item.id)}catch(error){toast(error.message)}};
}
openOperationalTask=async function(taskId){const dialog=$('#operationalTaskDialog'),body=$('#operationalTaskBody');if(dialog.open)dialog.close();body.innerHTML='<p>Завантаження…</p>';dialog.showModal();try{const item=await request(`${API}/operational-tasks/${encodeURIComponent(taskId)}`);activeOperationalTask=item;$('#operationalTaskTitle').textContent=operationalTaskTypeLabels[item.task_type]||'Операційна задача';$('#operationalTaskSubtitle').textContent=`${item.supplier_name_snapshot||''} · ${item.supplier_code||''}`;const summary=`<section class="operational-summary"><dl class="operational-compact-facts"><div><dt>Статус</dt><dd>${esc(operationalTaskStatusLabels[item.status]||item.status)}</dd></div><div><dt>Відповідальна УО</dt><dd class="operational-assignment">${esc(formatOfficerName(item.assigned_officer_name))||'Не призначено'}${operationalAssignmentAction(item)}</dd></div><div><dt>Створено</dt><dd>${esc(displayDate(item.created_at))}</dd></div><div><dt>Кваліфікації (активні / неактивні)</dt><dd>${item.qualification_summary?`${item.qualification_summary.current.active} / ${item.qualification_summary.current.inactive}`:'—'}</dd></div></dl><div class="operational-summary-actions"><strong>${esc(operationalTaskHumanState(item))}</strong><button type="button" class="ghost" id="operationalOpenSupplier">Відкрити картку постачальника</button></div></section>`;if(item.task_type==='nazk_check')body.innerHTML=`<div class="operational-sticky-context">${summary}${operationalNazkContext(item)}</div><div class="operational-workspace">${['completed','cancelled'].includes(item.status)?operationalTerminalHtml(item)+operationalNazkWorkspace(item):operationalNazkWorkspace(item)}${operationalQualificationHtml(item)}</div>`;else body.innerHTML=`<div class="operational-sticky-context">${summary}</div><div class="operational-workspace">${['completed','cancelled'].includes(item.status)?operationalTerminalHtml(item):item.task_type==='warning_block'?operationalWarningHtml(item):operationalAmcuHtml(item)}${operationalQualificationHtml(item)}${operationalCollapsedHistory(item.events||[])}</div>`;$('#operationalOpenSupplier').onclick=()=>openSupplierProfile(item.supplier_code,{returnTaskId:item.id});body.querySelectorAll('.operational-request-sent').forEach(b=>b.onclick=()=>openOperationalSemanticForm(item,'sent',b.dataset.channel,b.closest('[data-channel-card]')));body.querySelector('.operational-add-response')?.addEventListener('click',e=>openOperationalSemanticForm(item,'response','',e.currentTarget.closest('.operational-responses')));body.querySelectorAll('.operational-nazk-result').forEach(b=>b.onclick=async()=>{if(!confirm(`Зберегти результат: ${b.textContent}?`))return;try{await request(`${API}/operational-tasks/${item.id}/nazk-result`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({result:b.dataset.result})});toast('Результат перевірки збережено');await openOperationalTask(item.id);await loadOperationalTasks()}catch(error){toast(error.message)}});body.querySelector('.operational-tax-add')?.addEventListener('click',e=>{const dd=e.currentTarget.closest('dd');dd.innerHTML='<input class="operational-tax-input" inputmode="numeric" maxlength="10" placeholder="10 цифр"><button type="button" class="primary operational-tax-save">Зберегти</button><button type="button" class="ghost operational-tax-cancel">Скасувати</button>';dd.querySelector('.operational-tax-cancel').onclick=()=>openOperationalTask(item.id);dd.querySelector('.operational-tax-save').onclick=async()=>{try{await request(`${API}/operational-tasks/${item.id}/manager-tax-id`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({manager_tax_id:dd.querySelector('input').value})});toast('РНОКПП збережено');await openOperationalTask(item.id)}catch(error){toast(error.message)}}});$('#operationalTaskSave').hidden=['completed','cancelled'].includes(item.status)||['nazk_check','warning_block'].includes(item.task_type);installOperationalSupplierDocument(item,body);installOperationalNazkAuthorityDocument(item,body);installOperationalWarningActions(item,body);installOperationalAssignment(item,body);installOperationalAmcuActions(item,body);installOperationalTerminationDocuments(item,body);$('#operationalTaskSave').onclick=()=>saveOperationalTask(item)}catch(error){body.innerHTML=`<p class="request-warning">${esc(error.message)}</p>`;$('#operationalTaskSave').hidden=true}}
function operationalSubmissionStatus(value){return ({pending:'Очікує розгляду',active:'Активна',complete:'Завершена',completed:'Завершена',cancelled:'Скасована',deleted:'Видалена',unsuccessful:'Неуспішна',draft:'Чернетка',invalid:'Недійсна'})[value]|| (value?`Невідомий статус: ${value}`:'Не підтверджено')}
function operationalTargetDocumentIcon(row){const docs=row.registry_documents||[];if(!row.source_identity_proven||docs.length!==1||(row.limitations||[]).includes('MULTIPLE_LINKED_CONTRACTS_DISPLAYED_SEPARATELY'))return '—';const d=docs[0];if(!d.document_id||d.qualification_id!==row.qualification_id||d.registry_contract_id!==row.registry_contract_id||!d.provenance)return '—';try{const u=new URL(d.url);if(!['https:','http:'].includes(u.protocol)||!u.hostname||u.username||u.password)return '—'}catch{return '—'}return `<a class="operational-target-document-icon" href="${esc(d.url)}" title="${esc(d.title||'Документ Prozorro')}" aria-label="${esc(d.title||'Документ Prozorro')}" target="_blank" rel="noopener noreferrer">📎</a>`}
function operationalFrameworkName(row){const title=String(row.framework_title||'').trim(),code=String(row.dk_code||'').trim();if(code&&title.startsWith(code)){const suffix=title.slice(code.length);if(/^(?:\s|[—–:|])/.test(suffix)){const name=suffix.replace(/^[\s—–:|]+/,'');if(name)return name}}return title||'—'}
function operationalAmcuTargetsHtml(item){const rows=item.amcu_target_rows||[];return rows.length?`<section class="operational-targets"><h3>Кваліфікації, яких стосується рішення</h3><div class="operational-table"><table><thead><tr><th>Код ДК</th><th>Назва фреймворку</th><th>Виключення</th><th>Документ</th></tr></thead><tbody>${rows.map(x=>`<tr><td>${x.source_identity_proven&&x.framework_id&&x.framework_id===x.submission_framework_id?`<strong>${esc(x.dk_code||'—')}</strong>`:'—'}</td><td>${x.source_identity_proven&&x.framework_id&&x.framework_id===x.submission_framework_id?`<span class="operational-framework-title">${esc(operationalFrameworkName(x))}</span>`:'Зв’язок із відбором не підтверджено'}<details class="operational-target-source-details"><summary title="Джерела та обмеження" aria-label="Джерела та обмеження">ⓘ</summary><div class="operational-target-source-body"><small>Source title: ${esc(x.framework_title??'—')}</small><small>Заявка: ${esc(x.submission_id??'—')} · кваліфікація: ${esc(x.qualification_id??'—')} · контракт: ${esc(x.registry_contract_id??'—')} · framework: ${esc(x.framework_id??'—')}</small><small>Статус заявки: ${esc(operationalSubmissionStatus(x.submission_status))} · source: ${esc(x.submission_status??'—')}</small><small>Статус контракту: ${esc(x.registry_status??'—')} · технічний статус кваліфікації: ${esc(x.qualification_status??'—')}</small><small>${(x.limitations||[]).map(esc).join(' · ')}</small>${(x.registry_documents||[]).map(d=>`<small>${esc(d.title||'Документ')} · source: ${esc(d.document_id??'—')} · qualification: ${esc(d.qualification_id??'—')} · contract: ${esc(d.registry_contract_id??'—')} · milestone: ${esc(d.milestone_id??'—')} · ${esc(d.provenance??'—')} · protocol: ${esc(d.protocol_identity??'NOT_PROVEN')}</small>`).join('')}<small>Документ і поточна неактивність не є самостійним доказом виключення за цим рішенням.</small></div></details></td><td>${(x.sync_evidence||[]).length?`<strong>Підтверджено</strong>${x.sync_evidence.map(e=>`<small>${esc(displayDate(e.at))||'Дата не підтверджена'}</small>`).join('')}`:'Немає доказового підтвердження'}</td><td>${operationalTargetDocumentIcon(x)}</td></tr>`).join('')}</tbody></table></div></section>`:''}
function operationalV2Layout(item,body){
  const workspace=body.querySelector('.operational-workspace');if(!workspace)return;
  if(workspace.querySelector(':scope > .operational-targets')){
    const history=workspace.querySelector('.operational-history-details');
    if(history){history.open=false;workspace.append(history)}
    return;
  }
  if(['completed','cancelled'].includes(item.status)&&item.task_type!=='nazk_check'){
    const basis=operationalBasisHtml(item);
    if(basis){const section=document.createElement('section');section.innerHTML=`<h3>Підстава</h3>${basis}`;workspace.prepend(section)}
  }
  if(item.task_type==='nazk_check'){
    const person=body.querySelector('.operational-context-card .operational-compact-facts dd');
    if(person)person.innerHTML=operationalPersonHtml(item);
    [...workspace.children].filter(x=>x.querySelector('h3')?.textContent==='Подальші дії').forEach(section=>{
      if(!section.querySelector('button:not(:disabled),a[href]'))section.remove();
    });
  }
  const existingTargets=workspace.querySelector(':scope > .operational-targets');
  const coverage=[...workspace.children].find(x=>x!==existingTargets&&x.querySelector('h3')?.textContent==='Кваліфікації, яких стосується рішення');
  if(coverage){
    const h=item.qualification_summary?.coverage||{},r=item.qualification_summary?.residual||{};
    if(item.task_type==='nazk_check'&&(item.nazk_current_state?.result!=='confirmed'||!h.linked))coverage.remove();
    else if(item.task_type==='warning_block')coverage.remove();
    else if(!h.linked&&h.captured_active==null&&h.historically_excluded==null&&!r.linked_active&&!r.outside_linked_active)coverage.remove();
    else{
      if(!r.linked_active&&!r.outside_linked_active)coverage.querySelector('.request-warning')?.remove();
      const diagnostics=coverage.querySelectorAll(':scope>p')[1];
      if(diagnostics){const detail=document.createElement('details'),label=document.createElement('summary');label.textContent='Джерела та обмеження покриття';detail.append(label,diagnostics);coverage.append(detail)}
    }
  }
  if(item.task_type==='amcu_exclusion'&&(item.amcu_target_rows||[]).length){
    workspace.querySelectorAll(':scope > .operational-targets').forEach(section=>section.remove());
    const holder=document.createElement('div');holder.innerHTML=operationalAmcuTargetsHtml(item);
    const targets=holder.firstElementChild;
    if(coverage?.parentNode===workspace){
      const details=document.createElement('details'),label=document.createElement('summary');
      label.textContent='Покриття рішення та обмеження';details.append(label);
      [...coverage.children].filter(node=>node.tagName!=='H3').forEach(node=>{
        if(node.classList?.contains('request-warning'))targets.append(node);
        else details.append(node);
      });
      targets.append(details);workspace.insertBefore(targets,coverage);coverage.remove();
    }else workspace.append(targets);
  }
  const history=workspace.querySelector('.operational-history-details');
  if(item.task_type==='amcu_exclusion'){
    const sections=[...workspace.children],basis=sections.find(x=>['Підстава','Рішення АМКУ'].includes(x.querySelector('h3')?.textContent));
    let result=sections.find(x=>x.querySelector('h3')?.textContent==='Результат');
    if(basis&&!result){
      const controls=[...basis.querySelectorAll(':scope > .operational-amcu-action-row,:scope > .operational-amcu-generated,:scope > .operational-amcu-declensions,:scope > .operational-amcu-generation-error,:scope > .operational-amcu-document-status')];
      if(controls.length){result=document.createElement('section');const title=document.createElement('h3');title.textContent='Результат / Протокол УО';result.append(title,...controls)}
    }
    if(basis&&result){const group=document.createElement('div');group.className='operational-amcu-overview';workspace.insertBefore(group,basis);group.append(basis,result)}
  }
  if(history){history.open=false;workspace.append(history)}
}
const openOperationalTaskPolished=openOperationalTask;
openOperationalTask=async function(taskId){
  const result=await openOperationalTaskPolished(taskId),body=$('#operationalTaskBody'),item=activeOperationalTask;
  const supplierAction=body.querySelector('#operationalOpenSupplier'),summary=body.querySelector('.operational-summary');
  if(supplierAction&&summary&&item?.supplier_code){
    const context=document.createElement('div');context.className='operational-supplier-action';
    const code=document.createElement('span');code.textContent=`ЄДРПОУ / РНОКПП: ${item.supplier_code}`;
    supplierAction.textContent='↗ Картка постачальника';
    context.append(code,supplierAction);summary.querySelector('.operational-summary-actions')?.before(context);
  }
  if(item?.task_type==='amcu_exclusion'&&item.status==='awaiting_sync'){
    const statusValue=body.querySelector('.operational-compact-facts div:first-child dd');
    if(statusValue)statusValue.textContent='Розглянуто';
    $('#operationalTaskSave').hidden=true;
  }
  operationalV2Layout(item,body);
  body.querySelectorAll('.operational-history strong').forEach(node=>{if(node.textContent==='nazk_result_not_current')node.textContent='НАЗК · Не актуально'});
  body.querySelectorAll('.operational-nazk-result').forEach(button=>button.onclick=async()=>{
    if(!confirm(`Зберегти результат: ${button.textContent}?`))return;
    const comment=button.dataset.result==='not_current'?(prompt('Коротка причина (необов’язково):','')||''):'';
    try{await request(`${API}/operational-tasks/${item.id}/nazk-result`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({result:button.dataset.result,comment})});toast('Результат перевірки збережено');await openOperationalTask(item.id);await loadOperationalTasks()}catch(error){toast(error.message)}
  });
  return result;
};
$('#operationalTaskType').onchange=$('#operationalTaskStatus').onchange=$('#operationalTaskOfficer').onchange=$('#operationalTaskDateFrom').onchange=loadOperationalTasks;
function resetOperationalKpiFilters(){for(const id of ['operationalTaskSearch','operationalTaskType','operationalTaskOfficer','operationalTaskDateFrom'])$('#'+id).value='';$('#operationalTaskStatus').value='active';clearTimeout(operationalTaskTimer)}
$('#operationalTaskKpis').onclick=event=>{const card=event.target.closest('[data-task-kpi]');if(!card)return;resetOperationalKpiFilters();$('#operationalTaskStatus').value=card.dataset.taskKpi;loadOperationalTasks()};
$('#operationalTasksBody').onclick=event=>{const row=event.target.closest('[data-task-id]');if(row&&!event.target.closest('button,a,input,select,textarea,summary,details'))openOperationalTask(row.dataset.taskId)};
$('#operationalTasksBody').onkeydown=event=>{if((event.key==='Enter'||event.key===' ')&&event.target.matches('[data-task-id]')){event.preventDefault();openOperationalTask(event.target.dataset.taskId)}};
$('#operationalTaskBody').addEventListener('click',event=>{
  const button=event.target.closest('.operational-edit-response');
  if(!button||!activeOperationalTask)return;
  const evidence=(activeOperationalTask.responses||[]).find(item=>String(item.id)===String(button.dataset.evidenceId));
  if(evidence)openOperationalSemanticForm(activeOperationalTask,'response','',button.closest('.operational-response'),evidence);
});
$('#applicationsNav').onclick=()=>showModule('applications');$('#suppliersNav').onclick=()=>{showModule('suppliers');loadQualifiedSuppliersFiltered();loadSupplierEdrStatus()};$('#frameworksNav').onclick=()=>{showModule('frameworks');loadFrameworkAnalytics()};$('#procurementsNav').onclick=()=>showModule('procurements');$('#referencesNav').onclick=()=>showModule('references');$('#requestsNav').onclick=()=>{showModule('requests');loadViolationReports()};$('#administrationNav').onclick=()=>{showModule('administration');setAdminTab(adminTab)};$$('[data-admin-tab]').forEach(button=>button.onclick=()=>setAdminTab(button.dataset.adminTab));$('#adminFrameworkSearch').oninput=renderAdminFrameworks;$('#adminFrameworkStatus').onchange=$('#adminFrameworkCategory').onchange=$('#adminFrameworkOfficer').onchange=renderAdminFrameworks;$('#adminFrameworkReset').onclick=()=>{$('#adminFrameworkSearch').value=$('#adminFrameworkStatus').value=$('#adminFrameworkCategory').value=$('#adminFrameworkOfficer').value='';renderAdminFrameworks()};$$('#adminFrameworksPanel [data-admin-sort]').forEach(th=>th.onclick=()=>{const key=th.dataset.adminSort;if(adminFrameworkSort===key)adminFrameworkDirection=adminFrameworkDirection==='asc'?'desc':'asc';else{adminFrameworkSort=key;adminFrameworkDirection='asc'}renderAdminFrameworks()});$('#adminOfficerAdd').onclick=async()=>{try{await request(`${API}/admin/officers`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({full_name:$('#adminOfficerName').value,role:$('#adminOfficerRole').value})});$('#adminOfficerName').value='';toast('УО додано');await loadAdminOfficers()}catch(error){toast(error.message)}};$('#bidsStatusRefresh').onclick=async()=>{await request(`${API}/bids-sync-status?refresh=1`);loadBidsSyncStatus()};$('#bidsDataRefresh').onclick=startBidsUpdate;$('#bidsManualUpdateToggle').onclick=toggleManualBidsUpdate;$('#googleRuntimeToggle').onclick=toggleGoogleRuntime;$('#googleDisconnect').onclick=disconnectGoogle;$('#powerbiExportBtn').onclick=startPowerbiExport;$('#procurementSupplierLoad').onclick=()=>{supplierProcurementPage=1;loadSupplierProcurements()};$('#procurementSupplierPrev').onclick=()=>{if(supplierProcurementPage>1){supplierProcurementPage--;loadSupplierProcurements()}};$('#procurementSupplierNext').onclick=()=>{if(supplierProcurementPage<supplierProcurementPages){supplierProcurementPage++;loadSupplierProcurements()}};
$('#adminTemplateFile').onchange=replaceAdminTemplate;
$('#adminFrameworkAdd').onclick=addAdminFramework;
$('#adminFrameworkImportNew').onclick=importNewAdminFrameworks;
let workQueuePage=1,workQueuePages=1,workQueueTimer;
const baseBindViolationReview=bindViolationReview;
bindViolationReview=function(item){baseBindViolationReview(item);const footerSave=$('#requestDetailsSave'),review=$('#requestDetailsBody .request-review'),context=item.procurement_context||{},r=item.review||{};footerSave.hidden=Boolean(item.is_read_only||!review);footerSave.onclick=item.is_read_only?null:()=>saveViolationReview(item.id);const oldSave=$('#saveViolationReview');if(oldSave)oldSave.hidden=true;if(!review)return;const grid=review.querySelector('.request-form-grid:last-of-type');if(!grid)return;const notes=grid.querySelector('[data-review="review_notes"]');if(notes){const label=notes.closest('label');label.childNodes[0].textContent='Коментар УО (необов’язково)';notes.placeholder='Додатковий внутрішній коментар до рішення, якщо необхідно…'}const contractInputs=['actual_contract_date','actual_contract_number','actual_contract_url'].map(key=>grid.querySelector(`[data-review="${key}"]`)).filter(Boolean);contractInputs.forEach(input=>{const label=input.closest('label');label.classList.add('violation-contract-field');label.hidden=context.contract_info_required===false;if(!input.value){if(input.dataset.review==='actual_contract_date')input.value=String(context.contract_date||'').slice(0,10);if(input.dataset.review==='actual_contract_number')input.value=context.contract_pretty_id||'';if(input.dataset.review==='actual_contract_url')input.value=context.contract_url||''}});const official=document.createElement('section');official.className='violation-justification';official.innerHTML=`<h3>Обґрунтування рішення</h3><textarea data-review="decision_justification" placeholder="Офіційний текст рішення УО…">${esc(r.decision_justification||'')}</textarea><div class="violation-inline-actions"><button type="button" class="ghost" id="buildViolationJustification">${r.decision_justification?'Оновити чернетку':'Сформувати обґрунтування'}</button><button type="button" class="ghost" id="copyViolationJustification">Копіювати</button></div>${context.contract_warning?`<p class="request-warning">${esc(context.contract_warning)}</p>`:''}`;grid.before(official);$('#buildViolationJustification').onclick=()=>{const area=official.querySelector('textarea');if(area.value.trim()&&!confirm('Існуючий текст буде замінений новою чернеткою. Продовжити?'))return;area.value=item.justification_draft||''};$('#copyViolationJustification').onclick=async()=>{await copyText(official.querySelector('textarea').value);toast('Обґрунтування скопійовано')}};
async function reloadOpenViolationReportDetail(){
  const dialog=$('#requestDetailsDialog'),reportId=activeDeclensionRequest?.id;
  if(!dialog?.open||!reportId)return;
  try{
    const item=await request(`${API}/violation-reports/${encodeURIComponent(reportId)}`);
    if(!dialog.open||activeDeclensionRequest?.id!==reportId)return;
    $('#requestDetailsTitle').textContent=item.report_id||'Звернення замовника';
    $('#requestDetailsSubtitle').textContent=`${displayDate(item.date_published)} · ${requestLabel(item.status,requestStatusLabels)}`;
    $('#requestDetailsBody').innerHTML=violationDetailHtml(item);
    bindViolationReview(item);
    bindViolationCardDeclensionActions(item);
    return item;
  }catch(error){toast('Не вдалося оновити відкриту картку звернення','error');return null}
}
let activeSubmissionNazkRow=null;
async function openSubmissionNazkControl(row){activeSubmissionNazkRow=row;const dialog=$('#submissionNazkDialog'),body=$('#submissionNazkBody');$('#submissionNazkSubtitle').textContent=`${row.participant} · ${row.edrpou}`;body.innerHTML='<p>Завантаження…</p>';dialog.showModal();try{const data=await request(`${API}/applications/${encodeURIComponent(row.id)}/nazk-control`),c=data.control||{},docs=data.documents||[],context=data.context||{},manager=context.manager||{},matches=context.registry_matches||[],supplierCheck=context.latest_supplier_check||null,historicalReadOnly=Boolean(data.historical_read_only||row.historicalReadOnly);body.innerHTML=`${historicalReadOnly?historicalApplicationBadge({historicalReadOnly:true}):''}<div class="nazk-control-state ${c.nazk_certificate_checked?'done':'pending'}"><strong>${c.nazk_certificate_checked?'Довідку цієї заявки перевірено':'НАЗК · перевірити довідку цієї заявки'}</strong><p>Поточний керівник: <b>${esc(manager.current||c.manager_name)||'ПІБ керівника не визначено'}</b></p>${manager.previous?`<p>Попередній керівник: <b>${esc(manager.previous)}</b></p>`:''}</div><section class="submission-nazk-registry"><h3>НАЗК — запис у Реєстрі</h3>${matches.map(x=>`<dl><div><dt>ПІБ</dt><dd>${esc(x.full_name||'—')}</dd></div><div><dt>Суть порушення</dt><dd>${esc(x.offense_name||'—')}</dd></div><div><dt>№ судової справи</dt><dd>${esc(x.court_case_number||'—')}</dd></div><div><dt>Дата рішення</dt><dd>${esc(displayDateOnly(x.sentence_date))||'—'}</dd></div><div><dt>Дата набрання законної сили</dt><dd>${esc(displayDateOnly(x.punishment_start))||'—'}</dd></div></dl>${x.decision_url?`<a href="${esc(x.decision_url)}" target="_blank" rel="noopener">Відкрити рішення</a>`:''}`).join('')||'<p>Запис Реєстру НАЗК не знайдено</p>'}</section>${supplierCheck?`<section class="submission-nazk-supplier-context"><h3>Загальна перевірка НАЗК: ${supplierCheck.result==='refuted'?'СПРОСТОВАНО':supplierCheck.result==='confirmed'?'ПІДТВЕРДЖЕНО':esc(supplierCheck.result||'—')}</h3><p>Раніше перевірено: ${esc(displayDateOnly(supplierCheck.completed_at))||'—'} · Довідка станом на: ${esc(displayDateOnly(supplierCheck.evidence_date))||'—'}</p>${supplierCheck.comment?`<p>Коментар: ${esc(supplierCheck.comment)}</p>`:''}${supplierCheck.document_url?`<p><a href="${esc(supplierCheck.document_url)}" target="_blank" rel="noopener">Попередній доказ</a></p>`:''}<strong>Для поточної заявки довідку ще не перевірено.</strong></section>`:''}<label class="wide">Документ із поточної заявки<div class="nazk-document-list">${docs.map((doc,index)=>{const p7s=/\.p7s$/i.test(doc.title||'');return`<label><input type="radio" name="nazkDocument" value="${index}" ${String(doc.id||'')===String(c.selected_document_id||'')?'checked':''}><span><strong>${esc(doc.title||'Документ')}</strong><small>${esc(displayDate(doc.dateModified||doc.datePublished))}</small></span><a href="${esc(doc.url||'#')}" target="_blank" rel="noopener">${p7s?'Завантажити':'Переглянути'}</a></label>`}).join('')||'<p>Документів у заявці немає</p>'}</div></label><div class="request-form-grid"><label>Дата довідки / відповіді<input id="submissionNazkEvidenceDate" type="date"></label><label>РНОКПП керівника<input id="submissionNazkTaxId" inputmode="numeric" maxlength="10" placeholder="10 цифр"></label><label class="wide">Коментар УО (необов’язково)<textarea id="submissionNazkComment"></textarea></label></div><p class="muted">Юридична дата покриття НАЗК автоматично не визначається. Остаточне рішення приймає УО.</p>`;body._docs=docs;if(historicalReadOnly)body.querySelectorAll('input,textarea,select,button').forEach(control=>control.disabled=true);$('#submissionNazkComplete').hidden=historicalReadOnly||Boolean(c.nazk_certificate_checked);$('#submissionNazkComplete').disabled=historicalReadOnly||!c.nazk_certificate_required}catch(error){body.innerHTML=`<p class="request-warning">${esc(error.message)}</p>`}}
const openSubmissionNazkControlBase=openSubmissionNazkControl;
openSubmissionNazkControl=async function(row){await openSubmissionNazkControlBase(row);try{const data=await request(`${API}/applications/${encodeURIComponent(row.id)}/nazk-control`),manager=data.context?.manager||{},body=$('#submissionNazkBody'),registry=body.querySelector('.submission-nazk-registry'),decisionLink=registry?.querySelector(':scope > a'),effectiveDate=registry?.querySelector('dl>div:last-child');if(decisionLink&&effectiveDate){decisionLink.classList.add('submission-nazk-decision-link');effectiveDate.append(decisionLink)}const tax=data.context?.manager_tax_id||{},input=$('#submissionNazkTaxId');if(input){input.value=tax.value||'';input.placeholder='Додати';input.disabled=!tax.editable;const note=document.createElement('small');note.className='muted';note.textContent=tax.source==='manager'?'Підставлено з картки керівника':tax.source==='submission'?'Підставлено з перевірки заявки':tax.editable?'':'Поточну особу керівника не підтверджено';input.after(note);if(tax.editable){const save=document.createElement('button');save.type='button';save.className='ghost';save.textContent='Зберегти РНОКПП';note.after(save);save.onclick=async()=>{save.disabled=true;try{const result=await request(`${API}/applications/${encodeURIComponent(row.id)}/nazk-control`,{method:'PATCH',headers:{'Content-Type':'application/json'},body:JSON.stringify({action:'save_manager_tax_id',manager_id:tax.manager_id,manager_tax_id:input.value})});input.value=result.manager_tax_id.value;note.textContent='Підставлено з картки керівника';toast('РНОКПП керівника збережено')}catch(error){toast(error.message)}finally{save.disabled=false}}}}if(!manager.previous)return;const state=body.querySelector('.nazk-control-state'),paragraph=[...state.querySelectorAll('p')].find(p=>p.textContent.includes('Попередній керівник'));if(!paragraph)return;const source=manager.previous_source==='edr_profile'?`Перевірка ЄДР від ${displayDateOnly(manager.previous_date)}`:manager.previous_source==='previous_submission'?`Попередня заявка від ${displayDateOnly(manager.previous_date)}`:`${manager.previous_source||'Історія постачальника'} · ${displayDateOnly(manager.previous_date)}`;paragraph.innerHTML=`Попередньо відомий керівник: <b>${esc(manager.previous)}</b><small>${esc(source)}</small>`}catch{}}
$('#submissionNazkComplete').onclick=async()=>{const selected=$('input[name="nazkDocument"]:checked'),docs=$('#submissionNazkBody')._docs||[],doc=selected?docs[Number(selected.value)]:null;if(!doc)return toast('Оберіть документ із заявки');try{await request(`${API}/applications/${encodeURIComponent(activeSubmissionNazkRow.id)}/nazk-control`,{method:'PATCH',headers:{'Content-Type':'application/json'},body:JSON.stringify({action:'complete_refuted',selected_document_id:doc.id||'',selected_document_url:doc.url||'',evidence_date:$('#submissionNazkEvidenceDate').value,manager_tax_id:$('#submissionNazkTaxId').value,comment:$('#submissionNazkComment').value})});toast('Перевірку довідки цієї заявки зафіксовано');$('#submissionNazkDialog').close();deepLinkSubmissionId='';await loadRows();if(activeModule==='workQueue')loadWorkQueue()}catch(error){toast(error.message)}};
const queueTypeLabels={qualification:'Кваліфікація',submission_nazk:'НАЗК · заявка',violation_report:'Звернення'};
function queueParams(){const mine=$('#queueMine').value,overdue=$('#workQueueKpis [data-queue-overdue].active');return{search:$('#queueSearch').value.trim(),type:$('#queueType').value,status:$('#queueStatus').value,responsible_user:mine==='unassigned'?'__unassigned__':$('#queueResponsible').value.trim(),officer:$('#queueResponsible').value.trim(),category:$('#queueCategory').value,protocol_from:$('#queueProtocolFrom').value,protocol_to:$('#queueProtocolTo').value,mine:mine==='1'?'1':'',page:String(workQueuePage),size:'50',overdue:overdue?'1':''}}
function renderQueueChips(){const values=[];if($('#queueType').value)values.push(['type',queueTypeLabels[$('#queueType').value]||$('#queueType').value]);if($('#queueStatus').value)values.push(['status',$('#queueStatus option:checked').textContent]);if($('#queueMine').value)values.push(['mine',$('#queueMine option:checked').textContent]);if($('#queueResponsible').value)values.push(['responsible',`УО протоколу: ${$('#queueResponsible').value}`]);if($('#queueCategory').value)values.push(['category',`Категорія: ${$('#queueCategory').value}`]);if($('#queueSearch').value)values.push(['search',`Пошук: ${$('#queueSearch').value}`]);$('#queueFilterChips').innerHTML=values.map(([key,label])=>`<button data-queue-chip="${key}">${esc(label)} ×</button>`).join('')}
async function loadWorkQueue(){const body=$('#workQueueBody');body.innerHTML='<tr><td colspan="11">Завантаження…</td></tr>';try{const data=await request(`${API}/uo-work-queue?${new URLSearchParams(queueParams())}`);workQueuePage=data.page;workQueuePages=data.pages;const k=data.kpi||{};[['Total','total'],['Nazk','nazk'],['Violation','violation_report'],['Waiting','waiting_response'],['Overdue','overdue']].forEach(([id,key])=>{$(`#queueKpi${id}`).textContent=Number(k[key]||0).toLocaleString('uk-UA')});const summary=data.qualification_summary||{total:0,officers:[],categories:[],protocol:{},publication_control:{}};const renderOfficer=(item,prefix='qualification')=>`<button type="button" class="qualification-summary-officer ${item.officer==='Не призначено'?'unassigned':''}" data-${prefix}-officer="${esc(item.officer)}"><span>${esc(formatOfficerName(item.officer))}</span><strong>${Number(item.applications||0).toLocaleString('uk-UA')}</strong><small>${prefix==='protocol'?'у протоколі':'очікує рішення'}</small></button>`,renderCategory=(item,prefix='qualification')=>`<button type="button" class="qualification-summary-officer qualification-summary-category" data-${prefix}-category="${esc(item.category)}"><span>${esc(item.category)}</span><strong>${Number(item.applications||0).toLocaleString('uk-UA')}</strong><small>категорія</small></button>`;$('#queueQualificationTotal').textContent=Number(summary.total||0).toLocaleString('uk-UA');$('#queueQualificationCards').innerHTML=(summary.officers||[]).map(item=>renderOfficer(item)).join('')||'<p class="muted">Поточних нерозглянутих заявок немає</p>';$('#queueCategoryCards').innerHTML=(summary.categories||[]).map(item=>renderCategory(item)).join('');const protocol=summary.protocol||{};$('#queueProtocolTotal').textContent=Number(protocol.total||0).toLocaleString('uk-UA');if(!$('#queueProtocolFrom').value)$('#queueProtocolFrom').value=protocol.from||'';if(!$('#queueProtocolTo').value)$('#queueProtocolTo').value=protocol.to||'';$('#queueProtocolOfficerCards').innerHTML=(protocol.officers||[]).map(item=>renderOfficer(item,'protocol')).join('')||'<p class="muted">За вибраний період заявок немає</p>';$('#queueProtocolCategoryCards').innerHTML=(protocol.categories||[]).map(item=>renderCategory(item,'protocol')).join('');const control=summary.publication_control||{};$('#queuePublicationControl').innerHTML=`<button data-publication-state="active"><span>Допущено</span><strong>${Number(control.admitted||0).toLocaleString('uk-UA')}</strong></button><button data-publication-state="unsuccessful"><span>Відхилено</span><strong>${Number(control.rejected||0).toLocaleString('uk-UA')}</strong></button><button class="warning" data-publication-state="pending"><span>Все ще очікує рішення</span><strong>${Number(control.awaiting_sync||0).toLocaleString('uk-UA')}</strong></button>`;const categories=[...new Set([...(summary.categories||[]),...(protocol.categories||[])].map(x=>x.category))],selectedCategory=$('#queueCategory').value;$('#queueCategory').innerHTML='<option value="">Усі категорії</option>'+categories.map(value=>`<option value="${esc(value)}" ${value===selectedCategory?'selected':''}>${esc(value)}</option>`).join('');body.innerHTML=(data.items||[]).map(item=>`<tr><td><span class="queue-type queue-${esc(item.task_type)}">${esc(queueTypeLabels[item.task_type]||item.task_type)}</span></td><td><strong>${esc(item.title)}</strong><small>${esc(queueReasonLabel(item.reason))}</small></td><td><strong>${esc(item.subject_name)||'—'}</strong>${item.person_name?`<small>${esc(item.person_name)}</small>`:''}</td><td>${esc(item.subject_code)||'—'}</td><td>${esc(item.customer_name)||'—'}</td><td>${esc(item.object_pretty_id)||'—'}</td><td>${esc(displayDate(item.created_at))||'—'}</td><td class="${item.overdue?'queue-overdue':''}">${esc(displayDateOnly(item.deadline_date))||'—'}</td><td>${esc(item.task_type==='violation_report'?(violationReviewStatusLabels[item.status]||item.status):item.status)}</td><td class="queue-officer-name">${formatQueueOfficer(item.responsible_user)}</td><td><button class="primary queue-open" data-task="${esc(item.task_id)}">Відкрити</button></td></tr>`).join('')||'<tr><td colspan="11">Незавершених дій за вибраними умовами немає</td></tr>';body._items=data.items||[];$('#workQueuePageInfo').textContent=`Показано ${Number(data.total||0).toLocaleString('uk-UA')} · сторінка ${data.page} із ${data.pages}`;$('#workQueuePrev').disabled=data.page<=1;$('#workQueueNext').disabled=data.page>=data.pages;renderQueueChips()}catch(error){body.innerHTML=`<tr><td colspan="11">${esc(error.message)}</td></tr>`}}
async function openQueueTask(item){if(!item)return;const params=item.source_params||{},url=new URL(location.href);Object.entries({view:item.source_view,submission_id:params.submission_id,supplier_code:params.supplier_code,nazk_check_id:params.nazk_check_id,report_id:params.report_id,nazk_control:params.nazk_control?'1':''}).forEach(([key,value])=>value?url.searchParams.set(key,value):url.searchParams.delete(key));history.replaceState(null,'',url);if(item.source_view==='requests'){showModule('requests');return openViolationReportById(params.report_id)}if(item.source_view==='suppliers'){showModule('suppliers');return openSupplierProfile(params.supplier_code)}deepLinkSubmissionId=params.submission_id||'';showModule('applications');page=1;await loadRows();if(params.nazk_control&&rows[0])openSubmissionNazkControl(rows[0])}
$('#workQueueBody').onclick=e=>{const button=e.target.closest('.queue-open');if(button)openQueueTask(($('#workQueueBody')._items||[]).find(item=>item.task_id===button.dataset.task))};$('#workQueueKpis').onclick=e=>{const button=e.target.closest('button');if(!button)return;$$('#workQueueKpis button').forEach(x=>x.classList.remove('active'));button.classList.add('active');if(button.dataset.queueFilter!==undefined)$('#queueType').value=button.dataset.queueFilter;if(button.dataset.queueStatus)$('#queueStatus').value=button.dataset.queueStatus;workQueuePage=1;loadWorkQueue()};
function resetApplicationsForExternalKpi(){
  clearApplicationDeepLinkFilter();
  for(const id of ['searchInput','protocolNumberFilter','protocolDecisionFilter','complianceStatusFilter','dateFromFilter','dateToFilter'])$('#'+id).value='';
  Object.values(filterSelections).forEach(selection=>selection.clear());
  applicationSelection.clear();
  activeRow=null;officerFilter='';categoryFilter='';
  $$('#applicationsView .multi-filter input[type="checkbox"]').forEach(input=>input.checked=false);
  $$('#applicationsView .multi-search').forEach(input=>input.value='');
  updateMultiSummary('frameworkFilter','Усі відбори',filterSelections.framework);
  updateMultiSummary('dkFilter','Усі коди ДК',filterSelections.dk);
  updateMultiSummary('supplierCodeFilter','Коди ЄДРПОУ',filterSelections.supplier);
  // Invalidate responses from a previous visit even when the new KPI has the same scope.
  loadRowsGeneration++;invalidateRegistryStats();
}
let externalApplicationKpiSequence=0;
async function loadApplicationsForExternalKpi(){
  const sequence=++externalApplicationKpiSequence;
  await initializeApplicationsRegistry();
  // Metadata bootstrap is shared; a superseded row request may have been discarded.
  // Only the latest external navigation may request the final current scope.
  if(sequence===externalApplicationKpiSequence&&profilesMetadataReady&&!applicationRowsCurrent())return loadRows();
}
function openApplicationsFromQueue({officer='',category='',status='Очікує рішення',protocol=false}={}){resetApplicationsForExternalKpi();officerFilter=officer==='Не призначено'?'__unassigned__':officer;categoryFilter=category;if(status)filterSelections.status.add(status);if(protocol){$('#dateFromFilter').value=$('#queueProtocolFrom').value;$('#dateToFilter').value=$('#queueProtocolTo').value}else{$('#dateFromFilter').value=addCalendarDays($('#queueProtocolTo').value,1);$('#dateToFilter').value=''}page=1;statsSignature='';syncPrimaryFilters();saveFilterState();updateMultiSummary('statusFilter','Статус',filterSelections.status);$$('#statusFilter input[type="checkbox"]').forEach(input=>input.checked=filterSelections.status.has(input.value));updateMultiSummary('marketplaceDecisionFilter','Дія на майданчику',filterSelections.marketplace,value=>marketplaceFilterLabels[value]||value);updateMultiSummary('registryStatusFilter','Будь-який стан у відборі',filterSelections.registry);updateApplicationFilterStyles();showModule('applications');return loadApplicationsForExternalKpi()}
$('#queueQualificationCards').onclick=e=>{const card=e.target.closest('[data-qualification-officer]');if(card)openApplicationsFromQueue({officer:card.dataset.qualificationOfficer})};
$('#queueCategoryCards').onclick=e=>{const card=e.target.closest('[data-qualification-category]');if(card)openApplicationsFromQueue({category:card.dataset.qualificationCategory})};
$('#queueProtocolOfficerCards').onclick=e=>{const card=e.target.closest('[data-protocol-officer]');if(card)openApplicationsFromQueue({officer:card.dataset.protocolOfficer,status:'',protocol:true})};
$('#queueProtocolCategoryCards').onclick=e=>{const card=e.target.closest('[data-protocol-category]');if(card)openApplicationsFromQueue({category:card.dataset.protocolCategory,status:'',protocol:true})};
$('#queuePublicationControl').onclick=e=>{const card=e.target.closest('[data-publication-state]');if(!card)return;const labels={active:'Допущено',unsuccessful:'Відхилено',pending:'Очікує рішення'};openApplicationsFromQueue({status:labels[card.dataset.publicationState]||'',protocol:true})};
$('#queueProtocolApply').onclick=()=>{workQueuePage=1;loadWorkQueue()};
$('#procurementSupplierSummary').onclick=e=>{const card=e.target.closest('[data-procurement-result]');if(!card)return;$('#procurementResult').value=card.dataset.procurementResult;supplierProcurementPage=1;loadSupplierProcurements()};
$('#procurementTopDk').onclick=e=>{const chip=e.target.closest('[data-procurement-dk]');if(!chip)return;const selected=new Set($('#procurementDkCodes').value.split(',').map(x=>x.trim()).filter(Boolean)),code=chip.dataset.procurementDk;selected.has(code)?selected.delete(code):selected.add(code);$('#procurementDkCodes').value=[...selected].join(', ');supplierProcurementPage=1;loadSupplierProcurements()};
$('#queueFilterChips').onclick=e=>{const chip=e.target.closest('[data-queue-chip]');if(!chip)return;const key=chip.dataset.queueChip;if(key==='type')$('#queueType').value='';if(key==='status')$('#queueStatus').value='';if(key==='mine')$('#queueMine').value='';if(key==='responsible')$('#queueResponsible').value='';if(key==='category')$('#queueCategory').value='';if(key==='search')$('#queueSearch').value='';workQueuePage=1;loadWorkQueue()};$('#queueSearch').oninput=$('#queueResponsible').oninput=()=>{workQueuePage=1;clearTimeout(workQueueTimer);workQueueTimer=setTimeout(loadWorkQueue,300)};$('#queueType').onchange=$('#queueStatus').onchange=$('#queueMine').onchange=$('#queueCategory').onchange=()=>{workQueuePage=1;loadWorkQueue()};$('#queueReset').onclick=()=>{$('#queueSearch').value=$('#queueType').value=$('#queueStatus').value=$('#queueMine').value=$('#queueResponsible').value=$('#queueCategory').value='';$$('#workQueueKpis button').forEach(x=>x.classList.remove('active'));$('#workQueueKpis button').classList.add('active');workQueuePage=1;loadWorkQueue()};$('#workQueuePrev').onclick=()=>{if(workQueuePage>1){workQueuePage--;loadWorkQueue()}};$('#workQueueNext').onclick=()=>{if(workQueuePage<workQueuePages){workQueuePage++;loadWorkQueue()}};$('#workQueueNav').onclick=()=>{showModule('workQueue');loadWorkQueue()};
$('#frameworksSearch').oninput=$('#frameworksDk').oninput=()=>{frameworkPage=1;clearTimeout(frameworkTimer);frameworkTimer=setTimeout(loadFrameworkAnalytics,300)};
$('#frameworksStatus').onchange=$('#frameworksDateFrom').onchange=$('#frameworksDateTo').onchange=()=>{frameworkPage=1;loadFrameworkAnalytics()};
$('#frameworksRefresh').onclick=refreshFrameworksFromProzorro;$('#frameworksPrev').onclick=()=>{if(frameworkPage>1){frameworkPage--;loadFrameworkAnalytics()}};$('#frameworksNext').onclick=()=>{if(frameworkPage<frameworkPages){frameworkPage++;loadFrameworkAnalytics()}};
$$('[data-framework-sort]').forEach(th=>th.onclick=()=>{const next=th.dataset.frameworkSort;if(frameworkSort===next)frameworkDirection=frameworkDirection==='asc'?'desc':'asc';else{frameworkSort=next;frameworkDirection='asc'}frameworkPage=1;loadFrameworkAnalytics()});
$('#requestsSearch').oninput=()=>{requestsPage=1;clearTimeout(requestsTimer);requestsTimer=setTimeout(loadViolationReports,300)};$('#requestsStatus').onchange=$('#requestsReason').onchange=$('#requestsDateFrom').onchange=$('#requestsDateTo').onchange=()=>{requestsPage=1;loadViolationReports()};$('#requestsRefresh').onclick=syncViolationReports;
$('#requestQuickFilters').onclick=e=>{const button=e.target.closest('[data-status]');if(!button)return;$('#requestsStatus').value=$('#requestsStatus').value===button.dataset.status?'':button.dataset.status;requestsPage=1;loadViolationReports()};
$('#requestsPrev').onclick=()=>{if(requestsPage>1){requestsPage--;loadViolationReports()}};
$('#requestsNext').onclick=()=>{if(requestsPage<requestsPages){requestsPage++;loadViolationReports()}};
$('#supplierRegistrySearch').oninput=$('#supplierRegistryDk').oninput=()=>{updateSupplierFilterAppearance();supplierRegistryPage=1;clearTimeout(supplierRegistryTimer);supplierRegistryTimer=setTimeout(loadQualifiedSuppliersFiltered,300)};$('#supplierRegistryType').onchange=$('#supplierRegistryStatus').onchange=$('#supplierRegistryEdrStatus').onchange=$('#supplierRegistryFreshness').onchange=$('#supplierRegistryVerifiedFrom').onchange=$('#supplierRegistryVerifiedTo').onchange=$('#supplierRegistryAdmittedFrom').onchange=$('#supplierRegistryAdmittedTo').onchange=()=>{supplierRegistryPage=1;loadQualifiedSuppliersFiltered()};$('#supplierRegistryRefresh').onclick=refreshSupplierRegistry;
$('#supplierRegistrySelectPage').onchange=event=>{supplierRegistryItems.forEach(item=>{const code=String(item.code);event.target.checked?supplierRegistrySelectedCodes.add(code):supplierRegistrySelectedCodes.delete(code)});$$('#supplierRegistryBody .supplier-registry-check').forEach(input=>{input.checked=event.target.checked});updateSupplierRegistrySelection(Number($('#supplierRegistryPageInfo').textContent.match(/із\s+([\d\s]+)/)?.[1]?.replace(/\s/g,'')||0))};
$('#supplierEdrExportSelected').onclick=async()=>{if(!supplierRegistrySelectedCodes.size)return;const button=$('#supplierEdrExportSelected');button.disabled=true;try{const response=await fetch(`${API}/supplier-edr-export`,{method:'POST',headers:{'Content-Type':'application/json','X-PQM-Local-Role':role()},body:JSON.stringify({supplier_codes:[...supplierRegistrySelectedCodes].sort()})});if(!response.ok){const body=await response.json().catch(()=>({}));throw new Error(body.error||`Помилка сервера ${response.status}`)}const blob=await response.blob(),url=URL.createObjectURL(blob),link=document.createElement('a');link.href=url;link.download='ClarityChecker_вибрані.csv';document.body.append(link);link.click();link.remove();URL.revokeObjectURL(url)}catch(error){toast(error.message,'error')}finally{button.disabled=!supplierRegistrySelectedCodes.size}};
$$('.supplier-filter-kpi').forEach(card=>card.onclick=()=>{supplierRegistryRisk=supplierRegistryRisk===card.dataset.risk?'':card.dataset.risk;supplierRegistryPage=1;loadQualifiedSuppliersFiltered()});
$('#supplierEdrSync').onclick=()=>supplierEdrOauth.authorized&&!supplierEdrReconnectRequired?previewSupplierEdrSync():connectSupplierGoogle();$('#supplierEdrPreviewApply').onclick=startSupplierEdrSync;window.addEventListener('message',event=>{if(event.origin!==location.origin||event.data?.type!=='pqm-google-oauth')return;if(event.data.ok)supplierEdrReconnectRequired=false;loadSupplierEdrStatus();loadSupplierNazkReviewStatus();toast(event.data.ok?'Google підключено':'Підключення Google не завершено',event.data.ok?'success':'error')});
$('#supplierNazkReviewSync').onclick=()=>supplierEdrOauth.authorized?startSupplierNazkReviewSync():connectSupplierGoogle();
$('#suppliersNav').addEventListener('click',loadSupplierNazkReviewStatus);
$('#suppliersNav').addEventListener('click',loadSupplierRiskCounts);
$('#edrMonitoringNav').onclick=()=>{showModule('edrMonitoring');loadEdrMonitoring();loadSupplierEdrStatus()};
$('#edrMonitoringSearch').oninput=$('#edrMonitoringDk').oninput=()=>{edrMonitoringPage=1;saveEdrMonitoringFilters();clearTimeout(edrMonitoringTimer);edrMonitoringTimer=setTimeout(loadEdrMonitoring,250)};
bindEdrMonitoringStatusMulti('edrMonitoringProzorro','prozorro_status');
$('#edrMonitoringType').onchange=$('#edrMonitoringNames').onchange=$('#edrMonitoringFreshness').onchange=$('#edrMonitoringVerifiedFrom').onchange=$('#edrMonitoringVerifiedTo').onchange=$('#edrMonitoringApplicationFrom').onchange=$('#edrMonitoringApplicationTo').onchange=()=>{edrMonitoringPage=1;loadEdrMonitoring()};
$('#edrMonitoringFullName').onchange=$('#edrMonitoringShortName').onchange=()=>{edrMonitoringPage=1;loadEdrMonitoring()};
$('#edrMonitoringKpis').onclick=event=>{const button=event.target.closest('[data-freshness]');if(!button)return;$('#edrMonitoringFreshness').value=$('#edrMonitoringFreshness').value===button.dataset.freshness?'':button.dataset.freshness;edrMonitoringPage=1;loadEdrMonitoring()};
$('#edrMonitoringReset').onclick=()=>{$('#edrMonitoringSearch').value=$('#edrMonitoringDk').value=$('#edrMonitoringType').value=$('#edrMonitoringNames').value=$('#edrMonitoringFreshness').value=$('#edrMonitoringVerifiedFrom').value=$('#edrMonitoringVerifiedTo').value=$('#edrMonitoringApplicationFrom').value=$('#edrMonitoringApplicationTo').value='';Object.values(edrMonitoringStatusSelections).forEach(selection=>selection.clear());bindEdrMonitoringStatusMulti('edrMonitoringProzorro','prozorro_status');bindEdrMonitoringStatusMulti('edrMonitoringEdr','edr_status');edrMonitoringPage=1;edrMonitoringSelected.clear();updateEdrMonitoringFilters();loadEdrMonitoring()};
const resetEdrMonitoringBase=$('#edrMonitoringReset').onclick;
$('#edrMonitoringReset').onclick=()=>{$('#edrMonitoringFullName').value=$('#edrMonitoringShortName').value='';try{localStorage.removeItem(edrMonitoringStorageKey)}catch{}resetEdrMonitoringBase()};
$('#edrMonitoringSelectPage').onchange=event=>{edrMonitoringItems.forEach(item=>{const code=String(item.supplier_code);event.target.checked?edrMonitoringSelected.add(code):edrMonitoringSelected.delete(code)});$$('#edrMonitoringBody .edr-monitoring-check').forEach(input=>input.checked=event.target.checked);updateEdrMonitoringSelection()};
$('#edrMonitoringPrev').onclick=()=>{if(edrMonitoringPage>1){edrMonitoringPage--;loadEdrMonitoring()}};$('#edrMonitoringNext').onclick=()=>{if(edrMonitoringPage<edrMonitoringPages){edrMonitoringPage++;loadEdrMonitoring()}};
$('#edrMonitoringExport').onclick=async event=>{if(!edrMonitoringSelected.size)return;event.preventDefault();const button=event.currentTarget;button.setAttribute('aria-disabled','true');try{await exportSelectedEdrMonitoring()}catch(error){toast(error.message,'error')}finally{button.removeAttribute('aria-disabled')}};
$('#edrMonitoringCreateTermination').onclick=previewTerminationExclusions;
$('#edrMonitoringSync').onclick=()=>supplierEdrOauth.authorized&&!supplierEdrReconnectRequired?previewSupplierEdrSync():connectSupplierGoogle();
$$('#edrMonitoringView [data-edr-sort]').forEach(header=>header.onclick=()=>{const key=header.dataset.edrSort;if(edrMonitoringSort===key)edrMonitoringDirection=edrMonitoringDirection==='asc'?'desc':'asc';else{edrMonitoringSort=key;edrMonitoringDirection='asc'}edrMonitoringPage=1;loadEdrMonitoring()});
document.addEventListener('keydown',event=>{if(event.key!=='Escape')return;['#edrMonitoringAdvanced','#edrMonitoringProzorro','#edrMonitoringEdr','#edrMonitoringColumns'].forEach(selector=>{const details=$(selector);if(details)details.open=false})});
applyEdrMonitoringColumns();
$('#supplierRegistryPrev').onclick=()=>{if(supplierRegistryPage>1){supplierRegistryPage--;loadQualifiedSuppliersFiltered()}};
$('#supplierRegistryNext').onclick=()=>{if(supplierRegistryPage<supplierRegistryPages){supplierRegistryPage++;loadQualifiedSuppliersFiltered()}};
$('#auditPrev').onclick=()=>{if(auditPage>1){auditPage--;loadAudit()}};
$('#auditNext').onclick=()=>{if(auditPage<auditPages){auditPage++;loadAudit()}};
const schedulerJobLabels={prozorro:'Заявки / Prozorro',violation_reports:'Звернення замовників',nazk_registry:'Реєстр НАЗК'};
const schedulerEnableConfirmations={
  prozorro:'Увімкнути автоматичне оновлення заявок щогодини о :05?',
  violation_reports:'Увімкнути автоматичне оновлення звернень замовників щогодини о :05?',
  nazk_registry:'Увімкнути автоматичне оновлення Реєстру НАЗК у робочі дні о 09:20?'
};
let manualBidsFeatureState={enabled:false,configuration_source:'environment',mode_supported:true};
let googleRuntimeFeatureState={enabled:false,configuration_source:'environment',client_configured:false,oauth_connected:false};
function renderGoogleRuntimeState(feature={}){
  googleRuntimeFeatureState={...googleRuntimeFeatureState,...feature};
  const enabled=googleRuntimeFeatureState.enabled===true,connected=googleRuntimeFeatureState.oauth_connected===true,canManage=role()==='admin';
  const state=$('#googleRuntimeState'),toggle=$('#googleRuntimeToggle'),disconnect=$('#googleDisconnect');
  if(state){state.textContent=`Google integration: ${enabled?'Увімкнено':'Вимкнено'}`;state.className=`runtime-feature-state ${enabled?'enabled':'disabled'}`}
  if(toggle){toggle.hidden=!canManage;toggle.disabled=!canManage;toggle.dataset.enabled=enabled?'false':'true';toggle.textContent=enabled?'Вимкнути':'Увімкнути'}
  if(disconnect){disconnect.hidden=!canManage||!connected;disconnect.disabled=!canManage||!connected}
  if($('#googleClientState'))$('#googleClientState').textContent=googleRuntimeFeatureState.client_configured?'Налаштовано':'Не налаштовано';
  if($('#googleTokenState'))$('#googleTokenState').textContent=connected?'Підключено':'Не підключено';
  if($('#googleLastEdrSync'))$('#googleLastEdrSync').textContent=googleRuntimeFeatureState.last_edr_sync_at?displayDate(googleRuntimeFeatureState.last_edr_sync_at):'—';
  if($('#googleConfigurationSource'))$('#googleConfigurationSource').textContent=googleRuntimeFeatureState.configuration_source==='runtime'?'Адміністратор':'Середовище';
  if($('#googleRuntimeMessage'))$('#googleRuntimeMessage').textContent=googleRuntimeFeatureState.message||'Фактичний стан Google integration';
}
async function toggleGoogleRuntime(){
  const button=$('#googleRuntimeToggle'),enabled=button.dataset.enabled==='true';
  if(enabled&&!confirm('Увімкнути Google integration? OAuth і синхронізація не будуть запущені автоматично.'))return;
  button.disabled=true;
  try{const result=await request(`${API}/admin/runtime-features/google`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({enabled})});renderGoogleRuntimeState(result.feature);toast(`Google integration ${enabled?'увімкнено':'вимкнено'}`,'success');await Promise.all([loadRuntimeFeatures(),loadSupplierEdrStatus(),loadSupplierNazkReviewStatus()])}catch(error){button.disabled=false;toast(error.message,'error')}
}
async function disconnectGoogle(){
  if(!confirm('Видалити локальне підключення Google? OAuth client configuration залишиться без змін.'))return;
  const button=$('#googleDisconnect');button.disabled=true;
  try{const result=await request(`${API}/admin/google/disconnect`,{method:'POST',headers:{'Content-Type':'application/json'},body:'{}'});renderGoogleRuntimeState(result.feature);toast('Локальне підключення Google видалено','success');await Promise.all([loadRuntimeFeatures(),loadSupplierEdrStatus(),loadSupplierNazkReviewStatus()])}catch(error){button.disabled=false;toast(error.message,'error')}
}
function renderManualBidsUpdateState(feature={}){
  manualBidsFeatureState={...manualBidsFeatureState,...feature};
  const enabled=manualBidsFeatureState.enabled===true,state=$('#bidsManualUpdateState'),toggle=$('#bidsManualUpdateToggle'),update=$('#bidsDataRefresh'),canManage=role()==='admin';
  if(state){state.textContent=`Ручне оновлення Bids: ${enabled?'Увімкнено':'Вимкнено'}`;state.className=`runtime-feature-state ${enabled?'enabled':'disabled'}`;state.title=manualBidsFeatureState.configuration_source==='runtime'?'Налаштовано адміністратором':'Початкове значення середовища'}
  if(toggle){toggle.hidden=!canManage;toggle.disabled=!canManage||manualBidsFeatureState.mode_supported===false;toggle.dataset.enabled=enabled?'false':'true';toggle.textContent=enabled?'Вимкнути':'Увімкнути';toggle.title=manualBidsFeatureState.mode_supported===false?'Поточний режим Bids не підтримує ручне оновлення':''}
  if(update){update.dataset.runtimeDisabled=enabled?'0':'1';update.disabled=!enabled||update.dataset.bidsReady!=='1'||update.dataset.bidsRunning==='1'||!canManage;update.title=enabled?'':'Оновлення ProzorroBids вимкнено адміністратором'}
}
async function toggleManualBidsUpdate(){
  const button=$('#bidsManualUpdateToggle'),enabled=button.dataset.enabled==='true';
  if(enabled&&!confirm('Увімкнути ручне оновлення даних Bids? Саме оновлення не буде запущено.'))return;
  button.disabled=true;
  try{const result=await request(`${API}/admin/runtime-features/manual-bids-update`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({enabled})});renderManualBidsUpdateState(result.feature);toast(`Ручне оновлення Bids ${enabled?'увімкнено':'вимкнено'}`,'success');await loadRuntimeFeatures()}catch(error){button.disabled=false;toast(error.message,'error')}
}
async function toggleSchedulerJob(button){
  const job=button.dataset.schedulerJob,enabled=button.dataset.enabled==='true';
  const confirmation=button.dataset.sandbox==='true'
    ?'Увімкнути автоматичне оновлення в SANDBOX? Оновлюватимуться лише тестові дані SANDBOX; PROD не змінюється.'
    :(schedulerEnableConfirmations[job]||`Увімкнути ${schedulerJobLabels[job]||job}?`);
  if(enabled&&!confirm(confirmation))return;
  button.disabled=true;
  try{
    await request(`${API}/admin/scheduler-jobs/${encodeURIComponent(job)}`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({enabled})});
    toast(`${schedulerJobLabels[job]||job}: ${enabled?'автоматичне оновлення увімкнено':'автоматичне оновлення вимкнено'}`,'success');
    await loadRuntimeFeatures();
  }catch(error){button.disabled=false;toast(error.message,'error')}
}
function environmentBannerText(features){
  return 'PQM';
}
async function loadRuntimeFeatures(){
  try{
    const features=await request(`${API}/runtime-features`);
    const banner=$('#environmentBanner');
    if(banner){
      banner.textContent=environmentBannerText(features);
      banner.title='Profzakupivli Qualification Manager';
    }
    const schedulerRoot=$('#schedulerJobs');
    if(schedulerRoot){
      const isAdmin=role()==='admin';
      schedulerRoot.innerHTML=(features.scheduler_jobs||[]).map(job=>{const showAction=isAdmin;const manageable=job.manageable===true;return`<article class="scheduler-job ${job.enabled?'enabled':'disabled'}"><header><strong>${esc(schedulerJobLabels[job.job]||job.job)}</strong><span>${job.enabled?'Увімкнено':'Вимкнено'}</span></header><dl><div><dt>Розклад</dt><dd>${esc(job.schedule)}</dd></div><div><dt>Timezone</dt><dd>${esc(job.timezone)}</dd></div><div><dt>Останній запуск</dt><dd>${esc(job.last_finished_at?displayDate(job.last_finished_at):'—')}</dd></div><div><dt>Наступний запуск</dt><dd>${esc(job.enabled&&job.next_run?displayDate(job.next_run):'—')}</dd></div><div><dt>Джерело налаштування</dt><dd>${job.configuration_source==='runtime'?'Адміністратор':'Середовище'}</dd></div></dl>${showAction?`<footer><button type="button" class="ghost scheduler-toggle" data-scheduler-job="${esc(job.job)}" data-sandbox="${features.sandbox_mode?'true':'false'}" data-enabled="${job.enabled?'false':'true'}" ${features.sandbox_mode&&!manageable?'disabled title="SANDBOX destination не підтверджено"':''}>${job.enabled?'Вимкнути':'Увімкнути'}</button></footer>`:''}</article>`}).join('');
      schedulerRoot.onclick=event=>{const button=event.target.closest('.scheduler-toggle');if(button)toggleSchedulerJob(button)};
    }
    renderGoogleRuntimeState(features.google_integration||{enabled:Boolean(features.google),configuration_source:'environment'});
    renderManualBidsUpdateState(features.manual_bids_update||{enabled:Boolean(features.bids_update),configuration_source:'environment',mode_supported:features.bids_mode!=='disabled'});
    const disable=(selector,message)=>{const element=$(selector);if(!element)return;element.dataset.runtimeDisabled='1';element.disabled=true;element.title=message};
    if(features.bids_mode==='disabled'){
      disable('#bidsStatusRefresh','Локальна база ProzorroBids не підключена');
      $('#bidsSyncHeadline').textContent='ProzorroBids не підключено до TEST WEB';
    }
    if(!features.powerbi){
      disable('#powerbiExportBtn','Power BI доступний лише в локальному середовищі');
      $('#powerbiStatusMessage').textContent='Power BI вимкнено у TEST WEB';
    }
    if(!features.google){
      disable('#supplierEdrSync','Google integration вимкнено');
      disable('#supplierNazkReviewSync','Google integration вимкнено');
    }
    // SANDBOX local actions use the same role/UI controls as PROD. The server
    // attests the destination before mutation; no per-button sandbox allowlist.
    updateRequestsRefreshAvailability({runtimeLoaded:true,sandboxMode:Boolean(features.sandbox_mode),sandboxOperational:Boolean(features.sandbox_operational),sandboxProzorroRead:Boolean(features.sandbox_prozorro_read)});
    return features;
  }catch(error){const schedulerRoot=$('#schedulerJobs');if(schedulerRoot)schedulerRoot.innerHTML='<p>Статус автоматичних оновлень недоступний. Увімкнення заблоковано.</p>';return null}
}
document.addEventListener('click',event=>{
  const blocked=event.target.closest('[data-sandbox-blocked="1"]');
  if(blocked){event.preventDefault();event.stopImmediatePropagation();toast(blocked.title,'error')}
},true);
const persistedLocalRole=localStorage.getItem(localRoleKey);
if(persistedLocalRole&&$('#roleSelect').querySelector(`option[value="${persistedLocalRole}"]`))$('#roleSelect').value=persistedLocalRole;
// Login submits then reloads. Private module bootstrap waits for a real identity.
const authReady=loadAuthenticatedRole().then(me=>me||new Promise(()=>{}));
const templateIntro=$('#adminTemplatesPanel .admin-template-heading .muted');
if(templateIntro)templateIntro.textContent='Усі активні runtime DOCX-шаблони системи.';
// One predictable popover model for registry filters/settings. Native details
// keeps keyboard behaviour; this coordinator guarantees a single open panel.
const managedPopoverSelector='.registry-toolbar details,.multi-filter,.toolbar-settings,.advanced-filters';
document.addEventListener('toggle',event=>{
  const opened=event.target;
  if(!(opened instanceof HTMLDetailsElement)||!opened.open||!opened.matches(managedPopoverSelector))return;
  $$(managedPopoverSelector).forEach(item=>{
    if(item!==opened&&item instanceof HTMLDetailsElement&&!item.contains(opened))item.open=false;
  });
},true);
document.addEventListener('pointerdown',event=>{
  $$(managedPopoverSelector).forEach(item=>{
    if(item instanceof HTMLDetailsElement&&item.open&&!item.contains(event.target))item.open=false;
  });
});
authReady.then(()=>{
document.addEventListener('input',event=>{
  if(event.target.closest(sharedFilterSurfaceSelector))syncSharedFilterPresentation(event.target.closest('[data-module],main')||document);
});
document.addEventListener('change',event=>{
  if(event.target.closest(sharedFilterSurfaceSelector)||event.target.closest('.multi-filter'))syncSharedFilterPresentation(event.target.closest('[data-module],main')||document);
});
syncSharedFilterPresentation();
void loadRuntimeFeatures();
showModule(activeModule);
if(activeModule==='workQueue')loadWorkQueue();
else if(activeModule==='suppliers'){loadQualifiedSuppliersFiltered();loadSupplierRiskCounts();loadSupplierEdrStatus();loadSupplierNazkReviewStatus()}
else if(activeModule==='edrMonitoring'){loadEdrMonitoring();loadSupplierEdrStatus()}
else if(activeModule==='frameworks')loadFrameworkAnalytics();
else if(activeModule==='administration')setAdminTab(adminTab);
else if(activeModule==='requests')loadViolationReports();
const initialLink=new URLSearchParams(location.search);if(activeModule==='requests'&&initialLink.get('report_id'))setTimeout(()=>openViolationReportById(initialLink.get('report_id')),0);if(activeModule==='applications'&&initialLink.get('submission_id')){deepLinkSubmissionId=initialLink.get('submission_id');setTimeout(async()=>{await loadRows();if(initialLink.get('nazk_control')==='1'&&rows[0])openSubmissionNazkControl(rows[0])},0)}
});
$('#roleSelect').addEventListener('change',()=>{localStorage.setItem(localRoleKey,$('#roleSelect').value);loadAuthenticatedRole().then(()=>{renderProfiles();render();loadRuntimeFeatures()})});
loadAdminOfficers=async function(){
  const body=$('#adminOfficersBody');body.innerHTML='<tr><td colspan="5">Завантаження…</td></tr>';
  try{
    const items=await loadAuthorizedOfficers(false);
    body.innerHTML=items.map(x=>`<tr data-officer-id="${x.id}"><td><strong>${esc(x.full_name)}</strong></td><td><input data-officer-role value="${esc(x.role||'УО')}"></td><td><label><input data-officer-active type="checkbox" ${x.active?'checked':''}> ${x.active?'Активна':'Історична'}</label></td><td>${Number(x.active_frameworks||0).toLocaleString('uk-UA')}</td><td><button class="primary admin-officer-save">Зберегти</button>${x.can_delete?` <button class="ghost admin-officer-delete">Видалити</button>`:` <button class="ghost" disabled title="УО вже використана у предметних даних — доступна лише деактивація">Видалити</button>`}</td></tr>`).join('');
    $$('.admin-officer-save').forEach(button=>button.onclick=async()=>{const row=button.closest('tr');await request(`${API}/admin/officers/${row.dataset.officerId}`,{method:'PATCH',headers:{'Content-Type':'application/json'},body:JSON.stringify({role:row.querySelector('[data-officer-role]').value,active:row.querySelector('[data-officer-active]').checked})});toast('Довідник УО оновлено');await loadAdminOfficers()});
    $$('.admin-officer-delete').forEach(button=>button.onclick=async()=>{const row=button.closest('tr');if(!confirm('Видалити невикористану УО? Історію аудиту буде збережено.'))return;try{await request(`${API}/admin/officers/${row.dataset.officerId}`,{method:'DELETE'});toast('Невикористану УО видалено');await loadAdminOfficers();await loadAuthorizedOfficers(true)}catch(error){toast(error.message)}});
  }catch(error){body.innerHTML=`<tr><td colspan="5">${esc(error.message)}</td></tr>`}
};
const storedLocalRole=localStorage.getItem(localRoleKey);if(storedLocalRole&&$('#roleSelect').querySelector(`option[value="${storedLocalRole}"]`))$('#roleSelect').value=storedLocalRole;
$('#resetBtn').textContent='Оновити з Prozorro';
let applicationsRegistryInitialization=null,applicationsRegistryInitialized=false;
const initializeApplicationsRegistry=()=>{if(applicationsRegistryInitialization)return applicationsRegistryInitialization;applicationsRegistryInitialization=(async()=>{await authReady;if(applicationsRegistryInitialized&&profilesMetadataReady)return reloadApplicationsRegistry({reloadMetadata:false});for(let attempt=0;attempt<3;attempt++){try{const result=await reloadApplicationsRegistry({reloadMetadata:true});if(result.ok&&profilesMetadataReady){applicationsRegistryInitialized=true;return}if(attempt===2)throw new Error(`Не завантажено: ${result.failures.join(', ')}`)}catch(error){if(attempt===2){renderProfileFallback();loading=false;render();toast(`Не вдалося ініціалізувати реєстр: ${error.message}`,'error');return}}await new Promise(resolve=>setTimeout(resolve,350*(attempt+1)))}})().finally(()=>{applicationsRegistryInitialization=null});return applicationsRegistryInitialization};
$('#applicationsNav').onclick=()=>{showModule('applications');initializeApplicationsRegistry()};
authReady.then(()=>{if(activeModule==='applications')return initializeApplicationsRegistry()},()=>{if(activeModule==='applications')return initializeApplicationsRegistry()});
refreshSyncStatus();setInterval(refreshSyncStatus,30000);

// Violation-report workbench: compact, deadline-aware presentation. Official Prozorro
// data remains read-only; only the local review section is editable.
function violationTriState(value){return value===true?'1':value===false?'0':''}
function violationOfficerOptions(item){const review=item.review||{},selected=String(review.assigned_officer_effective_id||review.assigned_officer_id||''),snapshot=String(review.assigned_officer_display||review.assigned_officer||'').trim(),matched=(item.active_officers||[]).some(o=>String(o.id)===selected),fallback=!selected&&snapshot?`<option value="" selected>${esc(formatOfficerName(snapshot))} · історичне призначення</option>`:'<option value="">Не призначено</option>';return `${fallback}${(item.active_officers||[]).map(o=>`<option value="${o.id}" ${String(o.id)===selected?'selected':''}>${esc(formatOfficerName(o.full_name))}${o.active?'':' · неактивна'}</option>`).join('')}${selected&&!matched?`<option value="${esc(selected)}" selected>${esc(formatOfficerName(snapshot)||'Призначена УО')} · історичне призначення</option>`:''}`}
function violationDeadlinePanel(item){const d=item.deadline_control||{};return `<div class="violation-deadlines"><div><small>Строк постачальника (Prozorro)</small><strong>${esc(displayDateOnly(d.supplier_official_deadline||d.supplier_deadline))||'—'}</strong><span class="${d.supplier_ready?'deadline-ready':'deadline-wait'}">${d.supplier_ready?'Строк завершено':'Очікуємо пояснення'}</span></div><div><small>Контроль 3 робочих днів</small><strong>${esc(displayDateOnly(d.supplier_local_control_deadline))||'—'}</strong></div><div><small>Строк Адміністратора · 10 робочих днів</small><strong>${esc(displayDateOnly(d.admin_deadline))||'—'}</strong><span class="${d.admin_overdue?'deadline-overdue':''}">${d.admin_overdue?'Прострочено':'У межах строку'}</span></div></div>`}
requestContextBlock=function(item){const c=item.procurement_context||{},r=item.review||{},d=item.deadline_control||{},guarantee=c.contract_guarantee_required?`<label>Документи забезпечення перевірено<select data-review="guarantee_documents_visible"><option value="" ${r.guarantee_documents_visible==null?'selected':''}>Ще не перевірено</option><option value="0" ${r.guarantee_documents_visible===false?'selected':''}>Перевірено · не виявлені</option><option value="1" ${r.guarantee_documents_visible===true?'selected':''}>Перевірено · виявлені</option></select></label>`:'';return `<section class="request-review violation-workbench"><h3>ПЕРЕВІРКА УО</h3>${violationDeadlinePanel(item)}${!c.available?`<p class="request-warning">Контекст закупівлі не отримано: ${esc(c.error||'невідома помилка')}</p>`:`<div class="request-context-grid"><div><small>Переможець визначений</small><strong>${esc(displayDate(c.winner_selected_at))||'—'}</strong></div><div><small>Відхилення</small><strong>${esc(displayDate(c.rejection_date))||'Не зафіксовано'}</strong></div><div><small>Договір</small><strong>${esc(c.contract_pretty_id||c.contract_status)||'Не знайдено'}</strong></div><div><small>Забезпечення договору</small><strong>${c.contract_guarantee_required?'Передбачено':'Не виявлено'}</strong></div></div>`}<div class="request-form-grid"><label>Відповідальна УО<select data-review="assigned_officer_id">${violationOfficerOptions(item)}</select></label><label>Статус розгляду<select data-review="review_status"><option value="not_reviewed">Не розглянуто</option><option value="in_review">На розгляді</option><option value="completed">Завершено</option></select></label><label>Рішення УО<select data-review="internal_decision" ${!d.supplier_ready?'disabled title="До завершення строку постачальника"':''}><option value="">Не визначено</option>${Object.entries(internalDecisionLabels).map(([v,l])=>`<option value="${v}" ${r.internal_decision===v?'selected':''}>${l}</option>`).join('')}</select></label><label class="request-check"><input type="checkbox" data-review="additional_check_required" ${r.additional_check_required?'checked':''}> Потребує додаткової перевірки за п. 50</label>${guarantee}<label class="wide">Оцінка пояснень і документів постачальника<textarea data-review="supplier_explanation_assessment">${esc(r.supplier_explanation_assessment||'')}</textarea></label><label class="wide">Встановлена невідповідність (для обґрунтування відмови)<textarea data-review="established_discrepancy">${esc(r.established_discrepancy||'')}</textarea></label><label>Дата письмової відмови<input type="date" data-review="written_refusal_date" value="${esc(r.written_refusal_date||'')}"></label><label>Вих. № письмової відмови<input data-review="written_refusal_number" value="${esc(r.written_refusal_number||'')}"></label><label>Посилання на письмову відмову<input type="url" data-review="written_refusal_url" value="${esc(r.written_refusal_url||'')}"></label><label>Рішення суду набрало законної сили<select data-review="court_decision_final_present"><option value="">Не перевірено</option><option value="1" ${r.court_decision_final_present===true?'selected':''}>Так</option><option value="0" ${r.court_decision_final_present===false?'selected':''}>Ні</option></select></label><label class="wide">Коментар УО<textarea data-review="review_notes">${esc(r.review_notes||'')}</textarea></label></div><section class="violation-justification"><h3>Обґрунтування рішення</h3>${item.justification_stale?'<p class="request-warning">Вихідні дані змінилися. За потреби явно оновіть обґрунтування.</p>':''}<textarea data-review="decision_justification" placeholder="Чернетка або ручний текст УО…">${esc(r.decision_justification||'')}</textarea><div class="violation-inline-actions"><button type="button" class="ghost" id="regenerateViolationJustification">${r.decision_justification?'Оновити обґрунтування':'Сформувати чернетку'}</button><button type="button" class="ghost" id="copyViolationJustification">Копіювати</button></div></section></section>`}
violationDetailHtml=function(item){const w=item.warning_summary||{},customer=`${esc(item.author_name)||'—'}${item.author_code?` · ${esc(item.author_code)}`:''}`,supplier=`${esc(item.defendant_name)||'—'}${item.defendant_code?` · ${esc(item.defendant_code)}`:''}`;return `${item.is_read_only?'<div class="request-readonly">У Prozorro вже є рішення Адміністратора — картка лише для перегляду.</div>':''}<section class="violation-parties"><div><h3>Замовник</h3><p>${customer}</p>${item.review?.customer_verified_full_name?`<small>Перевірено: ${esc(item.review.customer_verified_full_name)}</small>`:''}</div><div><h3>Постачальник</h3><p>${supplier}</p><small>Попередження: за місяць ${Number(w.month||0)} / 3 · за 3 місяці ${Number(w.three_months||0)} / 5</small></div></section><section><h3>Закупівля · договір · звернення</h3><p>${requestTenderLinks(item)}</p></section><section><h3>Підстава та докази замовника</h3><p><strong>${esc(requestLabel(item.reason,requestReasonLabels))}</strong></p><div class="request-long-text">${esc(item.description||'Опис відсутній').replaceAll('\n','<br>')}</div><div class="request-documents">${requestDocumentLinks(item.evidence_documents)}</div></section><section class="violation-supplier-response"><div><h3>Строк постачальника</h3>${violationDeadlinePanel(item)}</div><div><h3>Пояснення та документи постачальника</h3>${requestStatements(item)}</div></section>${item.is_read_only?`<section><h3>Рішення Адміністратора</h3><p><strong>${esc(requestLabel(item.decision_resolution,requestStatusLabels))}</strong> · ${esc(displayDate(item.decision_date))}</p><div class="request-long-text">${esc(item.decision_description||'')}</div>${requestDocumentLinks(item.decision_documents)}</section>`:requestContextBlock(item)}`}
collectViolationReview=function(){const payload={};$$('#requestDetailsBody [data-review]').forEach(input=>{const key=input.dataset.review;if(input.type==='checkbox')payload[key]=input.checked;else payload[key]=input.value});return payload}
async function regenerateViolationJustification(item){try{const payload=collectViolationReview();payload.action='regenerate_justification';const data=await request(`${API}/violation-reports/${encodeURIComponent(item.id)}/review`,{method:'PATCH',headers:{'Content-Type':'application/json'},body:JSON.stringify(payload)});$('#requestDetailsBody').innerHTML=violationDetailHtml(data);bindViolationReview(data);bindViolationCardDeclensionActions(data);toast('Чернетку обґрунтування оновлено')}catch(error){toast(error.message)}}
bindViolationReview=function(item){const status=$('[data-review="review_status"]');if(status)status.value=item.review?.review_status||'not_reviewed';const save=$('#requestDetailsSave');if(save){save.hidden=Boolean(item.is_read_only);save.onclick=item.is_read_only?null:()=>saveViolationReview(item.id)}const inline=$('#saveViolationReview');if(inline)inline.hidden=true;const regen=$('#regenerateViolationJustification');if(regen)regen.onclick=()=>regenerateViolationJustification(item);const copy=$('#copyViolationJustification');if(copy)copy.onclick=async()=>{await copyText($('[data-review="decision_justification"]')?.value||'');toast('Обґрунтування скопійовано')}}
const violationWorkbenchBase=requestContextBlock;
requestContextBlock=function(item){const html=violationWorkbenchBase(item),r=item.review||{},c=item.procurement_context||{};const extra=`<div class="request-form-grid violation-supporting-fields"><label>Перевірена повна назва замовника<input data-review="customer_verified_full_name" value="${esc(r.customer_verified_full_name||'')}"></label><label>Скорочена назва замовника<input data-review="customer_verified_short_name" value="${esc(r.customer_verified_short_name||'')}"></label>${c.contract_info_required===false?'':`<label>Фактична дата договору<input type="date" data-review="actual_contract_date" value="${esc(r.actual_contract_date||'')}"></label><label>№ договору<input data-review="actual_contract_number" value="${esc(r.actual_contract_number||'')}"></label><label>Посилання на договір<input type="url" data-review="actual_contract_url" value="${esc(r.actual_contract_url||'')}"></label>`}</div>`;return html.replace('<section class="violation-justification">',extra+'<section class="violation-justification">')}

function zakupivliComplaintLink(item){const supplierCode=String(item?.defendant_code||'').trim(),valid=/^(?:\d{8}|\d{10})$/.test(supplierCode),base='https://my.zakupivli.pro/cabinet/ecatalog/gov/complaints/list',href=valid?`${base}?defendant_srn=${encodeURIComponent(supplierCode)}`:base,label='Звернення щодо постачальника на Zakupivli.Pro';return `<a class="violation-zakupivli-link" href="${href}" target="_blank" rel="noopener noreferrer" aria-label="${label}" title="${label}"><img src="/assets/zakupivli-pro-mark.svg" alt="Zakupivli.Pro"></a>`}
function violationObjectLinks(item){const c=item.factual_procurement_context||item.procurement_context||{},tender=item.tender_pretty_id?`<a href="https://prozorro.gov.ua/uk/tender/${encodeURIComponent(item.tender_pretty_id)}" target="_blank" rel="noopener">${esc(item.tender_pretty_id)}</a>`:'—',contractId=c.contract_pretty_id||item.contract_pretty_id,contract=contractId?`<a href="https://prozorro.gov.ua/uk/contract/${encodeURIComponent(contractId)}" target="_blank" rel="noopener">${esc(contractId)}</a> <small>${esc(c.contract_status||'')}</small>`:'Не знайдено',reportUrl=requestViolationUrl(item),report=reportUrl?`<a href="${reportUrl}" target="_blank" rel="noopener">${esc(item.report_id||'Звернення')}</a>`:esc(item.report_id||'—'),dk=(c.dk_classifications||[]).map(x=>`${x.code}${x.description?` — ${x.description}`:''}`).join('; ')||c.cpv||c.dk_code||'—';return `<dl class="violation-object-links"><div><dt>Закупівля</dt><dd>${tender}</dd></div><div><dt>ДК 021:2015</dt><dd>${esc(dk)}</dd></div><div><dt>Договір</dt><dd>${contract}</dd></div><div><dt>Звернення</dt><dd>${report}</dd></div><div><dt>Статус звернення</dt><dd><strong>${esc(requestLabel(item.decision_resolution||item.status,requestStatusLabels))}</strong></dd></div></dl>`}
function violationHasCompleteRejection(context={}){return Boolean(context.rejection_date&&String(context.rejection_reason||context.rejection_title||context.rejection_description||'').trim())}
function violationReasonFields(item){
  const c=item.procurement_context||{},r=item.review||{},hasStatements=(item.defendant_statements||[]).length>0;
  const rejectionDate=c.rejection_ambiguous?'Потрібна перевірка':(displayDate(c.rejection_date)||'—');
  const rejectionGround=c.rejection_ambiguous?'Потрібна перевірка':(c.rejection_title||c.rejection_description||'—');
  const assessment=hasStatements?`<label class="wide">Оцінка пояснень і документів постачальника<textarea data-review="supplier_explanation_assessment">${esc(r.supplier_explanation_assessment||'')}</textarea></label>`:'';
  const discrepancy=`<label class="wide">Встановлена невідповідність<textarea data-review="established_discrepancy">${esc(r.established_discrepancy||'')}</textarea></label>`;
  if(item.reason==='contractBreach'){
    const shiftedWeekday=String(c.day_5_weekday_uk||'').trim();
    const shiftedDeadline=c.day_5_shifted?(shiftedWeekday?`<small>5-й календарний день: ${esc(displayDateOnly(c.day_5))||'—'} (${esc(shiftedWeekday)})</small><small>Строк перенесено на перший робочий день відповідно до ч. 5 ст. 254 ЦК України.</small>`:`<small class="request-warning">Неузгоджені дані строку: backend не повернув day_5_weekday_uk.</small>`):'';
    const rejectionFacts=`<div class="request-context-grid violation-facts-row"><div><small>Дата визначення переможцем</small><strong>${esc(displayDate(c.winner_selected_at))||'—'}</strong></div><div><small>Граничний строк укладення договору</small><strong>${esc(displayDateOnly(c.contract_deadline))||'—'}</strong>${shiftedDeadline}</div><div><small>Дата відхилення</small><strong>${esc(rejectionDate)}</strong></div><div class="violation-fact-wide"><small>Підстава відхилення</small><strong>${esc(rejectionGround)}</strong></div></div>`;
    const contractState='';
    const guarantee=c.contract_guarantee_required?`<div class="violation-guarantee-row"><span>Забезпечення виконання договору про закупівлю: <strong>Так</strong></span><label>Документи забезпечення в Prozorro<select data-review="guarantee_documents_visible"><option value="" ${r.guarantee_documents_visible==null?'selected':''}>Ще не перевірено</option><option value="1" ${r.guarantee_documents_visible===true?'selected':''}>Наявні</option><option value="0" ${r.guarantee_documents_visible===false?'selected':''}>Відсутні</option></select></label></div>`:`<div class="violation-reference-row"><span>Забезпечення виконання договору про закупівлю</span><strong>Ні</strong></div>`;
    return `${rejectionFacts}${contractState}${guarantee}<div class="request-form-grid">${assessment}${discrepancy}</div>`;
  }
  if(item.reason==='signingRefusal'){
    const civil=c.day_3_shifted?'застосовується':'не застосовується';
    const chronology=`<div class="violation-p2-chronology"><div class="violation-p2-chronology-row"><div><small>Дата визначення переможцем</small><strong>${esc(displayDate(c.winner_selected_at))||'—'}</strong></div><div><small>Граничний строк письмової відмови</small><strong>${esc(displayDateOnly(c.written_refusal_deadline))||'—'}</strong><small>3-й календарний день: ${esc(displayDateOnly(c.day_3))||'—'}, ${esc(c.day_3_weekday_uk||c.day_3_weekday)||'—'}<br>ЦКУ: ${civil}</small></div><div><small>Дата письмової відмови</small><strong>${esc(displayDateOnly(r.written_refusal_date))||'—'}</strong></div><div><small>Дата відхилення</small><strong>${esc(rejectionDate)}</strong></div></div><div class="violation-p2-rejection-ground"><small>Підстава відхилення</small><strong>${esc(rejectionGround)}</strong></div></div>`;
    const refusalControls=`<div class="request-form-grid violation-written-refusal"><label>Дата письмової відмови постачальника<input type="date" data-review="written_refusal_date" value="${esc(r.written_refusal_date||'')}"></label><label>Вих. № відмови<input data-review="written_refusal_number" value="${esc(r.written_refusal_number||'')}"></label><label class="wide">Посилання на відмову<input type="url" data-review="written_refusal_url" value="${esc(r.written_refusal_url||'')}"></label><label>Дата рішення замовника<input type="date" data-review="customer_protocol_decision_date" value="${esc(r.customer_protocol_decision_date||'')}"></label><label>№ рішення замовника<input data-review="customer_protocol_decision_number" value="${esc(r.customer_protocol_decision_number||'')}"></label><label class="wide">Посилання на рішення замовника<input type="url" data-review="customer_protocol_decision_url" value="${esc(r.customer_protocol_decision_url||'')}"></label>${assessment}${discrepancy}</div>`;
    return chronology+refusalControls;
  }
  return `<div class="request-form-grid"><label>Рішення суду набрало законної сили<select data-review="court_decision_final_present"><option value="">Не перевірено</option><option value="1" ${r.court_decision_final_present===true?'selected':''}>Так</option><option value="0" ${r.court_decision_final_present===false?'selected':''}>Ні</option></select></label>${assessment}${discrepancy}</div>`;
}
const violationReasonFieldsBase=violationReasonFields;
violationReasonFields=function(item){
  const html=violationReasonFieldsBase(item),c=item.procurement_context||{},r=item.review||{};
  if(!['contractBreach','signingRefusal'].includes(item.reason)||!['unknown','ambiguous','unavailable'].includes(c.winner_state))return html;
  const displayed=html.replace('<small>Дата визначення переможцем</small><strong>—</strong>',
    '<small>Дата визначення переможцем</small><strong>Потрібна перевірка</strong>');
  const manual=`<div class="request-warning violation-manual-winner"><p>PQM не зміг однозначно визначити дату переможця. Перевірте ЕСЗ та за потреби підтвердьте дату вручну.</p><div class="request-form-grid"><label>Дата визначення переможцем, підтверджена УО<input type="date" data-review="manual_winner_date" value="${esc(r.manual_winner_date||'')}"></label><label class="wide">Джерело / коротка примітка підтвердження<input data-review="manual_winner_basis" value="${esc(r.manual_winner_basis||'')}"></label></div>${c.winner_date_source==='officer_manual'?`<small>Підтверджено УО вручну · ${esc(c.winner_manual_provenance?.entered_by||'')} · ${esc(displayDate(c.winner_manual_provenance?.entered_at)||'')}</small>`:''}</div>`;
  return manual+displayed;
};
requestContextBlock=function(item){const r=item.review||{},d=item.deadline_control||{},recommendation=item.recommendation||{},templateAvailable=Boolean(item.justification_template_key),generationReady=Boolean(d.supplier_ready),shownJustification=item.hide_saved_automatic_justification?'':(r.decision_justification||''),waitingNotice=!generationReady?'<p class="request-info">Обґрунтування рішення буде доступне після завершення строку для надання пояснень та документів постачальника.</p>':'';return `<section class="request-review violation-workbench"><h3>ПЕРЕВІРКА УО</h3><div class="request-form-grid violation-review-header"><label>Відповідальна УО<select data-review="assigned_officer_id">${violationOfficerOptions(item)}</select></label><label>Статус розгляду<select data-review="review_status"><option value="not_reviewed">Не розглянуто</option><option value="in_review">На розгляді</option><option value="reviewed">Розглянуто</option></select></label><div class="violation-admin-deadline"><small>Строк Адміністратора · 10 робочих днів</small><strong>${esc(displayDateOnly(d.admin_deadline))||'—'}</strong><span class="${d.admin_overdue?'deadline-overdue':''}">${d.admin_overdue?'Прострочено':'У межах строку'}</span></div><label class="request-check"><input type="checkbox" data-review="additional_check_required" ${r.additional_check_required?'checked':''}> Потребує додаткової перевірки за п. 50</label></div>${violationReasonFields(item)}<div class="request-recommendation"><small>Рекомендація системи</small><strong>${esc(internalDecisionLabels[recommendation.recommended_decision]||'Потрібна оцінка УО')}</strong><p>${esc(recommendation.recommendation_reason||'Система не формує остаточний юридичний висновок.')}</p></div>${item.scenario_summary?`<div class="violation-scenario-summary"><p>${esc(item.scenario_summary)}</p></div>`:''}<div class="request-form-grid"><label>Рішення УО<select data-review="internal_decision" ${!generationReady?'disabled title="До завершення строку постачальника"':''}><option value="">Не визначено</option>${Object.entries(internalDecisionLabels).map(([v,l])=>`<option value="${v}" ${r.internal_decision===v?'selected':''}>${l}</option>`).join('')}</select></label><label class="wide">Коментар УО<textarea data-review="review_notes">${esc(r.review_notes||'')}</textarea></label></div><section class="violation-justification"><h3>Обґрунтування рішення</h3>${waitingNotice}${generationReady&&item.justification_stale?'<p class="request-warning">Вихідні дані змінилися. За потреби оновіть обґрунтування</p>':''}${generationReady&&!templateAvailable&&!shownJustification?'<p class="request-warning">Для поточного збереженого стану погоджений шаблон не визначено. Після вибору підтримуваного рішення скористайтеся явною генерацією.</p>':''}<textarea data-review="decision_justification" placeholder="Чернетка з погодженого шаблону або ручний текст УО…">${esc(shownJustification)}</textarea><div class="violation-inline-actions"><button type="button" class="ghost" id="regenerateViolationJustification" ${!generationReady?'disabled title="До завершення строку постачальника"':''}>${shownJustification?'Оновити обґрунтування':'Сформувати обґрунтування'}</button><button type="button" class="ghost" id="copyViolationJustification">Копіювати</button></div></section></section>`}

const violationScenarioReviewBase=requestContextBlock;
// A matched draft is generated only after the officer chooses the recommended decision.
const violationApprovedDraftReviewBase=violationScenarioReviewBase;
requestContextBlock=function(item){
  return violationApprovedDraftReviewBase(item);
};
const violationContractReviewBase=requestContextBlock;
function violationContractEditorVisible(item){
  const context=item.procurement_context||{};
  if(context.contract_info_required!==true)return false;
  return !(['contractBreach','signingRefusal'].includes(item.reason)
    && context.rejection_present===true);
}
requestContextBlock=function(item){
  const html=violationContractReviewBase(item),c=item.procurement_context||{},r=item.review||{};
  if(c.available!==true)return html;
  const extension=item.reason==='contractBreach'?`<label class="request-check violation-contract-extension"><input type="checkbox" data-review="contract_deadline_extended" ${r.contract_deadline_extended?'checked':''}> Строк укладення договору продовжено до 10 к.д.</label>`:'';
  const contract=violationContractEditorVisible(item)?`<div class="violation-contract-editor"><label class="request-check"><input type="checkbox" id="violationContractSigned" data-review="actual_contract_signed" ${r.actual_contract_signed?'checked':''}> Договір укладено</label><div id="violationContractDetails" class="request-form-grid"><label>Дата укладення договору<input type="date" data-review="actual_contract_date" value="${esc(r.actual_contract_date||'')}"></label><label>№ договору<input data-review="actual_contract_number" value="${esc(r.actual_contract_number||'')}"></label><label class="wide">Посилання на договір<input type="url" data-review="actual_contract_url" value="${esc(r.actual_contract_url||'')}"></label></div></div>`:'';
  return html.replace('<section class="violation-justification">',extension+contract+'<section class="violation-justification">');
};
function violationKyivTodayISO(){
  const parts=Object.fromEntries(new Intl.DateTimeFormat('en-GB',{
    timeZone:'Europe/Kyiv',year:'numeric',month:'2-digit',day:'2-digit'
  }).formatToParts(new Date()).map(part=>[part.type,part.value]));
  return `${parts.year}-${parts.month}-${parts.day}`;
}
function violationAdminDeadlineState(deadlineControl,todayISO=violationKyivTodayISO()){
  const deadline=String(deadlineControl?.admin_deadline||'').slice(0,10);
  if(!/^\d{4}-\d{2}-\d{2}$/.test(deadline))return 'normal';
  if(deadlineControl?.admin_overdue===true||todayISO>deadline)return 'overdue';
  const ninth=new Date(`${deadline}T12:00:00Z`);
  do{ninth.setUTCDate(ninth.getUTCDate()-1)}while([0,6].includes(ninth.getUTCDay()));
  return todayISO>=ninth.toISOString().slice(0,10)?'attention':'normal';
}
function violationAdminDeadlineMarkup(deadlineControl,todayISO){
  const state=violationAdminDeadlineState(deadlineControl,todayISO);
  return `<div class="violation-admin-deadline" data-deadline-state="${state}"><small>Строк Адміністратора · 10 робочих днів</small><strong>${esc(displayDateOnly(deadlineControl?.admin_deadline))||'—'}</strong>${state==='overdue'?'<span>Строк сплив</span>':''}</div>`;
}
const violationDeadlineReviewBase=requestContextBlock;
requestContextBlock=function(item){
  return violationDeadlineReviewBase(item).replace(
    /<div class="violation-admin-deadline">[\s\S]*?<\/div>/,
    violationAdminDeadlineMarkup(item.deadline_control||{}));
};
bindViolationReview=function(item){const status=$('[data-review="review_status"]');if(status)status.value=item.review?.review_status||'not_reviewed';const save=$('#requestDetailsSave');if(save){save.hidden=Boolean(item.is_read_only);save.onclick=item.is_read_only?null:()=>saveViolationReview(item.id)}const inline=$('#saveViolationReview');if(inline)inline.hidden=true;const contractToggle=$('#violationContractSigned'),contractDetails=$('#violationContractDetails');if(contractToggle&&contractDetails){const syncContractDetails=()=>{const enabled=contractToggle.checked;contractDetails.hidden=!enabled;contractDetails.querySelectorAll('input').forEach(input=>input.disabled=!enabled)};contractToggle.onchange=syncContractDetails;syncContractDetails()}const regen=$('#regenerateViolationJustification');if(regen)regen.onclick=()=>regenerateViolationJustification(item);const copy=$('#copyViolationJustification');if(copy)copy.onclick=async()=>{await copyText($('[data-review="decision_justification"]')?.value||'');toast('Обґрунтування скопійовано')}}
violationDetailHtml=function(item){const w=item.warning_summary||{},customerClarity=item.author_code?`<a href="https://clarity-project.info/edr/${encodeURIComponent(item.author_code)}" target="_blank" rel="noopener">Clarity</a>`:'',supplierClarity=item.defendant_code?`<a href="https://clarity-project.info/edr/${encodeURIComponent(item.defendant_code)}" target="_blank" rel="noopener">Clarity</a>`:'',sv=item.supplier_verified||{},r=item.review||{},deadline=item.deadline_control||{};return `${item.is_read_only?'<div class="request-readonly">У Prozorro вже є рішення Адміністратора — картка лише для перегляду.</div>':''}<section class="violation-top-row"><div><h3>Замовник</h3><p><strong>${esc(item.author_name)||'—'}</strong><br>${esc(item.author_code)||'—'} · ${customerClarity}</p>${item.is_read_only?`<p><small>Назва для протоколу</small><br>${esc(r.customer_verified_full_name)||'—'}</p><p><small>Скорочена назва</small><br>${esc(r.customer_verified_short_name)||'—'}</p>`:`<label>Назва замовника для протоколу<input data-review="customer_verified_full_name" value="${esc(r.customer_verified_full_name||'')}"></label><label>Скорочена назва<input data-review="customer_verified_short_name" value="${esc(r.customer_verified_short_name||'')}"></label>`}</div><div><h3>Постачальник <span class="violation-thresholds">${Number(w.month||0)}/3 · ${Number(w.three_months||0)}/5</span></h3><p><strong>${esc(item.defendant_name)||'—'}</strong><br>${esc(item.defendant_code)||'—'} · ${supplierClarity}</p><p><small>Повна назва з ЄДР</small><br>${esc(sv.full_name)||'—'}</p><p><small>Скорочена назва з ЄДР</small><br>${esc(sv.short_name)||'—'}</p></div><div><h3>Закупівля · Договір · Звернення</h3>${violationObjectLinks(item)}</div></section><section><h3>Підстава та докази замовника</h3><p><strong>${esc(requestLabel(item.reason,requestReasonLabels))}</strong></p><div class="request-long-text">${esc(item.description||'Опис відсутній').replaceAll('\n','<br>')}</div><div class="request-documents">${requestDocumentLinks(item.evidence_documents)}</div></section><section class="violation-supplier-row"><div><h3>Строк для документів постачальника — 3 р.д.</h3><p><strong>${esc(displayDateOnly(deadline.supplier_official_deadline||deadline.supplier_deadline))||'—'}</strong></p><small>Контрольна дата 3 р.д.: ${esc(displayDateOnly(deadline.supplier_local_control_deadline))||'—'}</small><p class="${deadline.supplier_ready?'deadline-ready':'deadline-wait'}">${deadline.supplier_ready?'Строк завершено':'Строк ще триває'}</p></div><div><h3>Пояснення та документи постачальника</h3>${requestStatements(item)}</div></section>${item.is_read_only?`<section><h3>Рішення Адміністратора</h3><p><strong>${esc(requestLabel(item.decision_resolution,requestStatusLabels))}</strong> · ${esc(displayDate(item.decision_date))}</p><div class="request-long-text">${esc(item.decision_description||'')}</div>${requestDocumentLinks(item.decision_documents)}</section>`:requestContextBlock(item)}`}

const violationDetailHtmlBase=violationDetailHtml;
violationDetailHtml=function(item){
  let html=violationDetailHtmlBase(item)
    .replace('Строк для документів постачальника — 3 р.д.','Офіційний строк для документів постачальника')
    .replace('Контрольна дата 3 р.д.:','Довідковий локальний розрахунок 3 р.д. (не керує строком):');
  if(item.foreign_authority_read_only){
    html=html.replace('<div class="request-readonly">У Prozorro вже є рішення Адміністратора — картка лише для перегляду.</div>',
      '<div class="request-readonly">Інформаційний перегляд. Звернення належить іншій ЦЗО — розгляд у PQM недоступний.</div>');
  }
  return html;
};
function protocolSupplierNamesHtml(item){
  const names=item.protocol_supplier_names;
  if(!names||item.is_read_only)return '';
  const fields=[['full_name','Повна назва в документі'],['short_name','Скорочена назва в документі'],['filename_name','Назва постачальника у назві DOCX-файлу']];
  const warning=names.uses_fallback?'<p class="request-warning">Увага: для частини реквізитів використано найменування зі звернення Prozorro, а не з ЄДР чи кваліфікаційної заявки. Перевірте наведені значення перед формуванням. Відсутність назв із ЄДР сама по собі не блокує формування.</p>':'';
  return `<section class="protocol-supplier-name-provenance"><h4>Найменування для нового протоколу</h4>${warning}<dl>${fields.map(([key,label])=>{const field=names[key]||{};return `<div><dt>${esc(label)}</dt><dd><strong>${esc(field.value||'—')}</strong><small>${esc(field.source_label||'Не визначено')}</small></dd></div>`}).join('')}</dl></section>`;
}
const violationProtocolWorkbench=requestContextBlock;
requestContextBlock=function(item){const html=violationProtocolWorkbench(item),r=item.review||{},ready=item.protocol_readiness||{},reasons=ready.reasons||[],declensions=ready.declensions||[],unresolved=unresolvedDeclensionsByReport.get(String(item.id))||ready.unresolved||[],supplierReady=Boolean(item.deadline_control?.supplier_ready),disabled=!supplierReady?'disabled title="До завершення строку постачальника"':'',file=r.generated_protocol_filename?`${API}/protocol/files/${encodeURIComponent(r.generated_protocol_filename)}`:'',pdf=file?`${API}/violation-reports/${encodeURIComponent(item.id)}/protocol/pdf`:'',metadata=r.generated_protocol_resolved_metadata||[];const fileActions=file?`${protocolDocumentActions({docxUrl:file,pdfUrl:pdf})}${resolvedDocumentMetadataHtml(metadata)}`:'';const issueHtml=unresolved.length?`<div class="request-warning" id="violationProtocolReasons"><strong>Потрібні перевірені відмінкові форми:</strong><ul>${unresolved.map(entry=>`<li><span>${esc(entry.subject_label||'Назва')} · ${esc(entry.original)} · ${esc({genitive:'родовий',dative:'давальний',accusative:'знахідний'}[entry.grammatical_case]||entry.grammatical_case)}</span></li>`).join('')}</ul></div>`:(reasons.length?`<p class="request-warning" id="violationProtocolReasons">${reasons.map(esc).join(' · ')}</p>`:'<div class="request-warning" id="violationProtocolReasons" hidden></div>');const controls=`<section class="violation-protocol-controls protocol-decision-section"><h3>Протокольне рішення</h3><div class="request-form-grid"><label>№ протоколу<input data-review="protocol_number" value="${esc(r.protocol_number||'')}" ${disabled}></label><label>Дата протоколу<input type="date" data-review="protocol_date" value="${esc(String(r.protocol_date||'').slice(0,10))}" ${disabled}></label></div>${protocolSupplierNamesHtml(item)}${issueHtml}<div class="violation-inline-actions"><button type="button" class="primary" id="generateViolationProtocol" ${!ready.ready||unresolved.length?'disabled':''}>${file?'Перегенерувати протокол':'Сформувати протокол'}</button><button type="button" class="ghost" id="completeViolationReview" ${!supplierReady||!r.internal_decision?'disabled':''}>Завершити розгляд</button></div>${fileActions}</section>`;return html+violationDeclensionActions(declensions)+controls}
const violationProtocolNonBlockingBase=requestContextBlock;
requestContextBlock=function(item){
  let html=violationProtocolNonBlockingBase(item);
  if(!item.recommendation?.recommended_decision){
    html=html.replace('Потрібна оцінка УО','Автоматичну рекомендацію не визначено');
  }
  if(!item.justification_template_key){
    html=html.replace('Для поточного збереженого стану погоджений шаблон не визначено. Після вибору підтримуваного рішення скористайтеся явною генерацією.',
      'Типове обґрунтування не визначено. УО може внести обґрунтування вручну та сформувати протокол після заповнення обов’язкових реквізитів.');
  }
  return html;
};
const violationP3DraftReviewNotice='Рішення УО відрізняється від рекомендації системи. Внесіть обґрунтування рішення вручну.';
function violationP3DraftNeedsReview(item,decision,text){
  const recommended=item.recommendation?.recommended_decision;
  return ['warning','decline'].includes(recommended)
    && ['warning','decline'].includes(decision)
    && decision!==recommended;
}
function violationShouldAutoGenerateOnDecision(item,decision,text,editedInCard){
  return item.review_ready===true
    && decision===item.recommendation?.recommended_decision
    && Boolean(item.recommended_justification_key)
    && !editedInCard
    && (!String(text||'').trim() || item.review?.justification_manually_edited!==true);
}
const violationP3ReviewNoticeBase=requestContextBlock;
requestContextBlock=function(item){
  let html=violationP3ReviewNoticeBase(item);const review=item.review||{};
  const visibleText=review.decision_justification||item.justification_draft||'';
  const show=violationP3DraftNeedsReview(item,review.internal_decision,visibleText);
  if(!item.review_ready){
    html=html.replace(/<select data-review="internal_decision"(?![^>]*disabled)/,
      '<select data-review="internal_decision" disabled title="Не завершено перевірку обов’язкових фактів або строку пояснень"');
  }
  return html.replace('<section class="violation-justification">',`<section class="violation-justification"><p class="request-warning" id="violationP3DraftReviewNotice" ${show?'':'hidden'}>${esc(violationP3DraftReviewNotice)}</p>`);
};
const violationProtocolIndividualBase=requestContextBlock;
requestContextBlock=function(item){
  let html=violationProtocolIndividualBase(item);
  const review=item.review||{},canChoose=item.reason&&['contractBreach','signingRefusal','goodsNonCompliance'].includes(item.reason)&&review.internal_decision==='decline';
  if(!canChoose)return html;
  const selected=review.generated_protocol_metadata?.protocol_type==='decline_individual_review'?'decline_individual_review':'automatic';
  const control=`<label class="wide">Тип протоколу<select id="violationProtocolType"><option value="automatic" ${selected==='automatic'?'selected':''}>Автоматичний за підставою звернення</option><option value="decline_individual_review" ${selected==='decline_individual_review'?'selected':''}>Відмова — індивідуальний розгляд</option></select></label><label id="confirmReviewNotesField" class="request-check wide" ${selected==='decline_individual_review'?'':'hidden'}><input type="checkbox" id="confirmReviewNotes"> Підтверджую використання актуального коментаря УО: «${esc(review.review_notes||'')}»</label>`;
  html=html.replace('<label>№ протоколу<input data-review="protocol_number"',`${control}<label>№ протоколу<input data-review="protocol_number"`);
  const actions=violationDeclensionActions((selected==='decline_individual_review'?item.protocol_readiness_individual:item.protocol_readiness)?.declensions||[]);
  if(actions)html=html.replace(actions,`<div id="violationProtocolDeclensionActions">${actions}</div>`);
  return html;
};
async function generateViolationProtocol(item){
  const button=$('#generateViolationProtocol'),payload=collectViolationReview(),protocolType=$('#violationProtocolType')?.value||'automatic',confirmed=$('#confirmReviewNotes')?.checked===true,confirmedNotes=String(payload.review_notes||''),old=button.textContent;
  const canGenerate=Boolean(protocolType==='decline_individual_review'?item.protocol_readiness_individual?.ready:item.protocol_readiness?.ready);
  button.disabled=true;button.textContent='Формування…';
  try{
    await request(`${API}/violation-reports/${encodeURIComponent(item.id)}/review`,{method:'PATCH',headers:{'Content-Type':'application/json'},body:JSON.stringify(payload)});
    await request(`${API}/violation-reports/${encodeURIComponent(item.id)}/protocol/generate`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({protocol_number:payload.protocol_number||'',protocol_date:payload.protocol_date||'',protocol_type:protocolType==='automatic'?'':protocolType,confirm_review_notes:confirmed,confirmed_review_notes:confirmedNotes})});
    unresolvedDeclensionsByReport.delete(String(item.id));toast('Протокол сформовано · звернення залишається на розгляді');await openViolationReportById(item.id);await loadViolationReports().catch(()=>toast('Протокол сформовано, але реєстр не вдалося оновити','warning'));
  }catch(error){
    toast(error.message,error.code==='declension_unresolved'?'warning':'error');const reasons=$('#violationProtocolReasons');
    if(reasons){reasons.hidden=false;if(error.code==='declension_unresolved'&&Array.isArray(error.unresolved)){unresolvedDeclensionsByReport.set(String(item.id),error.unresolved);reasons.innerHTML=`<strong>Потрібні перевірені відмінкові форми:</strong><ul>${error.unresolved.map((entry,index)=>`<li><span>${esc(entry.subject_label||'Назва')} · ${esc(entry.original)} · ${esc({genitive:'родовий',dative:'давальний',accusative:'знахідний'}[entry.grammatical_case]||entry.grammatical_case)}</span> <button type="button" class="ghost" data-go-declension="${index}">Відкрити модуль відмінювання</button></li>`).join('')}</ul>`;reasons.querySelectorAll('[data-go-declension]').forEach(action=>action.onclick=()=>openDeclensionFromValidation(error.unresolved[Number(action.dataset.goDeclension)],item))}else reasons.textContent=error.message}
  }finally{button.disabled=!canGenerate||Boolean((unresolvedDeclensionsByReport.get(String(item.id))||[]).length)||(protocolType==='decline_individual_review'&&!$('#confirmReviewNotes')?.checked);button.textContent=old}
}
async function completeViolationReview(item){if(!confirm('Завершити розгляд звернення? Статус буде змінено на «Розглянуто». Переконайтеся, що протокол перевірено та необхідні дії в електронній системі закупівель виконано.'))return;try{const payload=collectViolationReview();await request(`${API}/violation-reports/${encodeURIComponent(item.id)}/review/complete`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(payload)});toast('Поточні поля збережено, розгляд звернення завершено');$('#requestDetailsDialog').close();await loadViolationReports();if(activeModule==='workQueue')await loadWorkQueue()}catch(error){toast(error.message)}}
const bindViolationProtocolBase=bindViolationReview;
function violationReviewedDocumentLinks(documents,source,item){
  const rows=(documents||[]).filter(document=>document&&document.url).map(document=>{
    const id=String(document.id||'');
    const title=esc(document.title||document.name||'Документ');
    const review=item.is_read_only?'':`<label class="violation-document-review"><input type="checkbox" data-violation-document-source="${esc(source)}" data-violation-document-id="${esc(id)}" ${document.file_unavailable?'checked':''}> Файл недоступний / не відкривається</label>`;
    const state=document.file_unavailable?'<span class="violation-document-unavailable">Недоступний</span>':'';
    return `<div class="violation-document-row"><span><a href="${esc(document.url)}" target="_blank" rel="noopener">${title}</a> ${state}</span>${review}</div>`;
  });
  return rows.length?rows.join(''):'<p>Документи не надано</p>';
}
function violationReviewedStatements(item){
  const statements=item.defendant_statements||[];
  if(!statements.length)return '<p>Пояснення постачальника не надано</p>';
  return statements.map(statement=>`<article class="request-statement"><div class="request-long-text">${esc(statement.description||statement.title||'Пояснення постачальника').replaceAll('\n','<br>')}</div>${violationReviewedDocumentLinks(statement.documents||[],'supplier',item)}</article>`).join('');
}
const violationDocumentDetailBase=violationDetailHtml;
violationDetailHtml=function(item){
  return violationDocumentDetailBase(item)
    .replace(requestDocumentLinks(item.evidence_documents),violationReviewedDocumentLinks(item.evidence_documents,'customer',item))
    .replace(requestStatements(item),violationReviewedStatements(item));
}
function violationReadOnlyReviewHtml(item){
  const r=item.review||{},c=item.procurement_context||{},rec=item.recommendation||{};
  const yesNo=value=>value==null?'Не перевірено':value?'Так':'Ні',value=v=>esc(String(v??'').trim())||'—';
  const file=r.generated_protocol_filename?`${API}/protocol/files/${encodeURIComponent(r.generated_protocol_filename)}`:'',pdf=file?`${API}/violation-reports/${encodeURIComponent(item.id)}/protocol/pdf`:'',metadata=r.generated_protocol_resolved_metadata||[];
  const facts=[
    ['Код ДК / CPV',c.cpv],['Дата визначення переможцем',displayDateOnly(c.winner_selected_at)],
    ['Граничний строк',displayDateOnly(c.contract_deadline||c.written_refusal_deadline)],
    ['Дата відхилення',displayDateOnly(c.rejection_at)],
    ['Підстава відхилення',c.rejection_reason],
    ['Договір · фактичний стан',c.contract_signed?(c.contract_status||'Укладено'):(c.contract_status||'Не укладено')],
    ['Забезпечення виконання договору',c.contract_guarantee_required?'Так':'Ні'],
    ['Документи забезпечення в Prozorro',yesNo(r.guarantee_documents_visible)]
  ];
  const manual=[
    ['Відповідальна УО',r.assigned_officer_display||r.assigned_officer],['Статус розгляду','Розглянуто'],
    ['Рішення УО',internalDecisionLabels[r.internal_decision]||r.internal_decision],
    ['Потребує додаткової перевірки за п. 50',r.additional_check_required?'Так':'Ні'],
    ['Оцінка пояснень і документів постачальника',r.supplier_explanation_assessment],
    ['Встановлена невідповідність',r.established_discrepancy],
    ['Дата письмової відмови постачальника',displayDateOnly(r.written_refusal_date)],
    ['Вих. № письмової відмови',r.written_refusal_number],['Посилання на письмову відмову',r.written_refusal_url],
    ['Дата рішення замовника',displayDateOnly(r.customer_protocol_decision_date)],
    ['№ рішення замовника',r.customer_protocol_decision_number],['Посилання на рішення замовника',r.customer_protocol_decision_url],
    ['Рішення суду набрало законної сили',yesNo(r.court_decision_final_present)],
    ['Договір укладено',r.actual_contract_signed?'Так':'Ні'],['Дата укладення договору',r.actual_contract_signed?displayDateOnly(r.actual_contract_date):'—'],['№ договору',r.actual_contract_signed?r.actual_contract_number:'—'],
    ['Посилання на договір',r.actual_contract_url],['Коментар УО',r.review_notes],
    ['№ протоколу',r.protocol_number],['Дата протоколу',displayDateOnly(r.protocol_date)],
    ['Завершено',displayDate(r.completed_at)],['Завершила УО',r.completed_by]
  ];
  const grid=rows=>`<div class="request-context-grid">${rows.map(([label,raw])=>`<div><small>${esc(label)}</small><strong>${value(raw)}</strong></div>`).join('')}</div>`;
  const jsonAction=item.sheets_json_available?'<button type="button" class="ghost" data-copy-violation-json>Скопіювати JSON</button>':'';
  const documentActions=file?`<a class="ghost" href="${file}" download>Завантажити DOCX</a><button type="button" class="ghost" data-download-protocol-pdf="${pdf}">Завантажити PDF</button>`:'';
  const actions=documentActions||jsonAction?`<div class="violation-inline-actions">${documentActions}${jsonAction}</div>`:'';
  return `<section class="request-review violation-workbench violation-readonly-review"><h3>ПЕРЕВІРКА УО</h3><h4>Збережений контекст рішення</h4>${grid(facts)}<div class="request-recommendation"><small>Рекомендація системи на момент завершення</small><strong>${value(internalDecisionLabels[rec.recommended_decision]||rec.recommended_decision)}</strong><p>${value(rec.recommendation_reason)}</p></div>${item.scenario_summary?`<div class="violation-scenario-summary"><p>${esc(item.scenario_summary)}</p></div>`:''}<h4>Збережені результати розгляду УО</h4>${grid(manual)}<section class="violation-justification"><h3>Обґрунтування рішення</h3><div class="request-long-text">${value(r.decision_justification).replaceAll('\n','<br>')}</div></section>${actions}${file?resolvedDocumentMetadataHtml(metadata):''}</section>`;
}

async function copyViolationReportJson(item,button){
  const old=button.textContent;button.disabled=true;button.textContent='Формування…';
  try{
    const payload=await request(`${API}/violation-reports/${encodeURIComponent(item.report_id||item.id)}/sheets-json`);
    await copyText(JSON.stringify(payload,null,2),'JSON скопійовано');
  }catch(error){toast(error.message||'Не вдалося сформувати JSON','error')}
  finally{button.disabled=false;button.textContent=old}
}
function violationReviewAccordion(item){
  const r=item.review||{};
  const hasLocal=Boolean(r.assigned_officer_id||r.assigned_officer||r.internal_decision||r.decision_justification||r.protocol_number||r.completed_at||r.review_status&&r.review_status!=='not_reviewed');
  return hasLocal?`<details class="violation-review-accordion"><summary>Деталі розгляду УО</summary>${violationReadOnlyReviewHtml(item)}</details>`:'';
}
const violationReadOnlyReasonBase=violationDetailHtml;
violationDetailHtml=function(item){
  let html=violationReadOnlyReasonBase(item);
  const official=`<section><h3>Рішення Адміністратора</h3><p><strong>${esc(requestLabel(item.decision_resolution,requestStatusLabels))}</strong> · ${esc(displayDate(item.decision_date))}</p><div class="request-long-text">${esc(item.decision_description||'')}</div>${requestDocumentLinks(item.decision_documents)}</section>`;
  const accordion=violationReviewAccordion(item);
  if(item.read_only_reason==='local_completion'){
    html=html.replace('<div class="request-readonly">У Prozorro вже є рішення Адміністратора — картка лише для перегляду.</div>',
      '<div class="request-readonly">Локальний розгляд завершено УО — картка доступна лише для перегляду. Офіційне рішення Prozorro ще не оприлюднено.</div>');
    const localDecision=`<section><h3>Локальне рішення УО</h3><p><strong>${esc(internalDecisionLabels[item.review?.internal_decision]||item.review?.internal_decision||'—')}</strong>${item.review?.completed_at?` · ${esc(displayDate(item.review.completed_at))}`:''}</p></section>`;
    html=html.replace(official,localDecision+accordion);
  }else if(item.read_only_reason==='official_decision'&&accordion){
    html=html.replace(official,official+accordion);
  }
  return html;
};
const violationDetailWithSupplierAction=violationDetailHtml;
violationDetailHtml=function(item){
  const html=violationDetailWithSupplierAction(item),code=String(item.defendant_code||'').trim();
  if(!code)return html;
  const clarity=`<a href="https://clarity-project.info/edr/${encodeURIComponent(code)}" target="_blank" rel="noopener">Clarity</a>`;
  const supplier=html.indexOf('<h3>Постачальник');
  return supplier<0?html:html.slice(0,supplier)+html.slice(supplier).replace(clarity+'</p>',clarity+` <button type="button" class="ghost supplier-context-card-action" data-supplier-code="${esc(code)}">↗ Картка постачальника</button></p>`);
};
$('#requestDetailsBody').addEventListener('click',event=>{
  const action=event.target.closest('.supplier-context-card-action');
  if(action)openSupplierProfile(action.dataset.supplierCode);
});
const violationDetailProductionBase=violationDetailHtml;
violationDetailHtml=function(item){
  let html=violationDetailProductionBase(item);
  if(canReadDeclensions()){
    html=html.replace('<h3>Замовник</h3>',`<div class="violation-party-heading"><h3>Замовник</h3>${violationCardDeclensionButton('customer')}</div>`);
    html=html.replace(/<h3>Постачальник(?: <span class="violation-thresholds">[\s\S]*?<\/span>)?<\/h3>/,heading=>`<div class="violation-party-heading">${heading}${violationCardDeclensionButton('supplier')}</div>`);
  }
  const icon=zakupivliComplaintLink(item);
  return html.replace('<h3>Закупівля · Договір · Звернення</h3>',`<h3 class="violation-platform-heading">Закупівля · Договір · Звернення${icon}</h3>`);
};
async function saveViolationDocumentReview(item,input){
  const source=input.dataset.violationDocumentSource,id=input.dataset.violationDocumentId;
  const requestedValue=input.checked,previousValue=!requestedValue;
  input.disabled=true;
  try{
    await request(`${API}/violation-reports/${encodeURIComponent(item.id)}/documents/${encodeURIComponent(source)}/${encodeURIComponent(id)}`,{method:'PATCH',headers:{'Content-Type':'application/json'},body:JSON.stringify({file_unavailable:requestedValue})});
    const updateDocuments=documents=>(documents||[]).map(document=>String(document.id||'')===String(id)?{...document,file_unavailable:requestedValue}:document);
    if(source==='customer')item.evidence_documents=updateDocuments(item.evidence_documents);
    if(source==='supplier')item.defendant_statements=(item.defendant_statements||[]).map(statement=>({...statement,documents:updateDocuments(statement.documents)}));
    const row=input.closest('.violation-document-row');let state=row?.querySelector('.violation-document-unavailable');
    if(requestedValue&&!state){state=document.createElement('span');state.className='violation-document-unavailable';state.textContent='Недоступний';row?.querySelector('a')?.after(document.createTextNode(' '),state)}
    else if(!requestedValue)state?.remove();
    input.disabled=false;toast('Ознаку документа збережено');
  }catch(error){input.checked=previousValue;input.disabled=false;toast(error.message)}
}
function downloadFilenameFromDisposition(disposition,fallback){
  const encoded=String(disposition||'').match(/filename\*=UTF-8''([^;]+)/i);
  if(encoded){try{return decodeURIComponent(encoded[1].trim())}catch{}}
  const plain=String(disposition||'').match(/filename="?([^";]+)"?/i);
  return plain?.[1]?.trim()||fallback;
}
async function downloadViolationProtocolPdf(button){
  const url=button.dataset.downloadProtocolPdf,old=button.textContent;
  button.disabled=true;button.textContent='Формування PDF…';
  try{
    const headers={},localRole=$('#roleSelect')?.value;
    if(localRole)headers['X-PQM-Local-Role']=localRole;
    const response=await fetch(url,{headers}),contentType=response.headers.get('content-type')||'';
    if(!response.ok||!contentType.toLowerCase().includes('application/pdf')){
      let message=`Не вдалося сформувати PDF (HTTP ${response.status})`;
      try{const body=await response.json();message=body.error||body.message||message}catch{}
      throw new Error(message);
    }
    const blob=await response.blob();
    if(!blob.size)throw new Error('Сервер повернув порожній PDF');
    const filename=downloadFilenameFromDisposition(
      response.headers.get('content-disposition'),'protocol.pdf');
    const objectUrl=URL.createObjectURL(blob),download=document.createElement('a');
    download.href=objectUrl;download.download=filename;document.body.append(download);
    download.click();download.remove();setTimeout(()=>URL.revokeObjectURL(objectUrl),0);
    toast('PDF завантажено','success');
  }catch(error){toast(error.message||'Не вдалося завантажити PDF','error')}
  finally{button.disabled=false;button.textContent=old}
}
function compactViolationProtocolControls(){
  const controls=$('#requestDetailsBody .violation-protocol-controls');
  if(!controls||controls.querySelector(':scope > .violation-protocol-main'))return;
  const fields=controls.querySelector(':scope > .request-form-grid');
  const confirmation=fields?.querySelector('#confirmReviewNotesField');
  const regenerate=controls.querySelector('#generateViolationProtocol');
  const docx=controls.querySelector('a[download]');
  const pdf=controls.querySelector('[data-download-protocol-pdf]');
  const complete=controls.querySelector('#completeViolationReview');
  if(!fields||!regenerate||!complete)return;
  const main=document.createElement('div'),actions=document.createElement('div');
  main.className='violation-protocol-main';actions.className='violation-protocol-actions';
  if(confirmation){
    const raw=confirmation.textContent.trim(),match=raw.match(/^Підтверджую використання актуального коментаря УО:\s*«([\s\S]*)»$/);
    const comment=match?match[1]:'';
    const checkbox=confirmation.querySelector('#confirmReviewNotes');
    confirmation.className='violation-review-notes-confirmation';
    const preview=document.createElement('p');preview.className='violation-review-notes-preview';preview.id='confirmReviewNotesText';preview.textContent=`«${comment}»`;
    const label=document.createElement('label');label.className='request-check';label.append(checkbox,document.createTextNode(' Підтверджую актуальність коментаря УО'));
    confirmation.replaceChildren(preview,label);confirmation.remove();
  }
  regenerate.classList.remove('primary');regenerate.classList.add('ghost');
  complete.classList.remove('ghost');complete.classList.add('primary');
  for(const action of [regenerate,docx,pdf,complete])if(action)actions.append(action);
  main.append(fields,actions);
  controls.insertBefore(main,controls.querySelector('.document-resolved-metadata'));
  if(confirmation)controls.insertBefore(confirmation,main.nextSibling);
  controls.querySelectorAll(':scope > .violation-inline-actions').forEach(row=>{
    if(!row.children.length)row.remove();
  });
}
function installViolationCompactReview(item){
  const review=$('#requestDetailsBody .request-review');if(!review||item.is_read_only)return;
  const header=review.querySelector('.violation-review-header');
  const optional=(key,labelText,target)=>{const area=review.querySelector(`[data-review="${key}"]`);if(!area)return;const field=area.closest('label');if(!field||field.dataset.optionalReady)return;field.dataset.optionalReady='1';field.classList.add('violation-optional-field');const toggle=document.createElement('label');toggle.className='request-check violation-optional-toggle';toggle.innerHTML=`<input type="checkbox"> ${labelText}`;const input=toggle.querySelector('input');input.checked=Boolean(String(area.value||'').trim());const sync=()=>{field.hidden=!input.checked};input.onchange=sync;sync();(target||field.parentElement).insertBefore(toggle,target?null:field);};
  optional('established_discrepancy','Є встановлена невідповідність',header);
  optional('review_notes','Додати коментар УО');
  const recommendation=review.querySelector('.request-recommendation'),scenario=review.querySelector('.violation-scenario-summary');
  if(recommendation&&scenario&&!recommendation.parentElement.classList.contains('violation-guidance-grid')){const grid=document.createElement('div');grid.className='violation-guidance-grid';recommendation.before(grid);grid.append(recommendation,scenario)}
}
bindViolationReview=function(item){
  activeDeclensionRequest=item;
  bindViolationProtocolBase(item);
  compactViolationProtocolControls();
  installViolationCompactReview(item);
  const protocolType=$('#violationProtocolType'),confirmField=$('#confirmReviewNotesField'),generateButton=$('#generateViolationProtocol');
  const syncProtocolType=()=>{
    if(!protocolType)return;
    const individual=protocolType.value==='decline_individual_review',confirmNotes=$('#confirmReviewNotes'),gate=individual?item.protocol_readiness_individual:item.protocol_readiness,reasons=$('#violationProtocolReasons'),declensions=$('#violationProtocolDeclensionActions');
    if(confirmField)confirmField.hidden=!individual;
    updateViolationCardDeclensionStatus(item);
    if(reasons){const list=gate?.reasons||[];reasons.hidden=!list.length;reasons.textContent=list.join(' · ')}
    if(declensions){declensions.innerHTML=violationDeclensionActions(gate?.declensions||[]);declensions.querySelectorAll('[data-check-declension-side]').forEach(button=>button.onclick=()=>openViolationDeclensionSide(button.dataset.checkDeclensionSide,item))}
    if(generateButton)generateButton.disabled=!gate?.ready||Boolean((gate?.unresolved||[]).length)||(individual&&!confirmNotes?.checked);
  };
  if(protocolType)protocolType.onchange=syncProtocolType;
  const confirmNotes=$('#confirmReviewNotes');if(confirmNotes)confirmNotes.onchange=syncProtocolType;
  const notesInput=$('#requestDetailsBody [data-review="review_notes"]');
  if(notesInput&&!notesInput.dataset.confirmationBound){notesInput.dataset.confirmationBound='1';notesInput.addEventListener('input',()=>{const preview=$('#confirmReviewNotesText');if(preview)preview.textContent=`«${notesInput.value}»`;const checkbox=$('#confirmReviewNotes');if(checkbox)checkbox.checked=false;syncProtocolType()})}
  syncProtocolType();
  const decision=$('#requestDetailsBody [data-review="internal_decision"]');
  const justification=$('#requestDetailsBody [data-review="decision_justification"]');
  const draftNotice=$('#violationP3DraftReviewNotice');
  if(decision&&justification&&draftNotice){
    let editedInCard=false;
    const refreshDraftNotice=()=>{draftNotice.hidden=!violationP3DraftNeedsReview(item,decision.value,justification.value)};
    decision.addEventListener('change',async()=>{
      refreshDraftNotice();
      if(violationShouldAutoGenerateOnDecision(item,decision.value,justification.value,editedInCard)){
        await regenerateViolationJustification(item);
      }
    });
    justification.addEventListener('input',()=>{editedInCard=true;refreshDraftNotice()});
    refreshDraftNotice();
  }
  const button=$('#generateViolationProtocol');if(button)button.onclick=()=>generateViolationProtocol(item);
  const complete=$('#completeViolationReview');if(complete)complete.onclick=()=>completeViolationReview(item);
  bindResolvedDocumentMetadata($('#requestDetailsBody'));
  $$('#requestDetailsBody [data-download-protocol-pdf]').forEach(button=>button.onclick=()=>downloadViolationProtocolPdf(button));
  $$('#requestDetailsBody [data-copy-violation-json]').forEach(button=>button.onclick=()=>copyViolationReportJson(item,button));
  $$('#requestDetailsBody [data-check-declension-side]').forEach(button=>button.onclick=()=>openViolationDeclensionSide(button.dataset.checkDeclensionSide,item));
  $('#violationProtocolReasons')?.querySelectorAll('[data-go-declension]').forEach(action=>action.onclick=()=>{const entries=unresolvedDeclensionsByReport.get(String(item.id))||[];openDeclensionFromValidation(entries[Number(action.dataset.goDeclension)],item)});
  $$('#requestDetailsBody [data-violation-document-id]').forEach(input=>{input.onchange=()=>saveViolationDocumentReview(item,input)});
}

async function loadAdminUsers(officers=authorizedOfficerItems){
  const select=$('#adminUserOfficer'),body=$('#adminUsersBody');
  select.innerHTML='<option value="">Оберіть УО</option>'+officers.filter(x=>x.active).map(x=>`<option value="${x.id}">${esc(x.full_name)}</option>`).join('');
  try{const data=await request(`${API}/admin/users`);body.innerHTML=(data.items||[]).map(x=>`<tr data-username="${esc(x.username)}" data-active="${x.active?'1':'0'}"><td><div class="user-identity">${x.has_avatar?`<img class="user-avatar" src="${userAvatarUrl(x.username)}" alt="">`:`<span class="user-avatar user-avatar-placeholder">${esc(x.username.slice(0,1).toLocaleUpperCase())}</span>`}<strong>${esc(x.username)}</strong></div></td><td>${esc(x.officer_name||'—')}</td><td>${x.role==='officer'?'УО':x.role==='admin'?'Адміністратор':'Глядач'}</td><td><span class="account-status ${x.active?'active':'suspended'}">${x.active?'Активний':'Призупинений'}</span></td><td><button class="ghost admin-user-avatar" type="button">${x.has_avatar?'Замінити':'Завантажити'}</button>${x.has_avatar?' <button class="ghost admin-user-avatar-delete" type="button">Видалити</button>':''}</td><td>${x.managed?`<button class="ghost admin-user-toggle" type="button">${x.active?'Призупинити':'Відновити'}</button> <button class="ghost admin-user-password" type="button">Змінити пароль</button> <button class="danger admin-user-delete" type="button">Видалити акаунт</button>`:'Керується через Render'}</td></tr>`).join('')||'<tr><td colspan="6">Користувачів ще немає.</td></tr>';
    $$('.admin-user-toggle').forEach(button=>button.onclick=async()=>{const row=button.closest('tr'),active=row.dataset.active!=='1',action=active?'відновити':'призупинити';if(!confirm(`Справді ${action} акаунт ${row.dataset.username}?`))return;try{await request(`${API}/admin/users/${encodeURIComponent(row.dataset.username)}`,{method:'PATCH',headers:{'Content-Type':'application/json'},body:JSON.stringify({active})});toast(active?'Акаунт відновлено':'Акаунт призупинено, його сесії завершено');await loadAdminUsers(officers)}catch(error){toast(error.message)}});
    $$('.admin-user-delete').forEach(button=>button.onclick=async()=>{const row=button.closest('tr'),username=row.dataset.username;if(!confirm(`Назавжди видалити акаунт ${username}? Налаштування та аватар також буде видалено.`))return;try{await request(`${API}/admin/users/${encodeURIComponent(username)}`,{method:'DELETE'});toast('Акаунт видалено');await loadAdminUsers(officers)}catch(error){toast(error.message)}});
    $$('.admin-user-password').forEach(button=>button.onclick=async()=>{const row=button.closest('tr'),password=prompt(`Новий пароль для ${row.dataset.username} (мінімум 10 символів)`);if(!password)return;try{await request(`${API}/admin/users/${encodeURIComponent(row.dataset.username)}`,{method:'PATCH',headers:{'Content-Type':'application/json'},body:JSON.stringify({password})});toast('Пароль змінено, активні сесії завершено')}catch(error){toast(error.message)}});
    $$('.admin-user-avatar').forEach(button=>button.onclick=()=>{const input=$('#adminUserAvatarFile');input.dataset.username=button.closest('tr').dataset.username;input.click()});
    $$('.admin-user-avatar-delete').forEach(button=>button.onclick=async()=>{const username=button.closest('tr').dataset.username;if(!confirm(`Видалити аватар ${username}?`))return;try{await request(`${API}/admin/users/${encodeURIComponent(username)}/avatar`,{method:'DELETE'});if(username===currentAuthUser)showCurrentUserAvatar(username,false);toast('Аватар видалено');await loadAdminUsers(officers)}catch(error){toast(error.message)}});
  }catch(error){body.innerHTML=`<tr><td colspan="6">${esc(error.message)}</td></tr>`}
}
const loadAdminUsersWithoutPresence=loadAdminUsers;
loadAdminUsers=async function(officers=authorizedOfficerItems){
  await loadAdminUsersWithoutPresence(officers);
  try{
    const data=await request(`${API}/admin/users`);
    (data.items||[]).forEach(user=>{
      const row=[...$$('#adminUsersBody tr')].find(item=>item.dataset.username===user.username);
      if(!row)return;
      const cell=row.insertCell(4),lastSeen=user.last_seen_at?displayDate(user.last_seen_at):'';
      cell.className='admin-online-cell';
      cell.innerHTML=`<span class="online-presence ${user.online?'online':'offline'}">${user.online?'Онлайн':'Офлайн'}</span>${user.online?'':`<small>${esc(lastSeen||'Ще не входив')}</small>`}`;
      cell.title=user.online?'Є активність у PQM протягом останніх 90 секунд':lastSeen?`Остання активність: ${lastSeen}`:'Користувач ще не входив після створення акаунта';
    });
  }catch{}
};
$('#adminUserAvatarFile').onchange=async event=>{const file=event.target.files[0],username=event.target.dataset.username;event.target.value='';if(!file||!username)return;if(file.size>2*1024*1024)return toast('Максимальний розмір аватара — 2 МБ');if(!['image/png','image/jpeg','image/webp'].includes(file.type))return toast('Дозволено лише PNG, JPEG або WebP');try{const bytes=new Uint8Array(await file.arrayBuffer());let binary='';for(let i=0;i<bytes.length;i+=32768)binary+=String.fromCharCode(...bytes.subarray(i,i+32768));await request(`${API}/admin/users/${encodeURIComponent(username)}/avatar`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({content_type:file.type,content:btoa(binary)})});if(username===currentAuthUser)showCurrentUserAvatar(username);toast('Аватар збережено');await loadAdminUsers()}catch(error){toast(error.message)}};
function syncAdminUserOfficerField(){const role=$('#adminUserRole').value,isOfficer=role==='officer',canLink=isOfficer||role==='admin',field=$('#adminUserOfficerField'),select=$('#adminUserOfficer');field.hidden=!canLink;select.required=isOfficer;if(!canLink)select.value=''}
$('#adminUserRole').onchange=syncAdminUserOfficerField;
syncAdminUserOfficerField();
$('#adminUserForm').onsubmit=async event=>{event.preventDefault();const password=$('#adminUserPassword').value,accountRole=$('#adminUserRole').value,officerId=['officer','admin'].includes(accountRole)&&$('#adminUserOfficer').value?Number($('#adminUserOfficer').value):null;if(password!==$('#adminUserPasswordConfirm').value)return toast('Паролі не збігаються');if(accountRole==='officer'&&!officerId)return toast('Оберіть конкретну УО');try{await request(`${API}/admin/users`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({username:$('#adminUserLogin').value.trim(),password,role:accountRole,officer_id:officerId})});event.target.reset();syncAdminUserOfficerField();toast('Користувача створено');await loadAdminUsers()}catch(error){toast(error.message)}};

const currentLoadAdminOfficers=loadAdminOfficers;
loadAdminOfficers=async function(){await currentLoadAdminOfficers();if(role()==='admin')await loadAdminUsers()};

const shareSelectionObserver=new MutationObserver(()=>{$('#shareApplicationBtn').disabled=selected.size!==1});shareSelectionObserver.observe($('#selectedCount'),{childList:true,characterData:true,subtree:true});
