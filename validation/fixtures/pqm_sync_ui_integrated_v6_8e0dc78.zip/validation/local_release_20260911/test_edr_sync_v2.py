import json
import sqlite3
import unittest
from datetime import date, timedelta

import edr_sync_v2 as sync


def database():
    con = sqlite3.connect(":memory:")
    con.row_factory = sqlite3.Row
    con.create_function("DIGITS", 1, sync.normalize_code, deterministic=True)
    con.executescript("""
      CREATE TABLE submissions(id TEXT PRIMARY KEY,supplier_code TEXT,supplier_name TEXT,date_published TEXT);
      CREATE TABLE application_fields(submission_id TEXT PRIMARY KEY,protocol_decision TEXT,
        protocol_date TEXT,protocol_officer TEXT,review_officer TEXT);
      CREATE TABLE supplier_edr_profiles(supplier_code TEXT PRIMARY KEY,full_name TEXT DEFAULT '',
        short_name TEXT DEFAULT '',manager_name TEXT DEFAULT '',edr_status TEXT DEFAULT '',
        edr_checked_at TEXT DEFAULT '',termination_decision_details TEXT DEFAULT '',
        edr_officer TEXT DEFAULT '',edr_notes TEXT DEFAULT '',source_sheet TEXT DEFAULT '',
        source_row INTEGER DEFAULT 0,synced_at TEXT NOT NULL);
      CREATE TABLE supplier_managers(id INTEGER PRIMARY KEY,supplier_code TEXT,manager_name TEXT,
        normalized_name TEXT DEFAULT '',valid_from TEXT,valid_to TEXT,is_current INTEGER,
        source TEXT DEFAULT '',updated_at TEXT,created_at TEXT);
      CREATE TABLE supplier_edr_sync_log(id INTEGER PRIMARY KEY,started_at TEXT,status TEXT,
        finished_at TEXT,processed INTEGER DEFAULT 0,inserted INTEGER DEFAULT 0,updated INTEGER DEFAULT 0,error TEXT DEFAULT '');
      CREATE TABLE registry_contracts(supplier_code TEXT,status TEXT,framework_id TEXT);
      CREATE TABLE frameworks(id TEXT PRIMARY KEY,status TEXT,raw_json TEXT DEFAULT '{}');
      CREATE TABLE qualifications(id TEXT,status TEXT,submission_id TEXT);
    """)
    sync.migrate(con)
    return con


def row(code="12345678", status="Зареєстровано", checked="15.09.2026", officer="УО",
        manager="НОВИЙ КЕРІВНИК", *, date_only=False):
    # New synthetic observations carry a real Kyiv wall-clock timestamp.
    # Legacy date-only inputs must opt in explicitly via date_only=True.
    if checked and not date_only and isinstance(checked, str):
        if len(checked) == 10 and checked[2] == ".":
            checked = checked + " 12:00:00"
        elif len(checked) == 10 and checked[4] == "-":
            checked = checked + "T12:00:00"
    values = ["", code, "Заявка", manager, status, "Активний", "", "", checked,
              "", "", officer, "", "ПОВНА НАЗВА", "СКОРОЧЕНА НАЗВА"]
    return values


def snapshot(*rows):
    values = [list(sync.HEADERS), *rows]
    return sync.source_snapshot({"ФОП": values, "ЮО": [list(sync.HEADERS)]})


class EdrSyncV2Tests(unittest.TestCase):
    def apply_observation(self, con, source):
        return sync.apply(con, source, source['source_fingerprint'], confirmed=True,
                          actor='test', synced_at='2026-09-16T12:00:00')

    def test_google_text_supplier_code_preserves_leading_zero(self):
        source = snapshot(row(code="00123456"))
        self.assertEqual(source["rows"][0]["Код ЄДРПОУ"], "00123456")
        self.assertEqual(source["rows"][0]["supplier_code"], "00123456")
        self.assertEqual(sync.source_item(source["rows"][0])["supplier_code"], "00123456")

    def test_new_google_code_with_decided_application_creates_canonical_names(self):
        con = database()
        code = '46130719'
        con.execute("INSERT INTO submissions VALUES(?,?,?,?)", ('application-1', code, 'Заявка', '2026-09-01'))
        con.execute("INSERT INTO application_fields(submission_id,protocol_decision,protocol_date,protocol_officer) VALUES(?,?,?,?)",
                    ('application-1', 'admit', '2026-09-02', 'УО'))
        con.execute("INSERT INTO qualifications VALUES ('q1','active','application-1')")
        google_row = row(code=code, checked='15.09.2026')
        source = sync.source_snapshot({'ФОП': [list(sync.HEADERS)],
                                       'ЮО': [list(sync.HEADERS), google_row]})
        plan = sync.build_preview(con, source)
        item = plan['items'][0]
        # Matched means present in PQM, not previously present in the Google snapshot.
        self.assertTrue(item['matched'])
        self.assertFalse(item['existing_profile'])
        self.assertTrue(item['apply_allowed'])
        self.assertEqual(plan['summary']['conflicts'], 0)
        result = self.apply_observation(con, source)
        profile = con.execute('SELECT full_name,short_name,source_sheet FROM supplier_edr_profiles WHERE supplier_code=?',
                              (code,)).fetchone()
        self.assertEqual(result['inserted'], 1)
        self.assertEqual(tuple(profile), ('ПОВНА НАЗВА', 'СКОРОЧЕНА НАЗВА', 'ЮО'))

    def test_new_google_code_without_decided_application_stays_ineligible(self):
        con = database()
        source = snapshot(row(code='46130719'))
        plan = sync.build_preview(con, source)
        self.assertFalse(plan['items'][0]['apply_allowed'])
        result = self.apply_observation(con, source)
        self.assertEqual(result['skipped_ineligible_new'], 1)
        self.assertIsNone(con.execute('SELECT 1 FROM supplier_edr_profiles WHERE supplier_code=?',
                                      ('46130719',)).fetchone())

    def test_google_status_is_canonical_before_profile_write(self):
        for incoming in ('✅ Зареєстровано', 'Зареєстровано'):
            with self.subTest(incoming=incoming):
                con = database()
                con.execute("INSERT INTO submissions VALUES(?,?,?,?)", ('s1', '46130719', 'Заявка', '2026-09-01'))
                con.execute("INSERT INTO application_fields(submission_id,protocol_decision,protocol_date,protocol_officer) VALUES(?,?,?,?)",
                            ('s1', 'admit', '2026-09-02', 'УО'))
                con.execute("INSERT INTO qualifications VALUES ('q1','active','s1')")
                values = row(code='46130719', status=incoming)
                source = snapshot(values)
                self.assertEqual(source['rows'][0]['Статус в реєстрі (ЄДР)'], incoming)
                self.assertEqual(sync.build_preview(con, source)['items'][0]['incoming']['edr_status'],
                                 'Зареєстровано')
                self.apply_observation(con, source)
                self.assertEqual(con.execute('SELECT edr_status FROM supplier_edr_profiles WHERE supplier_code=?',
                                             ('46130719',)).fetchone()[0], 'Зареєстровано')
        for presented, canonical in sync.EDR_PRESENTATION_PREFIXES.items():
            self.assertEqual(sync.canonical_edr_status(presented), canonical)
            self.assertEqual(sync.canonical_edr_status(presented.replace(' ', '', 1)), canonical)
        self.assertEqual(len('⚪️ Неактуально'), 14)
        self.assertEqual(len('⚪️ Немає інформації'), 19)
        with self.assertRaisesRegex(ValueError, 'presentation prefix'):
            sync.canonical_edr_status('🟠 Невідомий статус')

    def test_unrelated_row_move_does_not_migrate_legacy_status(self):
        con = database()
        con.execute("INSERT INTO supplier_edr_profiles(supplier_code,edr_status,source_sheet,source_row,synced_at) VALUES(?,?,?,?,?)",
                    ('12345678', '✅ Зареєстровано', 'ФОП', 12, 'old'))
        values = row(checked='')
        values[3] = values[4] = values[11] = ''
        values[13] = values[14] = ''
        source = snapshot(values)
        source['rows'][0]['source_row'] = 99
        self.apply_observation(con, source)
        profile = con.execute('SELECT edr_status,source_row FROM supplier_edr_profiles WHERE supplier_code=?',
                              ('12345678',)).fetchone()
        self.assertEqual(tuple(profile), ('✅ Зареєстровано', 12))

    def test_google_status_is_canonical_on_existing_profile_update(self):
        con = database()
        con.execute("INSERT INTO supplier_edr_profiles(supplier_code,edr_status,edr_checked_at,synced_at) VALUES(?,?,?,?)",
                    ('12345678', 'Припинено', '2026-09-14', 'old'))
        source = snapshot(row(status='✅ Зареєстровано'))
        self.apply_observation(con, source)
        self.assertEqual(con.execute('SELECT edr_status FROM supplier_edr_profiles WHERE supplier_code=?',
                                     ('12345678',)).fetchone()[0], 'Зареєстровано')

    def test_equivalent_google_status_does_not_bulk_normalize_legacy_profiles(self):
        con = database()
        con.execute("INSERT INTO supplier_edr_profiles(supplier_code,edr_status,edr_checked_at,synced_at) VALUES(?,?,?,?)",
                    ('12345678', '✅Зареєстровано', '2026-09-14', 'old'))
        source = snapshot(row(status='Зареєстровано'))
        preview = sync.build_preview(con, source)
        self.assertEqual(preview['summary']['edr_status_changes'], 0)
        self.assertNotIn('edr_status', preview['items'][0]['changed_fields'])
        self.apply_observation(con, source)
        self.assertEqual(con.execute('SELECT edr_status FROM supplier_edr_profiles WHERE supplier_code=?',
                                     ('12345678',)).fetchone()[0], '✅Зареєстровано')

    def test_verification_row_move_preserves_event_identity_and_provenance(self):
        con = database()
        con.execute("INSERT INTO supplier_edr_profiles(supplier_code,synced_at) VALUES('12345678','old')")
        source = snapshot(row())
        source['rows'][0]['source_row'] = 100
        self.assertEqual(self.apply_observation(con, source)['verification_events'], 1)
        source['rows'][0]['source_row'] = 500
        preview = sync.build_preview(con, source)
        self.assertEqual(preview['summary']['verification_event_changes'], 0)
        self.assertEqual(self.apply_observation(con, source)['verification_events'], 0)
        events = con.execute('SELECT source_row,snapshot_json FROM supplier_edr_verification_events').fetchall()
        self.assertEqual(len(events), 1)
        self.assertEqual(events[0]['source_row'], 100)
        self.assertIn('"source_row": 100', events[0]['snapshot_json'])
        self.assertEqual(con.execute('SELECT source_row FROM supplier_edr_profiles').fetchone()[0], 100)

    def test_same_timestamp_status_change_conflicts_until_a_newer_check(self):
        con = database()
        con.execute("INSERT INTO supplier_edr_profiles(supplier_code,synced_at) VALUES('12345678','old')")
        self.apply_observation(con, snapshot(row()))
        new_date = snapshot(row(checked='16.09.2026'))
        self.assertEqual(self.apply_observation(con, new_date)['verification_events'], 1)
        new_business = snapshot(row(checked='16.09.2026', status='Припинено'))
        before = con.total_changes
        same_timestamp_preview = sync.build_preview(con, new_business)
        self.assertEqual(same_timestamp_preview['conflicts'][0]['reasons'], ['same_timestamp_verification_conflict'])
        with self.assertRaises(ValueError):
            self.apply_observation(con, new_business)
        self.assertEqual(con.total_changes, before)
        self.assertEqual(con.execute('SELECT COUNT(*) FROM supplier_edr_verification_events').fetchone()[0], 2)
        self.assertEqual(con.execute("SELECT edr_status FROM supplier_edr_profiles WHERE supplier_code='12345678'").fetchone()[0],
                         'Зареєстровано')
        newer_business = snapshot(row(checked='16.09.2026 12:00:01', status='Припинено'))
        self.assertEqual(self.apply_observation(con, newer_business)['verification_events'], 1)
        self.assertEqual(con.execute('SELECT COUNT(*) FROM supplier_edr_verification_events').fetchone()[0], 3)

    def test_empty_ledger_bootstraps_once_and_duplicate_import_is_idempotent(self):
        con = database()
        for code in ('12345678', '87654321'):
            con.execute('INSERT INTO supplier_edr_profiles(supplier_code,synced_at) VALUES(?,?)', (code, 'old'))
        source = snapshot(row(), row(code='87654321'))
        self.assertEqual(sync.build_preview(con, source)['summary']['verification_event_changes'], 2)
        self.assertEqual(self.apply_observation(con, source)['verification_events'], 2)
        self.assertEqual(self.apply_observation(con, source)['verification_events'], 0)
        self.assertEqual(sync.build_preview(con, source)['summary']['verification_event_changes'], 0)
        self.assertEqual(con.execute('SELECT COUNT(*) FROM supplier_edr_verification_events').fetchone()[0], 2)

    def test_blank_source_profile_preservation_does_not_change_event_hash(self):
        con = database()
        con.execute("INSERT INTO supplier_edr_profiles(supplier_code,full_name,edr_checked_at,synced_at) VALUES('12345678','KNOWN FULL NAME','2026-09-14','old')")
        values = row()
        values[13] = ''
        source = snapshot(values)
        self.assertEqual(self.apply_observation(con, source)['verification_events'], 1)
        self.assertEqual(self.apply_observation(con, source)['verification_events'], 0)
        self.assertEqual(con.execute('SELECT full_name FROM supplier_edr_profiles').fetchone()[0], 'KNOWN FULL NAME')
        incoming = sync.source_item(source['rows'][0])
        moved = {**incoming, 'source_row': 500, 'source_sheet': 'ЮО'}
        self.assertEqual(sync.row_snapshot_hash(incoming), sync.row_snapshot_hash(moved))

    def test_active_registry_evidence_and_newer_profile_form_canonical_projection(self):
        con = database()
        con.execute("INSERT INTO frameworks(id,status,raw_json) VALUES('f1','active','{}')")
        con.execute("INSERT INTO registry_contracts VALUES('0013500191','active','f1')")
        con.execute("INSERT INTO submissions VALUES('s1','0013500191','Історична назва','2025-01-21')")
        con.execute("INSERT INTO application_fields(submission_id,protocol_decision,protocol_date,protocol_officer) VALUES('s1','admit','22.01.2025','ДМИТРО САВВА')")
        con.execute("""INSERT INTO supplier_edr_profiles
          (supplier_code,edr_status,edr_checked_at,edr_officer,source_sheet,source_row,synced_at)
          VALUES('0013500191','Зареєстровано','17.08.2026','Олена ЄРЬОМІНА','ФОП',2480,'2026-09-12')""")
        state = sync.canonical_supplier_edr_states(
            con, {'0013500191'}, today=date(2026, 9, 16))['0013500191']
        self.assertEqual(state['prozorro_status'], 'Активний')
        self.assertEqual(state['verification_date'], '2026-08-17T00:00:00.000+03:00')
        self.assertEqual(state['verification_officer'], 'Олена ЄРЬОМІНА')
        self.assertEqual(state['verification_event']['event_type'], 'google_clarity_profile')
        self.assertEqual(state['bucket'], 'gt30')

    def test_missing_current_manager_is_a_distinct_business_outcome(self):
        result = sync.classify_manager_identity("", "ЗАЙЧУК СЕРГІЙ ВАЛЕНТИНОВИЧ")
        self.assertEqual(result["kind"], "missing_current_manager")

    def test_missing_current_manager_with_conflicting_evidence_is_ambiguous(self):
        result = sync.classify_manager_identity("", "ЗАЙЧУК СЕРГІЙ ВАЛЕНТИНОВИЧ",
                                                ["ПЕТРЕНКО НАТАЛІЯ МИКОЛАЇВНА"])
        self.assertEqual(result["kind"], "ambiguous_missing_current_manager")

    def test_abbreviated_to_confirmed_full_name_is_representation_enrichment(self):
        result = sync.classify_manager_identity(
            "ТКАЧЕНКО Н.М.", "ТКАЧЕНКО НАТАЛІЯ МИКОЛАЇВНА")
        self.assertEqual(result["kind"], "representation_enrichment")

    def test_same_initials_are_not_merged_when_full_identity_conflicts(self):
        result = sync.classify_manager_identity(
            "ТКАЧЕНКО Н.М.", "ТКАЧЕНКО НАТАЛІЯ МИКОЛАЇВНА",
            ["ТКАЧЕНКО НІНА МИХАЙЛІВНА"])
        self.assertEqual(result["kind"], "real_identity_change")
        self.assertEqual(result["conflicting_evidence"], ["ТКАЧЕНКО НІНА МИХАЙЛІВНА"])

    def test_different_surname_and_different_full_name_are_real_changes(self):
        self.assertEqual(sync.classify_manager_identity(
            "ТКАЧЕНКО Н.М.", "ПЕТРЕНКО НАТАЛІЯ МИКОЛАЇВНА")["kind"], "real_identity_change")
        self.assertEqual(sync.classify_manager_identity(
            "ТКАЧЕНКО НАТАЛІЯ МИКОЛАЇВНА", "ТКАЧЕНКО НІНА МИХАЙЛІВНА")["kind"], "real_identity_change")

    def test_formatting_only_manager_difference_is_not_a_business_change(self):
        self.assertEqual(sync.classify_manager_identity(
            "  Ткаченко   Н. М. ", "ткаченко н.м.")["kind"], "same")

    def test_preview_splits_identity_changes_from_representation_enrichments(self):
        con = database()
        con.execute("""INSERT INTO supplier_edr_profiles
          (supplier_code,manager_name,edr_checked_at,synced_at) VALUES ('12345678','ТКАЧЕНКО Н.М.','2026-09-14','old')""")
        con.execute("""INSERT INTO supplier_managers
          (supplier_code,manager_name,is_current,updated_at,created_at)
          VALUES ('12345678','ТКАЧЕНКО Н.М.',1,'old','old')""")
        preview = sync.build_preview(con, snapshot(row(
            manager="ТКАЧЕНКО НАТАЛІЯ МИКОЛАЇВНА")))
        self.assertEqual(preview["summary"]["manager_identity_changes"], 0)
        self.assertEqual(preview["summary"]["manager_representation_enrichments"], 1)
        self.assertEqual(preview["items"][0]["manager_change_kind"], "representation_enrichment")

    def test_preview_uses_supplier_scoped_full_name_as_conflicting_evidence(self):
        con = database()
        con.execute("""INSERT INTO supplier_edr_profiles
          (supplier_code,manager_name,synced_at) VALUES ('12345678','ТКАЧЕНКО Н.М.','old')""")
        con.execute("INSERT INTO submissions VALUES ('s1','12345678','OLD','2026-09-01')")
        con.execute("""ALTER TABLE application_fields ADD COLUMN manager_name TEXT DEFAULT ''""")
        con.execute("""INSERT INTO application_fields
          (submission_id,protocol_decision,manager_name) VALUES ('s1','admit','ТКАЧЕНКО НІНА МИХАЙЛІВНА')""")
        preview = sync.build_preview(con, snapshot(row(
            manager="ТКАЧЕНКО НАТАЛІЯ МИКОЛАЇВНА")))
        self.assertEqual(preview["summary"]["manager_identity_changes"], 1)
        self.assertEqual(preview["summary"]["manager_representation_enrichments"], 0)
        self.assertEqual(preview["items"][0]["manager_change_kind"], "real_identity_change")

    def test_enrichment_apply_does_not_call_change_or_nazk_refresh(self):
        con = database()
        con.execute("""INSERT INTO supplier_edr_profiles
          (supplier_code,manager_name,edr_checked_at,synced_at) VALUES ('12345678','ТКАЧЕНКО Н.М.','2026-09-14','old')""")
        con.execute("""INSERT INTO supplier_managers
          (supplier_code,manager_name,is_current,updated_at,created_at)
          VALUES ('12345678','ТКАЧЕНКО Н.М.',1,'old','old')""")
        calls = {"change": 0, "enrich": 0, "nazk": 0}
        source = snapshot(row(manager="ТКАЧЕНКО НАТАЛІЯ МИКОЛАЇВНА"))
        result = sync.apply(con, source, source["source_fingerprint"], confirmed=True,
          actor="admin", synced_at="2026-09-15T18:00:00",
          sync_manager=lambda *args: calls.__setitem__("change", calls["change"] + 1) or {"changed": True},
          enrich_manager=lambda *args: calls.__setitem__("enrich", calls["enrich"] + 1) or {"enriched": True},
          refresh_manager_controls=lambda *args: calls.__setitem__("nazk", calls["nazk"] + 1))
        self.assertEqual(calls, {"change": 0, "enrich": 1, "nazk": 0})
        self.assertEqual(result["manager_identity_changes"], 0)
        self.assertEqual(result["manager_representation_enrichments"], 1)

    def test_missing_manager_apply_creates_one_current_row_without_nazk_refresh(self):
        import server
        con = database()
        con.execute("INSERT INTO supplier_edr_profiles(supplier_code,synced_at) VALUES ('12345678','old')")
        source = snapshot(row(manager="ЗАЙЧУК СЕРГІЙ ВАЛЕНТИНОВИЧ"))
        refreshes = []
        first = sync.apply(con, source, source["source_fingerprint"], confirmed=True,
          actor="admin", synced_at="2026-09-15T18:00:00",
          sync_manager=server.sync_current_supplier_manager,
          enrich_manager=server.enrich_current_supplier_manager,
          establish_manager=server.establish_current_supplier_manager,
          refresh_manager_controls=lambda *args: refreshes.append(args))
        rows = con.execute("SELECT * FROM supplier_managers").fetchall()
        self.assertEqual(first["manager_identity_changes"], 0)
        self.assertEqual(first["newly_established_managers"], 1)
        self.assertEqual(len(rows), 1)
        self.assertEqual(rows[0]["manager_name"], "ЗАЙЧУК СЕРГІЙ ВАЛЕНТИНОВИЧ")
        self.assertEqual(rows[0]["valid_from"], "2026-09-15")
        self.assertIsNone(rows[0]["valid_to"])
        self.assertEqual(refreshes, [])
        self.assertEqual(con.execute("""SELECT COUNT(*) FROM supplier_edr_verification_events
          WHERE event_type='google_clarity'""").fetchone()[0], 1)

        again = sync.apply(con, source, source["source_fingerprint"], confirmed=True,
          actor="admin", synced_at="2026-09-15T18:01:00",
          sync_manager=server.sync_current_supplier_manager,
          enrich_manager=server.enrich_current_supplier_manager,
          establish_manager=server.establish_current_supplier_manager,
          refresh_manager_controls=lambda *args: refreshes.append(args))
        self.assertEqual(again["newly_established_managers"], 0)
        self.assertEqual(again["verification_events"], 0)
        self.assertEqual(con.execute("SELECT COUNT(*) FROM supplier_managers").fetchone()[0], 1)
        self.assertEqual(refreshes, [])

    def test_application_known_manager_is_reestablished_without_identity_change_or_nazk(self):
        import server
        con = database()
        con.execute("ALTER TABLE application_fields ADD COLUMN manager_name TEXT DEFAULT ''")
        con.execute("ALTER TABLE application_fields ADD COLUMN manager_name_source TEXT DEFAULT ''")
        con.execute("INSERT INTO submissions VALUES ('s1','12345678','OLD','2026-08-30')")
        con.execute("""INSERT INTO application_fields
          (submission_id,protocol_decision,manager_name,manager_name_source)
          VALUES ('s1','admit','ЗАЙЧУК СЕРГІЙ ВАЛЕНТИНОВИЧ','manual')""")
        con.execute("INSERT INTO supplier_edr_profiles(supplier_code,synced_at) VALUES ('12345678','old')")
        source = snapshot(row(manager="ЗАЙЧУК СЕРГІЙ ВАЛЕНТИНОВИЧ"))
        preview = sync.build_preview(con, source)
        plan = preview["items"][0]
        self.assertEqual(plan["manager_change_kind"], "manager_reestablished")
        self.assertEqual(plan["manager_change_reason"], "same_known_identity_in_application")
        self.assertEqual(plan["manager_resolution_source"], "application")
        self.assertEqual(preview["summary"]["manager_identity_changes"], 0)
        refreshes = []
        result = sync.apply(con, source, source["source_fingerprint"], confirmed=True,
          actor="admin", synced_at="2026-09-15T18:00:00",
          sync_manager=server.sync_current_supplier_manager,
          enrich_manager=server.enrich_current_supplier_manager,
          establish_manager=server.establish_current_supplier_manager,
          reestablish_manager=server.reestablish_current_supplier_manager,
          refresh_manager_controls=lambda *args: refreshes.append(args))
        self.assertEqual(result["manager_reestablishments"], 1)
        self.assertEqual(result["newly_established_managers"], 0)
        self.assertEqual(result["manager_identity_changes"], 0)
        self.assertEqual(refreshes, [])
        current = con.execute("SELECT * FROM supplier_managers WHERE is_current=1").fetchall()
        self.assertEqual(len(current), 1)
        self.assertEqual(current[0]["manager_name"], "ЗАЙЧУК СЕРГІЙ ВАЛЕНТИНОВИЧ")

    def test_closed_same_manager_history_is_reestablished_without_rewriting_history(self):
        import server
        con = database()
        con.execute("INSERT INTO supplier_edr_profiles(supplier_code,synced_at) VALUES ('12345678','old')")
        con.execute("""INSERT INTO supplier_managers
          (id,supplier_code,manager_name,normalized_name,valid_from,valid_to,is_current,source,updated_at,created_at)
          VALUES (17,'12345678','ЗАЙЧУК СЕРГІЙ ВАЛЕНТИНОВИЧ','зайчук сергій валентинович',
          '2026-08-30','2026-08-31',0,'PQM application','2026-08-31','2026-08-30')""")
        source = snapshot(row(manager="ЗАЙЧУК СЕРГІЙ ВАЛЕНТИНОВИЧ"))
        preview = sync.build_preview(con, source)
        self.assertEqual(preview["items"][0]["manager_change_kind"], "manager_reestablished")
        self.assertEqual(preview["items"][0]["manager_change_reason"], "same_identity_in_closed_history")
        refreshes = []
        result = sync.apply(con, source, source["source_fingerprint"], confirmed=True,
          actor="admin", synced_at="2026-09-15T18:00:00",
          sync_manager=server.sync_current_supplier_manager,
          enrich_manager=server.enrich_current_supplier_manager,
          establish_manager=server.establish_current_supplier_manager,
          reestablish_manager=server.reestablish_current_supplier_manager,
          refresh_manager_controls=lambda *args: refreshes.append(args))
        self.assertEqual(result["manager_reestablishments"], 1)
        history = con.execute("SELECT * FROM supplier_managers WHERE id=17").fetchone()
        self.assertEqual(history["valid_from"], "2026-08-30")
        self.assertEqual(history["valid_to"], "2026-08-31")
        self.assertEqual(history["is_current"], 0)
        current = con.execute("SELECT * FROM supplier_managers WHERE is_current=1").fetchall()
        self.assertEqual(len(current), 1)
        self.assertNotEqual(current[0]["id"], 17)
        self.assertEqual(refreshes, [])
        again = sync.apply(con, source, source["source_fingerprint"], confirmed=True,
          actor="admin", synced_at="2026-09-15T18:01:00",
          sync_manager=server.sync_current_supplier_manager,
          enrich_manager=server.enrich_current_supplier_manager,
          establish_manager=server.establish_current_supplier_manager,
          reestablish_manager=server.reestablish_current_supplier_manager,
          refresh_manager_controls=lambda *args: refreshes.append(args))
        self.assertEqual(again["manager_reestablishments"], 0)
        self.assertEqual(again["verification_events"], 0)
        self.assertEqual(con.execute("SELECT COUNT(*) FROM supplier_managers").fetchone()[0], 2)
        self.assertEqual(refreshes, [])

    def test_application_fallback_resolver_does_not_materialize_rows(self):
        con = database()
        con.execute("ALTER TABLE application_fields ADD COLUMN manager_name TEXT DEFAULT ''")
        con.execute("INSERT INTO submissions VALUES ('s1','12345678','OLD','2026-08-30')")
        con.execute("""INSERT INTO application_fields
          (submission_id,protocol_decision,manager_name)
          VALUES ('s1','admit','ЗАЙЧУК СЕРГІЙ ВАЛЕНТИНОВИЧ')""")
        before = con.total_changes
        resolved = sync.resolve_known_manager(con, "12345678")
        self.assertEqual(resolved["manager_name"], "ЗАЙЧУК СЕРГІЙ ВАЛЕНТИНОВИЧ")
        self.assertEqual(resolved["resolution_source"], "application")
        self.assertEqual(con.total_changes, before)
        self.assertEqual(con.execute("SELECT COUNT(*) FROM supplier_managers").fetchone()[0], 0)

    def test_google_blank_preserves_current_manager_row(self):
        import server
        con = database()
        con.execute("""INSERT INTO supplier_managers
          (supplier_code,manager_name,normalized_name,valid_from,valid_to,is_current,source,updated_at,created_at)
          VALUES ('12345678','ЗАЙЧУК СЕРГІЙ ВАЛЕНТИНОВИЧ','зайчук сергій валентинович',
          '2026-08-30',NULL,1,'PQM application','2026-08-30','2026-08-30')""")
        result = server.sync_current_supplier_manager(
          con, "12345678", "", "Google Sheets: ЮО", "2026-08-31T19:49:52")
        current = con.execute("SELECT * FROM supplier_managers WHERE supplier_code='12345678'").fetchall()
        self.assertEqual(result["reason"], "no_edr_manager_observation")
        self.assertEqual(len(current), 1)
        self.assertEqual(current[0]["is_current"], 1)
        self.assertIsNone(current[0]["valid_to"])
        self.assertEqual(current[0]["updated_at"], "2026-08-30")

    def test_non_edr_explicit_blank_keeps_established_removal_semantics(self):
        import server
        con = database()
        con.execute("""INSERT INTO supplier_managers
          (supplier_code,manager_name,normalized_name,valid_from,valid_to,is_current,source,updated_at,created_at)
          VALUES ('12345678','ОСОБА А','особа а','2026-08-30',NULL,1,
          'PQM application','2026-08-30','2026-08-30')""")
        result = server.sync_current_supplier_manager(
          con, "12345678", "", "explicit business removal", "2026-09-15")
        row = con.execute("SELECT * FROM supplier_managers WHERE supplier_code='12345678'").fetchone()
        self.assertEqual(result["reason"], "manager_removed")
        self.assertEqual(row["is_current"], 0)
        self.assertEqual(row["valid_to"], "2026-09-15")

    def test_google_blank_preview_is_no_manager_observation(self):
        con = database()
        con.execute("""INSERT INTO supplier_managers
          (supplier_code,manager_name,normalized_name,valid_from,valid_to,is_current,source,updated_at,created_at)
          VALUES ('12345678','ЗАЙЧУК СЕРГІЙ ВАЛЕНТИНОВИЧ','зайчук сергій валентинович',
          '2026-08-30',NULL,1,'PQM application','2026-08-30','2026-08-30')""")
        preview = sync.build_preview(con, snapshot(row(manager="")))
        self.assertEqual(preview["items"][0]["manager_change_kind"], "same")
        self.assertNotIn("manager_name", preview["items"][0]["changed_fields"])
        self.assertEqual(preview["summary"]["manager_removals"], 0)

    def test_real_manager_change_closes_cycle_and_refreshes_nazk(self):
        import server
        con = database()
        con.execute("""INSERT INTO supplier_edr_profiles
          (supplier_code,manager_name,edr_checked_at,synced_at) VALUES ('12345678','ОСОБА А','2026-09-14','old')""")
        con.execute("""INSERT INTO supplier_managers
          (supplier_code,manager_name,normalized_name,valid_from,valid_to,is_current,source,updated_at,created_at)
          VALUES ('12345678','ОСОБА А','особа а','2026-08-01',NULL,1,'ЄДР','2026-08-01','2026-08-01')""")
        source = snapshot(row(manager="ОСОБА Б"))
        refreshes = []
        result = sync.apply(con, source, source["source_fingerprint"], confirmed=True,
          actor="admin", synced_at="2026-09-15T18:00:00",
          sync_manager=server.sync_current_supplier_manager,
          enrich_manager=server.enrich_current_supplier_manager,
          establish_manager=server.establish_current_supplier_manager,
          refresh_manager_controls=lambda *args: refreshes.append(args))
        rows = con.execute("SELECT * FROM supplier_managers ORDER BY id").fetchall()
        self.assertEqual(result["manager_identity_changes"], 1)
        self.assertEqual(len(rows), 2)
        self.assertEqual(rows[0]["valid_to"], "2026-09-15")
        self.assertEqual(rows[0]["is_current"], 0)
        self.assertEqual(rows[1]["manager_name"], "ОСОБА Б")
        self.assertEqual(rows[1]["is_current"], 1)
        self.assertEqual(len(refreshes), 1)

    def test_server_enrichment_preserves_current_cycle(self):
        import server
        con = sqlite3.connect(":memory:")
        con.row_factory = sqlite3.Row
        con.execute("""CREATE TABLE supplier_managers(id INTEGER PRIMARY KEY,supplier_code TEXT,
          manager_name TEXT,normalized_name TEXT,valid_from TEXT,valid_to TEXT,is_current INTEGER,
          source TEXT,created_at TEXT,updated_at TEXT)""")
        con.execute("""INSERT INTO supplier_managers VALUES
          (7,'12345678','ТКАЧЕНКО Н.М.','ткаченко н.м.','2026-08-01',NULL,1,
           'Google Sheets: ФОП','2026-08-01','2026-08-01')""")
        result = server.enrich_current_supplier_manager(con, '12345678',
          'ТКАЧЕНКО НАТАЛІЯ МИКОЛАЇВНА', 'Google Sheets: ФОП', '2026-09-15')
        rows = con.execute("SELECT * FROM supplier_managers").fetchall()
        self.assertTrue(result["enriched"])
        self.assertEqual(len(rows), 1)
        self.assertEqual(rows[0]["id"], 7)
        self.assertEqual(rows[0]["valid_from"], "2026-08-01")
        self.assertIsNone(rows[0]["valid_to"])
        self.assertEqual(rows[0]["manager_name"], 'ТКАЧЕНКО НАТАЛІЯ МИКОЛАЇВНА')

    def test_preview_is_read_only_and_legacy_profile_is_not_discarded(self):
        con = database()
        con.execute("INSERT INTO supplier_edr_profiles(supplier_code,synced_at) VALUES ('12345678','old')")
        before = con.total_changes
        result = sync.build_preview(con, snapshot(row()))
        self.assertEqual(con.total_changes, before)
        self.assertEqual(result["summary"]["legacy_ineligible"], 1)
        self.assertTrue(result["items"][0]["apply_allowed"])

    def test_new_population_requires_final_decision(self):
        con = database()
        denied = sync.build_preview(con, snapshot(row()))["items"][0]
        self.assertFalse(denied["apply_allowed"])
        con.execute("INSERT INTO submissions VALUES ('s1','12345678','OLD','2026-09-01')")
        con.execute("INSERT INTO application_fields VALUES ('s1','reject','2026-09-02','УО','')")
        self.assertFalse(sync.build_preview(con, snapshot(row()))["items"][0]["apply_allowed"])
        con.execute("INSERT INTO qualifications VALUES ('q1','unsuccessful','s1')")
        allowed = sync.build_preview(con, snapshot(row()))["items"][0]
        self.assertTrue(allowed["apply_allowed"])

    def test_apply_requires_exact_confirmed_fingerprint(self):
        con = database(); source = snapshot(row())
        with self.assertRaises(PermissionError):
            sync.apply(con, source, source["source_fingerprint"], confirmed=False, actor="admin", synced_at="2026-09-15T10:00:00")
        with self.assertRaises(RuntimeError):
            sync.apply(con, source, "0" * 64, confirmed=True, actor="admin", synced_at="2026-09-15T10:00:00")

    def test_manager_observed_at_comes_from_source(self):
        con = database()
        con.execute("INSERT INTO supplier_edr_profiles(supplier_code,manager_name,edr_checked_at,synced_at) VALUES ('12345678','СТАРИЙ','2026-09-14','old')")
        seen = []
        source = snapshot(row())
        result = sync.apply(con, source, source["source_fingerprint"], confirmed=True, actor="admin",
          synced_at="2026-09-15T18:00:00", sync_manager=lambda *args: seen.append(args[-1]) or {"changed": True})
        self.assertEqual(seen, ["2026-09-15"])
        self.assertEqual(result["manager_changes"], 1)

    def test_same_snapshot_is_idempotent(self):
        import server
        con = database()
        con.execute("INSERT INTO supplier_edr_profiles(supplier_code,synced_at) VALUES ('12345678','old')")
        source = snapshot(row())
        callbacks = dict(sync_manager=server.sync_current_supplier_manager,
          enrich_manager=server.enrich_current_supplier_manager,
          establish_manager=server.establish_current_supplier_manager,
          reestablish_manager=server.reestablish_current_supplier_manager)
        sync.apply(con, source, source["source_fingerprint"], confirmed=True, actor="admin",
                   synced_at="2026-09-15T18:00:00", **callbacks)
        again = sync.apply(con, source, source["source_fingerprint"], confirmed=True, actor="admin",
                           synced_at="2026-09-15T18:01:00", **callbacks)
        self.assertEqual(again["updated_profiles"], 0)
        self.assertEqual(again["verification_events"], 0)
        self.assertEqual(again["changed_fields"], {})

    def test_confirmed_blank_google_mirror_values_clear_pqm_values(self):
        con = database()
        con.execute("""INSERT INTO supplier_edr_profiles(supplier_code,edr_status,edr_checked_at,
          termination_decision_details,termination_record_date,termination_record_number,edr_notes,
          edr_officer,manager_name,full_name,short_name,synced_at) VALUES
          ('12345678','Зареєстровано','2026-08-01','Запис № 7','2026-07-01','N-7','Примітка','УО',
           'НОВИЙ КЕРІВНИК','ПОВНА НАЗВА','СКОРОЧЕНА НАЗВА','old')""")
        values = row(status="Зареєстровано")
        values[6] = values[9] = values[10] = values[12] = ''
        source = snapshot(values)
        result = sync.apply(con, source, source["source_fingerprint"], confirmed=True, actor="admin",
                            synced_at="2026-09-15T18:00:00")
        profile = con.execute("""SELECT termination_decision_details,termination_record_date,
          termination_record_number,edr_notes FROM supplier_edr_profiles""").fetchone()
        self.assertEqual(tuple(profile), ('','','',''))
        self.assertEqual(result["termination_clears"], 1)
        self.assertEqual(result["google_mirror_clears"], 4)
        self.assertEqual(con.execute("SELECT COUNT(*) FROM supplier_edr_verification_events WHERE event_type='google_mirror_clear'").fetchone()[0], 1)

    def test_google_owned_gjkm_values_update_independently_of_verification_date(self):
        date_pairs = [
            ('newer', '2026-09-15T12:00:00+03:00', '2026-09-14T12:00:00+03:00'),
            ('equal', '2026-09-15T12:00:00+03:00', '2026-09-15T12:00:00+03:00'),
            ('older', '2026-09-14T12:00:00+03:00', '2026-09-15T12:00:00+03:00'),
            ('missing', '', '2026-09-15T12:00:00+03:00'),
        ]
        for label, incoming_date, current_date in date_pairs:
            with self.subTest(date_case=label):
                con = database()
                con.execute("""INSERT INTO supplier_edr_profiles(supplier_code,manager_name,edr_status,
                  full_name,short_name,edr_checked_at,edr_officer,termination_decision_details,
                  termination_record_date,termination_record_number,edr_notes,synced_at)
                  VALUES('12345678','НОВИЙ КЕРІВНИК','Зареєстровано','ПОВНА НАЗВА','СКОРОЧЕНА НАЗВА',
                  ?,'УО','old G','2026-01-01','old K','old M','old')""", (current_date,))
                values = row(checked=incoming_date, status='Зареєстровано')
                values[3] = ''  # do not introduce a manager identity transition in this mirror-only case
                values[6], values[9], values[10], values[12] = ('new G', '2026-02-02', 'new K', 'new M')
                source = snapshot(values)
                preview = sync.build_preview(con, source)
                plan = preview['items'][0]
                self.assertEqual(set(plan['changed_fields']), set(sync.INDEPENDENT_GOOGLE_MIRROR_FIELDS))
                self.assertEqual(plan['row_state'], 'eligible')
                self.assertFalse(plan['datetime_gate']['accepted']) if label in {'older','missing','equal'} else None
                result = sync.apply(con, source, source['source_fingerprint'], confirmed=True,
                                    actor='test', synced_at='2026-09-16T12:00:00')
                actual = con.execute("""SELECT termination_decision_details,termination_record_date,
                  termination_record_number,edr_notes,manager_name,edr_status,edr_checked_at
                  FROM supplier_edr_profiles WHERE supplier_code='12345678'""").fetchone()
                self.assertEqual(tuple(actual[:4]), ('new G','2026-02-02','new K','new M'))
                expected_date = incoming_date if label == 'newer' else current_date
                self.assertEqual(tuple(actual[4:]), ('НОВИЙ КЕРІВНИК','Зареєстровано',expected_date or ''))
                self.assertEqual(result['changed_fields'], {field: 1 for field in sync.INDEPENDENT_GOOGLE_MIRROR_FIELDS})

    def test_confirmed_google_blanks_clear_mirrors_even_without_a_usable_verification_date(self):
        con = database()
        con.execute("""INSERT INTO supplier_edr_profiles(supplier_code,edr_checked_at,
          termination_decision_details,termination_record_date,termination_record_number,edr_notes,synced_at)
          VALUES('12345678','2026-09-15','old G','2026-08-01','old K','old M','old')""")
        values = row(checked='')
        values[6] = values[9] = values[10] = values[12] = ''
        source = snapshot(values)
        plan = sync.build_preview(con, source)['items'][0]
        self.assertEqual(set(plan['mirror_clear_fields']), set(sync.INDEPENDENT_GOOGLE_MIRROR_FIELDS))
        self.assertFalse(plan['datetime_gate']['accepted'])
        result = sync.apply(con, source, source['source_fingerprint'], confirmed=True,
                            actor='test', synced_at='2026-09-16T12:00:00')
        actual = con.execute("""SELECT termination_decision_details,termination_record_date,
          termination_record_number,edr_notes FROM supplier_edr_profiles""").fetchone()
        self.assertEqual(tuple(actual), ('','','',''))
        self.assertEqual(result['google_mirror_clears'], 4)
        self.assertEqual(result['termination_clears'], 1)
        self.assertEqual(con.execute("SELECT COUNT(*) FROM supplier_edr_verification_events WHERE event_type='google_mirror_clear'").fetchone()[0], 1)

    def test_google_mirror_plan_is_identical_in_sandbox_and_production_modes(self):
        for sandbox_mode in (False, True):
            with self.subTest(sandbox_mode=sandbox_mode):
                con = database()
                con.execute("""INSERT INTO supplier_edr_profiles(supplier_code,edr_checked_at,
                  termination_decision_details,synced_at)
                  VALUES('12345678','2026-09-15','old G','old')""")
                values = row(checked='')
                values[6] = 'new G'
                source = snapshot(values)
                plan = sync.build_preview(con, source, sandbox_mode=sandbox_mode)['items'][0]
                self.assertIn('termination_decision_details', plan['changed_fields'])
                sync.apply(con, source, source['source_fingerprint'], confirmed=True,
                           actor='test', synced_at='2026-09-16T12:00:00',
                           sandbox_mode=sandbox_mode)
                self.assertEqual(con.execute("SELECT termination_decision_details FROM supplier_edr_profiles").fetchone()[0],
                                 'new G')

    def test_mirror_values_update_when_other_edr_changes_are_blocked_by_missing_date(self):
        con = database()
        con.execute("""INSERT INTO supplier_edr_profiles(supplier_code,manager_name,edr_status,
          full_name,short_name,edr_checked_at,edr_officer,termination_decision_details,edr_notes,synced_at)
          VALUES('12345678','СТАРИЙ КЕРІВНИК','Зареєстровано','ПОВНА НАЗВА','СКОРОЧЕНА НАЗВА',
          '2026-09-15','УО','old G','old M','old')""")
        values = row(checked='', manager='НОВИЙ КЕРІВНИК', status='Припинено')
        values[6], values[12] = 'new G', 'new M'
        source = snapshot(values)
        preview = sync.build_preview(con, source)
        plan = preview['items'][0]
        self.assertTrue(plan['independent_mirror_only'])
        self.assertEqual(plan['row_state'], 'conflict')
        self.assertEqual(set(plan['changed_fields']), {'termination_decision_details', 'edr_notes'})
        sync.apply(con, source, source['source_fingerprint'], confirmed=True,
                   actor='test', synced_at='2026-09-16T12:00:00', sandbox_mode=True)
        actual = con.execute("""SELECT termination_decision_details,edr_notes,manager_name,edr_status
          FROM supplier_edr_profiles WHERE supplier_code='12345678'""").fetchone()
        self.assertEqual(tuple(actual), ('new G','new M','СТАРИЙ КЕРІВНИК','Зареєстровано'))

    def test_approved_same_timestamp_conflict_applies_only_google_owned_mirrors(self):
        con = database()
        con.execute("""INSERT INTO supplier_edr_profiles(supplier_code,edr_status,edr_checked_at,edr_officer,
          termination_decision_details,termination_record_date,termination_record_number,edr_notes,synced_at)
          VALUES('12345678','Зареєстровано','2026-09-15T12:00:00+03:00','УО','old G','2026-01-01','old K','old M','old')""")
        values = row(checked='2026-09-15T12:00:00+03:00', status='Припинено', manager='')
        values[6], values[9], values[10], values[12] = ('new G', '2026-02-02', 'new K', 'new M')
        source = snapshot(values)
        plan = sync.build_preview(con, source)['items'][0]
        self.assertEqual(plan['row_state'], 'conflict')
        self.assertTrue(plan['independent_mirror_only'])
        self.assertEqual(plan['conflicts'], ['same_timestamp_verification_conflict'])
        result = sync.apply(con, source, source['source_fingerprint'], confirmed=True,
                            actor='test', synced_at='2026-09-16T12:00:00')
        actual = con.execute("""SELECT edr_status,edr_checked_at,edr_officer,termination_decision_details,
          termination_record_date,termination_record_number,edr_notes FROM supplier_edr_profiles""").fetchone()
        self.assertEqual(tuple(actual), ('Зареєстровано','2026-09-15T12:00:00+03:00','УО',
          'new G','2026-02-02','new K','new M'))
        self.assertEqual(result['verification_events'], 0)
        self.assertEqual(result['changed_fields'], {field: 1 for field in sync.INDEPENDENT_GOOGLE_MIRROR_FIELDS})

    def test_unapproved_row_conflict_blocks_mirror_updates(self):
        con = database()
        con.execute("""INSERT INTO supplier_edr_profiles(supplier_code,edr_status,edr_checked_at,
          termination_decision_details,synced_at)
          VALUES('12345678','Зареєстровано','2026-09-15','old G','old')""")
        values = row(checked='', manager='')
        values[6], values[9] = 'new G', 'not-a-date'
        source = snapshot(values)
        plan = sync.build_preview(con, source)['items'][0]
        self.assertEqual(plan['row_state'], 'conflict')
        self.assertFalse(plan['independent_mirror_only'])
        self.assertIn('malformed_termination_record_date', plan['conflicts'])
        sync.apply(con, source, source['source_fingerprint'], confirmed=True,
                   actor='test', synced_at='2026-09-16T12:00:00', sandbox_mode=True)
        actual = con.execute("SELECT termination_decision_details FROM supplier_edr_profiles").fetchone()[0]
        self.assertEqual(actual, 'old G')

    def test_equal_google_mirror_values_are_noop(self):
        con = database()
        con.execute("""INSERT INTO supplier_edr_profiles(supplier_code,edr_checked_at,edr_officer,
          termination_decision_details,termination_record_date,termination_record_number,edr_notes,synced_at)
          VALUES('12345678','2026-09-15','УО','G','2026-01-01','K','M','old')""")
        values = row(checked='2026-09-15', officer='УО')
        values[6], values[9], values[10], values[12] = ('G','2026-01-01','K','M')
        source = snapshot(values)
        preview = sync.build_preview(con, source)
        self.assertFalse(set(preview['items'][0]['changed_fields']) & sync.INDEPENDENT_GOOGLE_MIRROR_FIELDS)
        self.assertEqual(preview['summary']['google_mirror_updates'], 0)

    def test_missing_trailing_google_mirror_columns_are_not_treated_as_blank(self):
        con = database()
        con.execute("INSERT INTO supplier_edr_profiles(supplier_code,termination_decision_details,edr_notes,synced_at) VALUES('12345678','keep G','keep M','old')")
        values = row(checked='', manager='')
        source = sync.source_snapshot({'ФОП': [list(sync.HEADERS)], 'ЮО': [list(sync.HEADERS), values[:12]]})
        preview = sync.build_preview(con, source)
        note = next(change for change in preview['items'][0]['mirror_field_changes'] if change['field']=='edr_notes')
        self.assertEqual(note['action'], 'blocked')
        self.assertEqual(note['reason'], 'missing_source_column')
        google_g = next(change for change in preview['items'][0]['mirror_field_changes']
                        if change['field']=='termination_decision_details')
        self.assertEqual(google_g['action'], 'blocked')
        self.assertEqual(google_g['reason'], 'incomplete_or_invalid_mirror_source')
        self.assertNotIn('edr_notes', preview['items'][0]['changed_fields'])
        self.assertNotIn('termination_decision_details', preview['items'][0]['changed_fields'])
        before = con.total_changes
        with self.assertRaises(ValueError):
            sync.apply(con, source, source['source_fingerprint'], confirmed=True,
                       actor='test', synced_at='2026-09-16T12:00:00')
        self.assertEqual(con.total_changes, before)
        self.assertEqual(tuple(con.execute("SELECT termination_decision_details,edr_notes FROM supplier_edr_profiles").fetchone()),
                         ('keep G', 'keep M'))

    def test_available_mirror_columns_apply_when_another_google_column_is_missing(self):
        con = database()
        con.execute("""INSERT INTO supplier_edr_profiles(supplier_code,manager_name,edr_status,full_name,
          short_name,edr_checked_at,edr_officer,termination_decision_details,termination_record_date,
          termination_record_number,edr_notes,synced_at) VALUES
          ('12345678','НОВИЙ КЕРІВНИК','Зареєстровано','ПОВНА НАЗВА','СКОРОЧЕНА НАЗВА',
           '2026-09-15','УО','old G','2025-01-01','old K','keep M','old')""")
        values = row(checked='')
        values[6], values[9], values[10] = 'new G', '2026-01-01', 'new K'
        source = sync.source_snapshot({'ФОП': [list(sync.HEADERS)], 'ЮО': [list(sync.HEADERS), values[:12]]})
        preview = sync.build_preview(con, source)
        plan = preview['items'][0]
        self.assertTrue(plan['independent_mirror_only'])
        self.assertIn('missing_source_column:Примітки', plan['conflicts'])
        sync.apply(con, source, source['source_fingerprint'], confirmed=True,
                   actor='test', synced_at='2026-09-16T12:00:00')
        actual = con.execute("""SELECT termination_decision_details,termination_record_date,
          termination_record_number,edr_notes FROM supplier_edr_profiles WHERE supplier_code='12345678'""").fetchone()
        self.assertEqual(tuple(actual), ('new G','2026-01-01','new K','keep M'))

    def test_available_mirror_value_applies_when_verification_date_column_is_unavailable(self):
        con = database()
        con.execute("""INSERT INTO supplier_edr_profiles(supplier_code,termination_decision_details,synced_at)
          VALUES('12345678','old G','old')""")
        values = row(checked='')
        values[6] = 'new G'
        source = sync.source_snapshot({'ФОП': [list(sync.HEADERS)], 'ЮО': [list(sync.HEADERS), values[:7]]})
        preview = sync.build_preview(con, source)
        plan = preview['items'][0]
        self.assertTrue(plan['independent_mirror_only'])
        self.assertIn('missing_source_column:Дата перевірки', plan['conflicts'])
        sync.apply(con, source, source['source_fingerprint'], confirmed=True,
                   actor='test', synced_at='2026-09-16T12:00:00')
        self.assertEqual(con.execute("SELECT termination_decision_details FROM supplier_edr_profiles").fetchone()[0], 'new G')

    def test_eligible_supplier_can_receive_mirror_profile_without_verification_date(self):
        con = database()
        con.execute("INSERT INTO submissions(id,supplier_code,supplier_name,date_published) VALUES('s1','12345678','ТОВ','2026-09-01')")
        con.execute("INSERT INTO qualifications(id,status,submission_id) VALUES('q1','active','s1')")
        values = row(checked='')
        values[6], values[9], values[10], values[12] = ('G','2026-01-01','K','M')
        source = snapshot(values)
        plan = sync.build_preview(con, source)['items'][0]
        self.assertTrue(plan['apply_allowed'])
        self.assertEqual(plan['row_state'], 'conflict')
        self.assertTrue(plan['independent_mirror_only'])
        result = sync.apply(con, source, source['source_fingerprint'], confirmed=True,
                            actor='test', synced_at='2026-09-16T12:00:00')
        actual = con.execute("""SELECT termination_decision_details,termination_record_date,
          termination_record_number,edr_notes,edr_checked_at FROM supplier_edr_profiles
          WHERE supplier_code='12345678'""").fetchone()
        self.assertEqual(tuple(actual), ('G','2026-01-01','K','M',''))
        self.assertEqual(result['inserted'], 1)

    def test_status_and_marker(self):
        con = database()
        con.execute("INSERT INTO submissions VALUES ('s1','11111111','A','2026-09-01')")
        con.execute("INSERT INTO application_fields VALUES ('s1','reject','2026-09-02','УО','')")
        con.execute("INSERT INTO qualifications VALUES ('q1','unsuccessful','s1')")
        con.execute("INSERT INTO frameworks VALUES ('f1','active','{}')")
        con.executemany("INSERT INTO registry_contracts VALUES (?,?,?)", [('22222222','active','f1'),('33333333','suspended','f1'),('44444444','cancelled','f1')])
        statuses = sync.prozorro_statuses(con)
        self.assertEqual(statuses['11111111'], 'Ще не в реєстрі')
        self.assertEqual(statuses['22222222'], 'Активний')
        self.assertEqual(statuses['33333333'], 'Призупинений')
        self.assertEqual(statuses['44444444'], 'Неактивний')
        self.assertEqual(sync.marker_for_status('Ще не в реєстрі','2026-09-15'), '🟣 Неактуально')

    def test_canonical_freshness_boundaries_and_non_monitored_states(self):
        today = date(2026, 9, 15)
        expected = {
            0: ('lt30', '🟢 <30 днів'), 29: ('lt30', '🟢 <30 днів'),
            30: ('gt30', '🟡 >30 днів'), 59: ('gt30', '🟡 >30 днів'),
            60: ('gt60', '🟠 >60 днів'), 89: ('gt60', '🟠 >60 днів'),
            90: ('gt90', '🔴 >90 днів'), 120: ('gt90', '🔴 >90 днів'),
        }
        for age, pair in expected.items():
            state = sync.freshness_state('Активний', (today - timedelta(days=age)).isoformat(), today)
            self.assertEqual((state['bucket'], state['marker']), pair)
            self.assertTrue(state['monitored'])
            suspended = sync.freshness_state('Призупинений', (today - timedelta(days=age)).isoformat(), today)
            self.assertEqual(suspended, state)
        self.assertEqual(sync.freshness_state('Неактивний', '2020-01-01', today)['marker'], '🟣 Неактуально')
        self.assertEqual(sync.freshness_state('Ще не в реєстрі', '2026-09-15', today)['marker'], '🟣 Неактуально')
        self.assertEqual(sync.freshness_state('Призупинений', '', today)['marker'], '⚪ Не перевірено')
        self.assertEqual(sync.freshness_state('Призупинений',
                         (today - timedelta(days=29)).isoformat(), today)['marker'],
                         '🟢 <30 днів')
        for status in ('Активний', 'Призупинений'):
            for invalid in ('', 'not-a-date', '2026-02-30'):
                state = sync.freshness_state(status, invalid, today)
                self.assertEqual((state['bucket'], state['marker'], state['age_days']),
                                 ('not_checked', '⚪ Не перевірено', None))
            future = (today + timedelta(days=1)).isoformat()
            state = sync.freshness_state(status, future, today)
            self.assertEqual((state['bucket'], state['marker'], state['age_days']),
                             ('not_checked', '⚪ Не перевірено', None))

    def test_latest_verification_keeps_date_and_officer_from_same_event(self):
        con = database()
        con.execute("INSERT INTO submissions VALUES ('s1','12345678','Supplier','2026-09-01')")
        con.execute("INSERT INTO application_fields VALUES ('s1','admit','2026-09-10','УО ДОПУСКУ','')")
        sync._insert_event(con,item={'supplier_code':'12345678'},event_type='google_clarity',
          occurred_at='2026-09-12',officer='УО CLARITY',source='Google Sheets',changed_fields=[],
          snapshot={'supplier_code':'12345678','event':'newer'},created_at='2026-09-12')
        state=sync.canonical_supplier_edr_states(con,['12345678'],today=date(2026,9,15))['12345678']
        self.assertEqual((state['verification_date'],state['verification_officer']),('2026-09-12','УО CLARITY'))
        self.assertEqual(state['last_admission_date'],'2026-09-10')

    def test_newer_admission_beats_older_google_event(self):
        con = database()
        sync._insert_event(con,item={'supplier_code':'12345678'},event_type='google_clarity',
          occurred_at='2026-09-01',officer='УО CLARITY',source='Google Sheets',changed_fields=[],
          snapshot={'supplier_code':'12345678','event':'older'},created_at='2026-09-01')
        con.execute("INSERT INTO submissions VALUES ('s2','12345678','Supplier','2026-09-13')")
        con.execute("INSERT INTO application_fields VALUES ('s2','admit','2026-09-14','УО ПРОТОКОЛУ','')")
        state=sync.canonical_supplier_edr_states(con,['12345678'],today=date(2026,9,15))['12345678']
        self.assertEqual((state['verification_date'],state['verification_officer']),('2026-09-14','УО ПРОТОКОЛУ'))


if __name__ == "__main__":
    unittest.main()
