import json
import sqlite3
import unittest

import operational_tasks


class NazkTaskPersonRelevanceTests(unittest.TestCase):
    CODE='12345678'
    def setUp(self):
        self.con=sqlite3.connect(':memory:'); self.con.row_factory=sqlite3.Row
        self.con.create_function('DIGITS',1,lambda value:''.join(x for x in str(value or '') if x.isdigit()))
        self.con.create_function('NORMALIZE_NAME',1,lambda value:' '.join(str(value or '').casefold().split()))
        self.con.executescript('''
          CREATE TABLE authorized_officers(id INTEGER PRIMARY KEY,full_name TEXT,active INTEGER DEFAULT 1);
          CREATE TABLE submissions(id TEXT PRIMARY KEY,framework_id TEXT,supplier_name TEXT,supplier_code TEXT,date_published TEXT,status TEXT);
          CREATE TABLE qualifications(id TEXT PRIMARY KEY,submission_id TEXT,status TEXT,decision_date TEXT);
          CREATE TABLE frameworks(id TEXT PRIMARY KEY,pretty_id TEXT,dk_code TEXT,title TEXT,status TEXT,raw_json TEXT);
          CREATE TABLE framework_officers(framework_id TEXT,marketplace_url TEXT);
          CREATE TABLE registry_contracts(id TEXT PRIMARY KEY,qualification_id TEXT,framework_id TEXT,supplier_code TEXT,status TEXT,raw_json TEXT DEFAULT '{}');
          CREATE TABLE supplier_edr_profiles(supplier_code TEXT,full_name TEXT,short_name TEXT);
          CREATE TABLE amcu_registry(row_key TEXT PRIMARY KEY,offender_code TEXT,decision_date TEXT);
          CREATE TABLE supplier_managers(id INTEGER PRIMARY KEY,supplier_code TEXT,manager_name TEXT,normalized_name TEXT,manager_tax_id TEXT,is_current INTEGER);
          CREATE TABLE supplier_nazk_checks(id INTEGER PRIMARY KEY,supplier_code TEXT,manager_id INTEGER,manager_name TEXT,workflow_status TEXT,result TEXT,started_at TEXT,completed_at TEXT,updated_at TEXT);
          CREATE TABLE supplier_nazk_check_matches(check_id INTEGER,nazk_source_id TEXT,match_status TEXT);
          CREATE TABLE violation_reports(id TEXT,report_id TEXT,status TEXT,decision_date TEXT,defendant_code TEXT,date_published TEXT,tender_pretty_id TEXT,author_name TEXT,contract_pretty_id TEXT);
        ''')
        operational_tasks.migrate(self.con)
        self.con.execute("INSERT INTO frameworks VALUES('F','UA-F-X','00000000-0','Fixture','active',?)",(json.dumps({'qualificationPeriod':{'endDate':'2099-01-01'}}),))
        self.con.execute("INSERT INTO submissions VALUES('S','F','Supplier X',?,'2026-01-01','complete')",(self.CODE,))
        self.con.execute("INSERT INTO qualifications VALUES('Q','S','active','2026-01-02')")
        self.con.execute("INSERT INTO registry_contracts(id,qualification_id,framework_id,supplier_code,status) VALUES('RC','Q','F',?,'active')",(self.CODE,))
        self.con.executemany("INSERT INTO supplier_managers VALUES(?,?,?,?,?,?)",[(1,self.CODE,'PERSON_A','person_a','111',0),(2,self.CODE,'PERSON_B','person_b','222',1)])
        self.con.execute("""INSERT INTO supplier_nazk_checks
          (id,supplier_code,manager_id,manager_name,workflow_status,result,started_at,completed_at,updated_at)
          VALUES(10,?,1,'PERSON_A','completed','confirmed','2025-01-01','2025-01-02','2025-01-02')""",(self.CODE,))
        self.con.execute("INSERT INTO supplier_nazk_check_matches VALUES(10,'RECORD_A','confirmed')")
        stamp=operational_tasks.now_iso()
        self.con.execute("""INSERT INTO operational_tasks(id,task_key,task_type,supplier_code,supplier_name_snapshot,status,priority,created_at,updated_at,source_context,document_context)
          VALUES('history','historical_exclusion:X:PERSON_A','nazk_check',?,'Supplier X','completed','critical',?,?,?,?)""",
          (self.CODE,stamp,stamp,json.dumps({'historical_exclusion':True,'person_name':'PERSON_A'}),'{}'))
        operational_tasks._event(self.con,'history','historical_exclusion_completed','fixture')

    def active_for_record(self,record):
        return self.con.execute("""SELECT COUNT(*) FROM operational_tasks WHERE task_type='nazk_check'
          AND status NOT IN ('completed','cancelled') AND source_context LIKE ?""",(f'%{record}%',)).fetchone()[0]

    def test_historical_confirmed_previous_manager_does_not_retrigger(self):
        self.assertNotEqual('PERSON_A',self.con.execute("SELECT manager_name FROM supplier_managers WHERE is_current=1").fetchone()[0])
        before=self.con.execute("SELECT result,manager_name FROM supplier_nazk_checks WHERE id=10").fetchone()
        self.assertEqual(tuple(before),('confirmed','PERSON_A'))
        self.assertEqual(len(operational_tasks._active_application_map(self.con)[self.CODE]),1)
        operational_tasks.build(self.con,'fixture',include_nazk=True); operational_tasks.build(self.con,'fixture repeat',include_nazk=True)
        self.assertEqual(self.active_for_record('RECORD_A'),0)
        self.assertEqual(tuple(self.con.execute("SELECT result,manager_name FROM supplier_nazk_checks WHERE id=10").fetchone()),('confirmed','PERSON_A'))
        self.assertEqual(self.con.execute("SELECT COUNT(*) FROM operational_task_events WHERE task_id='history'").fetchone()[0],1)

    def test_current_manager_match_creates_one_task_idempotently(self):
        self.con.execute("UPDATE supplier_managers SET is_current=CASE id WHEN 1 THEN 1 ELSE 0 END")
        operational_tasks.build(self.con,'fixture',include_nazk=True); operational_tasks.build(self.con,'fixture repeat',include_nazk=True)
        self.assertEqual(self.active_for_record('RECORD_A'),1)
        self.assertEqual(self.con.execute("SELECT task_key FROM operational_tasks WHERE source_context LIKE '%RECORD_A%'").fetchone()[0],
                         f'nazk_check:{self.CODE}:1:RECORD_A')

    def test_new_current_manager_match_is_a_new_business_event(self):
        self.con.execute("""INSERT INTO supplier_nazk_checks
          (id,supplier_code,manager_id,manager_name,workflow_status,result,started_at,completed_at,updated_at)
          VALUES(11,?,2,'PERSON_B','needs_review',NULL,'2026-01-03',NULL,'2026-01-03')""",(self.CODE,))
        self.con.execute("INSERT INTO supplier_nazk_check_matches VALUES(11,'RECORD_B','confirmed')")
        operational_tasks.build(self.con,'fixture',include_nazk=True); operational_tasks.build(self.con,'fixture repeat',include_nazk=True)
        self.assertEqual(self.active_for_record('RECORD_A'),0)
        self.assertEqual(self.active_for_record('RECORD_B'),1)
        self.assertEqual(self.con.execute("SELECT task_key FROM operational_tasks WHERE source_context LIKE '%RECORD_B%'").fetchone()[0],
                         f'nazk_check:{self.CODE}:2:RECORD_B')


class CanonicalRelationCycleTests(NazkTaskPersonRelevanceTests):
    def test_missing_record_cancellation_and_new_record(self):
        self.con.execute("""INSERT INTO supplier_nazk_checks
          (id,supplier_code,manager_id,manager_name,workflow_status,result,started_at,completed_at,updated_at)
          VALUES(11,?,2,'PERSON_B','needs_review',NULL,'2026-01-03',NULL,'2026-01-03')""",(self.CODE,))
        operational_tasks.build(self.con,'fixture',include_nazk=True)
        row=self.con.execute("SELECT id,task_key FROM operational_tasks WHERE status='in_progress'").fetchone()
        self.con.execute("UPDATE operational_tasks SET status='cancelled',resolution_code='nazk_record_no_longer_present' WHERE id=?",(row['id'],))
        operational_tasks.build(self.con,'repeat',include_nazk=True)
        self.assertEqual(self.con.execute("SELECT COUNT(*) FROM operational_tasks WHERE status='in_progress'").fetchone()[0],0)
        self.con.execute("INSERT INTO supplier_nazk_check_matches VALUES(11,'NEW_RECORD','candidate')")
        operational_tasks.build(self.con,'new event',include_nazk=True)
        operational_tasks.build(self.con,'repeat',include_nazk=True)
        self.assertEqual(self.con.execute("SELECT COUNT(*) FROM operational_tasks WHERE status='in_progress'").fetchone()[0],1)
        self.assertEqual(self.con.execute('SELECT status FROM operational_tasks WHERE id=?',(row['id'],)).fetchone()[0],'cancelled')

    def test_additive_relation_preserves_existing_task_key(self):
        self.con.execute("""INSERT INTO supplier_nazk_checks
          (id,supplier_code,manager_id,manager_name,workflow_status,result,started_at,completed_at,updated_at)
          VALUES(11,?,2,'PERSON_B','needs_review',NULL,'2026-01-03',NULL,'2026-01-03')""",(self.CODE,))
        operational_tasks.build(self.con,'fixture',include_nazk=True)
        key=self.con.execute("SELECT task_key FROM operational_tasks WHERE status='in_progress'").fetchone()[0]
        self.con.execute("INSERT INTO supplier_nazk_check_matches VALUES(11,'LINKED_RECORD','candidate')")
        operational_tasks.build(self.con,'repeat',include_nazk=True)
        self.assertEqual([r[0] for r in self.con.execute("SELECT task_key FROM operational_tasks WHERE status='in_progress'")],[key])


class ProzorroQualificationLossTests(NazkTaskPersonRelevanceTests):
    def _create_ready_nazk_task(self):
        self.con.execute("""INSERT INTO supplier_nazk_checks
          (id,supplier_code,manager_id,manager_name,workflow_status,result,started_at,completed_at,updated_at)
          VALUES(11,?,2,'PERSON_B','needs_review','confirmed','2026-01-03',NULL,'2026-01-03')""", (self.CODE,))
        self.con.execute("INSERT INTO supplier_nazk_check_matches VALUES(11,'RECORD_B','confirmed')")
        operational_tasks.materialize_nazk_tasks(self.con, 'synthetic fixture')
        task = self.con.execute("""SELECT id FROM operational_tasks WHERE task_type='nazk_check'
          AND CAST(json_extract(source_context,'$.nazk_check_id') AS INTEGER)=11""").fetchone()
        self.assertIsNotNone(task)
        self.con.execute("UPDATE operational_tasks SET status='ready_for_document' WHERE id=?", (task['id'],))
        return task['id']

    def test_reconciliation_cancels_ready_task_and_preserves_confirmed_evidence(self):
        task_id = self._create_ready_nazk_task()
        self.con.execute("UPDATE registry_contracts SET status='terminated' WHERE id='RC'")
        self.assertEqual(operational_tasks._active_application_map(self.con).get(self.CODE), None)

        first = operational_tasks.reconcile_stale_nazk_tasks(
            self.con, 'synthetic successful Prozorro sync', supplier_codes=[self.CODE])
        second = operational_tasks.reconcile_stale_nazk_tasks(
            self.con, 'repeat synthetic sync', supplier_codes=[self.CODE])
        task = self.con.execute("SELECT status,resolution_code FROM operational_tasks WHERE id=?", (task_id,)).fetchone()
        check = self.con.execute("SELECT result,workflow_status FROM supplier_nazk_checks WHERE id=11").fetchone()
        matches = self.con.execute("SELECT nazk_source_id,match_status FROM supplier_nazk_check_matches WHERE check_id=11").fetchall()
        self.assertEqual(first['cancelled'], 1)
        self.assertEqual(second['cancelled'], 0)
        self.assertEqual(tuple(task), ('cancelled', 'no_active_qualifications'))
        self.assertEqual(tuple(check), ('confirmed', 'needs_review'))
        self.assertEqual([tuple(row) for row in matches], [('RECORD_B', 'confirmed')])

    def test_successful_post_sync_must_cancel_ready_nazk_task(self):
        """A complete synthetic qualification sync cancels ready NAZK work idempotently."""
        task_id = self._create_ready_nazk_task()
        self.con.execute("UPDATE registry_contracts SET status='terminated' WHERE id='RC'")
        sync = {'frameworks': 1, 'completed': 1, 'errors': []}
        first = operational_tasks.reconcile_stale_nazk_tasks_after_prozorro_sync(
            self.con, sync, 'synthetic complete Prozorro sync')
        second = operational_tasks.reconcile_stale_nazk_tasks_after_prozorro_sync(
            self.con, sync, 'synthetic repeated Prozorro sync')
        task = self.con.execute("SELECT status,resolution_code FROM operational_tasks WHERE id=?", (task_id,)).fetchone()
        check = self.con.execute("SELECT result,workflow_status FROM supplier_nazk_checks WHERE id=11").fetchone()
        matches = self.con.execute("SELECT nazk_source_id,match_status FROM supplier_nazk_check_matches WHERE check_id=11").fetchall()
        self.assertEqual(first['cancelled'], 1)
        self.assertEqual(second['cancelled'], 0)
        self.assertEqual(tuple(task), ('cancelled', 'no_active_qualifications'))
        self.assertEqual(tuple(check), ('confirmed', 'needs_review'))
        self.assertEqual([tuple(row) for row in matches], [('RECORD_B', 'confirmed')])
        self.assertEqual(self.con.execute("SELECT COUNT(*) FROM operational_tasks WHERE task_type='nazk_check' AND status='cancelled'").fetchone()[0], 1)
        operational_tasks.build(self.con, 'post-sync generic rebuild', include_nazk=False)
        self.assertEqual(self.con.execute(
            "SELECT COUNT(*) FROM operational_tasks WHERE task_type='nazk_check' AND status NOT IN ('completed','cancelled')"
        ).fetchone()[0], 0)

        # A repeated materialization with the same factual check cannot reopen
        # the terminal task, even if qualification data later reappears.
        self.assertEqual(operational_tasks.materialize_nazk_tasks(
            self.con, 'repeat synthetic materialization')['created'], 0)
        self.con.execute("UPDATE registry_contracts SET status='active' WHERE id='RC'")
        self.assertEqual(operational_tasks.materialize_nazk_tasks(
            self.con, 'same check after qualification return')['created'], 0)
        self.assertEqual(self.con.execute(
            "SELECT COUNT(*) FROM operational_tasks WHERE task_type='nazk_check' AND status NOT IN ('completed','cancelled')"
        ).fetchone()[0], 0)

    def test_partial_failed_or_incomplete_sync_never_cancels_ready_task(self):
        for result in (
                {'frameworks': 1, 'completed': 1, 'errors': [{'framework': 'F', 'error': 'timeout'}]},
                {'frameworks': 1, 'completed': 1, 'errors': [], 'status': 'failed'},
                {'frameworks': 2, 'completed': 1, 'errors': []},
                {'frameworks': 0, 'completed': 0, 'errors': []},
                {'frameworks': 1, 'completed': 1, 'errors': [], 'officer_assignments_error': 'unavailable'},
                {'frameworks': 1, 'completed': 1, 'errors': [], 'status': 'partial'}):
            with self.subTest(result=result):
                task_id = self._create_ready_nazk_task()
                self.con.execute("UPDATE registry_contracts SET status='terminated' WHERE id='RC'")
                outcome = operational_tasks.reconcile_stale_nazk_tasks_after_prozorro_sync(
                    self.con, result, 'synthetic incomplete sync')
                self.assertEqual(outcome['cancelled'], 0)
                self.assertEqual(self.con.execute("SELECT status FROM operational_tasks WHERE id=?", (task_id,)).fetchone()[0],
                                 'ready_for_document')
                self.con.execute("DELETE FROM operational_tasks WHERE id=?", (task_id,))
                self.con.execute("DELETE FROM operational_task_events WHERE task_id=?", (task_id,))
                self.con.execute("DELETE FROM supplier_nazk_checks WHERE id=11")
                self.con.execute("DELETE FROM supplier_nazk_check_matches WHERE check_id=11")
                self.con.execute("UPDATE registry_contracts SET status='active' WHERE id='RC'")

    def test_complete_sync_keeps_tasks_when_supplier_still_has_active_qualification(self):
        task_id = self._create_ready_nazk_task()
        outcome = operational_tasks.reconcile_stale_nazk_tasks_after_prozorro_sync(
            self.con, {'frameworks': 1, 'completed': 1, 'errors': []}, 'synthetic complete sync')
        self.assertEqual(outcome['cancelled'], 0)
        self.assertEqual(self.con.execute("SELECT status FROM operational_tasks WHERE id=?", (task_id,)).fetchone()[0],
                         'ready_for_document')

if __name__=='__main__': unittest.main()
